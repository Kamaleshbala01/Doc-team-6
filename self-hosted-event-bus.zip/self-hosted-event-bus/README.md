# Self-hosted event bus (no Kafka required)

Two pieces:

1. **`event-broker/`** — a standalone Spring Boot app. This *is* your message broker:
   persists every event to disk (H2 file DB, survives restarts), tracks per-consumer-group
   offsets, and pushes events to subscribers over WebSocket.
2. **`event-bus-client/`** — a library your microservices depend on. Same developer-facing
   API you'd expect from a Kafka client: `EventPublisher.publish(...)` to send, and
   `@EventSubscribe(topic, eventType)` on any method to receive. Under the hood it talks to
   the broker over a single persistent WebSocket connection — no Kafka, no ZooKeeper, no
   external infra at all.

## How it behaves like Kafka

| Concept | This system |
|---|---|
| Topic | Created automatically on first publish |
| Offset | Auto-increment id in the event log (one partition per topic — strictly ordered per topic, no cross-partition parallelism) |
| Consumer group | `groupId` on `@EventSubscribe`; broker tracks one committed offset per (topic, group) |
| Replay | A brand-new `groupId` starts from offset 0 and receives the full history |
| Resume after restart | Existing groups pick up from their last committed offset — offsets are persisted |
| At-least-once delivery | Event is only marked committed after the client ACKs it; a crashed consumer gets redelivered on reconnect |
| Load balancing within a group | Multiple instances of the same service (same `groupId`) round-robin incoming events |

**What it does *not* do (yet):** multiple partitions per topic (so no parallel consumption
within one topic), transactional/exactly-once semantics, schema registry. See "Where to
go next" below if you outgrow this.

## 1. Run the broker

```bash
cd event-broker
mvn spring-boot:run
```

Starts on `ws://localhost:8085/event-bus`. Event data persists to `./data/eventbroker.mv.db`
(H2 file database) — delete that file to reset everything. Swap the `spring.datasource.*`
properties in `application.yml` to point at Postgres/MySQL instead if you want a shared,
networked datastore rather than a local file.

## 2. Add the client to each microservice

```bash
cd event-bus-client
mvn clean install
```

```xml
<dependency>
    <groupId>com.example</groupId>
    <artifactId>event-bus-client</artifactId>
    <version>1.0.0</version>
</dependency>
```

```yaml
# application.yml in each microservice
event-bus:
  service-name: order-service
  broker-url: ws://localhost:8085/event-bus
```

## 3. Publish

```java
@Service
public class OrderService {
    private final EventPublisher eventPublisher;

    public OrderService(EventPublisher eventPublisher) {
        this.eventPublisher = eventPublisher;
    }

    public void createOrder(Order order) {
        eventPublisher.publish(
            "order-events",                                   // topic
            "OrderCreated",                                    // event type
            order.getId(),                                     // key (informational; single partition today)
            new OrderCreatedEvent(order.getId(), order.getAmount())
        );
    }
}
```

`publish(...)` returns a `CompletableFuture<Void>` that completes once the broker
acknowledges the event has been durably stored.

## 4. Subscribe

```java
@Component
public class NotificationHandler {

    @EventSubscribe(topic = "order-events", eventType = "OrderCreated")
    public void onOrderCreated(OrderCreatedEvent event) {
        // send confirmation email, etc.
    }
}
```

No explicit `groupId` → defaults to `<service-name>-<topic>`, so every microservice gets
its own independent copy of the event stream (Kafka's default fan-out behavior). Set
`groupId` explicitly on the annotation if you want several instances of the *same* service
to share the load instead of each getting every event.

## Wire protocol (for reference / debugging)

Plain JSON frames over the single WebSocket connection:

```jsonc
// client -> broker: publish
{"action":"PUBLISH","correlationId":"...","topic":"order-events","eventType":"OrderCreated","key":"order-1","source":"order-service","payload":{...}}

// broker -> client: publish acknowledged
{"type":"PUBLISH_ACK","correlationId":"...","topic":"order-events","offset":42}

// client -> broker: subscribe
{"action":"SUBSCRIBE","topic":"order-events","groupId":"notification-service-order-events"}

// broker -> client: event delivery
{"type":"EVENT","topic":"order-events","groupId":"...","offset":42,"envelope":{"eventId":"...","eventType":"OrderCreated","source":"order-service","timestamp":"...","payload":{...}}}

// client -> broker: acknowledge processed, commit offset, request next
{"action":"ACK","topic":"order-events","groupId":"...","offset":42}
```

You can test the broker directly with any WebSocket CLI, e.g. `wscat`:

```bash
npm install -g wscat
wscat -c ws://localhost:8085/event-bus
> {"action":"SUBSCRIBE","topic":"order-events","groupId":"debug"}
> {"action":"PUBLISH","correlationId":"1","topic":"order-events","eventType":"OrderCreated","payload":{"orderId":"o1","amount":9.99}}
```

## Where to go next if you outgrow this

- **Multiple partitions per topic** — biggest one; needed for real parallel throughput.
- **Persistent client-side reconnection buffering** — currently a publish made while
  disconnected fails fast; you could add a local outbox queue that flushes on reconnect.
- **Clustering the broker itself** — this is a single-node broker; there's no replication.
  If a single Spring Boot process becomes a bottleneck or SPOF, that's the point to
  reconsider Kafka/Redpanda/NATS if they become available in your environment.
