package com.example.eventbus.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.UUID;

/**
 * Standard wrapper for every event published on the bus.
 * The actual business payload is carried in {@link #payload}.
 */
public class EventEnvelope<T> {

    private final String eventId;
    private final String eventType;
    private final String source;
    private final Instant timestamp;
    private final T payload;

    @JsonCreator
    public EventEnvelope(
            @JsonProperty("eventId") String eventId,
            @JsonProperty("eventType") String eventType,
            @JsonProperty("source") String source,
            @JsonProperty("timestamp") Instant timestamp,
            @JsonProperty("payload") T payload) {
        this.eventId = eventId;
        this.eventType = eventType;
        this.source = source;
        this.timestamp = timestamp;
        this.payload = payload;
    }

    public static <T> EventEnvelope<T> of(String eventType, String source, T payload) {
        return new EventEnvelope<>(UUID.randomUUID().toString(), eventType, source, Instant.now(), payload);
    }

    public String getEventId() { return eventId; }
    public String getEventType() { return eventType; }
    public String getSource() { return source; }
    public Instant getTimestamp() { return timestamp; }
    public T getPayload() { return payload; }

    @Override
    public String toString() {
        return "EventEnvelope{eventId='%s', eventType='%s', source='%s', timestamp=%s}"
                .formatted(eventId, eventType, source, timestamp);
    }
}
