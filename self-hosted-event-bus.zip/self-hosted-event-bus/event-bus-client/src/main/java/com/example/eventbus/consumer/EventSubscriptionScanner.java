package com.example.eventbus.consumer;

import com.example.eventbus.annotation.EventSubscribe;
import com.example.eventbus.config.EventBusProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * BeanPostProcessor that inspects every singleton bean for methods annotated
 * with @EventSubscribe and registers them into the SubscriptionRegistry.
 */
public class EventSubscriptionScanner implements BeanPostProcessor {

    private static final Logger log = LoggerFactory.getLogger(EventSubscriptionScanner.class);

    private final SubscriptionRegistry registry;
    private final EventBusProperties properties;

    public EventSubscriptionScanner(SubscriptionRegistry registry, EventBusProperties properties) {
        this.registry = registry;
        this.properties = properties;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Class<?> targetClass = AopUtils.getTargetClass(bean);
        List<Method> candidates = new ArrayList<>();

        ReflectionUtils.doWithMethods(targetClass, candidates::add,
                method -> AnnotationUtils.findAnnotation(method, EventSubscribe.class) != null);

        for (Method method : candidates) {
            EventSubscribe ann = AnnotationUtils.findAnnotation(method, EventSubscribe.class);
            if (ann == null) continue;

            if (method.getParameterCount() != 1) {
                throw new IllegalStateException(
                        "@EventSubscribe method %s.%s must take exactly one parameter (the payload type)"
                                .formatted(targetClass.getSimpleName(), method.getName()));
            }

            Class<?> payloadType = method.getParameterTypes()[0];
            String groupId = ann.groupId().isBlank()
                    ? properties.getServiceName() + "-" + ann.topic()
                    : ann.groupId();

            HandlerInvoker invoker = new HandlerInvoker(bean, method, payloadType, ann.topic(), ann.eventType(), groupId);
            registry.register(invoker);
            log.info("Registered event subscriber: {}", invoker);
        }

        return bean;
    }
}
