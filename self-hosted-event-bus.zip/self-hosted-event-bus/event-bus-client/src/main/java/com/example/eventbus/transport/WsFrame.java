package com.example.eventbus.transport;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Mirrors the broker's frame shape. One flexible class for all actions/types;
 * unused fields are simply null for a given message.
 */
public class WsFrame {

    // client -> broker
    public String action;       // PUBLISH | SUBSCRIBE | ACK
    // broker -> client
    public String type;         // PUBLISH_ACK | EVENT | ERROR

    public String correlationId;
    public String topic;
    public String eventType;
    public String groupId;
    public String key;
    public String source;
    public Long offset;
    public String message;      // ERROR text
    public JsonNode payload;    // outgoing PUBLISH payload
    public EnvelopeDto envelope; // incoming EVENT envelope

    public static class EnvelopeDto {
        public String eventId;
        public String eventType;
        public String source;
        public String timestamp;
        public JsonNode payload;
    }
}
