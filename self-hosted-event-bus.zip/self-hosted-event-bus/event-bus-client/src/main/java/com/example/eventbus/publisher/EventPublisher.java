package com.example.eventbus.publisher;

import java.util.concurrent.CompletableFuture;

/**
 * Implemented by the starter; inject this into any microservice bean to publish events.
 */
public interface EventPublisher {

    /**
     * Publish an event using the payload's simple class name as the event type,
     * and the object's hashCode-derived string as key (no ordering guarantee).
     */
    <T> CompletableFuture<Void> publish(String topic, String eventType, T payload);

    /**
     * Publish with an explicit partition key (e.g. aggregate/entity id) so all
     * events for the same key land on the same partition and preserve order.
     */
    <T> CompletableFuture<Void> publish(String topic, String eventType, String key, T payload);
}
