package com.example.eventbus.transport;

import com.example.eventbus.config.EventBusProperties;
import com.example.eventbus.consumer.HandlerInvoker;
import com.example.eventbus.consumer.SubscriptionRegistry;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.SmartLifecycle;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketHttpHeaders;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.handler.ConcurrentWebSocketSessionDecorator;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class BrokerConnectionManager implements SmartLifecycle {

    private static final Logger log = LoggerFactory.getLogger(BrokerConnectionManager.class);

    private final EventBusProperties properties;
    private final SubscriptionRegistry registry;
    private final ObjectMapper objectMapper;
    private final WebSocketClient webSocketClient = new StandardWebSocketClient();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "event-bus-reconnect");
        t.setDaemon(true);
        return t;
    });

    private final Map<String, CompletableFuture<Long>> pendingPublishAcks = new ConcurrentHashMap<>();
    private final Set<String> subscribedTopicGroups = ConcurrentHashMap.newKeySet();

    private volatile WebSocketSession session;
    private volatile boolean running = false;
    private volatile boolean stopping = false;

    public BrokerConnectionManager(EventBusProperties properties, SubscriptionRegistry registry, ObjectMapper objectMapper) {
        this.properties = properties;
        this.registry = registry;
        this.objectMapper = objectMapper;
    }

    @Override
    public void start() {
        stopping = false;
        running = true;
        connect();
    }

    private void connect() {
        try {
            log.info("Connecting to event broker at [{}]", properties.getBrokerUrl());
            webSocketClient.execute(new ClientHandler(), new WebSocketHttpHeaders(), URI.create(properties.getBrokerUrl()))
                    .whenComplete((s, ex) -> {
                        if (ex != null) {
                            log.warn("Failed to connect to event broker: {}. Retrying in {}ms", ex.getMessage(), properties.getReconnectDelayMs());
                            scheduleReconnect();
                        }
                    });
        } catch (Exception e) {
            log.warn("Error initiating connection to event broker: {}", e.getMessage());
            scheduleReconnect();
        }
    }

    private void scheduleReconnect() {
        if (stopping) return;
        scheduler.schedule(this::connect, properties.getReconnectDelayMs(), TimeUnit.MILLISECONDS);
    }

    /**
     * (Re)sends SUBSCRIBE for every distinct (topic, groupId) pair discovered from
     * @EventSubscribe-annotated beans. Called on every successful connect, including
     * reconnects — SUBSCRIBE is idempotent on the broker side.
     */
    private void resubscribeAll() {
        for (String topic : registry.getTopics()) {
            Set<String> seenGroups = ConcurrentHashMap.newKeySet();
            for (HandlerInvoker handler : registry.allHandlers(topic)) {
                if (seenGroups.add(handler.getGroupId())) {
                    subscribedTopicGroups.add(topic + "\u0001" + handler.getGroupId());
                    sendSubscribe(topic, handler.getGroupId());
                }
            }
        }
    }

    private void sendSubscribe(String topic, String groupId) {
        WsFrame frame = new WsFrame();
        frame.action = "SUBSCRIBE";
        frame.topic = topic;
        frame.groupId = groupId;
        sendFrame(frame);
    }

    public CompletableFuture<Long> publish(String topic, String eventType, String key, String source, com.fasterxml.jackson.databind.JsonNode payload) {
        String correlationId = UUID.randomUUID().toString();
        CompletableFuture<Long> future = new CompletableFuture<>();
        pendingPublishAcks.put(correlationId, future);

        WsFrame frame = new WsFrame();
        frame.action = "PUBLISH";
        frame.correlationId = correlationId;
        frame.topic = topic;
        frame.eventType = eventType;
        frame.key = key;
        frame.source = source;
        frame.payload = payload;

        if (!sendFrame(frame)) {
            pendingPublishAcks.remove(correlationId);
            future.completeExceptionally(new IllegalStateException("Not connected to event broker"));
            return future;
        }

        scheduler.schedule(() -> {
            CompletableFuture<Long> f = pendingPublishAcks.remove(correlationId);
            if (f != null && !f.isDone()) {
                f.completeExceptionally(new java.util.concurrent.TimeoutException(
                        "No PUBLISH_ACK from broker within " + properties.getPublishAckTimeoutMs() + "ms"));
            }
        }, properties.getPublishAckTimeoutMs(), TimeUnit.MILLISECONDS);

        return future;
    }

    private boolean sendFrame(WsFrame frame) {
        WebSocketSession s = this.session;
        if (s == null || !s.isOpen()) {
            log.warn("Cannot send frame, no active broker connection (action={})", frame.action);
            return false;
        }
        try {
            s.sendMessage(new TextMessage(objectMapper.writeValueAsString(frame)));
            return true;
        } catch (Exception e) {
            log.error("Failed to send frame to broker", e);
            return false;
        }
    }

    private void ackEvent(String topic, String groupId, Long offset) {
        WsFrame frame = new WsFrame();
        frame.action = "ACK";
        frame.topic = topic;
        frame.groupId = groupId;
        frame.offset = offset;
        sendFrame(frame);
    }

    private void handleIncoming(WsFrame frame) {
        if (frame.type == null) return;
        switch (frame.type) {
            case "PUBLISH_ACK" -> {
                CompletableFuture<Long> f = pendingPublishAcks.remove(frame.correlationId);
                if (f != null) f.complete(frame.offset);
            }
            case "EVENT" -> handleEvent(frame);
            case "ERROR" -> {
                log.error("Broker error: {}", frame.message);
                CompletableFuture<Long> f = frame.correlationId == null ? null : pendingPublishAcks.remove(frame.correlationId);
                if (f != null) f.completeExceptionally(new RuntimeException("Broker error: " + frame.message));
            }
            default -> log.warn("Unknown frame type from broker: {}", frame.type);
        }
    }

    private void handleEvent(WsFrame frame) {
        String eventType = frame.envelope.eventType;
        List<HandlerInvoker> handlers = registry.getHandlers(frame.topic, eventType).stream()
                .filter(h -> h.getGroupId().equals(frame.groupId))
                .toList();

        for (HandlerInvoker handler : handlers) {
            try {
                Object payload = objectMapper.treeToValue(frame.envelope.payload, handler.getPayloadType());
                handler.invoke(payload);
            } catch (Exception e) {
                log.error("Handler {} threw for topic [{}] eventType [{}] offset [{}] — acking anyway to avoid blocking the group",
                        handler, frame.topic, eventType, frame.offset, e);
            }
        }
        // Ack regardless of per-handler outcome: a stuck consumer would otherwise block the
        // whole group forever since delivery is strictly in-order, one-in-flight per group.
        ackEvent(frame.topic, frame.groupId, frame.offset);
    }

    @Override
    public void stop() {
        stopping = true;
        running = false;
        WebSocketSession s = this.session;
        if (s != null) {
            try { s.close(); } catch (Exception ignored) {}
        }
        scheduler.shutdownNow();
    }

    @Override
    public boolean isRunning() {
        return running;
    }

    @Override
    public int getPhase() {
        return Integer.MAX_VALUE - 1000;
    }

    private class ClientHandler extends TextWebSocketHandler {
        @Override
        public void afterConnectionEstablished(WebSocketSession rawSession) {
            session = new ConcurrentWebSocketSessionDecorator(rawSession, 10_000, 512 * 1024);
            log.info("Connected to event broker");
            resubscribeAll();
        }

        @Override
        protected void handleTextMessage(WebSocketSession s, TextMessage message) throws Exception {
            WsFrame frame = objectMapper.readValue(message.getPayload(), WsFrame.class);
            handleIncoming(frame);
        }

        @Override
        public void afterConnectionClosed(WebSocketSession s, org.springframework.web.socket.CloseStatus status) {
            log.warn("Disconnected from event broker: {}. Reconnecting in {}ms", status, properties.getReconnectDelayMs());
            session = null;
            scheduleReconnect();
        }
    }
}
