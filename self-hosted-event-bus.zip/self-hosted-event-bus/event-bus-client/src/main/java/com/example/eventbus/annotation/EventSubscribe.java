package com.example.eventbus.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a method as a handler for a given topic + eventType.
 * The method must take exactly one parameter: the deserialized payload type.
 *
 * Example:
 * <pre>
 *   {@literal @}EventSubscribe(topic = "order-events", eventType = "OrderCreated")
 *   public void onOrderCreated(OrderCreatedEvent event) { ... }
 * </pre>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface EventSubscribe {

    String topic();

    String eventType();

    /**
     * Consumer group id override. Defaults to "${event-bus.service-name}-${topic}" if blank.
     */
    String groupId() default "";
}
