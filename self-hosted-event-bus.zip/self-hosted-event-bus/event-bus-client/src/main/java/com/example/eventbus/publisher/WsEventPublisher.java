package com.example.eventbus.publisher;

import com.example.eventbus.config.EventBusProperties;
import com.example.eventbus.transport.BrokerConnectionManager;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CompletableFuture;

public class WsEventPublisher implements EventPublisher {

    private static final Logger log = LoggerFactory.getLogger(WsEventPublisher.class);

    private final BrokerConnectionManager connectionManager;
    private final ObjectMapper objectMapper;
    private final EventBusProperties properties;

    public WsEventPublisher(BrokerConnectionManager connectionManager, ObjectMapper objectMapper, EventBusProperties properties) {
        this.connectionManager = connectionManager;
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    @Override
    public <T> CompletableFuture<Void> publish(String topic, String eventType, T payload) {
        return publish(topic, eventType, null, payload);
    }

    @Override
    public <T> CompletableFuture<Void> publish(String topic, String eventType, String key, T payload) {
        JsonNode node = objectMapper.valueToTree(payload);
        return connectionManager.publish(topic, eventType, key, properties.getServiceName(), node)
                .thenAccept(offset -> log.debug("Published event [{}] to topic [{}] at offset [{}]", eventType, topic, offset))
                .toCompletableFuture();
    }
}
