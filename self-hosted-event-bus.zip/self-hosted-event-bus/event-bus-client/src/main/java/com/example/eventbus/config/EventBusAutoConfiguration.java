package com.example.eventbus.config;

import com.example.eventbus.consumer.EventSubscriptionScanner;
import com.example.eventbus.consumer.SubscriptionRegistry;
import com.example.eventbus.publisher.EventPublisher;
import com.example.eventbus.publisher.WsEventPublisher;
import com.example.eventbus.transport.BrokerConnectionManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties(EventBusProperties.class)
public class EventBusAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public ObjectMapper eventBusObjectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        return mapper;
    }

    @Bean
    public SubscriptionRegistry subscriptionRegistry() {
        return new SubscriptionRegistry();
    }

    @Bean
    public EventSubscriptionScanner eventSubscriptionScanner(SubscriptionRegistry registry, EventBusProperties properties) {
        return new EventSubscriptionScanner(registry, properties);
    }

    @Bean
    public BrokerConnectionManager brokerConnectionManager(EventBusProperties properties,
                                                             SubscriptionRegistry registry,
                                                             ObjectMapper eventBusObjectMapper) {
        return new BrokerConnectionManager(properties, registry, eventBusObjectMapper);
    }

    @Bean
    @ConditionalOnMissingBean
    public EventPublisher eventPublisher(BrokerConnectionManager connectionManager,
                                          ObjectMapper eventBusObjectMapper,
                                          EventBusProperties properties) {
        return new WsEventPublisher(connectionManager, eventBusObjectMapper, properties);
    }
}
