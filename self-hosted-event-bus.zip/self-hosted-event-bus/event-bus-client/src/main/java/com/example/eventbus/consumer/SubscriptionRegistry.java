package com.example.eventbus.consumer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class SubscriptionRegistry {

    // topic -> eventType -> handlers
    private final Map<String, Map<String, List<HandlerInvoker>>> byTopicAndType = new ConcurrentHashMap<>();

    public void register(HandlerInvoker invoker) {
        byTopicAndType
                .computeIfAbsent(invoker.getTopic(), t -> new ConcurrentHashMap<>())
                .computeIfAbsent(invoker.getEventType(), et -> new CopyOnWriteArrayList<>())
                .add(invoker);
    }

    public Set<String> getTopics() {
        return byTopicAndType.keySet();
    }

    public List<HandlerInvoker> getHandlers(String topic, String eventType) {
        return byTopicAndType.getOrDefault(topic, Map.of()).getOrDefault(eventType, List.of());
    }

    /** Every handler registered for a topic, across all event types — used to resolve which groupIds to subscribe. */
    public List<HandlerInvoker> allHandlers(String topic) {
        List<HandlerInvoker> all = new ArrayList<>();
        byTopicAndType.getOrDefault(topic, Map.of()).values().forEach(all::addAll);
        return all;
    }
}
