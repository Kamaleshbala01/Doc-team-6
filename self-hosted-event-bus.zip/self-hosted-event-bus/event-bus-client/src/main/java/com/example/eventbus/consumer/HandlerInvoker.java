package com.example.eventbus.consumer;

import java.lang.reflect.Method;

/**
 * Wraps a bean + method annotated with @EventSubscribe so it can be invoked reflectively
 * once an incoming record's eventType is matched.
 */
public class HandlerInvoker {

    private final Object bean;
    private final Method method;
    private final Class<?> payloadType;
    private final String topic;
    private final String eventType;
    private final String groupId;

    public HandlerInvoker(Object bean, Method method, Class<?> payloadType,
                           String topic, String eventType, String groupId) {
        this.bean = bean;
        this.method = method;
        this.payloadType = payloadType;
        this.topic = topic;
        this.eventType = eventType;
        this.groupId = groupId;
        this.method.setAccessible(true);
    }

    public void invoke(Object payload) throws Exception {
        method.invoke(bean, payload);
    }

    public Class<?> getPayloadType() { return payloadType; }
    public String getTopic() { return topic; }
    public String getEventType() { return eventType; }
    public String getGroupId() { return groupId; }

    @Override
    public String toString() {
        return "HandlerInvoker{%s#%s topic='%s' eventType='%s' groupId='%s'}"
                .formatted(bean.getClass().getSimpleName(), method.getName(), topic, eventType, groupId);
    }
}
