package com.example.eventbus.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "event-bus")
public class EventBusProperties {

    /** Logical name of this microservice, stamped on published events. */
    private String serviceName = "unknown-service";

    /** WebSocket URL of the event-broker, e.g. ws://localhost:8085/event-bus */
    private String brokerUrl = "ws://localhost:8085/event-bus";

    /** Milliseconds to wait for a PUBLISH_ACK before failing the publish future. */
    private long publishAckTimeoutMs = 5000L;

    /** Delay before attempting to reconnect after the broker connection drops. */
    private long reconnectDelayMs = 3000L;

    public String getServiceName() { return serviceName; }
    public void setServiceName(String serviceName) { this.serviceName = serviceName; }

    public String getBrokerUrl() { return brokerUrl; }
    public void setBrokerUrl(String brokerUrl) { this.brokerUrl = brokerUrl; }

    public long getPublishAckTimeoutMs() { return publishAckTimeoutMs; }
    public void setPublishAckTimeoutMs(long publishAckTimeoutMs) { this.publishAckTimeoutMs = publishAckTimeoutMs; }

    public long getReconnectDelayMs() { return reconnectDelayMs; }
    public void setReconnectDelayMs(long reconnectDelayMs) { this.reconnectDelayMs = reconnectDelayMs; }
}
