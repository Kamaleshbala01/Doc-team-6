package com.example.eventbroker.dto;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Single flexible frame type covering all broker->client messages:
 * PUBLISH_ACK, EVENT, ERROR.
 */
public class OutboundFrame {

    private String type; // PUBLISH_ACK | EVENT | ERROR
    private String correlationId;
    private String topic;
    private String groupId;
    private Long offset;
    private String message; // for ERROR
    private EnvelopeDto envelope; // for EVENT

    public static OutboundFrame publishAck(String correlationId, String topic, Long offset) {
        OutboundFrame f = new OutboundFrame();
        f.type = "PUBLISH_ACK";
        f.correlationId = correlationId;
        f.topic = topic;
        f.offset = offset;
        return f;
    }

    public static OutboundFrame event(String topic, String groupId, Long offset, EnvelopeDto envelope) {
        OutboundFrame f = new OutboundFrame();
        f.type = "EVENT";
        f.topic = topic;
        f.groupId = groupId;
        f.offset = offset;
        f.envelope = envelope;
        return f;
    }

    public static OutboundFrame error(String correlationId, String message) {
        OutboundFrame f = new OutboundFrame();
        f.type = "ERROR";
        f.correlationId = correlationId;
        f.message = message;
        return f;
    }

    public String getType() { return type; }
    public String getCorrelationId() { return correlationId; }
    public String getTopic() { return topic; }
    public String getGroupId() { return groupId; }
    public Long getOffset() { return offset; }
    public String getMessage() { return message; }
    public EnvelopeDto getEnvelope() { return envelope; }

    public static class EnvelopeDto {
        public String eventId;
        public String eventType;
        public String source;
        public String timestamp;
        public JsonNode payload;

        public EnvelopeDto() {}

        public EnvelopeDto(String eventId, String eventType, String source, String timestamp, JsonNode payload) {
            this.eventId = eventId;
            this.eventType = eventType;
            this.source = source;
            this.timestamp = timestamp;
            this.payload = payload;
        }
    }
}
