package com.example.eventbroker.service;

import com.example.eventbroker.model.EventRecord;
import com.example.eventbroker.repository.EventRecordRepository;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

@Service
public class BrokerService {

    private final EventRecordRepository eventRecordRepository;
    private final SubscriptionManager subscriptionManager;

    public BrokerService(EventRecordRepository eventRecordRepository, SubscriptionManager subscriptionManager) {
        this.eventRecordRepository = eventRecordRepository;
        this.subscriptionManager = subscriptionManager;
    }

    public Long publish(String topic, String eventType, String key, String source, JsonNode payload) {
        EventRecord record = new EventRecord(
                topic, eventType, UUID.randomUUID().toString(), source, key,
                payload.toString(), Instant.now());
        record = eventRecordRepository.save(record);
        subscriptionManager.onNewEvent(topic);
        return record.getId();
    }
}
