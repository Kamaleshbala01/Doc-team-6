package com.example.eventbroker.model;

import jakarta.persistence.*;
import java.time.Instant;

/**
 * One row per published event. The auto-increment id doubles as the topic's
 * offset (single-partition-per-topic model — simple, strictly ordered per topic).
 */
@Entity
@Table(name = "event_log", indexes = {
        @Index(name = "idx_event_log_topic", columnList = "topic")
})
public class EventRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // doubles as the offset

    @Column(nullable = false)
    private String topic;

    @Column(nullable = false)
    private String eventType;

    @Column(nullable = false)
    private String eventId;

    private String source;

    private String partitionKey;

    @Lob
    @Column(nullable = false)
    private String payload; // JSON

    @Column(nullable = false)
    private Instant createdAt;

    protected EventRecord() {}

    public EventRecord(String topic, String eventType, String eventId, String source,
                        String partitionKey, String payload, Instant createdAt) {
        this.topic = topic;
        this.eventType = eventType;
        this.eventId = eventId;
        this.source = source;
        this.partitionKey = partitionKey;
        this.payload = payload;
        this.createdAt = createdAt;
    }

    public Long getId() { return id; }
    public String getTopic() { return topic; }
    public String getEventType() { return eventType; }
    public String getEventId() { return eventId; }
    public String getSource() { return source; }
    public String getPartitionKey() { return partitionKey; }
    public String getPayload() { return payload; }
    public Instant getCreatedAt() { return createdAt; }
}
