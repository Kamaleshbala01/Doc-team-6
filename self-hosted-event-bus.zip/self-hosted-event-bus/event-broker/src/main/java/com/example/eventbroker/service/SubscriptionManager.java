package com.example.eventbroker.service;

import com.example.eventbroker.dto.OutboundFrame;
import com.example.eventbroker.model.ConsumerOffset;
import com.example.eventbroker.model.EventRecord;
import com.example.eventbroker.repository.ConsumerOffsetRepository;
import com.example.eventbroker.repository.EventRecordRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.ConcurrentWebSocketSessionDecorator;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Kafka-like consumer-group delivery: for each (topic, groupId) at most one event is
 * "in flight" at a time. When a subscriber ACKs, the offset is committed and the next
 * event (if any) is pushed. Multiple sessions in the same group round-robin the load.
 */
@Component
public class SubscriptionManager {

    private static final Logger log = LoggerFactory.getLogger(SubscriptionManager.class);

    private final EventRecordRepository eventRecordRepository;
    private final ConsumerOffsetRepository consumerOffsetRepository;
    private final ObjectMapper objectMapper;

    // topic -> groupId -> group state
    private final Map2<GroupState> groups = new Map2<>();
    // sessionId -> set of (topic, groupId) it belongs to, for cleanup on disconnect
    private final ConcurrentHashMap<String, Set<String>> sessionMemberships = new ConcurrentHashMap<>();

    public SubscriptionManager(EventRecordRepository eventRecordRepository,
                                ConsumerOffsetRepository consumerOffsetRepository,
                                ObjectMapper objectMapper) {
        this.eventRecordRepository = eventRecordRepository;
        this.consumerOffsetRepository = consumerOffsetRepository;
        this.objectMapper = objectMapper;
    }

    public synchronized void subscribe(WebSocketSession rawSession, String topic, String groupId) {
        WebSocketSession session = new ConcurrentWebSocketSessionDecorator(rawSession, 10_000, 512 * 1024);
        GroupState state = groups.computeIfAbsent(topic, groupId, () -> new GroupState(topic, groupId));
        state.sessions.add(session);
        sessionMemberships.computeIfAbsent(rawSession.getId(), k -> ConcurrentHashMap.newKeySet()).add(key(topic, groupId));
        log.info("Session [{}] subscribed to topic [{}] group [{}]", rawSession.getId(), topic, groupId);
        deliverNext(state);
    }

    public synchronized void onDisconnect(WebSocketSession rawSession) {
        Set<String> memberships = sessionMemberships.remove(rawSession.getId());
        if (memberships == null) return;
        for (String k : memberships) {
            String[] parts = k.split("\u0001", 2);
            GroupState state = groups.get(parts[0], parts[1]);
            if (state != null) {
                state.sessions.removeIf(s -> s.getId().equals(rawSession.getId()));
            }
        }
    }

    /** Called after a new event is persisted; tries to push it to every group subscribed to the topic. */
    public synchronized void onNewEvent(String topic) {
        groups.forEachInTopic(topic, this::deliverNext);
    }

    public synchronized void ack(String topic, String groupId, Long offset) {
        GroupState state = groups.get(topic, groupId);
        if (state == null) return;
        if (!offset.equals(state.inFlightOffset)) {
            log.warn("Ack offset [{}] does not match in-flight offset [{}] for group [{}]/[{}], ignoring",
                    offset, state.inFlightOffset, topic, groupId);
            return;
        }
        ConsumerOffset committed = consumerOffsetRepository.findByTopicAndGroupId(topic, groupId)
                .orElseGet(() -> new ConsumerOffset(topic, groupId));
        committed.setCommittedOffset(offset);
        consumerOffsetRepository.save(committed);
        state.inFlightOffset = null;
        deliverNext(state);
    }

    private void deliverNext(GroupState state) {
        if (state.inFlightOffset != null) return; // waiting for an ack already
        if (state.sessions.isEmpty()) return; // nobody connected right now

        long committed = consumerOffsetRepository.findByTopicAndGroupId(state.topic, state.groupId)
                .map(ConsumerOffset::getCommittedOffset).orElse(0L);

        Optional<EventRecord> next = eventRecordRepository
                .findFirstByTopicAndIdGreaterThanOrderByIdAsc(state.topic, committed);
        if (next.isEmpty()) return;

        EventRecord record = next.get();
        WebSocketSession session = pickSession(state);
        if (session == null || !session.isOpen()) return;

        try {
            var payloadNode = objectMapper.readTree(record.getPayload());
            var envelopeDto = new OutboundFrame.EnvelopeDto(
                    record.getEventId(), record.getEventType(), record.getSource(),
                    record.getCreatedAt().toString(), payloadNode);
            OutboundFrame frame = OutboundFrame.event(state.topic, state.groupId, record.getId(), envelopeDto);
            session.sendMessage(new TextMessage(objectMapper.writeValueAsString(frame)));
            state.inFlightOffset = record.getId();
        } catch (Exception e) {
            log.error("Failed to deliver offset [{}] to group [{}]/[{}]", record.getId(), state.topic, state.groupId, e);
        }
    }

    private WebSocketSession pickSession(GroupState state) {
        List<WebSocketSession> open = state.sessions.stream().filter(WebSocketSession::isOpen).toList();
        if (open.isEmpty()) return null;
        int idx = Math.floorMod(state.roundRobin.getAndIncrement(), open.size());
        return open.get(idx);
    }

    private String key(String topic, String groupId) {
        return topic + "\u0001" + groupId;
    }

    private static class GroupState {
        final String topic;
        final String groupId;
        final List<WebSocketSession> sessions = new CopyOnWriteArrayList<>();
        final AtomicInteger roundRobin = new AtomicInteger(0);
        volatile Long inFlightOffset = null;

        GroupState(String topic, String groupId) {
            this.topic = topic;
            this.groupId = groupId;
        }
    }

    /** Tiny helper: topic -> groupId -> GroupState, with a topic-scoped iteration helper. */
    private static class Map2<V> {
        private final ConcurrentHashMap<String, ConcurrentHashMap<String, V>> data = new ConcurrentHashMap<>();

        V computeIfAbsent(String topic, String groupId, java.util.function.Supplier<V> supplier) {
            return data.computeIfAbsent(topic, t -> new ConcurrentHashMap<>())
                    .computeIfAbsent(groupId, g -> supplier.get());
        }

        V get(String topic, String groupId) {
            var inner = data.get(topic);
            return inner == null ? null : inner.get(groupId);
        }

        void forEachInTopic(String topic, java.util.function.Consumer<V> consumer) {
            var inner = data.get(topic);
            if (inner == null) return;
            inner.values().forEach(consumer);
        }
    }
}
