package com.example.eventbroker.ws;

import com.example.eventbroker.dto.InboundFrame;
import com.example.eventbroker.dto.OutboundFrame;
import com.example.eventbroker.service.BrokerService;
import com.example.eventbroker.service.SubscriptionManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

@Component
public class BrokerWebSocketHandler extends TextWebSocketHandler {

    private static final Logger log = LoggerFactory.getLogger(BrokerWebSocketHandler.class);

    private final BrokerService brokerService;
    private final SubscriptionManager subscriptionManager;
    private final ObjectMapper objectMapper;

    public BrokerWebSocketHandler(BrokerService brokerService, SubscriptionManager subscriptionManager, ObjectMapper objectMapper) {
        this.brokerService = brokerService;
        this.subscriptionManager = subscriptionManager;
        this.objectMapper = objectMapper;
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        InboundFrame frame;
        try {
            frame = objectMapper.readValue(message.getPayload(), InboundFrame.class);
        } catch (Exception e) {
            send(session, OutboundFrame.error(null, "Malformed frame: " + e.getMessage()));
            return;
        }

        if (frame.getAction() == null) {
            send(session, OutboundFrame.error(frame.getCorrelationId(), "Missing 'action'"));
            return;
        }

        switch (frame.getAction()) {
            case "PUBLISH" -> handlePublish(session, frame);
            case "SUBSCRIBE" -> handleSubscribe(session, frame);
            case "ACK" -> handleAck(frame);
            default -> send(session, OutboundFrame.error(frame.getCorrelationId(), "Unknown action: " + frame.getAction()));
        }
    }

    private void handlePublish(WebSocketSession session, InboundFrame frame) throws Exception {
        if (frame.getTopic() == null || frame.getEventType() == null || frame.getPayload() == null) {
            send(session, OutboundFrame.error(frame.getCorrelationId(), "PUBLISH requires topic, eventType, payload"));
            return;
        }
        Long offset = brokerService.publish(frame.getTopic(), frame.getEventType(), frame.getKey(), frame.getSource(), frame.getPayload());
        send(session, OutboundFrame.publishAck(frame.getCorrelationId(), frame.getTopic(), offset));
    }

    private void handleSubscribe(WebSocketSession session, InboundFrame frame) throws Exception {
        if (frame.getTopic() == null || frame.getGroupId() == null) {
            send(session, OutboundFrame.error(frame.getCorrelationId(), "SUBSCRIBE requires topic and groupId"));
            return;
        }
        subscriptionManager.subscribe(session, frame.getTopic(), frame.getGroupId());
    }

    private void handleAck(InboundFrame frame) {
        if (frame.getTopic() == null || frame.getGroupId() == null || frame.getOffset() == null) {
            log.warn("Ignoring malformed ACK frame: {}", frame);
            return;
        }
        subscriptionManager.ack(frame.getTopic(), frame.getGroupId(), frame.getOffset());
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        subscriptionManager.onDisconnect(session);
        log.info("Session [{}] disconnected: {}", session.getId(), status);
    }

    private void send(WebSocketSession session, OutboundFrame frame) throws Exception {
        session.sendMessage(new TextMessage(objectMapper.writeValueAsString(frame)));
    }
}
