package com.example.eventbroker.dto;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Single flexible frame type covering all client->broker actions:
 * PUBLISH, SUBSCRIBE, ACK. Unused fields are simply null for a given action.
 */
public class InboundFrame {

    private String action;       // PUBLISH | SUBSCRIBE | ACK
    private String correlationId;
    private String topic;
    private String eventType;
    private String groupId;
    private String key;
    private String source;
    private Long offset;
    private JsonNode payload;

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getCorrelationId() { return correlationId; }
    public void setCorrelationId(String correlationId) { this.correlationId = correlationId; }

    public String getTopic() { return topic; }
    public void setTopic(String topic) { this.topic = topic; }

    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }

    public String getGroupId() { return groupId; }
    public void setGroupId(String groupId) { this.groupId = groupId; }

    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }

    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }

    public Long getOffset() { return offset; }
    public void setOffset(Long offset) { this.offset = offset; }

    public JsonNode getPayload() { return payload; }
    public void setPayload(JsonNode payload) { this.payload = payload; }
}
