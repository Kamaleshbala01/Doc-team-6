package com.example.eventbroker.repository;

import com.example.eventbroker.model.EventRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EventRecordRepository extends JpaRepository<EventRecord, Long> {

    Optional<EventRecord> findFirstByTopicAndIdGreaterThanOrderByIdAsc(String topic, Long id);
}
