package com.example.eventbroker.repository;

import com.example.eventbroker.model.ConsumerOffset;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ConsumerOffsetRepository extends JpaRepository<ConsumerOffset, Long> {

    Optional<ConsumerOffset> findByTopicAndGroupId(String topic, String groupId);
}
