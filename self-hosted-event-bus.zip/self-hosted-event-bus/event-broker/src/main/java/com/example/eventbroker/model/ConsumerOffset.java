package com.example.eventbroker.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "consumer_offset", uniqueConstraints = {
        @UniqueConstraint(name = "uk_topic_group", columnNames = {"topic", "groupId"})
})
public class ConsumerOffset {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String topic;

    @Column(nullable = false)
    private String groupId;

    /** Highest offset this group has fully processed (acked). 0 = nothing consumed yet. */
    @Column(nullable = false)
    private Long committedOffset = 0L;

    @Column(nullable = false)
    private Instant updatedAt;

    protected ConsumerOffset() {}

    public ConsumerOffset(String topic, String groupId) {
        this.topic = topic;
        this.groupId = groupId;
        this.committedOffset = 0L;
        this.updatedAt = Instant.now();
    }

    public Long getId() { return id; }
    public String getTopic() { return topic; }
    public String getGroupId() { return groupId; }
    public Long getCommittedOffset() { return committedOffset; }

    public void setCommittedOffset(Long committedOffset) {
        this.committedOffset = committedOffset;
        this.updatedAt = Instant.now();
    }
}
