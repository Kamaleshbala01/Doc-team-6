package com.esports.project.Service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.SendInvitationRequest;
import com.esports.project.DTO.TeamInvitationDTO;
import com.esports.project.DTO.UpdateInvitationStatusRequest;
import com.esports.project.Repository.TeamInvitationRepository;
import com.esports.project.Repository.TeamMemberRepository;
import com.esports.project.Repository.TeamRepository;
import com.esports.project.entity.Team;
import com.esports.project.entity.TeamInvitation;
import com.esports.project.enums.InvitationStatus;
import com.esports.project.service.TeamInvitationService;

@ExtendWith(MockitoExtension.class)
class TeamInvitationServiceTest {

    @Mock
    private TeamRepository teamRepository;

    @Mock
    private TeamInvitationRepository teamInvitationRepository;

    @Mock
    private TeamMemberRepository teamMemberRepository;

    @InjectMocks
    private TeamInvitationService teamInvitationService;

    @Test
    void sendInvitationSuccess() {

        Team team = new Team();

        team.setId("TEAM001");
        team.setTeamName("Dragon Warriors");

        SendInvitationRequest request =
                new SendInvitationRequest();

        request.setReceiverId("USER002");
        request.setReceiverName("Kumar");

        TeamInvitation invitation =
                new TeamInvitation();

        invitation.setId("INV001");
        invitation.setTeamId("TEAM001");
        invitation.setReceiverId("USER002");
        invitation.setStatus(
                InvitationStatus.PENDING);

        when(teamRepository.findById("TEAM001"))
                .thenReturn(Optional.of(team));

        when(teamInvitationRepository
                .existsByTeamIdAndReceiverIdAndStatus(
                        any(),
                        any(),
                        any()))
                .thenReturn(false);

        when(teamInvitationRepository.save(any()))
                .thenReturn(invitation);

        TeamInvitationDTO response =
                teamInvitationService
                        .sendInvitation(
                                "TEAM001",
                                request);

        assertEquals(
                "INV001",
                response.getInvitationId());
    }

    @Test
    void updateInvitationStatusSuccess() {

        TeamInvitation invitation =
                new TeamInvitation();

        invitation.setId("INV001");
        invitation.setTeamId("TEAM001");
        invitation.setReceiverId("USER002");
        invitation.setStatus(
                InvitationStatus.PENDING);

        UpdateInvitationStatusRequest request =
                new UpdateInvitationStatusRequest();

        request.setStatus(
                InvitationStatus.REJECTED);

        when(teamInvitationRepository.findById("INV001"))
                .thenReturn(Optional.of(invitation));

        when(teamInvitationRepository.save(any()))
                .thenReturn(invitation);

        TeamInvitationDTO response =
                teamInvitationService
                        .updateInvitationStatus(
                                "INV001",
                                request);

        assertNotNull(response);
    }

    @Test
    void deleteInvitationSuccess() {

        TeamInvitation invitation =
                new TeamInvitation();

        invitation.setId("INV001");

        when(teamInvitationRepository.findById("INV001"))
                .thenReturn(Optional.of(invitation));

        teamInvitationService.deleteInvitation(
                "INV001");

        verify(teamInvitationRepository)
                .delete(invitation);
    }
}