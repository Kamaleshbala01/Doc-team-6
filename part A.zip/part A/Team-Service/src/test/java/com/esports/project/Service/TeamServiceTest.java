package com.esports.project.Service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.CreateTeamRequest;
import com.esports.project.DTO.TeamDTO;
import com.esports.project.DTO.UpdateTeamRequest;
import com.esports.project.Repository.TeamRepository;
import com.esports.project.entity.Team;
import com.esports.project.service.TeamService;

@ExtendWith(MockitoExtension.class)
class TeamServiceTest {

    @Mock
    private TeamRepository teamRepository;

    @InjectMocks
    private TeamService teamService;

    @Test
    void createTeamSuccess() {

        CreateTeamRequest request =
                new CreateTeamRequest();

        request.setTeamName("Dragon Warriors");
        request.setGameTitle("BGMI");
        request.setRegion("India");
        request.setLeaderId("USER001");
        request.setLeaderName("Rakesh");
        request.setFoundedDate(LocalDateTime.now());

        Team team = new Team();
        team.setId("TEAM001");
        team.setTeamName("Dragon Warriors");

        when(teamRepository.save(any(Team.class)))
                .thenReturn(team);

        TeamDTO response =
                teamService.createTeam(request);

        assertNotNull(response);
        assertEquals("TEAM001",
                response.getTeamId());

        verify(teamRepository)
                .save(any(Team.class));
    }

    @Test
    void getTeamByIdSuccess() {

        Team team = new Team();

        team.setId("TEAM001");
        team.setTeamName("Dragon Warriors");

        when(teamRepository.findById("TEAM001"))
                .thenReturn(Optional.of(team));

        TeamDTO dto =
                teamService.getTeamById("TEAM001");

        assertEquals(
                "TEAM001",
                dto.getTeamId());
    }

    @Test
    void updateTeamSuccess() {

        Team team = new Team();

        team.setId("TEAM001");
        team.setTeamName("Old Team");

        UpdateTeamRequest request =
                new UpdateTeamRequest();

        request.setTeamName("New Team");
        request.setGameTitle("BGMI");
        request.setRegion("India");

        when(teamRepository.findById("TEAM001"))
                .thenReturn(Optional.of(team));

        when(teamRepository.save(any()))
                .thenReturn(team);

        TeamDTO response =
                teamService.updateTeam(
                        "TEAM001",
                        request);

        assertNotNull(response);

        verify(teamRepository)
                .save(any(Team.class));
    }

    @Test
    void deleteTeamSuccess() {

        Team team = new Team();

        team.setId("TEAM001");

        when(teamRepository.findById("TEAM001"))
                .thenReturn(Optional.of(team));

        teamService.deleteTeam("TEAM001");

        verify(teamRepository)
                .delete(team);
    }
}