// package com.esports.project.controller;

// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;

// import java.util.Collections;

// import com.esports.project.DTO.CreateTeamRequest;
// import com.esports.project.DTO.TeamDTO;
// import com.esports.project.DTO.UpdateTeamRequest;
// import com.esports.project.service.TeamService;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;

// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.PageImpl;

// @ExtendWith(MockitoExtension.class)
// class TeamControllerTest {

//     @Mock
//     private TeamService teamService;

//     @InjectMocks
//     private TeamController teamController;

//     private TeamDTO teamDTO;

//     @BeforeEach
//     void setup() {

//         teamDTO = new TeamDTO();
//         teamDTO.setTeamId("TEAM001");
//         teamDTO.setTeamName("RCB");
//     }

//     @Test
//     void createTeamTest() {

//         CreateTeamRequest request =
//                 new CreateTeamRequest();

//         request.setTeamName("RCB");

//         when(teamService.createTeam(request))
//                 .thenReturn(teamDTO);

//         TeamDTO result =
//                 teamController.createTeam(request);

//         assertNotNull(result);
//         assertEquals(
//                 "RCB",
//                 result.getTeamName());
//     }

//     @Test
//     void createTeamVerifyServiceCall() {

//         CreateTeamRequest request =
//                 new CreateTeamRequest();

//         request.setTeamName("RCB");

//         when(teamService.createTeam(request))
//                 .thenReturn(teamDTO);

//         teamController.createTeam(request);

//         verify(teamService, times(1))
//                 .createTeam(request);
//     }

//     @Test
//     void getTeamByIdTest() {

//         when(teamService.getTeamById("TEAM001"))
//                 .thenReturn(teamDTO);

//         TeamDTO result =
//                 teamController.getTeamById("TEAM001");

//         assertEquals(
//                 "TEAM001",
//                 result.getTeamId());
//     }

//     @Test
//     void getTeamByIdVerifyServiceCall() {

//         when(teamService.getTeamById("TEAM001"))
//                 .thenReturn(teamDTO);

//         teamController.getTeamById("TEAM001");

//         verify(teamService, times(1))
//                 .getTeamById("TEAM001");
//     }

//     @Test
//     void getAllTeamsTest() {

//         Page<TeamDTO> page =
//                 new PageImpl<>(
//                         Collections.singletonList(teamDTO));

//         when(teamService.getAllTeams(0, 10))
//                 .thenReturn(page);

//         Page<TeamDTO> result =
//                 teamController.getAllTeams(0, 10);

//         assertEquals(
//                 1,
//                 result.getTotalElements());
//     }

//     @Test
//     void getAllTeamsEmptyResult() {

//         Page<TeamDTO> page =
//                 new PageImpl<>(
//                         Collections.emptyList());

//         when(teamService.getAllTeams(0, 10))
//                 .thenReturn(page);

//         Page<TeamDTO> result =
//                 teamController.getAllTeams(0, 10);

//         assertEquals(
//                 0,
//                 result.getTotalElements());
//     }

//     @Test
//     void getAllTeamsVerifyServiceCall() {

//         Page<TeamDTO> page =
//                 new PageImpl<>(
//                         Collections.singletonList(teamDTO));

//         when(teamService.getAllTeams(0, 10))
//                 .thenReturn(page);

//         teamController.getAllTeams(0, 10);

//         verify(teamService, times(1))
//                 .getAllTeams(0, 10);
//     }

//     @Test
//     void searchTeamsTest() {

//         Page<TeamDTO> page =
//                 new PageImpl<>(
//                         Collections.singletonList(teamDTO));

//         when(teamService.searchTeams(
//                 "RCB",
//                 0,
//                 10))
//                 .thenReturn(page);

//         Page<TeamDTO> result =
//                 teamController.searchTeams(
//                         "RCB",
//                         0,
//                         10);

//         assertEquals(
//                 1,
//                 result.getTotalElements());
//     }

//     @Test
//     void searchTeamsEmptyResult() {

//         Page<TeamDTO> page =
//                 new PageImpl<>(
//                         Collections.emptyList());

//         when(teamService.searchTeams(
//                 "XYZ",
//                 0,
//                 10))
//                 .thenReturn(page);

//         Page<TeamDTO> result =
//                 teamController.searchTeams(
//                         "XYZ",
//                         0,
//                         10);

//         assertEquals(
//                 0,
//                 result.getTotalElements());
//     }

//     @Test
//     void searchTeamsVerifyServiceCall() {

//         Page<TeamDTO> page =
//                 new PageImpl<>(
//                         Collections.singletonList(teamDTO));

//         when(teamService.searchTeams(
//                 "RCB",
//                 0,
//                 10))
//                 .thenReturn(page);

//         teamController.searchTeams(
//                 "RCB",
//                 0,
//                 10);

//         verify(teamService, times(1))
//                 .searchTeams(
//                         "RCB",
//                         0,
//                         10);
//     }

//     @Test
//     void getTeamsByTournamentIdTest() {

//         Page<TeamDTO> page =
//                 new PageImpl<>(
//                         Collections.singletonList(teamDTO));

//         when(teamService.getTeamsByTournamentId(
//                 "T1",
//                 0,
//                 10))
//                 .thenReturn(page);

//         Page<TeamDTO> result =
//                 teamController.getTeamsByTournamentId(
//                         "T1",
//                         0,
//                         10);

//         assertEquals(
//                 1,
//                 result.getTotalElements());
//     }

//     @Test
//     void getTeamsByTournamentIdEmptyResult() {

//         Page<TeamDTO> page =
//                 new PageImpl<>(
//                         Collections.emptyList());

//         when(teamService.getTeamsByTournamentId(
//                 "INVALID",
//                 0,
//                 10))
//                 .thenReturn(page);

//         Page<TeamDTO> result =
//                 teamController.getTeamsByTournamentId(
//                         "INVALID",
//                         0,
//                         10);

//         assertEquals(
//                 0,
//                 result.getTotalElements());
//     }

//     @Test
//     void getTeamsByTournamentIdVerifyServiceCall() {

//         Page<TeamDTO> page =
//                 new PageImpl<>(
//                         Collections.singletonList(teamDTO));

//         when(teamService.getTeamsByTournamentId(
//                 "T1",
//                 0,
//                 10))
//                 .thenReturn(page);

//         teamController.getTeamsByTournamentId(
//                 "T1",
//                 0,
//                 10);

//         verify(teamService, times(1))
//                 .getTeamsByTournamentId(
//                         "T1",
//                         0,
//                         10);
//     }

//     @Test
//     void updateTeamTest() {

//         UpdateTeamRequest request =
//                 new UpdateTeamRequest();

//         request.setTeamName("CSK");

//         TeamDTO updated =
//                 new TeamDTO();

//         updated.setTeamId("TEAM001");
//         updated.setTeamName("CSK");

//         when(teamService.updateTeam(
//                 "TEAM001",
//                 request))
//                 .thenReturn(updated);

//         TeamDTO result =
//                 teamController.updateTeam(
//                         "TEAM001",
//                         request);

//         assertEquals(
//                 "CSK",
//                 result.getTeamName());
//     }

//     @Test
//     void updateTeamVerifyServiceCall() {

//         UpdateTeamRequest request =
//                 new UpdateTeamRequest();

//         request.setTeamName("CSK");

//         TeamDTO updated =
//                 new TeamDTO();

//         updated.setTeamName("CSK");

//         when(teamService.updateTeam(
//                 "TEAM001",
//                 request))
//                 .thenReturn(updated);

//         teamController.updateTeam(
//                 "TEAM001",
//                 request);

//         verify(teamService, times(1))
//                 .updateTeam(
//                         "TEAM001",
//                         request);
//     }

//     @Test
//     void deleteTeamTest() {

//         doNothing()
//                 .when(teamService)
//                 .deleteTeam("TEAM001");

//         String result =
//                 teamController.deleteTeam("TEAM001");

//         assertEquals(
//                 "Team deleted successfully",
//                 result);
//     }

//     @Test
//     void deleteTeamVerifyServiceCall() {

//         doNothing()
//                 .when(teamService)
//                 .deleteTeam("TEAM001");

//         teamController.deleteTeam("TEAM001");

//         verify(teamService, times(1))
//                 .deleteTeam("TEAM001");
//     }

//     @Test
//     void deleteTeamReturnsSuccessMessage() {

//         doNothing()
//                 .when(teamService)
//                 .deleteTeam("TEAM001");

//         String result =
//                 teamController.deleteTeam("TEAM001");

//         assertNotNull(result);

//         assertEquals(
//                 "Team deleted successfully",
//                 result);
//     }
// }