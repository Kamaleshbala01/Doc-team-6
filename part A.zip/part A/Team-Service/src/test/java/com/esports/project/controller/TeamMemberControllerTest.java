// package com.esports.project.controller;

// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;

// import java.util.Arrays;
// import java.util.Collections;
// import java.util.List;

// import com.esports.project.DTO.AddTeamMemberRequest;
// import com.esports.project.DTO.TeamMemberDTO;
// import com.esports.project.enums.TeamPosition;
// import com.esports.project.service.TeamMemberService;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;

// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// @ExtendWith(MockitoExtension.class)
// class TeamMemberControllerTest {

//     @Mock
//     private TeamMemberService teamMemberService;

//     @InjectMocks
//     private TeamMemberController teamMemberController;

//     private TeamMemberDTO memberDTO;

//     @BeforeEach
//     void setup() {

//         memberDTO = new TeamMemberDTO();
//         memberDTO.setMemberId("MEM001");
//         memberDTO.setUserId("USER001");
//         memberDTO.setUsername("Rakesh");
//         memberDTO.setPosition(TeamPosition.LEADER);
//     }

//     @Test
//     void addMemberTest() {

//         AddTeamMemberRequest request =
//                 new AddTeamMemberRequest();

//         request.setUserId("USER001");
//         request.setPosition(TeamPosition.LEADER);

//         when(teamMemberService.addMember(
//                 "TEAM001",
//                 request))
//                 .thenReturn(memberDTO);

//         TeamMemberDTO result =
//                 teamMemberController.addMember(
//                         "TEAM001",
//                         request);

//         assertNotNull(result);
//         assertEquals("MEM001",
//                 result.getMemberId());
//     }

//     @Test
//     void addMemberReturnedObjectNotNullTest() {

//         AddTeamMemberRequest request =
//                 new AddTeamMemberRequest();

//         request.setUserId("USER001");
//         request.setPosition(TeamPosition.LEADER);

//         when(teamMemberService.addMember(
//                 "TEAM001",
//                 request))
//                 .thenReturn(memberDTO);

//         TeamMemberDTO result =
//                 teamMemberController.addMember(
//                         "TEAM001",
//                         request);

//         assertNotNull(result);
//     }

//     @Test
//     void addMemberVerifyServiceCall() {

//         AddTeamMemberRequest request =
//                 new AddTeamMemberRequest();

//         request.setUserId("USER001");
//         request.setPosition(TeamPosition.LEADER);

//         when(teamMemberService.addMember(
//                 "TEAM001",
//                 request))
//                 .thenReturn(memberDTO);

//         teamMemberController.addMember(
//                 "TEAM001",
//                 request);

//         verify(teamMemberService, times(1))
//                 .addMember(
//                         "TEAM001",
//                         request);
//     }

//     @Test
//     void getMembersTest() {

//         when(teamMemberService.getMembers("TEAM001"))
//                 .thenReturn(
//                         Collections.singletonList(memberDTO));

//         List<TeamMemberDTO> result =
//                 teamMemberController.getMembers("TEAM001");

//         assertEquals(1, result.size());
//     }

//     @Test
//     void getMembersEmptyListTest() {

//         when(teamMemberService.getMembers("TEAM001"))
//                 .thenReturn(Collections.emptyList());

//         List<TeamMemberDTO> result =
//                 teamMemberController.getMembers("TEAM001");

//         assertTrue(result.isEmpty());
//     }

//     @Test
//     void getMembersMultipleRecordsTest() {

//         TeamMemberDTO member2 =
//                 new TeamMemberDTO();

//         member2.setMemberId("MEM002");
//         member2.setPosition(TeamPosition.MEMBER);

//         when(teamMemberService.getMembers("TEAM001"))
//                 .thenReturn(
//                         Arrays.asList(memberDTO, member2));

//         List<TeamMemberDTO> result =
//                 teamMemberController.getMembers("TEAM001");

//         assertEquals(2, result.size());
//     }

//     @Test
//     void getMembersVerifyServiceCall() {

//         when(teamMemberService.getMembers("TEAM001"))
//                 .thenReturn(
//                         Collections.singletonList(memberDTO));

//         teamMemberController.getMembers("TEAM001");

//         verify(teamMemberService, times(1))
//                 .getMembers("TEAM001");
//     }

//     @Test
//     void getMemberTest() {

//         when(teamMemberService.getMember(
//                 "TEAM001",
//                 "MEM001"))
//                 .thenReturn(memberDTO);

//         TeamMemberDTO result =
//                 teamMemberController.getMember(
//                         "TEAM001",
//                         "MEM001");

//         assertEquals(
//                 "MEM001",
//                 result.getMemberId());
//     }

//     @Test
//     void getMemberReturnedObjectNotNullTest() {

//         when(teamMemberService.getMember(
//                 "TEAM001",
//                 "MEM001"))
//                 .thenReturn(memberDTO);

//         TeamMemberDTO result =
//                 teamMemberController.getMember(
//                         "TEAM001",
//                         "MEM001");

//         assertNotNull(result);
//     }

//     @Test
//     void getMemberVerifyServiceCall() {

//         when(teamMemberService.getMember(
//                 "TEAM001",
//                 "MEM001"))
//                 .thenReturn(memberDTO);

//         teamMemberController.getMember(
//                 "TEAM001",
//                 "MEM001");

//         verify(teamMemberService, times(1))
//                 .getMember(
//                         "TEAM001",
//                         "MEM001");
//     }

//     @Test
//     void updatePositionTest() {

//         when(teamMemberService.updatePosition(
//                 "TEAM001",
//                 "MEM001",
//                 TeamPosition.LEADER))
//                 .thenReturn(memberDTO);

//         TeamMemberDTO result =
//                 teamMemberController.updatePosition(
//                         "TEAM001",
//                         "MEM001",
//                         TeamPosition.LEADER);

//         assertEquals(
//                 TeamPosition.LEADER,
//                 result.getPosition());
//     }

//     @Test
//     void updatePositionMemberRoleTest() {

//         TeamMemberDTO dto =
//                 new TeamMemberDTO();

//         dto.setMemberId("MEM001");
//         dto.setPosition(TeamPosition.MEMBER);

//         when(teamMemberService.updatePosition(
//                 "TEAM001",
//                 "MEM001",
//                 TeamPosition.MEMBER))
//                 .thenReturn(dto);

//         TeamMemberDTO result =
//                 teamMemberController.updatePosition(
//                         "TEAM001",
//                         "MEM001",
//                         TeamPosition.MEMBER);

//         assertEquals(
//                 TeamPosition.MEMBER,
//                 result.getPosition());
//     }

//     @Test
//     void updatePositionReturnedObjectNotNullTest() {

//         when(teamMemberService.updatePosition(
//                 "TEAM001",
//                 "MEM001",
//                 TeamPosition.LEADER))
//                 .thenReturn(memberDTO);

//         TeamMemberDTO result =
//                 teamMemberController.updatePosition(
//                         "TEAM001",
//                         "MEM001",
//                         TeamPosition.LEADER);

//         assertNotNull(result);
//     }

//     @Test
//     void updatePositionVerifyServiceCall() {

//         when(teamMemberService.updatePosition(
//                 "TEAM001",
//                 "MEM001",
//                 TeamPosition.LEADER))
//                 .thenReturn(memberDTO);

//         teamMemberController.updatePosition(
//                 "TEAM001",
//                 "MEM001",
//                 TeamPosition.LEADER);

//         verify(teamMemberService, times(1))
//                 .updatePosition(
//                         "TEAM001",
//                         "MEM001",
//                         TeamPosition.LEADER);
//     }

//     @Test
//     void removeMemberTest() {

//         doNothing()
//                 .when(teamMemberService)
//                 .removeMember(
//                         "TEAM001",
//                         "MEM001");

//         String result =
//                 teamMemberController.removeMember(
//                         "TEAM001",
//                         "MEM001");

//         assertEquals(
//                 "Member removed successfully",
//                 result);
//     }

//     @Test
//     void removeMemberReturnsSuccessMessageTest() {

//         doNothing()
//                 .when(teamMemberService)
//                 .removeMember(
//                         "TEAM001",
//                         "MEM001");

//         String result =
//                 teamMemberController.removeMember(
//                         "TEAM001",
//                         "MEM001");

//         assertNotNull(result);
//         assertEquals(
//                 "Member removed successfully",
//                 result);
//     }

//     @Test
//     void removeMemberVerifyServiceCall() {

//         doNothing()
//                 .when(teamMemberService)
//                 .removeMember(
//                         "TEAM001",
//                         "MEM001");

//         teamMemberController.removeMember(
//                 "TEAM001",
//                 "MEM001");

//         verify(teamMemberService, times(1))
//                 .removeMember(
//                         "TEAM001",
//                         "MEM001");
//     }
// }