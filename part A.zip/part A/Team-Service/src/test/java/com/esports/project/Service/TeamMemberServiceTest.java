package com.esports.project.Service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.AddTeamMemberRequest;
import com.esports.project.DTO.TeamMemberDTO;
import com.esports.project.DTO.UpdateTeamMemberPositionRequest;
import com.esports.project.Repository.TeamMemberRepository;
import com.esports.project.Repository.TeamRepository;
import com.esports.project.entity.Team;
import com.esports.project.entity.TeamMember;
import com.esports.project.enums.TeamPosition;
import com.esports.project.service.TeamMemberService;

@ExtendWith(MockitoExtension.class)
class TeamMemberServiceTest {

    @Mock
    private TeamRepository teamRepository;

    @Mock
    private TeamMemberRepository teamMemberRepository;

    @InjectMocks
    private TeamMemberService teamMemberService;

    @Test
    void addMemberSuccess() {

        Team team = new Team();
        team.setId("TEAM001");
        team.setTeamName("Dragon Warriors");

        AddTeamMemberRequest request =
                new AddTeamMemberRequest();

        request.setUserId("USER001");
        request.setUsername("Rakesh");
        request.setPosition(
                TeamPosition.LEADER);

        TeamMember member =
                new TeamMember();

        member.setId("MEM001");
        member.setUserId("USER001");
        member.setUsername("Rakesh");
        member.setPosition(
                TeamPosition.LEADER);
        member.setTeam(team);

        when(teamRepository.findById("TEAM001"))
                .thenReturn(Optional.of(team));

        when(teamMemberRepository
                .existsByTeamIdAndUserId(
                        "TEAM001",
                        "USER001"))
                .thenReturn(false);

        when(teamMemberRepository.save(any()))
                .thenReturn(member);

        TeamMemberDTO response =
                teamMemberService.addMember(
                        "TEAM001",
                        request);

        assertEquals(
                "MEM001",
                response.getMemberId());
    }

    @Test
    void getMemberSuccess() {

        Team team = new Team();
        team.setId("TEAM001");

        TeamMember member =
                new TeamMember();

        member.setId("MEM001");
        member.setTeam(team);

        when(teamMemberRepository.findById("MEM001"))
                .thenReturn(Optional.of(member));

        TeamMemberDTO response =
                teamMemberService.getMember(
                        "TEAM001",
                        "MEM001");

        assertEquals(
                "MEM001",
                response.getMemberId());
    }

    @Test
    void updatePositionSuccess() {

        Team team = new Team();
        team.setId("TEAM001");

        TeamMember member =
                new TeamMember();

        member.setId("MEM001");
        member.setTeam(team);

        UpdateTeamMemberPositionRequest request =
                new UpdateTeamMemberPositionRequest();

        request.setPosition(
                TeamPosition.MEMBER);

        when(teamMemberRepository.findById("MEM001"))
                .thenReturn(Optional.of(member));

        when(teamMemberRepository.save(any()))
                .thenReturn(member);

        TeamMemberDTO response =
                teamMemberService.updatePosition(
                        "TEAM001",
                        "MEM001",
                        request);

        assertNotNull(response);
    }

    @Test
    void removeMemberSuccess() {

        TeamMember member =
                new TeamMember();

        member.setId("MEM001");

        when(teamMemberRepository.findById("MEM001"))
                .thenReturn(Optional.of(member));

        teamMemberService.removeMember(
                "TEAM001",
                "MEM001");

        verify(teamMemberRepository)
                .delete(member);
    }
}