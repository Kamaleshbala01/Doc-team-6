package com.esports.project.enums;

public enum PriceCategory {
    FIRST_PRICE,
    SECOND_PRICE,
    MVP
}
