package com.esports.project.controller;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.esports.project.DTO.SendInvitationRequest;
import com.esports.project.DTO.TeamInvitationDTO;
import com.esports.project.DTO.UpdateInvitationStatusRequest;
import com.esports.project.service.TeamInvitationService;

@RestController
@RequestMapping("/teams")
public class TeamInvitationController {

    private final TeamInvitationService
            teamInvitationService;

    public TeamInvitationController(
            TeamInvitationService teamInvitationService) {

        this.teamInvitationService =
                teamInvitationService;
    }

    //@PreAuthorize("hasAuthority('PLAYER')")
    @PostMapping("/{teamId}/invitations")
    public TeamInvitationDTO sendInvitation(
            @PathVariable String teamId,

            @RequestBody SendInvitationRequest request) {

        return teamInvitationService
                .sendInvitation(
                        teamId,
                        request);
    }

    @GetMapping("/{teamId}/invitations")
    public List<TeamInvitationDTO>
            getTeamInvitations(
                    @PathVariable String teamId) {

        return teamInvitationService
                .getTeamInvitations(teamId);
    }

    @GetMapping("/invitations/user/{userId}")
    public List<TeamInvitationDTO>
            getUserInvitations(
                    @PathVariable String userId) {

        return teamInvitationService
                .getUserInvitations(userId);
    }

    //@PreAuthorize("hasAuthority('PLAYER')")
    @PutMapping("/invitations/{invitationId}/status")
    public TeamInvitationDTO
            updateInvitationStatus(

                    @PathVariable
                    String invitationId,

                    @RequestBody
                    UpdateInvitationStatusRequest request) {

        return teamInvitationService
                .updateInvitationStatus(
                        invitationId,
                        request);
    }

    //@PreAuthorize("hasAuthority('PLAYER')")
    @DeleteMapping("/invitations/{invitationId}")
    public String deleteInvitation(

            @PathVariable
            String invitationId) {

        teamInvitationService
                .deleteInvitation(invitationId);

        return "Invitation deleted successfully";
    }
}