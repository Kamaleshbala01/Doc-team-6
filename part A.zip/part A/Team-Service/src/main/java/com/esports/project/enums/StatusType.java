package com.esports.project.enums;

public enum StatusType {
    TOURNAMENT,
    VERIFICATION,
}
