package com.esports.project.enums;

public enum PaymentMethod {
    GPAY,
    ONLINE_PAYMENT,
    PAYTM
}
