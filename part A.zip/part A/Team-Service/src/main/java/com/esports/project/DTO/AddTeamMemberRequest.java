package com.esports.project.DTO;

import com.esports.project.enums.TeamPosition;

public class AddTeamMemberRequest {

    private String userId;
    private String username;
    private TeamPosition position;

    public AddTeamMemberRequest() {
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public TeamPosition getPosition() {
        return position;
    }

    public void setPosition(TeamPosition position) {
        this.position = position;
    }
}