package com.esports.project.service;

import java.time.LocalDateTime;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.CreateTeamRequest;
import com.esports.project.DTO.TeamDTO;
import com.esports.project.DTO.UpdateTeamRequest;
import com.esports.project.Repository.TeamRepository;
import com.esports.project.entity.Team;
import com.esports.project.exception.ResourceNotFoundException;

@Service
public class TeamService {

    private final TeamRepository teamRepository;

    public TeamService(
            TeamRepository teamRepository) {

        this.teamRepository = teamRepository;
    }

    public TeamDTO createTeam(
            CreateTeamRequest request) {

        Team team = new Team();

        team.setTeamName(
                request.getTeamName());

        team.setGameTitle(
                request.getGameTitle());

        team.setRegion(
                request.getRegion());

        team.setLeaderId(
                request.getLeaderId());

        team.setLeaderName(
                request.getLeaderName());

        team.setFoundedDate(
                request.getFoundedDate());

        team.setCreatedAt(
                LocalDateTime.now());

        team.setUpdatedAt(
                LocalDateTime.now());

        Team savedTeam =
                teamRepository.save(team);

        return convertToDTO(savedTeam);
    }

    public TeamDTO getTeamById(
            String teamId) {

        Team team =
                teamRepository.findById(teamId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Team not found with id : "
                                                + teamId));

        return convertToDTO(team);
    }

    public Page<TeamDTO> getAllTeams(
            int page,
            int size) {

        return teamRepository
                .findAll(
                        PageRequest.of(
                                page,
                                size))
                .map(this::convertToDTO);
    }

    public Page<TeamDTO> searchTeams(
            String teamName,
            int page,
            int size) {

        return teamRepository
                .findByTeamNameContainingIgnoreCase(
                        teamName,
                        PageRequest.of(
                                page,
                                size))
                .map(this::convertToDTO);
    }

    public TeamDTO updateTeam(
            String teamId,
            UpdateTeamRequest request) {

        Team existingTeam =
                teamRepository.findById(teamId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Team not found with id : "
                                                + teamId));

        existingTeam.setTeamName(
                request.getTeamName());

        existingTeam.setGameTitle(
                request.getGameTitle());

        existingTeam.setRegion(
                request.getRegion());

        existingTeam.setUpdatedAt(
                LocalDateTime.now());

        Team updatedTeam =
                teamRepository.save(
                        existingTeam);

        return convertToDTO(
                updatedTeam);
    }

    public void deleteTeam(
            String teamId) {

        Team team =
                teamRepository.findById(teamId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Team not found with id : "
                                                + teamId));

        teamRepository.delete(team);
    }

    private TeamDTO convertToDTO(
            Team team) {

        TeamDTO dto =
                new TeamDTO();

        dto.setTeamId(
                team.getId());

        dto.setTeamName(
                team.getTeamName());

        dto.setGameTitle(
                team.getGameTitle());

        dto.setRegion(
                team.getRegion());

        dto.setLeaderId(
                team.getLeaderId());

        dto.setLeaderName(
                team.getLeaderName());

        dto.setFoundedDate(
                team.getFoundedDate());

        dto.setCreatedAt(
                team.getCreatedAt());

        dto.setUpdatedAt(
                team.getUpdatedAt());

        dto.setTotalMembers(0);

        return dto;
    }
}