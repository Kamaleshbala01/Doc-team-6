package com.esports.project.enums;

public enum InvitationStatus {

    PENDING,
    ACCEPTED,
    REJECTED
}