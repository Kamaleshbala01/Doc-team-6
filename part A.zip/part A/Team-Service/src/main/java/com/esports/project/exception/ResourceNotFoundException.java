package com.esports.project.exception;

public class ResourceNotFoundException extends BadRequestException{
    public ResourceNotFoundException(String message){
        super(message);
    }
}
