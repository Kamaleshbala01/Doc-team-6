package com.esports.project.enums;

public enum TournamentCategory {
    BRACKETS,
    LEADERBOARD
}
