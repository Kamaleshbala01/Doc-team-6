package com.esports.project.DTO;

import com.esports.project.enums.InvitationStatus;

public class UpdateInvitationStatusRequest {

    private InvitationStatus status;

    public UpdateInvitationStatusRequest() {
    }

    public InvitationStatus getStatus() {
        return status;
    }

    public void setStatus(
            InvitationStatus status) {
        this.status = status;
    }
}