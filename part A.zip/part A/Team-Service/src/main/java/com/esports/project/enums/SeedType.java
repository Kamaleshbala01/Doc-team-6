package com.esports.project.enums;

public enum SeedType {
    RANDOM,
    MANUAL
}
