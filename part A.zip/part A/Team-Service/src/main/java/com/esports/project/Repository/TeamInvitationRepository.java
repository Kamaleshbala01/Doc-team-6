package com.esports.project.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.esports.project.entity.TeamInvitation;
import com.esports.project.enums.InvitationStatus;

public interface TeamInvitationRepository
        extends JpaRepository<TeamInvitation, String> {

    List<TeamInvitation> findByTeamId(
            String teamId);

    List<TeamInvitation> findByReceiverId(
            String receiverId);

    List<TeamInvitation> findByStatus(
            InvitationStatus status);

    boolean existsByTeamIdAndReceiverIdAndStatus(
            String teamId,
            String receiverId,
            InvitationStatus status);

    List<TeamInvitation> findByTeamIdAndStatus(
            String teamId,
            InvitationStatus status);

    List<TeamInvitation> findByReceiverIdAndStatus(
            String receiverId,
            InvitationStatus status);
}