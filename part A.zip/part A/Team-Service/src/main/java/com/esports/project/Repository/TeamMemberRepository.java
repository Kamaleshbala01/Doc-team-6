package com.esports.project.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.esports.project.entity.Team;
import com.esports.project.entity.TeamMember;

public interface TeamMemberRepository
        extends JpaRepository<TeamMember, String> {

    List<TeamMember> findByTeam(
            Team team);

    boolean existsByTeamIdAndUserId(
            String teamId,
            String userId);

    long countByTeamId(
            String teamId);

    List<TeamMember> findByUserId(
            String userId);

    List<TeamMember> findByUsernameContainingIgnoreCase(
            String username);
}
