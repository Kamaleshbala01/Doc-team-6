package com.esports.project.controller;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.esports.project.DTO.AddTeamMemberRequest;
import com.esports.project.DTO.TeamMemberDTO;
import com.esports.project.DTO.UpdateTeamMemberPositionRequest;
import com.esports.project.service.TeamMemberService;

@RestController
@RequestMapping("/teams/{teamId}/members")
public class TeamMemberController {

    private final TeamMemberService teamMemberService;

    public TeamMemberController(
            TeamMemberService teamMemberService) {

        this.teamMemberService = teamMemberService;
    }

    //@PreAuthorize("hasAuthority('PLAYER')")
    @PostMapping
    public TeamMemberDTO addMember(
            @PathVariable String teamId,

            @RequestBody AddTeamMemberRequest request) {

        return teamMemberService.addMember(
                teamId,
                request);
    }

    @GetMapping
    public List<TeamMemberDTO> getMembers(
            @PathVariable String teamId) {

        return teamMemberService.getMembers(
                teamId);
    }

    @GetMapping("/{memberId}")
    public TeamMemberDTO getMember(
            @PathVariable String teamId,

            @PathVariable String memberId) {

        return teamMemberService.getMember(
                teamId,
                memberId);
    }

    //@PreAuthorize("hasAuthority('PLAYER')")
    @PutMapping("/{memberId}/position")
    public TeamMemberDTO updatePosition(
            @PathVariable String teamId,

            @PathVariable String memberId,

            @RequestBody UpdateTeamMemberPositionRequest request) {

        return teamMemberService.updatePosition(
                teamId,
                memberId,
                request);
    }

    //@PreAuthorize("hasAuthority('PLAYER')")
    @DeleteMapping("/{memberId}")
    public String removeMember(
            @PathVariable String teamId,

            @PathVariable String memberId) {

        teamMemberService.removeMember(
                teamId,
                memberId);

        return "Member removed successfully";
    }
}