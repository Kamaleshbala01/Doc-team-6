package com.esports.project.enums;

public enum RulesCategory {
    MATCH_RULE,
    TEAM_RULE,
    PLAYER_RULE,
    SCORING_RULE,
    ELIGIBILITY_RULE,
    DISCIPLINARY_RULE,
    TOURNAMENT_RULE,
    GENERAL
}
