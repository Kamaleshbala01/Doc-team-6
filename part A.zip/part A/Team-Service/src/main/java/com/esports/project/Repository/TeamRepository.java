package com.esports.project.Repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.esports.project.entity.Team;

public interface TeamRepository
        extends JpaRepository<Team, String> {

    boolean existsByTeamName(
            String teamName);

    Page<Team> findByTeamNameContainingIgnoreCase(
            String teamName,
            Pageable pageable);

    Page<Team> findByGameTitle(
            String gameTitle,
            Pageable pageable);

    Page<Team> findByRegion(
            String region,
            Pageable pageable);

    Page<Team> findByLeaderId(
            String leaderId,
            Pageable pageable);
}