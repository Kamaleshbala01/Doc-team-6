package com.esports.project.DTO;

import com.esports.project.enums.TeamPosition;

public class UpdateTeamMemberPositionRequest {

    private TeamPosition position;

    public UpdateTeamMemberPositionRequest() {
    }

    public TeamPosition getPosition() {
        return position;
    }

    public void setPosition(TeamPosition position) {
        this.position = position;
    }
}