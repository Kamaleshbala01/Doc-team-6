package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.AddTeamMemberRequest;
import com.esports.project.DTO.TeamMemberDTO;
import com.esports.project.DTO.UpdateTeamMemberPositionRequest;
import com.esports.project.Repository.TeamMemberRepository;
import com.esports.project.Repository.TeamRepository;
import com.esports.project.entity.Team;
import com.esports.project.entity.TeamMember;
import com.esports.project.exception.BadRequestException;
import com.esports.project.exception.ResourceNotFoundException;

@Service
public class TeamMemberService {

    private final TeamRepository teamRepository;
    private final TeamMemberRepository teamMemberRepository;

    public TeamMemberService(
            TeamRepository teamRepository,
            TeamMemberRepository teamMemberRepository) {

        this.teamRepository = teamRepository;
        this.teamMemberRepository = teamMemberRepository;
    }

    public TeamMemberDTO addMember(
            String teamId,
            AddTeamMemberRequest request) {

        Team team = teamRepository.findById(teamId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Team not found"));

        if (teamMemberRepository
                .existsByTeamIdAndUserId(
                        teamId,
                        request.getUserId())) {

            throw new BadRequestException(
                    "Member already exists");
        }

        TeamMember member = new TeamMember();

        member.setUserId(
                request.getUserId());

        member.setUsername(
                request.getUsername());

        member.setPosition(
                request.getPosition());

        member.setJoinedAt(
                LocalDateTime.now());

        member.setCreatedAt(
                LocalDateTime.now());

        member.setUpdatedAt(
                LocalDateTime.now());

        member.setTeam(team);

        TeamMember savedMember =
                teamMemberRepository.save(member);

        return convertToDTO(savedMember);
    }

    public List<TeamMemberDTO> getMembers(
            String teamId) {

        Team team = teamRepository.findById(teamId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Team not found"));

        return teamMemberRepository
                .findByTeam(team)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public TeamMemberDTO getMember(
            String teamId,
            String memberId) {

        TeamMember member =
                teamMemberRepository.findById(memberId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Member not found"));

        return convertToDTO(member);
    }

    public TeamMemberDTO updatePosition(
            String teamId,
            String memberId,
            UpdateTeamMemberPositionRequest request) {

        TeamMember member =
                teamMemberRepository.findById(memberId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Member not found"));

        member.setPosition(
                request.getPosition());

        member.setUpdatedAt(
                LocalDateTime.now());

        TeamMember updatedMember =
                teamMemberRepository.save(member);

        return convertToDTO(updatedMember);
    }

    public void removeMember(
            String teamId,
            String memberId) {

        TeamMember member =
                teamMemberRepository.findById(memberId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Member not found"));

        teamMemberRepository.delete(member);
    }

    private TeamMemberDTO convertToDTO(
            TeamMember member) {

        TeamMemberDTO dto =
                new TeamMemberDTO();

        dto.setMemberId(
                member.getId());

        dto.setUserId(
                member.getUserId());

        dto.setUsername(
                member.getUsername());

        dto.setPosition(
                member.getPosition());

        dto.setJoinedAt(
                member.getJoinedAt());

        dto.setCreatedAt(
                member.getCreatedAt());

        dto.setUpdatedAt(
                member.getUpdatedAt());

        dto.setTeamId(
                member.getTeam().getId());

        dto.setTeamName(
                member.getTeam().getTeamName());

        return dto;
    }
}