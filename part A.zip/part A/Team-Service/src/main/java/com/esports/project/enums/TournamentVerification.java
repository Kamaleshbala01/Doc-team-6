package com.esports.project.enums;

public enum TournamentVerification {
    YES,
    NO
}
