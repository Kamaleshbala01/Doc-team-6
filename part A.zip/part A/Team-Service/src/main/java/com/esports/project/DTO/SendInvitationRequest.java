package com.esports.project.DTO;

public class SendInvitationRequest {

    private String receiverId;
    private String receiverName;

    public SendInvitationRequest() {
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String receiverId) {
        this.receiverId = receiverId;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }
}