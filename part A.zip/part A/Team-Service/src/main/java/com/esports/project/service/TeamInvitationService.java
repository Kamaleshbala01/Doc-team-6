package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.SendInvitationRequest;
import com.esports.project.DTO.TeamInvitationDTO;
import com.esports.project.DTO.UpdateInvitationStatusRequest;
import com.esports.project.Repository.TeamInvitationRepository;
import com.esports.project.Repository.TeamMemberRepository;
import com.esports.project.Repository.TeamRepository;
import com.esports.project.entity.Team;
import com.esports.project.entity.TeamInvitation;
import com.esports.project.entity.TeamMember;
import com.esports.project.enums.InvitationStatus;
import com.esports.project.enums.TeamPosition;
import com.esports.project.exception.BadRequestException;
import com.esports.project.exception.ResourceNotFoundException;

@Service
public class TeamInvitationService {

    private final TeamRepository teamRepository;

    private final TeamInvitationRepository teamInvitationRepository;

    private final TeamMemberRepository teamMemberRepository;

    public TeamInvitationService(
            TeamRepository teamRepository,
            TeamInvitationRepository teamInvitationRepository,
            TeamMemberRepository teamMemberRepository) {

        this.teamRepository = teamRepository;
        this.teamInvitationRepository = teamInvitationRepository;
        this.teamMemberRepository = teamMemberRepository;
    }

    public TeamInvitationDTO sendInvitation(
            String teamId,
            SendInvitationRequest request) {

        Team team = teamRepository.findById(teamId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Team not found"));

        boolean invitationExists =
                teamInvitationRepository
                        .existsByTeamIdAndReceiverIdAndStatus(
                                teamId,
                                request.getReceiverId(),
                                InvitationStatus.PENDING);

        if (invitationExists) {
            throw new BadRequestException(
                    "Pending invitation already exists");
        }

        TeamInvitation invitation =
                new TeamInvitation();

        invitation.setTeamId(team.getId());

        invitation.setTeamName(
                team.getTeamName());

        invitation.setSenderId(
                team.getLeaderId());

        invitation.setSenderName(
                team.getLeaderName());

        invitation.setReceiverId(
                request.getReceiverId());

        invitation.setReceiverName(
                request.getReceiverName());

        invitation.setStatus(
                InvitationStatus.PENDING);

        invitation.setSentAt(
                LocalDateTime.now());

        TeamInvitation savedInvitation =
                teamInvitationRepository
                        .save(invitation);

        return convertToDTO(savedInvitation);
    }

    public List<TeamInvitationDTO>
    getTeamInvitations(
            String teamId) {

        return teamInvitationRepository
                .findByTeamId(teamId)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<TeamInvitationDTO>
    getUserInvitations(
            String userId) {

        return teamInvitationRepository
                .findByReceiverId(userId)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public TeamInvitationDTO updateInvitationStatus(
            String invitationId,
            UpdateInvitationStatusRequest request) {

        TeamInvitation invitation =
                teamInvitationRepository
                        .findById(invitationId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Invitation not found"));

        if (invitation.getStatus()
                != InvitationStatus.PENDING) {

            throw new BadRequestException(
                    "Invitation already processed");
        }

        invitation.setStatus(
                request.getStatus());

        invitation.setRespondedAt(
                LocalDateTime.now());

        if (request.getStatus()
                == InvitationStatus.ACCEPTED) {

            Team team =
                    teamRepository.findById(
                            invitation.getTeamId())
                            .orElseThrow(() ->
                                    new ResourceNotFoundException(
                                            "Team not found"));

            boolean memberExists =
                    teamMemberRepository
                            .existsByTeamIdAndUserId(
                                    team.getId(),
                                    invitation.getReceiverId());

            if (!memberExists) {

                TeamMember member =
                        new TeamMember();

                member.setUserId(
                        invitation.getReceiverId());

                member.setUsername(
                        invitation.getReceiverName());

                member.setPosition(
                        TeamPosition.MEMBER);

                member.setJoinedAt(
                        LocalDateTime.now());

                member.setCreatedAt(
                        LocalDateTime.now());

                member.setUpdatedAt(
                        LocalDateTime.now());

                member.setTeam(team);

                teamMemberRepository.save(member);
            }
        }

        TeamInvitation updatedInvitation =
                teamInvitationRepository.save(
                        invitation);

        return convertToDTO(updatedInvitation);
    }

    public void deleteInvitation(
            String invitationId) {

        TeamInvitation invitation =
                teamInvitationRepository
                        .findById(invitationId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Invitation not found"));

        teamInvitationRepository
                .delete(invitation);
    }

    private TeamInvitationDTO convertToDTO(
            TeamInvitation invitation) {

        TeamInvitationDTO dto =
                new TeamInvitationDTO();

        dto.setInvitationId(
                invitation.getId());

        dto.setTeamId(
                invitation.getTeamId());

        dto.setTeamName(
                invitation.getTeamName());

        dto.setSenderId(
                invitation.getSenderId());

        dto.setSenderName(
                invitation.getSenderName());

        dto.setReceiverId(
                invitation.getReceiverId());

        dto.setReceiverName(
                invitation.getReceiverName());

        dto.setStatus(
                invitation.getStatus());

        dto.setSentAt(
                invitation.getSentAt());

        dto.setRespondedAt(
                invitation.getRespondedAt());

        return dto;
    }
}