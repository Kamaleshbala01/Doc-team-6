package com.esports.project.controller;

import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.esports.project.DTO.CreateTeamRequest;
import com.esports.project.DTO.TeamDTO;
import com.esports.project.DTO.UpdateTeamRequest;
import com.esports.project.service.TeamService;

@RestController
@RequestMapping("/teams")
public class TeamController {

    private final TeamService teamService;

    public TeamController(
            TeamService teamService) {

        this.teamService = teamService;
    }

    //@PreAuthorize("hasAuthority('PLAYER')")
    @PostMapping
    public TeamDTO createTeam(
            @RequestBody CreateTeamRequest request) {

        return teamService.createTeam(request);
    }

    @GetMapping("/{teamId}")
    public TeamDTO getTeamById(
            @PathVariable String teamId) {

        return teamService.getTeamById(teamId);
    }

    @GetMapping
    public Page<TeamDTO> getAllTeams(
            @RequestParam(defaultValue = "0")
            int page,

            @RequestParam(defaultValue = "10")
            int size) {

        return teamService.getAllTeams(
                page,
                size);
    }

    @GetMapping("/search")
    public Page<TeamDTO> searchTeams(
            @RequestParam String teamName,

            @RequestParam(defaultValue = "0")
            int page,

            @RequestParam(defaultValue = "10")
            int size) {

        return teamService.searchTeams(
                teamName,
                page,
                size);
    }

    //@PreAuthorize("hasAuthority('PLAYER')")
    @PutMapping("/{teamId}")
    public TeamDTO updateTeam(
            @PathVariable String teamId,

            @RequestBody UpdateTeamRequest request) {

        return teamService.updateTeam(
                teamId,
                request);
    }

    //@PreAuthorize("hasAuthority('PLAYER')")
    @DeleteMapping("/{teamId}")
    public String deleteTeam(
            @PathVariable String teamId) {

        teamService.deleteTeam(teamId);

        return "Team deleted successfully";
    }
}