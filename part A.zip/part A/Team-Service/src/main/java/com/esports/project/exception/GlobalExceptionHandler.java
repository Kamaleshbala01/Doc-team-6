//package com.esports.project.exception;
//
//import jakarta.servlet.http.HttpServletRequest;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.bind.annotation.RestControllerAdvice;
//
//import com.esports.project.DTO.ExceptionDTO;
//
//@RestControllerAdvice
//public class GlobalExceptionHandler {
//
//    @ExceptionHandler(ResourceNotFoundException.class)
//    public ResponseEntity<ExceptionDTO> handleNotFoundException(
//            ResourceNotFoundException ex,
//            HttpServletRequest request) {
//
//        ExceptionDTO dto =
//                new ExceptionDTO(
//                        404,
//                        "Not Found",
//                        ex.getMessage(),
//                        request.getRequestURI());
//
//        return ResponseEntity
//                .status(HttpStatus.NOT_FOUND)
//                .body(dto);
//    }
//
//    @ExceptionHandler(BadRequestException.class)
//    public ResponseEntity<ExceptionDTO> handleBadRequestException(
//            BadRequestException ex,
//            HttpServletRequest request) {
//
//        ExceptionDTO dto =
//                new ExceptionDTO(
//                        400,
//                        "Bad Request",
//                        ex.getMessage(),
//                        request.getRequestURI());
//
//        return ResponseEntity
//                .status(HttpStatus.BAD_REQUEST)
//                .body(dto);
//    }
//
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<ExceptionDTO> handleException(
//            Exception ex,
//            HttpServletRequest request) {
//
//        ExceptionDTO dto =
//                new ExceptionDTO(
//                        500,
//                        "Internal Server Error",
//                        ex.getMessage(),
//                        request.getRequestURI());
//
//        return ResponseEntity
//                .status(HttpStatus.INTERNAL_SERVER_ERROR)
//                .body(dto);
//    }
//}