package com.esports.project.service;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.InfluencerProfilePublishEvent;
//import com.esports.project.entity.SocialMediaAccount;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TestService {
    private final SocialMediaEventPublisher publisher;

    public void throwNotFound() {

        // SocialMediaAccount account =
        // new SocialMediaAccount();

        // account.setId("SM_001");
        // account.setPlatform("YOUTUBE");
        // account.setAccountName("mrbeast");
        // account.setProfileUrl(
        // "https://youtube.com/@MrBeast");

        // try {
        // publisher.publishValidateInfluencer(account);
        // } catch (Exception e) {
        // System.out.println("publish from spocial media" + e.getMessage());
        // }
        InfluencerProfilePublishEvent publishEvent = new InfluencerProfilePublishEvent(
                "account.getUserId()",
                "account.getStatus()");
        try {
            publisher.publishInfluencerProfileUpdate(publishEvent);
        } catch (Exception e) {
            System.out.println("send event to user for update influencer profile : " + e.getMessage());
        }

    }
}
