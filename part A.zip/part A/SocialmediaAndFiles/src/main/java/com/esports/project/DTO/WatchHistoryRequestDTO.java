package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WatchHistoryRequestDTO {

    private String userId;
    private String matchId;
}