package com.esports.project.enums;

import java.util.List;

public enum Game {

    BGMI(
            List.of(GamePlatform.MOBILE),
            List.of(GameMode.SOLO, GameMode.DUO, GameMode.SQUAD)
    ),

    VALORANT(
            List.of(GamePlatform.PC),
            List.of(GameMode.TEAM_5V5)
    ),
    CHESS(
            List.of(GamePlatform.PC,GamePlatform.MOBILE),
            List.of(GameMode.SOLO)
    );;

    private final List<GamePlatform> gamePlatforms;
    private final List<GameMode> modes;

    Game(List<GamePlatform> gamePlatforms, List<GameMode> modes) {
        this.gamePlatforms = gamePlatforms;
        this.modes = modes;
    }

    public List<GamePlatform> getGamePlatforms() {
        return gamePlatforms;
    }

    public List<GameMode> getModes() {
        return modes;
    }
    
}
