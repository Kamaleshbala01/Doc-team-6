package com.esports.project.Repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.WatchHistory;

@Repository
public interface WatchHistoryRepository extends JpaRepository<WatchHistory, String> {

    List<WatchHistory> findByUserId(String userId);

    List<WatchHistory> findByMatchId(String matchId);

    boolean existsByUserIdAndMatchId(String userId, String matchId);

    Page<WatchHistory> findByUserId(String userId, Pageable pageable);

    Page<WatchHistory> findByMatchId(
            String matchId,
            Pageable pageable);
}
