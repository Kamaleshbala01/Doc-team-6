package com.esports.project.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InfluencerProfilePublishEvent {
    private String userId;
    private String profileStatus;
}
