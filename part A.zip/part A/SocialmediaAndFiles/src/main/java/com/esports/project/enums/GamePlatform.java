package com.esports.project.enums;

public enum GamePlatform {
    MOBILE,
    PC
}
