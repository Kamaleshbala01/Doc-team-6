package com.esports.project.enums;

public enum GameMode {
    SOLO,
    DUO,
    SQUAD,
    TEAM_5V5
}
