package com.esports.project.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.esports.project.DTO.FilesDTO;
import com.esports.project.entity.Files;
import com.esports.project.service.FilesService;

@RestController
@RequestMapping("/media/files")
public class FilesController {

        private final FilesService filesService;

        public FilesController(FilesService filesService) {
                this.filesService = filesService;
        }

        @PostMapping
        @PreAuthorize("hasAuthority('FILE_WRITE')")
        public ResponseEntity<Files> createFile(
                        @RequestBody FilesDTO dto) {

                return ResponseEntity.ok(
                                filesService.createFile(dto));
        }

        @GetMapping
        @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<Page<Files>> getAllFiles(
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "fileName") String sortBy,
                        @RequestParam(defaultValue = "asc") String sortDir) {

                return ResponseEntity.ok(
                                filesService.getAllFiles(
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/{id}")
        @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<Files> getFileById(
                        @PathVariable String id) {

                return ResponseEntity.ok(
                                filesService.getFileById(id));
        }

        @GetMapping("/user/{userId}")
        @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<Page<Files>> getFilesByUserId(
                        @PathVariable String userId,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "fileName") String sortBy,
                        @RequestParam(defaultValue = "asc") String sortDir) {

                return ResponseEntity.ok(
                                filesService.getFilesByUserId(
                                                userId,
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/type/{fileType}")
        @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<Page<Files>> getFilesByType(
                        @PathVariable String fileType,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "fileName") String sortBy,
                        @RequestParam(defaultValue = "asc") String sortDir) {

                return ResponseEntity.ok(
                                filesService.getFilesByType(
                                                fileType,
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/bucket/{bucketName}")
        @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<Page<Files>> getFilesByBucket(
                        @PathVariable String bucketName,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "fileName") String sortBy,
                        @RequestParam(defaultValue = "asc") String sortDir) {

                return ResponseEntity.ok(
                                filesService.getFilesByBucket(
                                                bucketName,
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/search/{fileName}")
        @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<List<Files>> searchFile(
                        @PathVariable String fileName) {

                return ResponseEntity.ok(
                                filesService.searchByFileName(fileName));
        }

        @DeleteMapping("/{id}")
        @PreAuthorize("hasAuthority('FILE_DELETE')")
        public ResponseEntity<String> deleteFile(
                        @PathVariable String id) {

                filesService.deleteFile(id);

                return ResponseEntity.ok(
                                "File deleted successfully");
        }

        @PutMapping("/{id}")
        @PreAuthorize("hasAuthority('FILE_WRITE')")
        public ResponseEntity<Files> updateFile(
                        @PathVariable String id,
                        @RequestBody FilesDTO dto) {

                return ResponseEntity.ok(
                                filesService.updateFile(id, dto));
        }

        @PatchMapping("/{id}")
        @PreAuthorize("hasAuthority('FILE_WRITE')")
        public ResponseEntity<Files> patchFile(
                        @PathVariable String id,
                        @RequestBody FilesDTO dto) {

                return ResponseEntity.ok(
                                filesService.patchFile(id, dto));
        }

        @GetMapping("/{id}/download")
        @PreAuthorize("hasAuthority('FILE_READ')")
        public ResponseEntity<String> downloadFile(
                        @PathVariable String id) {

                return ResponseEntity.ok(
                                filesService.getFileDownloadPath(id));
        }
}