package com.esports.project.controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.service.TestService;

@RestController
@RequestMapping("/media/user")
public class Test {

    private final TestService testService;

    public Test(TestService testService){
        this.testService = testService;
    }

    @GetMapping("/testevent")
    public String getGreeting(){
        testService.throwNotFound();
        return "User end point";
    }
    
}
