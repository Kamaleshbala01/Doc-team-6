package com.esports.project.controller;

//import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.esports.project.DTO.WatchHistoryRequestDTO;
import com.esports.project.entity.WatchHistory;
import com.esports.project.service.WatchHistoryService;

@RestController
@RequestMapping("/media/watch-history")
public class WatchHistoryController {

        private final WatchHistoryService watchHistoryService;

        public WatchHistoryController(
                        WatchHistoryService watchHistoryService) {

                this.watchHistoryService = watchHistoryService;
        }

        @PostMapping
        @PreAuthorize("hasAuthority('WATCH_HISTORY_GENERATE')")
        public ResponseEntity<WatchHistory> watchMatch(
                        @RequestBody WatchHistoryRequestDTO dto) {

                return ResponseEntity.ok(
                                watchHistoryService.watchMatch(dto));
        }

        @GetMapping
        @PreAuthorize("hasAuthority('WATCH_HISTORY_READ')")
        public ResponseEntity<Page<WatchHistory>> getAllWatchHistory(
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "watchedAt") String sortBy,
                        @RequestParam(defaultValue = "desc") String sortDir) {

                return ResponseEntity.ok(
                                watchHistoryService.getAllWatchHistory(
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/{id}")
        @PreAuthorize("hasAuthority('WATCH_HISTORY_READ')")
        public ResponseEntity<WatchHistory> getWatchHistoryById(
                        @PathVariable String id) {

                return ResponseEntity.ok(
                                watchHistoryService.getWatchHistoryById(id));
        }

        @GetMapping("/user/{userId}")
        @PreAuthorize("hasAuthority('WATCH_HISTORY_READ')")
        public ResponseEntity<Page<WatchHistory>> getByUserId(
                        @PathVariable String userId,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size,
                        @RequestParam(defaultValue = "watchedAt") String sortBy,
                        @RequestParam(defaultValue = "desc") String sortDir) {

                return ResponseEntity.ok(
                                watchHistoryService.getByUserId(
                                                userId,
                                                page,
                                                size,
                                                sortBy,
                                                sortDir));
        }

        @GetMapping("/match/{matchId}")
        @PreAuthorize("hasAuthority('WATCH_HISTORY_READ')")
        public ResponseEntity<Page<WatchHistory>> getByMatchId(
                        @PathVariable String matchId,
                        @RequestParam(defaultValue = "0") int page,
                        @RequestParam(defaultValue = "10") int size) {

                return ResponseEntity.ok(
                                watchHistoryService.getByMatchId(
                                                matchId,
                                                page,
                                                size));
        }

        @DeleteMapping("/{id}")
        @PreAuthorize("hasAuthority('WATCH_HISTORY_DELETE')")
        public ResponseEntity<String> deleteWatchHistory(
                        @PathVariable String id) {

                watchHistoryService.deleteWatchHistory(id);

                return ResponseEntity.ok(
                                "Watch history deleted successfully");
        }
}