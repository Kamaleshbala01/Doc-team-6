package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BecomeInfluencerDTO {
    private String message;
}
