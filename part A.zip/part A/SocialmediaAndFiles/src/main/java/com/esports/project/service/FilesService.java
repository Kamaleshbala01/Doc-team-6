package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.FilesDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.Repository.FilesRepository;
import com.esports.project.entity.Files;
import com.esports.project.exception.CustomException;
import com.esports.project.exception.NotFoundException;

@Service
public class FilesService {

    private final FilesRepository filesRepository;

    public FilesService(FilesRepository filesRepository) {
        this.filesRepository = filesRepository;
    }

    public Files createFile(FilesDTO dto) {

        Files file = new Files();

        file.setFileName(dto.getFileName());
        file.setFileType(dto.getFileType());
        file.setBucketName(dto.getBucketName());
        file.setStoragePath(dto.getStoragePath());
        file.setFileSize(dto.getFileSize());

        file.setCreatedAt(LocalDateTime.now());
        UserDetailsDTO userDetailsDTO = (UserDetailsDTO)
                 SecurityContextHolder.getContext().getAuthentication().getPrincipal();
                

        file.setUserId(userDetailsDTO.getUserId());


        return filesRepository.save(file);
    }

    public Files updateFile(
            String id,
            FilesDTO dto) {

        Files file = filesRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "File not found with id: " + id));
        UserDetailsDTO userDetailsDTO = (UserDetailsDTO)
                 SecurityContextHolder.getContext().getAuthentication().getPrincipal();
                

                 if(!file.getUserId().equals(userDetailsDTO.getUserId())) 
                 {
                        throw new CustomException("Illegal access Try with different/own User id");
                 }

        //file.setUserId(userDetailsDTO.getUserId());

        file.setFileName(dto.getFileName());
        file.setFileType(dto.getFileType());
        file.setBucketName(dto.getBucketName());
        file.setStoragePath(dto.getStoragePath());
        file.setFileSize(dto.getFileSize());
        

        return filesRepository.save(file);
    }

    public Page<Files> getAllFiles(
            int page,
            int size,
            String sortBy,
            String sortDir) {

        Sort sort = sortDir.equalsIgnoreCase("asc")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageable = PageRequest.of(
                page,
                size,
                sort);

        return filesRepository.findAll(pageable);
    }

    public Files getFileById(String id) {

        return filesRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "File not found with id: " + id));
    }

    public Files patchFile(
            String id,
            FilesDTO dto) {

        Files file = filesRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "File not found with id: " + id));
        UserDetailsDTO userDetailsDTO = (UserDetailsDTO)
                 SecurityContextHolder.getContext().getAuthentication().getPrincipal();
                

                 if(!file.getUserId().equals(userDetailsDTO.getUserId())) 
                 {
                        throw new CustomException("Illegal access Try with different/own User id");
                 }


        if (dto.getFileName() != null) {
            file.setFileName(dto.getFileName());
        }

        if (dto.getFileType() != null) {
            file.setFileType(dto.getFileType());
        }

        if (dto.getBucketName() != null) {
            file.setBucketName(dto.getBucketName());
        }

        if (dto.getStoragePath() != null) {
            file.setStoragePath(dto.getStoragePath());
        }

        if (dto.getFileSize() != null) {
            file.setFileSize(dto.getFileSize());
        }

        return filesRepository.save(file);
    }

    public String getFileDownloadPath(String id) {

        Files file = filesRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "File not found with id: " + id));

        return file.getStoragePath();
    }

    public Page<Files> getFilesByUserId(
            String userId,
            int page,
            int size,
            String sortBy,
            String sortDir) {

        Sort sort = sortDir.equalsIgnoreCase("asc")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageable = PageRequest.of(
                page,
                size,
                sort);

        return filesRepository.findByUserId(
                userId,
                pageable);
    }

    public Page<Files> getFilesByType(
            String fileType,
            int page,
            int size,
            String sortBy,
            String sortDir) {

        Sort sort = sortDir.equalsIgnoreCase("asc")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageable = PageRequest.of(
                page,
                size,
                sort);

        return filesRepository.findByFileType(
                fileType,
                pageable);
    }

    public Page<Files> getFilesByBucket(
            String bucketName,
            int page,
            int size,
            String sortBy,
            String sortDir) {

        Sort sort = sortDir.equalsIgnoreCase("asc")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageable = PageRequest.of(
                page,
                size,
                sort);

        return filesRepository.findByBucketName(
                bucketName,
                pageable);
    }

    public List<Files> searchByFileName(String fileName) {
        return filesRepository.findByFileNameContainingIgnoreCase(fileName);
    }

    public void deleteFile(String id) {

        Files file = filesRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "File not found with id: " + id));

        filesRepository.delete(file);
    }
 
}