package com.esports.project.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {

    @Value("${jwt.secret}")
    private String secretKey;

    public boolean validateToken(String token){
        return  !isTokenExpiration(token);
    }

    private boolean isTokenExpiration(String token){
        return extractExpiration(token).before(new Date()); 
    }

    private Date extractExpiration(String token){
        return extractClaims(token,Claims::getExpiration);
    }

     private <T> T extractClaims(String token,Function<Claims,T> claimresolver){
        final Claims claims = extractAllClaims(token);
        return claimresolver.apply(claims);
    }

     public Claims extractAllClaims(String token){
        return Jwts.parser()
            .verifyWith(getKey())
            .build()
            .parseSignedClaims(token).getPayload();
    }

    
    private SecretKey getKey(){
        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    public String generateToken(String subject){
        Map<String,Object> claims = new HashMap<>();
        claims.put("token_type","SERVICE");

        return Jwts
                .builder()
                .claims()
                .add(claims)
                .subject(subject)
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 24 * 5))
                .and()
                .signWith(getKey())
                .compact();
    }
}
