package com.esports.project.service;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.DTO.InfluencerProfilePublishEvent;
import com.esports.project.DTO.SocialMediaValidationEvent;
import com.esports.project.entity.SocialMediaAccount;
import com.esports.project.websocket.PublisherBrokerClient;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SocialMediaEventPublisher {

    private final PublisherBrokerClient brokerClient;

    public void publishValidateInfluencer(
            SocialMediaAccount account)
            throws Exception {

        SocialMediaValidationEvent payload =
                new SocialMediaValidationEvent(
                        account.getId(),
                        account.getPlatform(),
                        account.getAccountName(),
                        account.getProfileUrl());

        BrokerMessage message =
                new BrokerMessage();

        message.setType("PUBLISH");

        message.setTopic(
                "socialmedia.validateinfluencer");

        message.setPayload(payload);
        brokerClient.publish(message);
    }
    public void publishInfluencerProfileUpdate(
            InfluencerProfilePublishEvent account)
            throws Exception {

        BrokerMessage message =
                new BrokerMessage();

        message.setType("PUBLISH");

        message.setTopic(
                "socialmedia.incfluencerprofileupdate");

        message.setPayload(account);
        brokerClient.publish(message);
    }
}