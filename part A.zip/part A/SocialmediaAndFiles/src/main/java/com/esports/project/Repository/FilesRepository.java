package com.esports.project.Repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.Files;

@Repository
public interface FilesRepository extends JpaRepository<Files, String> {

        List<Files> findByUserId(String userId);

        List<Files> findByFileType(String fileType);

        List<Files> findByBucketName(String bucketName);

        List<Files> findByFileNameContainingIgnoreCase(String fileName);

        Page<Files> findByUserId(
                        String userId,
                        Pageable pageable);

        Page<Files> findByFileType(
                        String fileType,
                        Pageable pageable);

        Page<Files> findByBucketName(
                        String bucketName,
                        Pageable pageable);
}