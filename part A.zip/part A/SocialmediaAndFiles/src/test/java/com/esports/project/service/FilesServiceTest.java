package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import com.esports.project.DTO.FilesDTO;
import com.esports.project.Repository.FilesRepository;
import com.esports.project.entity.Files;
import com.esports.project.exception.NotFoundException;

@ExtendWith(MockitoExtension.class)
class FilesServiceTest {

    @Mock
    private FilesRepository repository;

    @InjectMocks
    private FilesService service;

    @Test
void shouldCreateFile() {

    FilesDTO dto = new FilesDTO();

    dto.setFileName("video.mp4");
    dto.setFileType("VIDEO");
    dto.setBucketName("esports");
    dto.setStoragePath("/uploads/video.mp4");
    dto.setFileSize(1000L);
    dto.setUserId("USER001");

    Files file = new Files();

    file.setId("1");
    file.setFileName("video.mp4");

    when(repository.save(any(Files.class)))
            .thenReturn(file);

    Files result = service.createFile(dto);

    assertNotNull(result);
    assertEquals("video.mp4",
            result.getFileName());

    verify(repository)
            .save(any(Files.class));
}
@Test
void shouldReturnFileById() {

    Files file = new Files();

    file.setId("1");
    file.setFileName("test.pdf");

    when(repository.findById("1"))
            .thenReturn(Optional.of(file));

    Files result =
            service.getFileById("1");

    assertNotNull(result);
    assertEquals("test.pdf",
            result.getFileName());

    verify(repository)
            .findById("1");
}
@Test
void shouldThrowExceptionWhenFileNotFound() {

    when(repository.findById("100"))
            .thenReturn(Optional.empty());

    assertThrows(
            NotFoundException.class,
            () -> service.getFileById("100"));

    verify(repository)
            .findById("100");
}
@Test
void shouldDeleteFile() {

    Files file = new Files();

    file.setId("1");

    when(repository.findById("1"))
            .thenReturn(Optional.of(file));

    service.deleteFile("1");

    verify(repository)
            .delete(file);
}
@Test
void shouldReturnFilesByUserId() {

    Page<Files> page =
            new PageImpl<>(
                    List.of(
                            new Files(),
                            new Files()));

    when(repository.findByUserId(
            org.mockito.ArgumentMatchers.eq("USER001"),
            any(Pageable.class)))
            .thenReturn(page);

    Page<Files> result =
            service.getFilesByUserId(
                    "USER001",
                    0,
                    10,
                    "fileName",
                    "asc");

    assertEquals(
            2,
            result.getNumberOfElements());

    verify(repository)
            .findByUserId(
                    org.mockito.ArgumentMatchers.eq("USER001"),
                    any(Pageable.class));
}
@Test
void shouldSearchFileByName() {

    List<Files> files = List.of(
            new Files());

    when(repository.findByFileNameContainingIgnoreCase(
            "video"))
            .thenReturn(files);

    List<Files> result =
            service.searchByFileName("video");

    assertEquals(1,
            result.size());

    verify(repository)
            .findByFileNameContainingIgnoreCase(
                    "video");
}
@Test
void shouldUpdateFile() {

    Files existing = new Files();

    existing.setId("1");
    existing.setFileName("old.pdf");

    FilesDTO dto = new FilesDTO();

    dto.setFileName("new.pdf");
    dto.setFileType("PDF");

    when(repository.findById("1"))
            .thenReturn(Optional.of(existing));

    when(repository.save(any(Files.class)))
            .thenAnswer(
                    invocation -> invocation.getArgument(0));

    Files result =
            service.updateFile("1", dto);

    assertEquals("new.pdf",
            result.getFileName());

    verify(repository)
            .save(existing);
}
@Test
void shouldPatchFile() {

    Files existing = new Files();

    existing.setId("1");
    existing.setFileName("old.pdf");
    existing.setFileType("PDF");

    FilesDTO dto = new FilesDTO();

    dto.setFileName("updated.pdf");

    when(repository.findById("1"))
            .thenReturn(Optional.of(existing));

    when(repository.save(any(Files.class)))
            .thenAnswer(
                    invocation -> invocation.getArgument(0));

    Files result =
            service.patchFile("1", dto);

    assertEquals(
            "updated.pdf",
            result.getFileName());

    assertEquals(
            "PDF",
            result.getFileType());

    verify(repository)
            .save(existing);
}
@Test
void shouldReturnPaginatedFiles() {

    Page<Files> page =
            new PageImpl<>(
                    List.of(
                            new Files(),
                            new Files()));

    when(repository.findAll(any(Pageable.class)))
            .thenReturn(page);

    Page<Files> result =
            service.getAllFiles(
                    0,
                    10,
                    "fileName",
                    "asc");

    assertEquals(
            2,
            result.getContent().size());

    verify(repository)
            .findAll(any(Pageable.class));
}
@Test
void shouldReturnDownloadPath() {

    Files file = new Files();

    file.setId("1");
    file.setStoragePath("/uploads/test.pdf");

    when(repository.findById("1"))
            .thenReturn(Optional.of(file));

    String result =
            service.getFileDownloadPath("1");

    assertEquals(
            "/uploads/test.pdf",
            result);
}
@Test
void shouldReturnFilesByType() {

    Page<Files> page =
            new PageImpl<>(
                    List.of(new Files()));

    when(repository.findByFileType(
            org.mockito.ArgumentMatchers.eq("VIDEO"),
            any(Pageable.class)))
            .thenReturn(page);

    Page<Files> result =
            service.getFilesByType(
                    "VIDEO",
                    0,
                    10,
                    "fileName",
                    "asc");

    assertEquals(
            1,
            result.getContent().size());
}
@Test
void shouldReturnFilesByBucket() {

    Page<Files> page =
            new PageImpl<>(
                    List.of(new Files()));

    when(repository.findByBucketName(
            org.mockito.ArgumentMatchers.eq("bucket1"),
            any(Pageable.class)))
            .thenReturn(page);

    Page<Files> result =
            service.getFilesByBucket(
                    "bucket1",
                    0,
                    10,
                    "fileName",
                    "asc");

    assertEquals(
            1,
            result.getContent().size());
}
@Test
void shouldThrowExceptionWhenUpdatingFileNotFound() {

    when(repository.findById("1"))
            .thenReturn(Optional.empty());

    assertThrows(
            NotFoundException.class,
            () -> service.updateFile(
                    "1",
                    new FilesDTO()));
}
@Test
void shouldThrowExceptionWhenPatchingFileNotFound() {

    when(repository.findById("1"))
            .thenReturn(Optional.empty());

    assertThrows(
            NotFoundException.class,
            () -> service.patchFile(
                    "1",
                    new FilesDTO()));
}
@Test
void shouldThrowExceptionWhenDeletingFileNotFound() {

    when(repository.findById("1"))
            .thenReturn(Optional.empty());

    assertThrows(
            NotFoundException.class,
            () -> service.deleteFile("1"));
}

}