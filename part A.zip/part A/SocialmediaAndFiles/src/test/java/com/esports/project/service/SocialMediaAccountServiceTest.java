package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import com.esports.project.DTO.SocialMediaAccountDTO;
import com.esports.project.Repository.SocialMediaAccountRepository;
import com.esports.project.entity.SocialMediaAccount;
import com.esports.project.exception.NotFoundException;

@ExtendWith(MockitoExtension.class)
class SocialMediaAccountServiceTest {

    @Mock
    private SocialMediaAccountRepository repository;

    @InjectMocks
    private SocialMediaAccountService service;

    @Test
void shouldCreateAccount() {

    SocialMediaAccountDTO dto =
            new SocialMediaAccountDTO();

    dto.setPlatform("YouTube");
    dto.setAccountName("GamingKing");
    dto.setSubscriberCount(10000L);
    dto.setTotalViews(50000L);
    dto.setTotalLikes(4500L);
    dto.setTotalComments(500L);

    SocialMediaAccount account =
            new SocialMediaAccount();

    account.setId("1");
    account.setAccountName("GamingKing");

    when(repository.save(any(
            SocialMediaAccount.class)))
            .thenReturn(account);

    SocialMediaAccount result =
            service.createAccount(dto);

    assertNotNull(result);
    assertEquals(
            "GamingKing",
            result.getAccountName());

    verify(repository)
            .save(any(
                    SocialMediaAccount.class));
}

@Test
void shouldReturnAccountById() {

    SocialMediaAccount account =
            new SocialMediaAccount();

    account.setId("1");

    when(repository.findById("1"))
            .thenReturn(Optional.of(account));

    SocialMediaAccount result =
            service.getAccountById("1");

    assertNotNull(result);

    verify(repository)
            .findById("1");
}
@Test
void shouldThrowExceptionWhenNotFound() {

    when(repository.findById("99"))
            .thenReturn(Optional.empty());

    assertThrows(
            NotFoundException.class,
            () -> service.getAccountById("99"));

    verify(repository)
            .findById("99");
}
@Test
void shouldDeleteAccount() {

    SocialMediaAccount account =
            new SocialMediaAccount();

    account.setId("1");

    when(repository.findById("1"))
            .thenReturn(Optional.of(account));

    service.deleteAccount("1");

    verify(repository)
            .delete(account);
}
@Test
void shouldReturnTopInfluencers() {

    List<SocialMediaAccount> influencers =
            List.of(
                    new SocialMediaAccount(),
                    new SocialMediaAccount());

    Page<SocialMediaAccount> page =
            new PageImpl<>(influencers);

    when(repository
            .findByPlatformIgnoreCaseOrderByGenuineInfluencerScoreDesc(
                    eq("YouTube"),
                    any(Pageable.class)))
            .thenReturn(page);

    Page<SocialMediaAccount> result =
            service.getTopInfluencersByPlatform(
                    "YouTube",
                    0,
                    10
                    );

    assertEquals(
            2,
            result.getContent().size());
}
@Test
void shouldReturnAllAccounts() {

    Page<SocialMediaAccount> page =
            new PageImpl<>(
                    List.of(
                            new SocialMediaAccount(),
                            new SocialMediaAccount()));

    when(repository.findAll(any(Pageable.class)))
            .thenReturn(page);

    Page<SocialMediaAccount> result =
            service.getAllAccounts(
                    0,
                    10,
                    "accountName",
                    "asc");

    assertEquals(
            2,
            result.getContent().size());

    verify(repository)
            .findAll(any(Pageable.class));
}
@Test
void shouldReturnAccountsByUserId() {

    Page<SocialMediaAccount> page =
            new PageImpl<>(
                    List.of(
                            new SocialMediaAccount()));

    when(repository.findByUserId(
            eq("USER001"),
            any(Pageable.class)))
            .thenReturn(page);

    Page<SocialMediaAccount> result =
            service.getAccountsByUserId(
                    "USER001",
                    0,
                    10,
                    "accountName",
                    "asc");

    assertEquals(
            1,
            result.getContent().size());

    verify(repository)
            .findByUserId(
                    eq("USER001"),
                    any(Pageable.class));
}
@Test
void shouldReturnAccountsByPlatform() {

    Page<SocialMediaAccount> page =
            new PageImpl<>(
                    List.of(
                            new SocialMediaAccount()));

    when(repository.findByPlatformIgnoreCase(
            eq("YouTube"),
            any(Pageable.class)))
            .thenReturn(page);

    Page<SocialMediaAccount> result =
            service.getAccountsByPlatform(
                    "YouTube",
                    0,
                    10,
                    "accountName",
                    "asc");

    assertEquals(
            1,
            result.getContent().size());

    verify(repository)
            .findByPlatformIgnoreCase(
                    eq("YouTube"),
                    any(Pageable.class));
}
@Test
void shouldReturnAccountsByStatus() {

    Page<SocialMediaAccount> page =
            new PageImpl<>(
                    List.of(
                            new SocialMediaAccount()));

    when(repository.findByStatusIgnoreCase(
            eq("ACTIVE"),
            any(Pageable.class)))
            .thenReturn(page);

    Page<SocialMediaAccount> result =
            service.getAccountsByStatus(
                    "ACTIVE",
                    0,
                    10,
                    "accountName",
                    "asc");

    assertEquals(
            1,
            result.getContent().size());

    verify(repository)
            .findByStatusIgnoreCase(
                    eq("ACTIVE"),
                    any(Pageable.class));
}
@Test
void shouldSearchByAccountName() {

    List<SocialMediaAccount> accounts =
            List.of(
                    new SocialMediaAccount(),
                    new SocialMediaAccount());

    when(repository.findByAccountNameContainingIgnoreCase(
            "gaming"))
            .thenReturn(accounts);

    List<SocialMediaAccount> result =
            service.searchByAccountName(
                    "gaming");

    assertEquals(
            2,
            result.size());

    verify(repository)
            .findByAccountNameContainingIgnoreCase(
                    "gaming");
}
@Test
void shouldUpdateAccount() {

    SocialMediaAccount account =
            new SocialMediaAccount();

    account.setId("1");
    account.setAccountName("Old");

    account.setSubscriberCount(1000L);
    account.setTotalViews(5000L);
    account.setTotalLikes(500L);
    account.setTotalComments(50L);

    SocialMediaAccountDTO dto =
            new SocialMediaAccountDTO();

    dto.setAccountName("New");

    when(repository.findById("1"))
            .thenReturn(Optional.of(account));

    when(repository.save(any(
            SocialMediaAccount.class)))
            .thenAnswer(i -> i.getArgument(0));

    SocialMediaAccount result =
            service.updateAccount(
                    "1",
                    dto);

    assertEquals(
            "New",
            result.getAccountName());
}
@Test
void shouldPatchAccount() {

    SocialMediaAccount account =
            new SocialMediaAccount();

    account.setId("1");
    account.setAccountName("Old Name");

    account.setSubscriberCount(1000L);
    account.setTotalViews(5000L);
    account.setTotalLikes(500L);
    account.setTotalComments(50L);

    SocialMediaAccountDTO dto =
            new SocialMediaAccountDTO();

    dto.setAccountName("Updated Name");

    when(repository.findById("1"))
            .thenReturn(Optional.of(account));

    when(repository.save(any(
            SocialMediaAccount.class)))
            .thenAnswer(i -> i.getArgument(0));

    SocialMediaAccount result =
            service.patchAccount(
                    "1",
                    dto);

    assertEquals(
            "Updated Name",
            result.getAccountName());

    verify(repository)
            .save(account);
}
@Test
void shouldThrowExceptionWhenUpdatingNonExistingAccount() {

    when(repository.findById("1"))
            .thenReturn(Optional.empty());

    SocialMediaAccountDTO dto =
            new SocialMediaAccountDTO();

    assertThrows(
            NotFoundException.class,
            () -> service.updateAccount(
                    "1",
                    dto));
}
@Test
void shouldThrowExceptionWhenPatchingNonExistingAccount() {

    when(repository.findById("1"))
            .thenReturn(Optional.empty());

    SocialMediaAccountDTO dto =
            new SocialMediaAccountDTO();

    assertThrows(
            NotFoundException.class,
            () -> service.patchAccount(
                    "1",
                    dto));
}

}
