// package com.esports.user_service.test;


// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;

// import java.util.HashSet;
// import java.util.List;
// import java.util.Optional;
// import java.util.Set;

// import com.esports.user_service.DTO.PermissionRequestDTO;
// import com.esports.user_service.entity.Permission;
// import com.esports.user_service.entity.Role;
// import com.esports.user_service.exception.BusinessValidationException;
// import com.esports.user_service.exception.PermissionNotFoundException;
// import com.esports.user_service.exception.ResourceAlreadyExistsException;
// import com.esports.user_service.repository.PermissionRepository;
// import com.esports.user_service.service.PermissionService;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// @ExtendWith(MockitoExtension.class)
// class PermissionServiceTest {

//     @Mock
//     private PermissionRepository permissionRepository;

//     @InjectMocks
//     private PermissionService permissionService;

//     private Permission permission;
 
//     private PermissionRequestDTO request;

//     @BeforeEach
//     void setUp() {

//         permission = new Permission();
//         permission.setId("PERM001");
//         permission.setPermissionName("CREATE_USER");
//         permission.setRoles(new HashSet<>());

//         request = new PermissionRequestDTO();
//         request.setPermissionName("CREATE_USER");
//     }

//     // ==========================================
//     // GET ALL PERMISSIONS
//     // ==========================================

//     @Test
//     void getAllPermissions_Positive() {

//         when(permissionRepository.findAll())
//                 .thenReturn(List.of(permission));

//         List<Permission> result =
//                 permissionService.getAllPermissions();

//         assertEquals(1, result.size());
//         assertEquals(
//                 "CREATE_USER",
//                 result.get(0).getPermissionName());
//     }

//     @Test
//     void getAllPermissions_EdgeCase_EmptyList() {

//         when(permissionRepository.findAll())
//                 .thenReturn(List.of());

//         List<Permission> result =
//                 permissionService.getAllPermissions();

//         assertTrue(result.isEmpty());
//     }

//     // ==========================================
//     // GET PERMISSION BY ID
//     // ==========================================

//     @Test
//     void getPermissionById_Positive() {

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         Permission result =
//                 permissionService.getPermissionById("PERM001");

//         assertEquals("PERM001", result.getId());
//     }

//     @Test
//     void getPermissionById_Negative_NotFound() {

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 PermissionNotFoundException.class,
//                 () -> permissionService
//                         .getPermissionById("PERM001"));
//     }

//     // ==========================================
//     // CREATE PERMISSION
//     // ==========================================

//     @Test
//     void createPermission_Positive() {

//         when(permissionRepository
//                 .existsByPermissionName("CREATE_USER"))
//                 .thenReturn(false);

//         when(permissionRepository.save(any(Permission.class)))
//                 .thenReturn(permission);

//         Permission result =
//                 permissionService.createPermission(request);

//         assertNotNull(result);
//         assertEquals(
//                 "CREATE_USER",
//                 result.getPermissionName());

//         verify(permissionRepository)
//                 .save(any(Permission.class));
//     }

//     @Test
//     void createPermission_Negative_NullName() {

//         request.setPermissionName(null);

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> permissionService
//                         .createPermission(request));
//     }

//     @Test
//     void createPermission_Negative_EmptyName() {

//         request.setPermissionName("");

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> permissionService
//                         .createPermission(request));
//     }

//     @Test
//     void createPermission_Negative_DuplicatePermission() {

//         when(permissionRepository
//                 .existsByPermissionName("CREATE_USER"))
//                 .thenReturn(true);

//         assertThrows(
//                 ResourceAlreadyExistsException.class,
//                 () -> permissionService
//                         .createPermission(request));
//     }

//     @Test
//     void createPermission_EdgeCase_TrimmedName() {

//         request.setPermissionName("   create_user   ");

//         when(permissionRepository
//                 .existsByPermissionName("create_user"))
//                 .thenReturn(false);

//         when(permissionRepository.save(any(Permission.class)))
//                 .thenReturn(permission);

//         assertDoesNotThrow(
//                 () -> permissionService
//                         .createPermission(request));
//     }

//     // ==========================================
//     // UPDATE PERMISSION
//     // ==========================================

//     @Test
//     void updatePermission_Positive() {

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         when(permissionRepository
//                 .findByPermissionName("CREATE_USER"))
//                 .thenReturn(Optional.of(permission));

//         when(permissionRepository.save(any(Permission.class)))
//                 .thenReturn(permission);

//         Permission result =
//                 permissionService.updatePermission(
//                         "PERM001",
//                         request);

//         assertNotNull(result);

//         verify(permissionRepository)
//                 .save(any(Permission.class));
//     }

//     @Test
//     void updatePermission_Negative_PermissionNotFound() {

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 PermissionNotFoundException.class,
//                 () -> permissionService
//                         .updatePermission(
//                                 "PERM001",
//                                 request));
//     }

//     @Test
//     void updatePermission_Negative_EmptyPermissionName() {

//         request.setPermissionName("");

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> permissionService
//                         .updatePermission(
//                                 "PERM001",
//                                 request));
//     }

//     @Test
//     void updatePermission_Negative_DuplicatePermission() {

//         Permission existingPermission =
//                 new Permission();

//         existingPermission.setId("PERM999");

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         when(permissionRepository
//                 .findByPermissionName("CREATE_USER"))
//                 .thenReturn(Optional.of(existingPermission));

//         assertThrows(
//                 ResourceAlreadyExistsException.class,
//                 () -> permissionService
//                         .updatePermission(
//                                 "PERM001",
//                                 request));
//     }

//     @Test
//     void updatePermission_EdgeCase_SamePermissionNameDifferentCase() {

//         request.setPermissionName("create_user");

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         when(permissionRepository
//                 .findByPermissionName("create_user"))
//                 .thenReturn(Optional.of(permission));

//         when(permissionRepository.save(any(Permission.class)))
//                 .thenReturn(permission);

//         assertDoesNotThrow(
//                 () -> permissionService
//                         .updatePermission(
//                                 "PERM001",
//                                 request));
//     }

//     // ==========================================
//     // DELETE PERMISSION
//     // ==========================================

//     @Test
//     void deletePermission_Positive() {

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         permissionService.deletePermission("PERM001");

//         verify(permissionRepository)
//                 .delete(permission);
//     }

//     @Test
//     void deletePermission_Negative_NotFound() {

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 PermissionNotFoundException.class,
//                 () -> permissionService
//                         .deletePermission("PERM001"));
//     }

//     @Test
//     void deletePermission_EdgeCase_AssignedToRole() {

//         Role role = new Role();

//         Set<Role> roles = new HashSet<>();
//         roles.add(role);

//         permission.setRoles(roles);

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> permissionService
//                         .deletePermission("PERM001"));
//     }

//     @Test
//     void deletePermission_EdgeCase_NullRoles() {

//         permission.setRoles(null);

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         assertDoesNotThrow(
//                 () -> permissionService
//                         .deletePermission("PERM001"));
//     }
// }