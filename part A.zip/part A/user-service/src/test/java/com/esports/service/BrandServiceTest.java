package com.esports.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import com.esports.user_service.DTO.BrandProfileDTO;
import com.esports.user_service.DTO.VerificationStatusDTO;
import com.esports.user_service.entity.BrandDetails;
import com.esports.user_service.entity.User;
import com.esports.user_service.exception.BrandVerificationException;
import com.esports.user_service.exception.ResourceNotFoundException;
import com.esports.user_service.repository.BrandDetailsRepository;
import com.esports.user_service.repository.UserRepository;
import com.esports.user_service.service.BrandService;

@ExtendWith(MockitoExtension.class)
class BrandServiceTest {

    @Mock
    private BrandDetailsRepository brandDetailsRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private BrandService brandService;

    private User user;
    private BrandDetails brand;

    @BeforeEach
    void setup() {

        user = new User();
        user.setId("USER001");
        user.setEmail("brand@test.com");

        brand = new BrandDetails();
        brand.setId("BRAND001");
        brand.setBrandName("Test Brand");
        brand.setMobileNumber("9876543210");
        brand.setWebsiteUrl("https://brand.com");
        brand.setLegalEntityIdentifier("LEI123");
        brand.setBusinessAddress("Chennai");
        brand.setVerificationStatus("DRAFT");
        brand.setCreatedAt(LocalDateTime.now());
        brand.setUpdatedAt(LocalDateTime.now());
        brand.setUser(user);

        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(
                        "brand@test.com",
                        null,
                        List.of());

        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(authentication);
        SecurityContextHolder.setContext(context);
    }

    // ========================================================
    // GET BRAND PROFILE
    // ========================================================

    @Test
    void getBrandProfile_Positive() {

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.of(brand));

        BrandProfileDTO result = brandService.getBrandProfile();

        assertNotNull(result);
        assertEquals("Test Brand", result.getBrandName());
    }

    @Test
    void getBrandProfile_Negative_BrandNotFound() {

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> brandService.getBrandProfile());
    }

    @Test
    void getBrandProfile_Edge_NullOptionalField() {

        brand.setWebsiteUrl(null);

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.of(brand));

        BrandProfileDTO result = brandService.getBrandProfile();

        assertNotNull(result);
    }

    // ========================================================
    // SUBMIT VERIFICATION
    // ========================================================

    @Test
    void submitVerification_Positive() {

        brand.setVerificationStatus("DRAFT");

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.of(brand));

        String result = brandService.submitVerification();

        assertEquals(
                "Verification submitted successfully",
                result);

        verify(brandDetailsRepository).save(any(BrandDetails.class));
    }

    @Test
    void submitVerification_Negative_AlreadyApproved() {

        brand.setVerificationStatus("APPROVED");

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.of(brand));

        assertThrows(
                BrandVerificationException.class,
                () -> brandService.submitVerification());
    }

    @Test
    void submitVerification_Edge_AlreadyPending() {

        brand.setVerificationStatus("PENDING");

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.of(brand));

        assertThrows(
                BrandVerificationException.class,
                () -> brandService.submitVerification());
    }

    // ========================================================
    // GET VERIFICATION STATUS
    // ========================================================

    @Test
    void getVerificationStatus_Positive() {

        brand.setVerificationStatus("PENDING");

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.of(brand));

        VerificationStatusDTO result =
                brandService.getVerificationStatus();

        assertEquals("PENDING",
                result.getVerificationStatus());
    }

    @Test
    void getVerificationStatus_Negative_BrandNotFound() {

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> brandService.getVerificationStatus());
    }

    @Test
    void getVerificationStatus_Edge_RejectedStatus() {

        brand.setVerificationStatus("REJECTED");

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.of(brand));

        VerificationStatusDTO result =
                brandService.getVerificationStatus();

        assertEquals("REJECTED",
                result.getVerificationStatus());
    }

    // ========================================================
    // APPROVE BRAND
    // ========================================================

    @Test
    void approveBrand_Positive() {

        when(brandDetailsRepository.findById("BRAND001"))
                .thenReturn(Optional.of(brand));

        when(brandDetailsRepository.save(any()))
                .thenReturn(brand);

        String result =
                brandService.approveBrand("BRAND001");

        assertEquals(
                "Brand approved successfully",
                result);
    }

    @Test
    void approveBrand_Negative_NotFound() {

        when(brandDetailsRepository.findById("BRAND001"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> brandService.approveBrand("BRAND001"));
    }

    @Test
    void approveBrand_Edge_AlreadyApproved() {

        brand.setVerificationStatus("APPROVED");

        when(brandDetailsRepository.findById("BRAND001"))
                .thenReturn(Optional.of(brand));

        assertThrows(
                BrandVerificationException.class,
                () -> brandService.approveBrand("BRAND001"));
    }

    // ========================================================
    // REJECT BRAND
    // ========================================================

    @Test
    void rejectBrand_Positive() {

        when(brandDetailsRepository.findById("BRAND001"))
                .thenReturn(Optional.of(brand));

        when(brandDetailsRepository.save(any()))
                .thenReturn(brand);

        String result =
                brandService.rejectBrand("BRAND001");

        assertEquals(
                "Brand rejected successfully",
                result);
    }

    @Test
    void rejectBrand_Negative_NotFound() {

        when(brandDetailsRepository.findById("BRAND001"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> brandService.rejectBrand("BRAND001"));
    }

    @Test
    void rejectBrand_Edge_AlreadyRejected() {

        brand.setVerificationStatus("REJECTED");

        when(brandDetailsRepository.findById("BRAND001"))
                .thenReturn(Optional.of(brand));

        assertThrows(
                BrandVerificationException.class,
                () -> brandService.rejectBrand("BRAND001"));
    }

    // ========================================================
    // GET PENDING BRANDS
    // ========================================================

    @Test
    void getPendingBrands_Positive() {

        brand.setVerificationStatus("PENDING");

        when(brandDetailsRepository
                .findByVerificationStatus("PENDING"))
                .thenReturn(List.of(brand));

        List<BrandProfileDTO> result =
                brandService.getPendingBrands();

        assertEquals(1, result.size());
    }

    @Test
    void getPendingBrands_Negative_NullResult() {

        when(brandDetailsRepository
                .findByVerificationStatus("PENDING"))
                .thenReturn(null);

        assertThrows(
                NullPointerException.class,
                () -> brandService.getPendingBrands());
    }

    @Test
    void getPendingBrands_Edge_EmptyList() {

        when(brandDetailsRepository
                .findByVerificationStatus("PENDING"))
                .thenReturn(List.of());

        List<BrandProfileDTO> result =
                brandService.getPendingBrands();

        assertTrue(result.isEmpty());
    }

    // ========================================================
    // DELETE BRAND PROFILE
    // ========================================================

    @Test
    void deleteBrandProfile_Positive() {

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.of(brand));

        brandService.deleteBrandProfile();

        verify(brandDetailsRepository).delete(brand);
    }

    @Test
    void deleteBrandProfile_Negative_NotFound() {

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> brandService.deleteBrandProfile());
    }

    @Test
    void deleteBrandProfile_Edge_DeleteAlreadyMappedEntity() {

        when(userRepository.findByEmail("brand@test.com"))
                .thenReturn(Optional.of(user));

        when(brandDetailsRepository.findByUser(user))
                .thenReturn(Optional.of(brand));

        assertDoesNotThrow(() ->
                brandService.deleteBrandProfile());
    }

    // ========================================================
    // GET ALL BRANDS
    // ========================================================

    @Test
    void getAllBrands_Positive() {

        when(brandDetailsRepository.findAll())
                .thenReturn(List.of(brand));

        assertEquals(
                1,
                brandService.getAllBrands().size());
    }

    @Test
    void getAllBrands_Negative_NullResponse() {

        when(brandDetailsRepository.findAll())
                .thenReturn(null);

        assertThrows(
                NullPointerException.class,
                () -> brandService.getAllBrands());
    }

    @Test
    void getAllBrands_Edge_EmptyList() {

        when(brandDetailsRepository.findAll())
                .thenReturn(List.of());

        assertTrue(
                brandService.getAllBrands().isEmpty());
    }
}