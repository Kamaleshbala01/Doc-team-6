// package com.esports.service;

// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;

// import java.time.LocalDateTime;
// import java.util.List;
// import java.util.Optional;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;
// import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
// import org.springframework.security.core.context.SecurityContext;
// import org.springframework.security.core.context.SecurityContextHolder;

// import com.esports.user_service.DTO.OrganizerVerificationDTO;
// import com.esports.user_service.DTO.UserDetailsDTO;
// import com.esports.user_service.entity.OrganizerDetails;
// import com.esports.user_service.entity.User;
// import com.esports.user_service.exception.BusinessValidationException;
// import com.esports.user_service.exception.ResourceNotFoundException;
// import com.esports.user_service.repository.OrganizerDetailsRepository;
// import com.esports.user_service.repository.UserRepository;
// import com.esports.user_service.service.OrganizerDetailsService;

// @ExtendWith(MockitoExtension.class)
// class OrganizerDetailsServiceTest {

//     @Mock
//     private OrganizerDetailsRepository organizerDetailsRepository;

//     @Mock
//     private UserRepository userRepository;

//     @InjectMocks
//     private OrganizerDetailsService organizerDetailsService;

//     private User user;
//     private OrganizerDetails organizer;
//     private OrganizerVerificationDTO request;

//     @BeforeEach
//     void setup() {

//         user = new User();
//         user.setId("USER001");
//         user.setEmail("organizer@test.com");

//         organizer = new OrganizerDetails();
//         organizer.setId("ORG001");
//         organizer.setUser(user);
//         organizer.setGovernmentIdUri("gov-uri");
//         organizer.setSelfieVerificationUri("selfie-uri");
//         organizer.setVerificationStatus("PENDING");
//         organizer.setCreatedAt(LocalDateTime.now());
//         organizer.setUpdatedAt(LocalDateTime.now());

//         request = new OrganizerVerificationDTO();
//         request.setGovernmentIdUri("updated-gov-uri");
//         request.setSelfieVerificationUri("updated-selfie-uri");

//         UserDetailsDTO userDetails = new UserDetailsDTO();
//         userDetails.setUserId("USER001");

//         UsernamePasswordAuthenticationToken authentication =
//                 new UsernamePasswordAuthenticationToken(
//                         userDetails,
//                         null,
//                         List.of());

//         SecurityContext context =
//                 SecurityContextHolder.createEmptyContext();

//         context.setAuthentication(authentication);
//         SecurityContextHolder.setContext(context);
//     }

//     // ====================================================
//     // GET ORGANIZER PROFILE
//     // ====================================================

//     @Test
//     void getOrganizerProfile_Positive() {

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.of(user));

//         when(organizerDetailsRepository.findByUser(user))
//                 .thenReturn(Optional.of(organizer));

//         OrganizerDetails result =
//                 organizerDetailsService.getOrganizerProfile("USER001");

//         assertNotNull(result);
//         assertEquals("ORG001", result.getId());
//     }

//     @Test
//     void getOrganizerProfile_Negative_UserNotFound() {

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> organizerDetailsService.getOrganizerProfile("USER001"));
//     }

//     @Test
//     void getOrganizerProfile_Edge_ProfileNotFound() {

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.of(user));

//         when(organizerDetailsRepository.findByUser(user))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> organizerDetailsService.getOrganizerProfile("USER001"));
//     }

//     // ====================================================
//     // SUBMIT VERIFICATION
//     // ====================================================

//     @Test
//     void submitVerification_Positive() {

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.of(user));

//         when(organizerDetailsRepository.findByUser(user))
//                 .thenReturn(Optional.empty());

//         when(organizerDetailsRepository.save(any()))
//                 .thenReturn(organizer);

//         OrganizerDetails result =
//                 organizerDetailsService.submitVerification(request);

//         assertNotNull(result);
//     }

//     @Test
//     void submitVerification_Negative_UserNotFound() {

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> organizerDetailsService.submitVerification(request));
//     }

//     @Test
//     void submitVerification_Edge_AlreadyPending() {

//         organizer.setVerificationStatus("PENDING");

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.of(user));

//         when(organizerDetailsRepository.findByUser(user))
//                 .thenReturn(Optional.of(organizer));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> organizerDetailsService.submitVerification(request));
//     }

//     // ====================================================
//     // UPDATE PROFILE
//     // ====================================================

//     @Test
//     void updateOrganizerProfile_Positive() {

//         organizer.setVerificationStatus("PENDING");

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.of(user));

//         when(organizerDetailsRepository.findByUser(user))
//                 .thenReturn(Optional.of(organizer));

//         when(organizerDetailsRepository.save(any()))
//                 .thenReturn(organizer);

//         OrganizerDetails result =
//                 organizerDetailsService.updateOrganizerProfile(request);

//         assertNotNull(result);
//     }

//     @Test
//     void updateOrganizerProfile_Negative_MissingGovernmentId() {

//         request.setGovernmentIdUri("");

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.of(user));

//         when(organizerDetailsRepository.findByUser(user))
//                 .thenReturn(Optional.of(organizer));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> organizerDetailsService.updateOrganizerProfile(request));
//     }

//     @Test
//     void updateOrganizerProfile_Edge_ApprovedProfile() {

//         organizer.setVerificationStatus("APPROVED");

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.of(user));

//         when(organizerDetailsRepository.findByUser(user))
//                 .thenReturn(Optional.of(organizer));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> organizerDetailsService.updateOrganizerProfile(request));
//     }

//     // ====================================================
//     // DELETE PROFILE
//     // ====================================================

//     @Test
//     void deleteOrganizerProfile_Positive() {

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.of(user));

//         when(organizerDetailsRepository.findByUser(user))
//                 .thenReturn(Optional.of(organizer));

//         organizerDetailsService.deleteOrganizerProfile("USER001");

//         verify(organizerDetailsRepository)
//                 .delete(organizer);
//     }

//     @Test
//     void deleteOrganizerProfile_Negative_ProfileNotFound() {

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.of(user));

//         when(organizerDetailsRepository.findByUser(user))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> organizerDetailsService.deleteOrganizerProfile("USER001"));
//     }

//     @Test
//     void deleteOrganizerProfile_Edge_ApprovedProfile() {

//         organizer.setVerificationStatus("APPROVED");

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.of(user));

//         when(organizerDetailsRepository.findByUser(user))
//                 .thenReturn(Optional.of(organizer));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> organizerDetailsService.deleteOrganizerProfile("USER001"));
//     }

//     // ====================================================
//     // APPROVE ORGANIZER
//     // ====================================================

//     @Test
//     void approveOrganizer_Positive() {

//         organizer.setVerificationStatus("PENDING");

//         when(organizerDetailsRepository.findById("ORG001"))
//                 .thenReturn(Optional.of(organizer));

//         when(organizerDetailsRepository.save(any()))
//                 .thenReturn(organizer);

//         OrganizerDetails result =
//                 organizerDetailsService.approveOrganizer("ORG001");

//         assertNotNull(result);
//     }

//     @Test
//     void approveOrganizer_Negative_NotFound() {

//         when(organizerDetailsRepository.findById("ORG001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> organizerDetailsService.approveOrganizer("ORG001"));
//     }

//     @Test
//     void approveOrganizer_Edge_AlreadyApproved() {

//         organizer.setVerificationStatus("APPROVED");

//         when(organizerDetailsRepository.findById("ORG001"))
//                 .thenReturn(Optional.of(organizer));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> organizerDetailsService.approveOrganizer("ORG001"));
//     }

//     // ====================================================
//     // REJECT ORGANIZER
//     // ====================================================

//     @Test
//     void rejectOrganizer_Positive() {

//         organizer.setVerificationStatus("PENDING");

//         when(organizerDetailsRepository.findById("ORG001"))
//                 .thenReturn(Optional.of(organizer));

//         when(organizerDetailsRepository.save(any()))
//                 .thenReturn(organizer);

//         OrganizerDetails result =
//                 organizerDetailsService.rejectOrganizer("ORG001");

//         assertNotNull(result);
//     }

//     @Test
//     void rejectOrganizer_Negative_NotFound() {

//         when(organizerDetailsRepository.findById("ORG001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> organizerDetailsService.rejectOrganizer("ORG001"));
//     }

//     @Test
//     void rejectOrganizer_Edge_AlreadyRejected() {

//         organizer.setVerificationStatus("REJECTED");

//         when(organizerDetailsRepository.findById("ORG001"))
//                 .thenReturn(Optional.of(organizer));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> organizerDetailsService.rejectOrganizer("ORG001"));
//     }

//     // ====================================================
//     // GET VERIFICATION STATUS
//     // ====================================================

//     @Test
//     void getVerificationStatus_Positive() {

//         when(userRepository.findById("USER001"))
//                 .thenReturn(Optional.of(user));

//         when(organizerDetailsRepository.findByUser(user))
//                 .thenReturn(Optional.of(organizer));

//         String status =
//                 organizerDetailsService.getVerificationStatus("USER001");

//         assertEquals("PENDING", status);
//     }

//     // ====================================================
//     // GET PENDING ORGANIZERS
//     // ====================================================

//     @Test
//     void getPendingOrganizers_Positive() {

//         when(organizerDetailsRepository
//                 .findByVerificationStatus("PENDING"))
//                 .thenReturn(List.of(organizer));

//         assertEquals(
//                 1,
//                 organizerDetailsService.getPendingOrganizers().size());
//     }

//     @Test
//     void getPendingOrganizers_Edge_EmptyList() {

//         when(organizerDetailsRepository
//                 .findByVerificationStatus("PENDING"))
//                 .thenReturn(List.of());

//         assertTrue(
//                 organizerDetailsService.getPendingOrganizers().isEmpty());
//     }

//     // ====================================================
//     // GET ALL
//     // ====================================================

//     @Test
//     void getAll_Positive() {

//         when(organizerDetailsRepository.findAll())
//                 .thenReturn(List.of(organizer));

//         assertEquals(
//                 1,
//                 organizerDetailsService.getAll().size());
//     }

//     @Test
//     void getAll_Edge_EmptyList() {

//         when(organizerDetailsRepository.findAll())
//                 .thenReturn(List.of());

//         assertTrue(
//                 organizerDetailsService.getAll().isEmpty());
//     }
// }