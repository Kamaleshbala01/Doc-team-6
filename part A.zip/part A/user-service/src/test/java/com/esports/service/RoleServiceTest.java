// package com.esports.user_service.test;



// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;

// import java.time.LocalDateTime;
// import java.util.HashSet;
// import java.util.List;
// import java.util.Optional;
// import java.util.Set;

// import com.esports.user_service.DTO.RoleRequestDTO;
// import com.esports.user_service.DTO.RoleResponseDTO;
// import com.esports.user_service.entity.Permission;
// import com.esports.user_service.entity.Role;
// import com.esports.user_service.exception.BusinessValidationException;
// import com.esports.user_service.exception.ResourceAlreadyExistsException;
// import com.esports.user_service.exception.ResourceNotFoundException;
// import com.esports.user_service.repository.PermissionRepository;
// import com.esports.user_service.repository.RoleRepository;
// import com.esports.user_service.service.RoleService;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.junit.jupiter.MockitoExtension;

// @ExtendWith(MockitoExtension.class)
// class RoleServiceTest {

//     @Mock
//     private RoleRepository roleRepository;

//     @Mock
//     private PermissionRepository permissionRepository;

//     @InjectMocks
//     private RoleService roleService;

//     private Role role;
//     private Permission permission;
//     private RoleRequestDTO request;

//     @BeforeEach
//     void setUp() {

//         permission = new Permission();
//         permission.setId("PERM001");

//         role = new Role();
//         role.setId("ROLE001");
//         role.setRoleName("ADMIN");
//         role.setCreatedAt(LocalDateTime.now());
//         role.setPermissions(new HashSet<>());

//         request = new RoleRequestDTO();
//         request.setRoleName("ADMIN");
//     }

//     // ==========================================
//     // GET ALL ROLES
//     // ==========================================

//     @Test
//     void getAllRoles_Positive() {

//         when(roleRepository.findAll())
//                 .thenReturn(List.of(role));

//         List<RoleResponseDTO> response =
//                 roleService.getAllRoles();

//         assertEquals(1, response.size());
//         assertEquals("ADMIN",
//                 response.get(0).getRoleName());
//     }

//     @Test
//     void getAllRoles_EdgeCase_EmptyList() {

//         when(roleRepository.findAll())
//                 .thenReturn(List.of());

//         List<RoleResponseDTO> response =
//                 roleService.getAllRoles();

//         assertTrue(response.isEmpty());
//     }

//     // ==========================================
//     // GET ROLE BY ID
//     // ==========================================

//     @Test
//     void getRoleById_Positive() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         RoleResponseDTO response =
//                 roleService.getRoleById("ROLE001");

//         assertEquals("ROLE001",
//                 response.getId());
//     }

//     @Test
//     void getRoleById_Negative_NotFound() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> roleService.getRoleById("ROLE001"));
//     }

//     // ==========================================
//     // CREATE ROLE
//     // ==========================================

//     @Test
//     void createRole_Positive() {

//         when(roleRepository.existsByRoleName("ADMIN"))
//                 .thenReturn(false);

//         when(roleRepository.save(any(Role.class)))
//                 .thenReturn(role);

//         RoleResponseDTO response =
//                 roleService.createRole(request);

//         assertNotNull(response);
//         assertEquals("ADMIN",
//                 response.getRoleName());

//         verify(roleRepository).save(any(Role.class));
//     }

//     @Test
//     void createRole_Negative_NullRoleName() {

//         request.setRoleName(null);

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> roleService.createRole(request));
//     }

//     @Test
//     void createRole_Negative_EmptyRoleName() {

//         request.setRoleName("");

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> roleService.createRole(request));
//     }

//     @Test
//     void createRole_Negative_DuplicateRole() {

//         when(roleRepository.existsByRoleName("ADMIN"))
//                 .thenReturn(true);

//         assertThrows(
//                 ResourceAlreadyExistsException.class,
//                 () -> roleService.createRole(request));
//     }

//     @Test
//     void createRole_EdgeCase_TrimAndUpperCaseRoleName() {

//         request.setRoleName("   admin   ");

//         when(roleRepository.existsByRoleName("admin"))
//                 .thenReturn(false);

//         when(roleRepository.save(any(Role.class)))
//                 .thenReturn(role);

//         assertDoesNotThrow(
//                 () -> roleService.createRole(request));
//     }

//     // ==========================================
//     // UPDATE ROLE
//     // ==========================================

//     @Test
//     void updateRole_Positive() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         when(roleRepository.findByRoleName("ADMIN"))
//         .thenReturn(Optional.of(role));

//         when(roleRepository.save(any(Role.class)))
//                 .thenReturn(role);

//         RoleResponseDTO response =
//                 roleService.updateRole("ROLE001",
//                         request);

//         assertNotNull(response);
//     }

//     @Test
//     void updateRole_Negative_RoleNotFound() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> roleService.updateRole(
//                         "ROLE001",
//                         request));
//     }

//     @Test
//     void updateRole_Negative_EmptyRoleName() {

//         request.setRoleName("");

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> roleService.updateRole(
//                         "ROLE001",
//                         request));
//     }

//     @Test
//     void updateRole_Negative_DuplicateRoleName() {

//         Role existingRole = new Role();
//         existingRole.setId("ROLE999");

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         when(roleRepository.findByRoleName("ADMIN"))
//         .thenReturn(Optional.of(existingRole));
        
//         assertThrows(
//                 ResourceAlreadyExistsException.class,
//                 () -> roleService.updateRole(
//                         "ROLE001",
//                         request));
//     }

//     // ==========================================
//     // DELETE ROLE
//     // ==========================================

//     @Test
//     void deleteRole_Positive() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         roleService.deleteRole("ROLE001");

//         verify(roleRepository)
//                 .delete(role);
//     }

//     @Test
//     void deleteRole_Negative_NotFound() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> roleService.deleteRole("ROLE001"));
//     }

//     @Test
//     void deleteRole_EdgeCase_SuperAdminCannotDelete() {

//         role.setRoleName("SUPER_ADMIN");

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> roleService.deleteRole("ROLE001"));
//     }

//     // ==========================================
//     // GET ROLE PERMISSIONS
//     // ==========================================

//     @Test
//     void getRolePermissions_Positive() {

//         role.getPermissions().add(permission);

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         Set<Permission> result =
//                 roleService.getRolePermissions("ROLE001");

//         assertEquals(1, result.size());
//     }

//     @Test
//     void getRolePermissions_Negative_NotFound() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> roleService.getRolePermissions(
//                         "ROLE001"));
//     }

//     // ==========================================
//     // ASSIGN PERMISSION
//     // ==========================================

//     @Test
//     void assignPermission_Positive() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         when(roleRepository.save(any(Role.class)))
//                 .thenReturn(role);

//         Role response =
//                 roleService.assignPermission(
//                         "ROLE001",
//                         "PERM001");

//         assertNotNull(response);
//     }

//     @Test
//     void assignPermission_Negative_RoleNotFound() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> roleService.assignPermission(
//                         "ROLE001",
//                         "PERM001"));
//     }

//     @Test
//     void assignPermission_Negative_PermissionNotFound() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> roleService.assignPermission(
//                         "ROLE001",
//                         "PERM001"));
//     }

//     @Test
//     void assignPermission_EdgeCase_AlreadyAssigned() {

//         role.getPermissions().add(permission);

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> roleService.assignPermission(
//                         "ROLE001",
//                         "PERM001"));
//     }

//     // ==========================================
//     // REMOVE PERMISSION
//     // ==========================================

//     @Test
//     void removePermission_Positive() {

//         role.getPermissions().add(permission);

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         when(roleRepository.save(any(Role.class)))
//                 .thenReturn(role);

//         Role response =
//                 roleService.removePermission(
//                         "ROLE001",
//                         "PERM001");

//         assertNotNull(response);
//     }

//     @Test
//     void removePermission_Negative_RoleNotFound() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> roleService.removePermission(
//                         "ROLE001",
//                         "PERM001"));
//     }

//     @Test
//     void removePermission_Negative_PermissionNotFound() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.empty());

//         assertThrows(
//                 ResourceNotFoundException.class,
//                 () -> roleService.removePermission(
//                         "ROLE001",
//                         "PERM001"));
//     }

//     @Test
//     void removePermission_EdgeCase_NotAssigned() {

//         when(roleRepository.findById("ROLE001"))
//                 .thenReturn(Optional.of(role));

//         when(permissionRepository.findById("PERM001"))
//                 .thenReturn(Optional.of(permission));

//         assertThrows(
//                 BusinessValidationException.class,
//                 () -> roleService.removePermission(
//                         "ROLE001",
//                         "PERM001"));
//     }
// }