package com.esports.service;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import com.esports.user_service.DTO.UserDetailsDTO;
import com.esports.user_service.DTO.UserProfileRequestDTO;
import com.esports.user_service.entity.User;
import com.esports.user_service.entity.UserProfile;
import com.esports.user_service.enums.StatusMaster;
import com.esports.user_service.exception.ResourceAlreadyExistsException;
import com.esports.user_service.exception.ResourceNotFoundException;
import com.esports.user_service.repository.UserProfileRepository;
import com.esports.user_service.repository.UserRepository;
import com.esports.user_service.service.UserEventPublisher;
import com.esports.user_service.service.UserProfileService;

@ExtendWith(MockitoExtension.class)
class UserProfileServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private UserProfileRepository userProfileRepository;

    @Mock
    private UserEventPublisher publisher;

    @InjectMocks
    private UserProfileService userProfileService;

    private User user;
    private UserProfile profile;
    private UserDetailsDTO currentUser;

    @BeforeEach
    void setup() {

        currentUser = new UserDetailsDTO();
        currentUser.setUserId("user1");

        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(
                        currentUser,
                        null,
                        null));

        user = new User();
        user.setId("user1");

        profile = new UserProfile();
        profile.setId("profile1");
        profile.setUser(user);
        profile.setFirstName("John");
        profile.setLastName("Doe");
        profile.setBio("Bio");
        profile.setStatus(StatusMaster.PENDING);
    }

    // ================= CREATE PROFILE =================

    @Test
    void createProfileSuccess() {

        UserProfileRequestDTO request = new UserProfileRequestDTO();
        request.setFirstName("John");
        request.setLastName("Doe");
        request.setBio("Bio");

        when(userRepository.findById("user1"))
                .thenReturn(Optional.of(user));

        when(userProfileRepository.findByUser(user))
                .thenReturn(Optional.empty());

        when(userProfileRepository.save(any(UserProfile.class)))
                .thenAnswer(i -> i.getArgument(0));

        UserProfile result =
                userProfileService.createProfile(request);

        assertNotNull(result);
        assertEquals("John", result.getFirstName());

        verify(userProfileRepository).save(any(UserProfile.class));
    }

    @Test
    void createProfileUserNotFound() {

        UserProfileRequestDTO request =
                new UserProfileRequestDTO();

        when(userRepository.findById("user1"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> userProfileService.createProfile(request));
    }

    @Test
    void createProfileAlreadyExists() {

        UserProfileRequestDTO request =
                new UserProfileRequestDTO();

        when(userRepository.findById("user1"))
                .thenReturn(Optional.of(user));

        when(userProfileRepository.findByUser(user))
                .thenReturn(Optional.of(profile));

        assertThrows(
                ResourceAlreadyExistsException.class,
                () -> userProfileService.createProfile(request));
    }

    // ================= GET PROFILE =================

    @Test
    void getProfileSuccess() {

        when(userRepository.findById("user1"))
                .thenReturn(Optional.of(user));

        when(userProfileRepository.findByUser(user))
                .thenReturn(Optional.of(profile));

        UserProfile result =
                userProfileService.getProfile();

        assertNotNull(result);
        assertEquals("John", result.getFirstName());
    }

    @Test
    void getProfileUserNotFound() {

        when(userRepository.findById("user1"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> userProfileService.getProfile());
    }

    @Test
    void getProfileNotFound() {

        when(userRepository.findById("user1"))
                .thenReturn(Optional.of(user));

        when(userProfileRepository.findByUser(user))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> userProfileService.getProfile());
    }

    // ================= UPDATE PROFILE =================

    @Test
    void updateProfileSuccess() {

        UserProfile request = new UserProfile();
        request.setFirstName("Updated");
        request.setLastName("User");
        request.setBio("Updated Bio");
        request.setProfileImageURI("img.png");

        when(userRepository.findById("user1"))
                .thenReturn(Optional.of(user));

        when(userProfileRepository.findByUser(user))
                .thenReturn(Optional.of(profile));

        when(userProfileRepository.save(any(UserProfile.class)))
                .thenAnswer(i -> i.getArgument(0));

        UserProfile updated =
                userProfileService.updateProfile(request);

        assertEquals("Updated", updated.getFirstName());
        assertEquals("Updated Bio", updated.getBio());
    }

    // ================= APPLY INFLUENCER =================

    @Test
    void applyInfluencerSuccess() {

        when(userProfileRepository.findByUserId("user1"))
                .thenReturn(Optional.of(profile));

        when(userProfileRepository.save(any(UserProfile.class)))
                .thenAnswer(i -> i.getArgument(0));

        UserProfile result =
                userProfileService.applyInfluencer("user1");

        assertEquals(StatusMaster.PENDING, result.getStatus());
        assertFalse(result.getIsInfluencer());
    }

    @Test
    void applyInfluencerProfileNotFound() {

        when(userProfileRepository.findByUserId("user1"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> userProfileService.applyInfluencer("user1"));
    }

    // ================= STATUS =================

  

    @Test
    void getInfluencerStatusNotFound() {

        when(userProfileRepository.findByUserId("user1"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> userProfileService.getInfluencerStatus("user1"));
    }

    
}
