package com.esports.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;


import com.esports.user_service.DTO.LoginRequestDTO;
import com.esports.user_service.DTO.RegisterUserRequestDTO;
import com.esports.user_service.DTO.UserResponseDTO;
import com.esports.user_service.entity.Role;
import com.esports.user_service.entity.User;
import com.esports.user_service.exception.InvalidEmailException;
import com.esports.user_service.exception.InvalidPasswordException;
import com.esports.user_service.exception.ResourceAlreadyExistsException;
import com.esports.user_service.exception.ResourceNotFoundException;
import com.esports.user_service.repository.RoleRepository;
import com.esports.user_service.repository.UserRepository;
import com.esports.user_service.service.JwtService;
import com.esports.user_service.service.UserService;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private JwtService jwtService;

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private UserService userService;

    private User user;
    private Role role;

    @BeforeEach
    void setup() {

        role = new Role();
        role.setRoleName("USER");

        user = new User();
        user.setId("1");
        user.setUsername("john");
        user.setEmail("john@test.com");
        user.setMobileNumber("9876543210");
        user.setStatus("ACTIVE");
        user.setEmailVerified(true);
        user.setMobileVerifed(true);
        user.setCreatedAt(LocalDateTime.now());
        user.getRoles().add(role);
    }

    // ================= LOGIN =================

    @Test
    void loginSuccess() {

        LoginRequestDTO request = new LoginRequestDTO();
        request.setUsername("john");
        request.setPassword("password");

        when(authenticationManager.authenticate(any(
                UsernamePasswordAuthenticationToken.class)))
                .thenReturn(authentication);

        when(authentication.isAuthenticated()).thenReturn(true);

        when(userRepository.findByUsername("john"))
                .thenReturn(Optional.of(user));

        when(jwtService.generateToken(user))
                .thenReturn("jwt-token");

        String result = userService.login(request);

        assertEquals("jwt-token", result);
    }

    @Test
    void loginShouldThrowWhenAuthenticationFails() {

        LoginRequestDTO request = new LoginRequestDTO();
        request.setUsername("john");
        request.setPassword("wrong");

        when(authenticationManager.authenticate(any()))
                .thenReturn(authentication);

        when(authentication.isAuthenticated()).thenReturn(false);

        assertThrows(
                InvalidPasswordException.class,
                () -> userService.login(request));
    }

    @Test
    void loginShouldThrowWhenUserNotFound() {

        LoginRequestDTO request = new LoginRequestDTO();
        request.setUsername("john");
        request.setPassword("password");

        when(authenticationManager.authenticate(any()))
                .thenReturn(authentication);

        when(authentication.isAuthenticated()).thenReturn(true);

        when(userRepository.findByUsername("john"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> userService.login(request));
    }

    
    // ================= REGISTER =================

    @Test
    void registerSuccess() {

        RegisterUserRequestDTO dto =
                new RegisterUserRequestDTO();

        dto.setUsername("john");
        dto.setPassword("password");
        dto.setEmail("john@test.com");
        dto.setMobileNumber("9876543210");

        when(userRepository.existsByUsername(anyString()))
                .thenReturn(false);

        when(userRepository.existsByEmail(anyString()))
                .thenReturn(false);

        when(userRepository.existsByMobileNumber(anyString()))
                .thenReturn(false);

        when(roleRepository.findByRoleName("USER"))
                .thenReturn(Optional.of(role));

        when(userRepository.save(any(User.class)))
                .thenReturn(user);

        User saved = userService.register(dto, "USER");

        assertNotNull(saved);
    }

    @Test
    void registerShouldFailWhenUsernameExists() {

        RegisterUserRequestDTO dto =
                new RegisterUserRequestDTO();

        dto.setUsername("john");

        when(userRepository.existsByUsername("john"))
                .thenReturn(true);

        assertThrows(
                ResourceAlreadyExistsException.class,
                () -> userService.register(dto, "USER"));
    }

    @Test
    void registerShouldFailWhenEmailExists() {

        RegisterUserRequestDTO dto =
                new RegisterUserRequestDTO();

        dto.setUsername("john");
        dto.setEmail("john@test.com");

        when(userRepository.existsByUsername(anyString()))
                .thenReturn(false);

        when(userRepository.existsByEmail(anyString()))
                .thenReturn(true);

        assertThrows(
                ResourceAlreadyExistsException.class,
                () -> userService.register(dto, "USER"));
    }

    @Test
    void registerShouldFailWhenMobileExists() {

        RegisterUserRequestDTO dto =
                new RegisterUserRequestDTO();

        dto.setUsername("john");
        dto.setEmail("john@test.com");
        dto.setMobileNumber("9876543210");

        when(userRepository.existsByUsername(anyString()))
                .thenReturn(false);

        when(userRepository.existsByEmail(anyString()))
                .thenReturn(false);

        when(userRepository.existsByMobileNumber(anyString()))
                .thenReturn(true);

        assertThrows(
                ResourceAlreadyExistsException.class,
                () -> userService.register(dto, "USER"));
    }

    @Test
    void registerShouldFailWhenEmailInvalid() {

        RegisterUserRequestDTO dto =
                new RegisterUserRequestDTO();

        dto.setUsername("john");
        dto.setPassword("password");
        dto.setEmail("invalid");
        dto.setMobileNumber("9876543210");

        when(userRepository.existsByUsername(anyString()))
                .thenReturn(false);

        when(userRepository.existsByEmail(anyString()))
                .thenReturn(false);

        when(userRepository.existsByMobileNumber(anyString()))
                .thenReturn(false);

        assertThrows(
                InvalidEmailException.class,
                () -> userService.register(dto, "USER"));
    }

    @Test
    void registerShouldFailWhenRoleNotFound() {

        RegisterUserRequestDTO dto =
                new RegisterUserRequestDTO();

        dto.setUsername("john");
        dto.setPassword("password");
        dto.setEmail("john@test.com");
        dto.setMobileNumber("9876543210");

        when(userRepository.existsByUsername(anyString()))
                .thenReturn(false);

        when(userRepository.existsByEmail(anyString()))
                .thenReturn(false);

        when(userRepository.existsByMobileNumber(anyString()))
                .thenReturn(false);

        when(roleRepository.findByRoleName("USER"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> userService.register(dto, "USER"));
    }

    // ================= GET USER =================

    @Test
    void getUserByIdSuccess() {

        when(userRepository.findById("1"))
                .thenReturn(Optional.of(user));

        Optional<User> result =
                userService.getUserById("1");

        assertTrue(result.isPresent());
    }

    @Test
    void getUserByIdNotFound() {

        when(userRepository.findById("1"))
                .thenReturn(Optional.empty());

        Optional<User> result =
                userService.getUserById("1");

        assertTrue(result.isEmpty());
    }

    // ================= GET USERS =================

    @Test
    void getUsersSuccess() {

        when(userRepository.findAll())
                .thenReturn(List.of(user));

        List<UserResponseDTO> result =
                userService.getUsers();

        assertEquals(1, result.size());
        assertEquals("john", result.get(0).getUsername());
    }
}