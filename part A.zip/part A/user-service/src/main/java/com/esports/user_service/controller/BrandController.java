package com.esports.user_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.user_service.DTO.BrandDetailsDTO;
import com.esports.user_service.service.BrandService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class BrandController {

	
	@Autowired
    private BrandService brandService;

    // =====================================================
    // BRAND PROFILE
    // =====================================================

    @GetMapping("/brands/profile")
    @PreAuthorize("hasAuthority('BRAND_PROFILE_READ')")
    public ResponseEntity<?> getBrandProfile() {
        return ResponseEntity.ok(brandService.getBrandProfile());
    }

   

    @DeleteMapping("/brands/profile")
    @PreAuthorize("hasAuthority('BRAND_PROFILE_DELETE')")
    public ResponseEntity<?> deleteBrandProfile() {

        brandService.deleteBrandProfile();

        return ResponseEntity.ok("Brand profile deleted successfully");
    }
    
    

    // =====================================================
    // BRAND VERIFICATION
    // =====================================================

    @PostMapping("/brands/verification/submit")
    @PreAuthorize("hasAuthority('BRAND_VERIFICATION_SUBMIT')")
    public ResponseEntity<?> submitVerification() {

        return ResponseEntity.ok(
                brandService.submitVerification());
    }

    @GetMapping("/brands/verification-status")
    @PreAuthorize("hasAuthority('BRAND_VERIFICATION_STATUS_READ')")
    public ResponseEntity<?> getVerificationStatus() {

        return ResponseEntity.ok(
                brandService.getVerificationStatus());
    }

    // =====================================================
    // ADMIN APIS
    // =====================================================
    
    
    @GetMapping
    @PreAuthorize("hasAuthority('BRAND_READ_ALL')")
    public ResponseEntity<List<BrandDetailsDTO>> getAllBrands() {
    return ResponseEntity.ok(brandService.getAllBrands());
    
    }
    

    @GetMapping("/admin/brands/pending")
    @PreAuthorize("hasAuthority('BRAND_READ_PENDING')")
    public ResponseEntity<?> getPendingBrands() {

        return ResponseEntity.ok(
                brandService.getPendingBrands());
    }

    @GetMapping("/admin/brands/rejected")
    @PreAuthorize("hasAuthority('BRAND_READ_REJECTED')")
    public ResponseEntity<?> getRejectedBrands() {

        return ResponseEntity.ok(
                brandService.getRejectedBrands());
    }

    @GetMapping("/admin/brands/{brandId}")
    @PreAuthorize("hasAuthority('BRAND_READ')")
    public ResponseEntity<?> getBrandVerificationDetails(
            @PathVariable String brandId) {

        return ResponseEntity.ok(
                brandService.getBrandVerificationDetails(brandId));
    }

    @PutMapping("/admin/brands/{brandId}/approve")
    @PreAuthorize("hasAuthority('BRAND_APPROVE')")
    public ResponseEntity<?> approveBrand(
            @PathVariable String brandId) {

        return ResponseEntity.ok(
                brandService.approveBrand(brandId));
    }

    @PutMapping("/admin/brands/{brandId}/reject")
    @PreAuthorize("hasAuthority('BRAND_REJECT')")
    public ResponseEntity<?> rejectBrand(
            @PathVariable String brandId) {

        return ResponseEntity.ok(
                brandService.rejectBrand(brandId));
    }
    
    
    @PostMapping("/create")
    @PreAuthorize("hasAuthority('BRAND_CREATE')")
    public ResponseEntity<BrandDetailsDTO> createBrand( @RequestBody BrandDetailsDTO dto) {

        return new ResponseEntity<>( brandService.createBrand(dto), HttpStatus.CREATED);
    }
    
    @PutMapping("/update/brand")
    @PreAuthorize("hasAuthority('BRAND_UPDATE')")
    public ResponseEntity<BrandDetailsDTO> updateBrand(@RequestBody BrandDetailsDTO dto) {

        return ResponseEntity.ok(brandService.updateBrand(dto));
    }
}