package com.esports.user_service.exception;

public class InvalidMobileNumberException extends RuntimeException {

	public InvalidMobileNumberException(String message) {
		super(message);
		
	}

}
