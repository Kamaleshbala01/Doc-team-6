package com.esports.user_service.service;

import org.springframework.stereotype.Service;

import com.esports.user_service.DTO.NotificationEventDTO;
import com.esports.user_service.DTO.BrokerMessage;
import com.esports.user_service.websocket.PublisherBrokerClient;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserEventPublisher {

	
    private final PublisherBrokerClient brokerClient;

    public void publishNotification(
            NotificationEventDTO notification)
            throws Exception {

        BrokerMessage message =
                new BrokerMessage();

        message.setType("PUBLISH");

        message.setTopic(
                "user.notification");

        message.setPayload(notification);
        brokerClient.publish(message);
    }
}