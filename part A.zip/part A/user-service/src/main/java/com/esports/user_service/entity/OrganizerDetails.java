package com.esports.user_service.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "organizer_details")
public class OrganizerDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String governmentIdUri;
    private String selfieVerificationUri;
    private String verificationStatus;
    private LocalDateTime verifiedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getGovernmentIdUri() {
		return governmentIdUri;
	}

	public void setGovernmentIdUri(String governmentIdUri) {
		this.governmentIdUri = governmentIdUri;
	}

	public String getSelfieVerificationUri() {
		return selfieVerificationUri;
	}

	public void setSelfieVerificationUri(String selfieVerificationUri) {
		this.selfieVerificationUri = selfieVerificationUri;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	public LocalDateTime getVerifiedAt() {
		return verifiedAt;
	}

	public void setVerifiedAt(LocalDateTime verifiedAt) {
		this.verifiedAt = verifiedAt;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/**
     * Relationship mapping
     */

     @OneToOne
     @JoinColumn(name = "user_id")
     @JsonIgnore
     private User user;
}
