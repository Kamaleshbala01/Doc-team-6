package com.esports.user_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.user_service.DTO.OrganizerVerificationDTO;
import com.esports.user_service.entity.OrganizerDetails;
import com.esports.user_service.service.OrganizerDetailsService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/auth/OrganizerDetails")
public class OrganizerDetailsController {

	@Autowired
    private OrganizerDetailsService organizerService;

    @GetMapping("/profile")
    @PreAuthorize("hasAuthority('ORGANIZER_PROFILE_READ')")
    public ResponseEntity<OrganizerDetails> getOrganizerProfile(@RequestParam String userId) { 
    	return ResponseEntity.ok(organizerService.getOrganizerProfile(userId));
    	}

    @PutMapping("/profile")
    @PreAuthorize("hasAuthority('ORGANIZER_PROFILE_UPDATE')")
    public ResponseEntity<OrganizerDetails> updateOrganizerProfile( @RequestBody OrganizerVerificationDTO request) {
    	return ResponseEntity.ok(organizerService.updateOrganizerProfile(request));
    	}

    @DeleteMapping("/profile")
    @PreAuthorize("hasAuthority('ORGANIZER_PROFILE_DELETE')")
    public ResponseEntity<String> deleteOrganizerProfile(@RequestParam String userId) { 
    	organizerService.deleteOrganizerProfile(userId);
    	return ResponseEntity.ok("Organizer profile deleted successfully"); 
    	}

    @PostMapping("/create/organizerProfile")
    @PreAuthorize("hasAuthority('ORGANIZER_PROFILE_CREATE')")
    public ResponseEntity<OrganizerDetails> submitVerification( @RequestBody OrganizerVerificationDTO request) { 
    	return ResponseEntity.status(HttpStatus.CREATED).body(organizerService.submitVerification( request));
    	}

    @GetMapping("/verification-status")
    @PreAuthorize("hasAuthority('ORGANIZER_VERIFICATION_STATUS_READ')")
    public ResponseEntity<String> getVerificationStatus(@RequestParam String userId) { 
    	return ResponseEntity.ok(organizerService.getVerificationStatus(userId));
    	}

    @GetMapping("/status/pending")
    @PreAuthorize("hasAuthority('ORGANIZER_READ_PENDING')")
    public ResponseEntity<List<OrganizerDetails>> getPendingOrganizers() { 
    	return ResponseEntity.ok(organizerService.getPendingOrganizers()); 
    	}

    @GetMapping("/status/rejected")
    @PreAuthorize("hasAuthority('ORGANIZER_READ_REJECTED')")
    public ResponseEntity<List<OrganizerDetails>> getRejectedOrganizers() { 
    	return ResponseEntity.ok(organizerService.getRejectedOrganizers()); 
    	}

    @GetMapping("/{organizerId}")
    @PreAuthorize("hasAuthority('ORGANIZER_READ')")
    public ResponseEntity<OrganizerDetails> getOrganizerVerificationDetails(@PathVariable String organizerId) { 
    	return ResponseEntity.ok(organizerService.getOrganizerVerificationDetails(organizerId)); 
    }
    
    @GetMapping("/all")
    @PreAuthorize("hasAuthority('ORGANIZER_READ_ALL')")
    public ResponseEntity<List<OrganizerDetails>>getAll() { 
    	return ResponseEntity.ok(organizerService.getAll()); 
    }

    @PutMapping("/{organizerId}/approve")
    @PreAuthorize("hasAuthority('ORGANIZER_APPROVE')")
    public ResponseEntity<OrganizerDetails> approveOrganizer(@PathVariable String organizerId) { 
    	return ResponseEntity.ok(organizerService.approveOrganizer(organizerId));
    }

    @PutMapping("/{organizerId}/reject")
    @PreAuthorize("hasAuthority('ORGANIZER_REJECT')")
    public ResponseEntity<OrganizerDetails> rejectOrganizer(@PathVariable String organizerId) { 
    	return ResponseEntity.ok(organizerService.rejectOrganizer(organizerId)); 
    }
}
