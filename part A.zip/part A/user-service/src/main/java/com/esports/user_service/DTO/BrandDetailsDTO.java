package com.esports.user_service.DTO;


import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BrandDetailsDTO {

    private String id;
    private String brandName;
    private String mobileNumber;
    private String websiteUrl;
    private String legalEntityIdentifier;
    private String businessAddress;
    private String verificationStatus;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private String userId; // Added userId

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public String getLegalEntityIdentifier() {
		return legalEntityIdentifier;
	}

	public void setLegalEntityIdentifier(String legalEntityIdentifier) {
		this.legalEntityIdentifier = legalEntityIdentifier;
	}

	public String getBusinessAddress() {
		return businessAddress;
	}

	public void setBusinessAddress(String businessAddress) {
		this.businessAddress = businessAddress;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public BrandDetailsDTO(String id, String brandName, String mobileNumber, String websiteUrl,
			String legalEntityIdentifier, String businessAddress, String verificationStatus, LocalDateTime createdAt,
			LocalDateTime updatedAt, String userId) {
		super();
		this.id = id;
		this.brandName = brandName;
		this.mobileNumber = mobileNumber;
		this.websiteUrl = websiteUrl;
		this.legalEntityIdentifier = legalEntityIdentifier;
		this.businessAddress = businessAddress;
		this.verificationStatus = verificationStatus;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.userId = userId;
	}

	public BrandDetailsDTO() {
		// TODO Auto-generated constructor stub
	}
    
    
    
    
}