package com.esports.user_service.exception;

public class PermissionNotFoundException extends RuntimeException {

    public PermissionNotFoundException(String permissionId) {
        super("Permission not found with ID: " + permissionId);
    }
}