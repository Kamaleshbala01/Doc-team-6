package com.esports.user_service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.esports.user_service.DTO.PermissionRequestDTO;
import com.esports.user_service.entity.Permission;
import com.esports.user_service.exception.BusinessValidationException;
import com.esports.user_service.exception.PermissionNotFoundException;
import com.esports.user_service.exception.ResourceAlreadyExistsException;
import com.esports.user_service.repository.PermissionRepository;

@Service
public class PermissionService {

    @Autowired
    private PermissionRepository permissionRepository;

    public List<Permission> getAllPermissions() {
        return permissionRepository.findAll();
    }

    public Permission getPermissionById(String permissionId) {

        return permissionRepository.findById(permissionId)
                .orElseThrow(() -> new PermissionNotFoundException(
                        "Permission not found with id : " + permissionId));
    }

    public Permission createPermission(PermissionRequestDTO request) {

        String permissionName = request.getPermissionName();

        if (permissionName == null || permissionName.trim().isEmpty())
            throw new BusinessValidationException(
                    "Permission name cannot be null or empty");

        if (permissionRepository.existsByPermissionName(permissionName.trim()))
            throw new ResourceAlreadyExistsException(
                    "Permission already exists with name : " + permissionName);

        Permission permission = new Permission();

        permission.setPermissionName(
                permissionName.trim().toUpperCase());

        return permissionRepository.save(permission);
    }

    public Permission updatePermission(
            String permissionId,
            PermissionRequestDTO request) {

        Permission existingPermission = permissionRepository.findById(permissionId)
                .orElseThrow(() -> new PermissionNotFoundException(
                        "Permission not found with id : " + permissionId));

        String permissionName = request.getPermissionName();

        if (permissionName == null || permissionName.trim().isEmpty())
            throw new BusinessValidationException(
                    "Permission name cannot be null or empty");

        Permission permissionByName = permissionRepository
                .findByPermissionName(permissionName.trim())
                .orElse(null);

        if (permissionByName != null &&
                !permissionByName.getId().equals(permissionId))
            throw new ResourceAlreadyExistsException(
                    "Permission already exists with name : " + permissionName);

        existingPermission.setPermissionName(
                permissionName.trim().toUpperCase());

        return permissionRepository.save(existingPermission);
    }

    public void deletePermission(String permissionId) {

        Permission permission = permissionRepository.findById(permissionId)
                .orElseThrow(() -> new PermissionNotFoundException(
                        "Permission not found with id : " + permissionId));

        if (permission.getRoles() != null &&
                !permission.getRoles().isEmpty())
            throw new BusinessValidationException(
                    "Permission is assigned to one or more roles and cannot be deleted");

        permissionRepository.delete(permission);
    }
}