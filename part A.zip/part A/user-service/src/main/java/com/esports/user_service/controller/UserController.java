package com.esports.user_service.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.user_service.DTO.ApiResponse;
import com.esports.user_service.DTO.LoginRequestDTO;
import com.esports.user_service.DTO.RegisterUserRequestDTO;
import com.esports.user_service.DTO.UserDetailsDTO;
import com.esports.user_service.DTO.UserResponseDTO;
import com.esports.user_service.entity.User;
import com.esports.user_service.service.TestService;
import com.esports.user_service.service.UserService;

import jakarta.annotation.security.PermitAll;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/auth/users")
@RequiredArgsConstructor
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private TestService testService;
    
    
  

    @PostMapping("/email/send-otp")
     @PermitAll
    public ResponseEntity<ApiResponse> sendEmailOtp(@RequestParam String email) {

        return new ResponseEntity<>(userService.sendEmailOtp(email),HttpStatus.OK);
    }

    @PostMapping("/email/verify-otp")
     @PermitAll
    public ResponseEntity<ApiResponse> verifyEmailOtp( @RequestParam String otp) {

        return new ResponseEntity<>( userService.verifyEmailOtp(otp), HttpStatus.OK);
    }

    @PostMapping("/mobile/send-otp")
     @PermitAll
    public ResponseEntity<ApiResponse> sendMobileOtp(@RequestParam String mobileNumber) {

        return new ResponseEntity<>(userService.sendMobileOtp(mobileNumber), HttpStatus.OK);
    }

    @PostMapping("/mobile/verify-otp")
    @PermitAll
    public ResponseEntity<ApiResponse> verifyMobileOtp( @RequestParam String otp) {

        return new ResponseEntity<>(userService.verifyMobileOtp(otp),HttpStatus.OK);
    }

    @PostMapping("/register")
    @PermitAll
    public ResponseEntity<String> register(@RequestParam String roleName,@RequestBody RegisterUserRequestDTO request) {

    	 userService.register(request, roleName);
        return new ResponseEntity<>("User created Sucessfully",HttpStatus.CREATED);
    }

    @PostMapping("/login")
    @PermitAll
    public ResponseEntity<String> login(@RequestBody LoginRequestDTO request) {

        return new ResponseEntity<>( userService.login(request), HttpStatus.ACCEPTED);
    }

   
    @GetMapping("/id")
    @PreAuthorize("hasAuthority('USER_READ')")
    public ResponseEntity<Optional<User>> getUserById() {
    	UserDetailsDTO user = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return new ResponseEntity<>( userService.getUserById(user.getUserId()), HttpStatus.OK);
    }
    
    @GetMapping("/all")
    @PreAuthorize("hasAuthority('USER_READ_ALL')")
    public ResponseEntity<List<UserResponseDTO>> getUsers() {

        return new ResponseEntity<>(userService.getUsers(), HttpStatus.OK);
    }

    @GetMapping("/test/notify")
    public String test(){
        testService.test();
        return "sucess";
    }
    
    
}