package com.esports.user_service.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoleRequestDTO {

    private String roleName;

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public RoleRequestDTO(String roleName) {
		super();
		this.roleName = roleName;
	}
    
	
}

