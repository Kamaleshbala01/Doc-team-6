package com.esports.user_service.exception;

public class BrandVerificationException extends RuntimeException {

    public BrandVerificationException(String message) {
        super(message);
    }
}