package com.esports.user_service.DTO;

import lombok.Data;

@Data
public class UserProfileRequestDTO {

    private String firstName;
    private String lastName;
    private String profileImageURI;
    private String bio;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getProfileImageURI() {
		return profileImageURI;
	}
	public void setProfileImageURI(String profileImageURI) {
		this.profileImageURI = profileImageURI;
	}
	public String getBio() {
		return bio;
	}
	public void setBio(String bio) {
		this.bio = bio;
	}
	public UserProfileRequestDTO(String firstName, String lastName, String profileImageURI, String bio) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.profileImageURI = profileImageURI;
		this.bio = bio;
	}
    public UserProfileRequestDTO() {
        //TODO Auto-generated constructor stub
    }
    
    
    
}