package com.esports.user_service.exception;

public class ResourceAlreadyExistsException extends RuntimeException {

    public ResourceAlreadyExistsException(String roleName) {
        super("Role already exists with name: " + roleName);
    }
}