package com.esports.user_service.entity;

import com.esports.user_service.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "user_profiles")
@Getter
@Setter
public class UserProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String firstName;
    private String lastName;
    private String profileImageURI;
    private String bio;
    private Boolean isInfluencer;
	private String influencerStatus;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;

     @OneToOne
     @JoinColumn(name = "user_id")
     @JsonIgnore
     private User user;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getProfileImageURI() {
		return profileImageURI;
	}

	public void setProfileImageURI(String profileImageURI) {
		this.profileImageURI = profileImageURI;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public Boolean getIsInfluencer() {
		return isInfluencer;
	}

	public void setIsInfluencer(Boolean isInfluencer) {
		this.isInfluencer = isInfluencer;
	}

	public StatusMaster getStatus() {
		return status;
	}

	public void setStatus(StatusMaster status) {
		this.status = status;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
     
     
}
