package com.esports.user_service.service;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.esports.user_service.entity.Permission;
import com.esports.user_service.entity.Role;
import com.esports.user_service.entity.User;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {
    @Value("${jwt.secret}")
    private String secretKey;

    public String generateToken(User user){
        Map<String,Object> claims = new HashMap<>();

        Set<String> roles = new HashSet<>();
        Set<String> permissions = new HashSet<>();
        for(Role role : user.getRoles()){
            roles.add(role.getRoleName());

            for(Permission permission : role.getPermissions()){
                permissions.add(permission.getPermissionName());
            }
        }

        claims.put("roles",roles);
        claims.put("permissions", permissions);
        claims.put("user_id", user.getId());

        return Jwts
                .builder()
                .claims()
                .add(claims)
                .subject(user.getUsername())
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 24 * 5))
                .and()
                .signWith(getKey())
                .compact();
    }
    public String generateToken(String subject){
        Map<String,Object> claims = new HashMap<>();
        claims.put("token_type","SERVICE");

        return Jwts
                .builder()
                .claims()
                .add(claims)
                .subject(subject)
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 24 * 5))
                .and()
                .signWith(getKey())
                .compact();
    }

    private SecretKey getKey(){
        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    public String getUserName(String token){
        return extractClaims(token,Claims::getSubject);
    }

    public boolean validateToken(String token,UserDetails user){
        final String username = getUserName(token);
        return (username.equals(user.getUsername()) && !isTokenExpiration(token));
    }

    private <T> T extractClaims(String token,Function<Claims,T> claimresolver){
        final Claims claims = extractAllClaims(token);
        return claimresolver.apply(claims);
    }

    private boolean isTokenExpiration(String token){
        return extractExpiration(token).before(new Date()); 
    }

    private Date extractExpiration(String token){
        return extractClaims(token,Claims::getExpiration);
    }


    private Claims extractAllClaims(String token){
        return Jwts.parser()
            .verifyWith(getKey())
            .build()
            .parseSignedClaims(token).getPayload();
    }
}
