package com.esports.user_service.enums;

public enum StatusMaster {
    SUSPENDED,
    ACTIVE,
    DELETED,
    PENDING
}
