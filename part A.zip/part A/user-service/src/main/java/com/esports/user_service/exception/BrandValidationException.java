package com.esports.user_service.exception;

public class BrandValidationException extends RuntimeException {

    public BrandValidationException(String message) {
        super(message);
    }
}