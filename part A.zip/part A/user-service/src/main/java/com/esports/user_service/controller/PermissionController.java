package com.esports.user_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.user_service.DTO.PermissionRequestDTO;
import com.esports.user_service.entity.Permission;
import com.esports.user_service.service.PermissionService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/auth/admin/permissions")
@RequiredArgsConstructor
public class PermissionController {

	@Autowired
    private PermissionService permissionService;

    @GetMapping
    @PreAuthorize("hasAuthority('PERMISSION_READ_ALL')")
    public ResponseEntity<List<Permission>> getPermissions() {
        return ResponseEntity.ok(permissionService.getAllPermissions());
    }

    @GetMapping("/{permissionId}")
    @PreAuthorize("hasAuthority('PERMISSION_READ')")
    public ResponseEntity<Permission> getPermissionById(@PathVariable String permissionId) {
        return ResponseEntity.ok(permissionService.getPermissionById(permissionId));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('PERMISSION_CREATE')")
    public ResponseEntity<Permission> createPermission(@RequestBody PermissionRequestDTO request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(permissionService.createPermission(request));
    }

    @PutMapping("/{permissionId}")
    @PreAuthorize("hasAuthority('PERMISSION_UPDATE')")
    public ResponseEntity<Permission> updatePermission(
            @PathVariable String permissionId,
            @RequestBody PermissionRequestDTO request) {

        return ResponseEntity.ok(
                permissionService.updatePermission(permissionId, request));
    }

    @DeleteMapping("/{permissionId}")
    @PreAuthorize("hasAuthority('PERMISSION_DELETE')")
    public ResponseEntity<String> deletePermission(@PathVariable String permissionId) {

        permissionService.deletePermission(permissionId);
        return ResponseEntity.ok("Permission deleted successfully");
    }
}
