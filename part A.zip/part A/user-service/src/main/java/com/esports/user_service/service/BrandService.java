package com.esports.user_service.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esports.user_service.DTO.BrandDetailsDTO;
import com.esports.user_service.DTO.BrandProfileDTO;
import com.esports.user_service.DTO.UserDetailsDTO;
import com.esports.user_service.DTO.VerificationStatusDTO;
import com.esports.user_service.entity.BrandDetails;
import com.esports.user_service.entity.User;
import com.esports.user_service.exception.BrandValidationException;
import com.esports.user_service.exception.BrandVerificationException;
import com.esports.user_service.exception.ResourceNotFoundException;
import com.esports.user_service.repository.BrandDetailsRepository;
import com.esports.user_service.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class BrandService {

	@Autowired
    private BrandDetailsRepository brandDetailsRepository;
	@Autowired
    private UserRepository userRepository;
	
	
	 

    // ==========================================
    // GET PROFILE
    // ==========================================

    public BrandProfileDTO getBrandProfile() {

        User user = getCurrentUser();

        BrandDetails brand = brandDetailsRepository
                .findByUser(user)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Brand profile not found"));

        return mapToDto(brand);
    }

 

    // ==========================================
    // DELETE PROFILE
    // ==========================================

    public void deleteBrandProfile() {

        User user = getCurrentUser();

        BrandDetails brand = brandDetailsRepository
                .findByUser(user)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Brand profile not found"));

        brandDetailsRepository.delete(brand);
    }

    // ==========================================
    // SUBMIT VERIFICATION
    // ==========================================

    public String submitVerification() {

        User user = getCurrentUser();

        BrandDetails brand = brandDetailsRepository
                .findByUser(user)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Brand profile not found"));

        if ("APPROVED".equalsIgnoreCase(
                brand.getVerificationStatus())) {

            throw new BrandVerificationException(
                    "Brand already approved");
        }

        if ("PENDING".equalsIgnoreCase(
                brand.getVerificationStatus())) {

            throw new BrandVerificationException(
                    "Verification request already submitted");
        }

        validateVerificationSubmission(brand);

        brand.setVerificationStatus("PENDING");
        brand.setUpdatedAt(LocalDateTime.now());

        brandDetailsRepository.save(brand);

        return "Verification submitted successfully";
    }

    // ==========================================
    // GET VERIFICATION STATUS
    // ==========================================

    public VerificationStatusDTO getVerificationStatus() {

        User user = getCurrentUser();

        BrandDetails brand = brandDetailsRepository
                .findByUser(user)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Brand profile not found"));

        return new VerificationStatusDTO(
                brand.getId(),
                brand.getVerificationStatus());
    }

    // ==========================================
    // ADMIN - GET PENDING BRANDS
    // ==========================================

    public List<BrandProfileDTO> getPendingBrands() {

        return brandDetailsRepository
                .findByVerificationStatus("PENDING")
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    // ==========================================
    // ADMIN - GET REJECTED BRANDS
    // ==========================================

    public List<BrandProfileDTO> getRejectedBrands() {

        return brandDetailsRepository
                .findByVerificationStatus("REJECTED")
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    // ==========================================
    // ADMIN - GET BRAND DETAILS
    // ==========================================

    public BrandProfileDTO getBrandVerificationDetails(
            String brandId) {

        BrandDetails brand = brandDetailsRepository
                .findById(brandId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Brand not found"));

        return mapToDto(brand);
    }

    // ==========================================
    // ADMIN - APPROVE BRAND
    // ==========================================

    public String approveBrand(String brandId) {

        BrandDetails brand = brandDetailsRepository
                .findById(brandId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Brand not found"));

        if ("APPROVED".equalsIgnoreCase(
                brand.getVerificationStatus())) {

            throw new BrandVerificationException(
                    "Brand already approved");
        }

        brand.setVerificationStatus("APPROVED");
        brand.setUpdatedAt(LocalDateTime.now());

        brandDetailsRepository.save(brand);

        return "Brand approved successfully";
    }

    // ==========================================
    // ADMIN - REJECT BRAND
    // ==========================================

    public String rejectBrand(String brandId) {

        BrandDetails brand = brandDetailsRepository
                .findById(brandId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Brand not found"));

        if ("REJECTED".equalsIgnoreCase(
                brand.getVerificationStatus())) {

            throw new BrandVerificationException(
                    "Brand already rejected");
        }

        brand.setVerificationStatus("REJECTED");
        brand.setUpdatedAt(LocalDateTime.now());

        brandDetailsRepository.save(brand);

        return "Brand rejected successfully";
    }

    // ==========================================
    // VALIDATIONS
    // ==========================================

    /*private void validateBrandProfile(
            BrandProfileDTO dto) {

        if (dto.getBrandName() == null ||
                dto.getBrandName().isBlank()) {

            throw new BrandValidationException(
                    "Brand name is required");
        }

        if (dto.getMobileNumber() == null ||
                dto.getMobileNumber().isBlank()) {

            throw new BrandValidationException(
                    "Mobile number is required");
        }

        if (dto.getWebsiteUrl() == null ||
                dto.getWebsiteUrl().isBlank()) {

            throw new BrandValidationException(
                    "Website URL is required");
        }

        if (dto.getLegalEntityIdentifier() == null ||
                dto.getLegalEntityIdentifier().isBlank()) {

            throw new BrandValidationException(
                    "Legal entity identifier is required");
        }

        if (dto.getBusinessAddress() == null ||
                dto.getBusinessAddress().isBlank()) {

            throw new BrandValidationException(
                    "Business address is required");
        }
    }  */

    private void validateVerificationSubmission(
            BrandDetails brand) {

        if (brand.getBrandName() == null ||
                brand.getBrandName().isBlank()) {

            throw new BrandValidationException(
                    "Brand name is required before verification");
        }

        if (brand.getWebsiteUrl() == null ||
                brand.getWebsiteUrl().isBlank()) {

            throw new BrandValidationException(
                    "Website URL is required before verification");
        }

        if (brand.getLegalEntityIdentifier() == null ||
                brand.getLegalEntityIdentifier().isBlank()) {

            throw new BrandValidationException(
                    "Legal entity identifier is required before verification");
        }
    }

    // ==========================================
    // GET CURRENT USER
    // ==========================================

    private User getCurrentUser() {

        Authentication authentication =
                SecurityContextHolder.getContext()
                        .getAuthentication();

        String email = authentication.getName();

        return userRepository.findByEmail(email)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found"));
    }

    // ==========================================
    // MAPPER
    // ==========================================

    private BrandProfileDTO mapToDto(
            BrandDetails brand) {

        BrandProfileDTO dto = new BrandProfileDTO();

        dto.setId(brand.getId());
        dto.setBrandName(brand.getBrandName());
        dto.setMobileNumber(brand.getMobileNumber());
        dto.setWebsiteUrl(brand.getWebsiteUrl());
        dto.setLegalEntityIdentifier(
                brand.getLegalEntityIdentifier());
        dto.setBusinessAddress(
                brand.getBusinessAddress());
        dto.setVerificationStatus(
                brand.getVerificationStatus());
        dto.setCreatedAt(brand.getCreatedAt());
        dto.setUpdatedAt(brand.getUpdatedAt());

        return dto;
    }

   

        public List<BrandDetailsDTO> getAllBrands() {

            return brandDetailsRepository.findAll()
                    .stream()
                    .map(this::convertToDTO)
                    .collect(Collectors.toList());
        }

        private BrandDetailsDTO convertToDTO(BrandDetails brand) {

            BrandDetailsDTO dto = new BrandDetailsDTO();

            dto.setId(brand.getId());
            dto.setBrandName(brand.getBrandName());
            dto.setMobileNumber(brand.getMobileNumber());
            dto.setWebsiteUrl(brand.getWebsiteUrl());
            dto.setLegalEntityIdentifier(brand.getLegalEntityIdentifier());
            dto.setBusinessAddress(brand.getBusinessAddress());
            dto.setVerificationStatus(brand.getVerificationStatus());
            dto.setCreatedAt(brand.getCreatedAt());
            dto.setUpdatedAt(brand.getUpdatedAt());

            if (brand.getUser() != null) {
                dto.setUserId(brand.getUser().getId());
            }

            return dto;
        }
        
      
        public BrandDetailsDTO createBrand( BrandDetailsDTO dto) {

        	UserDetailsDTO user = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            User user2 = userRepository.findById(user.getUserId())
                    .orElseThrow(() -> new RuntimeException("User not found"));

            BrandDetails brand = new BrandDetails();

            brand.setBrandName(dto.getBrandName());
            brand.setMobileNumber(dto.getMobileNumber());
            brand.setWebsiteUrl(dto.getWebsiteUrl());
            brand.setLegalEntityIdentifier(dto.getLegalEntityIdentifier());
            brand.setBusinessAddress(dto.getBusinessAddress());
            brand.setVerificationStatus("PENDING");
            brand.setCreatedAt(LocalDateTime.now());
            brand.setUpdatedAt(LocalDateTime.now());
            brand.setUser(user2);

            BrandDetails savedBrand = brandDetailsRepository.save(brand);

            BrandDetailsDTO response = new BrandDetailsDTO();
            response.setBrandName(savedBrand.getBrandName());
            response.setMobileNumber(savedBrand.getMobileNumber());
            response.setWebsiteUrl(savedBrand.getWebsiteUrl());
            response.setLegalEntityIdentifier(savedBrand.getLegalEntityIdentifier());
            response.setBusinessAddress(savedBrand.getBusinessAddress());

            return response;
        }
        
        
       
        public BrandDetailsDTO updateBrand( BrandDetailsDTO dto) {

        	UserDetailsDTO user = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            BrandDetails brand = brandDetailsRepository.findByUserId(user.getUserId())
                    .orElseThrow(() -> new RuntimeException("Brand details not found for user"));

            brand.setBrandName(dto.getBrandName());
            brand.setMobileNumber(dto.getMobileNumber());
            brand.setWebsiteUrl(dto.getWebsiteUrl());
            brand.setLegalEntityIdentifier(dto.getLegalEntityIdentifier());
            brand.setBusinessAddress(dto.getBusinessAddress());
            brand.setUpdatedAt(LocalDateTime.now());

            BrandDetails updatedBrand = brandDetailsRepository.save(brand);

            BrandDetailsDTO response = new BrandDetailsDTO();
            response.setBrandName(updatedBrand.getBrandName());
            response.setMobileNumber(updatedBrand.getMobileNumber());
            response.setWebsiteUrl(updatedBrand.getWebsiteUrl());
            response.setLegalEntityIdentifier(updatedBrand.getLegalEntityIdentifier());
            response.setBusinessAddress(updatedBrand.getBusinessAddress());

            return response;
        }
    
}