package com.esports.user_service.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import com.esports.user_service.entity.User;

public interface UserRepository extends JpaRepository<User,String> {

	    @EntityGraph(attributePaths = {
	        "roles", 
	        "roles.permissions"})
	    Optional<User> findByUsername(String username);
	    

        Optional<User> findByEmail(String email);

        Optional<User> findByMobileNumber(String mobileNumber);

        boolean existsByUsername(String username);

        boolean existsByEmail(String email);

        boolean existsByMobileNumber(String mobileNumber);
    

}
