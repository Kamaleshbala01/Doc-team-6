package com.esports.user_service.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizerVerificationDTO {

    private String governmentIdUri;
    private String selfieVerificationUri;
	public String getGovernmentIdUri() {
		return governmentIdUri;
	}
	public void setGovernmentIdUri(String governmentIdUri) {
		this.governmentIdUri = governmentIdUri;
	}
	public String getSelfieVerificationUri() {
		return selfieVerificationUri;
	}
	public void setSelfieVerificationUri(String selfieVerificationUri) {
		this.selfieVerificationUri = selfieVerificationUri;
	}
	public OrganizerVerificationDTO(String governmentIdUri, String selfieVerificationUri) {
		super();
		this.governmentIdUri = governmentIdUri;
		this.selfieVerificationUri = selfieVerificationUri;
	}
    
    
}