package com.esports.user_service.DTO;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JWTClaimsDTO{
    private String username;
}