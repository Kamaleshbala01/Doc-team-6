package com.esports.user_service.service;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.esports.user_service.DTO.InfluencerProfilePublishEvent;
import com.esports.user_service.DTO.NotificationEventDTO;
import com.esports.user_service.DTO.UserDetailsDTO;
import com.esports.user_service.DTO.UserProfileRequestDTO;
import com.esports.user_service.entity.User;
import com.esports.user_service.entity.UserProfile;
import com.esports.user_service.enums.StatusMaster;
import com.esports.user_service.exception.ResourceAlreadyExistsException;
import com.esports.user_service.exception.ResourceNotFoundException;
import com.esports.user_service.repository.UserProfileRepository;
import com.esports.user_service.repository.UserRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserProfileService {

	@Autowired
    private  UserRepository userRepository;
	
	@Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private UserEventPublisher publisher;

     
	public UserProfile createProfile( UserProfileRequestDTO request) {

        UserDetailsDTO activeUser = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

	    User user = userRepository.findById(activeUser.getUserId())
	            .orElseThrow(() ->
	                    new ResourceNotFoundException(
	                            "User not found"));

	    userProfileRepository.findByUser(user)
	            .ifPresent(existing -> {
	                throw new ResourceAlreadyExistsException(
	                        "Profile already exists");
	            });

	    UserProfile profile = new UserProfile();

	    profile.setFirstName(request.getFirstName());
	    profile.setLastName(request.getLastName());
	    profile.setProfileImageURI(request.getProfileImageURI());
	    profile.setBio(request.getBio());

	    profile.setUser(user);
	    profile.setIsInfluencer(false);
	    profile.setStatus(StatusMaster.PENDING);

	    return userProfileRepository.save(profile);
	}
     
    public UserProfile getProfile() {
        UserDetailsDTO activeUser = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User user = userRepository.findById(activeUser.getUserId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found"));

        return userProfileRepository.findByUser(user)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Profile not found"));
    }

     
    public UserProfile updateProfile( UserProfile request) {

       // UserDetailsDTO activeUser = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UserProfile profile =getProfile();

        profile.setFirstName(
                request.getFirstName());

        profile.setLastName(
                request.getLastName());

        profile.setBio(
                request.getBio());

        profile.setProfileImageURI(
                request.getProfileImageURI());

        return userProfileRepository.save(profile);
    }

     
    public UserProfile applyInfluencer(
            String userId) {

         UserProfile profile = userProfileRepository.findByUserId(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User Profile not found"));

        profile.setStatus(StatusMaster.PENDING);
        profile.setIsInfluencer(false);

        return userProfileRepository.save(profile);
    }

     
    public String getInfluencerStatus(
            String userId) {

        UserProfile profile = userProfileRepository.findByUserId(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User Profile not found"));

        return profile.getStatus().name();
    }

     
    
    	@Transactional
	public void updateInfluencerProfile(InfluencerProfilePublishEvent influencerEvent){
		Optional<UserProfile> user = userProfileRepository.findByUserId(influencerEvent.getUserId());
		if(!user.isPresent()) throw new ResourceNotFoundException("USer not found with id : " + influencerEvent.getUserId());
		
		user.get().setInfluencerStatus(influencerEvent.getProfileStatus());
		user.get().setIsInfluencer(true);

		userProfileRepository.save(user.get());
                try {
                        NotificationEventDTO event = new NotificationEventDTO(influencerEvent.getUserId(), "Profile status updated By System", "Your profile is " + influencerEvent.getProfileStatus() + "check in become influencer page");
                        publisher.publishNotification(event);
                } catch (Exception e) {
                        System.out.println("User notification :" + e.getMessage());
                }
		System.out.println("event for : " + influencerEvent.toString());
	}
}