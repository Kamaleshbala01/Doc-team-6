package com.esports.user_service.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.user_service.entity.OrganizerDetails;
import com.esports.user_service.entity.User;

@Repository
public interface OrganizerDetailsRepository extends JpaRepository<OrganizerDetails, String> {

    Optional<OrganizerDetails> findByUser(User user);

    List<OrganizerDetails> findByVerificationStatus(String verificationStatus);
}