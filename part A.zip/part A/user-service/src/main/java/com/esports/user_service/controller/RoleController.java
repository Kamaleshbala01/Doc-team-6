package com.esports.user_service.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.user_service.DTO.RoleRequestDTO;
import com.esports.user_service.DTO.RoleResponseDTO;
import com.esports.user_service.entity.Permission;
import com.esports.user_service.service.RoleService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/auth/admin/roles")
@RequiredArgsConstructor
public class RoleController {

	@Autowired
    private RoleService roleService;
    
    
    @GetMapping
    @PreAuthorize("hasAuthority('ROLE_READ_ALL')")
    public ResponseEntity<List<RoleResponseDTO>> getRoles() {
        return ResponseEntity.ok(roleService.getAllRoles());
    }

    @GetMapping("/{roleId}")
    @PreAuthorize("hasAuthority('ROLE_READ')")
    public ResponseEntity<RoleResponseDTO> getRoleById(@PathVariable String roleId) {
        return ResponseEntity.ok(roleService.getRoleById(roleId));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_CREATE')")
    public ResponseEntity<RoleResponseDTO> createRole(@RequestBody RoleRequestDTO request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(roleService.createRole(request));
    }

    @PutMapping("/{roleId}")
    @PreAuthorize("hasAuthority('ROLE_UPDATE')")
    public ResponseEntity<RoleResponseDTO> updateRole(
            @PathVariable String roleId,
            @RequestBody RoleRequestDTO request) {

        return ResponseEntity.ok(
                roleService.updateRole(roleId, request));
    }

    @DeleteMapping("/{roleId}")
    @PreAuthorize("hasAuthority('ROLE_DELETE')")
    public ResponseEntity<String> deleteRole(@PathVariable String roleId) {
        roleService.deleteRole(roleId);
        return ResponseEntity.ok("Role deleted successfully");
    }

    @GetMapping("/{roleId}/permissions")
    @PreAuthorize("hasAuthority('ROLE_PERMISSION_READ')")
    public ResponseEntity<Set<Permission>> getRolePermissions(@PathVariable String roleId) {
        return ResponseEntity.ok(roleService.getRolePermissions(roleId));
    }

    @PostMapping("/{roleId}/permissions")
    @PreAuthorize("hasAuthority('ROLE_PERMISSION_ASSIGN')")
    public ResponseEntity<String> assignPermission(
            @PathVariable String roleId,
            @RequestParam String permissionId) {

        roleService.assignPermission(roleId, permissionId);
        return ResponseEntity.ok("Permission added to the Role successfully");
    }

    @DeleteMapping("/{roleId}/permissions/{permissionId}")
    @PreAuthorize("hasAuthority('ROLE_PERMISSION_REMOVE')")
    public ResponseEntity<String> removePermission(
            @PathVariable String roleId,
            @PathVariable String permissionId) {

        roleService.removePermission(roleId, permissionId);
        return ResponseEntity.ok("Permission removed from the Role successfully");
    }
}