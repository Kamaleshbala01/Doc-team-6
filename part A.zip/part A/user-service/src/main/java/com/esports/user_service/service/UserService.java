package com.esports.user_service.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.esports.user_service.DTO.ApiResponse;
import com.esports.user_service.DTO.LoginRequestDTO;
import com.esports.user_service.DTO.RegisterUserRequestDTO;
import com.esports.user_service.DTO.UserResponseDTO;
import com.esports.user_service.entity.Role;
import com.esports.user_service.entity.User;
import com.esports.user_service.exception.InvalidEmailException;
import com.esports.user_service.exception.InvalidMobileNumberException;
import com.esports.user_service.exception.InvalidPasswordException;
import com.esports.user_service.exception.ResourceAlreadyExistsException;
import com.esports.user_service.exception.ResourceNotFoundException;
import com.esports.user_service.repository.RoleRepository;
import com.esports.user_service.repository.UserRepository;


@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;


	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private JwtService jwtService;

	@Autowired
	private AuthenticationManager authenticationManager;

	private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder(12);

	private static final String DEFAULT_OTP = "123456";

	/*
	 * public User register(User user) {
	 * user.setPassword(encoder.encode(user.getPassword())); return
	 * userRepository.save(user); }
	 */

	
	 public String login(LoginRequestDTO request) {
	  
	 System.out.println("Login flag A");
	  
	 Authentication authentication = authenticationManager.authenticate( new
	  UsernamePasswordAuthenticationToken( request.getUsername(),
	  request.getPassword() ) );
	  
	  if (!authentication.isAuthenticated()) { throw new InvalidPasswordException(
	  "Invalid username or password" ); }
	 
	  User user = userRepository .findByUsername(request.getUsername())
	  .orElseThrow( () -> new ResourceNotFoundException("User not found") );
	  
	 return jwtService.generateToken(user); }
	 

	public List<User> getAllUser() {
		return userRepository.findAll();
	}

	public ApiResponse sendEmailOtp(String email) {
		
		 if (!isValidEmail(email)) {
		        throw new InvalidEmailException("Invalid email format");
		    }

		if (userRepository.existsByEmail(email)) {
			return new ApiResponse(HttpStatus.BAD_REQUEST.value(), "Email already registered", null);

		}

		System.out.println("EMAIL OTP : " + DEFAULT_OTP);
		return new ApiResponse(HttpStatus.OK.value(), "OTP sent successfully", DEFAULT_OTP);
	}

	public ApiResponse verifyEmailOtp(String otp) {

		if (!DEFAULT_OTP.equals(otp)) {
			return new ApiResponse(HttpStatus.BAD_REQUEST.value(), "Invalid OTP", null);
		}

		return new ApiResponse(HttpStatus.OK.value(), "Email verified successfully", null);

	}

	public ApiResponse sendMobileOtp(String mobileNumber) {
		
		if (mobileNumber.matches("\\d+")) {
	        throw new InvalidMobileNumberException("Mobile number must contain only digits");
	    }
	    
	    if (mobileNumber.matches("^\\d{10}$")) {
	        throw new InvalidMobileNumberException("Mobile number must be exactly 10 digits");
	    }

		if (userRepository.existsByMobileNumber(mobileNumber)) {
			return new ApiResponse(HttpStatus.BAD_REQUEST.value(), "Mobile number already registered", null);
		}

		System.out.println("MOBILE OTP : " + DEFAULT_OTP);
		return new ApiResponse(HttpStatus.OK.value(), "OTP sent successfully", DEFAULT_OTP);

	}

	public ApiResponse verifyMobileOtp(String otp) {

		if (!DEFAULT_OTP.equals(otp)) {
			return new ApiResponse(HttpStatus.BAD_REQUEST.value(), "Invalid OTP", null);
		}

		return new ApiResponse(HttpStatus.OK.value(), "Mobile verified successfully", null);
	}
	
	
	public User register(RegisterUserRequestDTO request, String roleName) {

	    if (userRepository.existsByUsername(request.getUsername())) {
	        throw new ResourceAlreadyExistsException("Username already exists");
	    }

	    if (userRepository.existsByEmail(request.getEmail())) {
	        throw new ResourceAlreadyExistsException("Email already exists");
	    }

	    if (userRepository.existsByMobileNumber(request.getMobileNumber())) {
	        throw new ResourceAlreadyExistsException("Mobile number already exists");
	    }
	    
	    if (!request.getMobileNumber().matches("\\d+")) {
	        throw new ResourceAlreadyExistsException("Mobile number must contain only digits");
	    }
	    
	    if (!request.getMobileNumber().matches("^\\d{10}$")) {
	        throw new ResourceAlreadyExistsException("Mobile number must be exactly 10 digits");
	    }

	    if (!isValidEmail(request.getEmail())) {
	        throw new InvalidEmailException("Invalid email format");
	    }

	    Role role = roleRepository.findByRoleName(roleName)
	            .orElseThrow(() -> new ResourceNotFoundException("Role not found"));

	    User user = new User();

	    user.setUsername(request.getUsername());
	    user.setPassword(passwordEncoder.encode(request.getPassword()));
	    user.setEmail(request.getEmail());
	    user.setMobileNumber(request.getMobileNumber());

	    user.setEmailVerified(true);
	    user.setMobileVerifed(true);

	    user.setStatus("ACTIVE");
	    user.setCreatedAt(LocalDateTime.now());
	    user.setUpdatedAt(LocalDateTime.now());

	    user.getRoles().add(role);

	    return userRepository.save(user);
	}
	/*
	 * public String login(LoginRequestDTO request) {
	 * 
	 * User user = userRepository.findByUsername(request.getUsername())
	 * .orElseThrow(() -> new ResourceNotFoundException("User not found"));
	 * 
	 * if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
	 * 
	 * throw new InvalidPasswordException("Invalid password"); }
	 * 
	 * return "Login Successful"; }
	 */

	public Optional<User> getUserById(String id) {

		return userRepository.findById(id);
	}

	private boolean isValidEmail(String email) {

		String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";

		return email.matches(regex);
	}

	public List<UserResponseDTO> getUsers() {

	    return userRepository.findAll()
	            .stream()
	            .map(this::convertToDto)
	            .toList();
	}

	private UserResponseDTO convertToDto(User user) {

	    UserResponseDTO dto = new UserResponseDTO();

	    dto.setUserId(user.getId());
	    dto.setUsername(user.getUsername());
	    dto.setEmail(user.getEmail());
	    dto.setMobileNumber(user.getMobileNumber());
	    dto.setStatus(user.getStatus());
	    dto.setEmailVerified(user.getEmailVerified());
	    dto.setMobileVerified(user.getMobileVerifed());
	    dto.setCreatedAt(user.getCreatedAt());

	    dto.setRoles(
	            user.getRoles()
	                .stream()
	                .map(Role::getRoleName)
	                .collect(Collectors.toSet())
	    );

	    return dto;
	}

}
