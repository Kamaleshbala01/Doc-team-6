package com.esports.user_service.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.esports.user_service.DTO.OrganizerVerificationDTO;
import com.esports.user_service.DTO.UserDetailsDTO;
import com.esports.user_service.entity.OrganizerDetails;
import com.esports.user_service.entity.User;
import com.esports.user_service.exception.BusinessValidationException;
import com.esports.user_service.exception.ResourceNotFoundException;
import com.esports.user_service.repository.OrganizerDetailsRepository;
import com.esports.user_service.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OrganizerDetailsService {

	@Autowired
    private  OrganizerDetailsRepository organizerDetailsRepository;
	
	@Autowired
    private UserRepository userRepository;
	

	
	
	
    public OrganizerDetails getOrganizerProfile(String userId) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException( "User not found with id : " + userId));

        return organizerDetailsRepository.findByUser(user)
                .orElseThrow(() -> new ResourceNotFoundException( "Organizer profile not found for user : " + userId));
    }

    public OrganizerDetails updateOrganizerProfile( OrganizerVerificationDTO request) {

    	UserDetailsDTO user = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        OrganizerDetails organizer = getOrganizerProfile(user.getUserId());
        if(organizer.getUser().getId()==user.getUserId())
        		new BusinessValidationException("Organizer details not found for user");
        

        if ("APPROVED".equalsIgnoreCase(organizer.getVerificationStatus()))
            throw new BusinessValidationException("Approved organizer profile cannot be modified");

        if (request.getGovernmentIdUri() == null  || request.getGovernmentIdUri().trim().isEmpty())
            throw new BusinessValidationException("Government Id URI is required");

        if (request.getSelfieVerificationUri() == null  || request.getSelfieVerificationUri().trim().isEmpty())
            throw new BusinessValidationException( "Selfie Verification URI is required");

        organizer.setGovernmentIdUri(request.getGovernmentIdUri());
        organizer.setSelfieVerificationUri(request.getSelfieVerificationUri());
        organizer.setUpdatedAt(LocalDateTime.now());

        return organizerDetailsRepository.save(organizer);
    }

    public void deleteOrganizerProfile(String userId) {

        OrganizerDetails organizer = getOrganizerProfile(userId);

        if ("APPROVED".equalsIgnoreCase(organizer.getVerificationStatus())) {
            throw new BusinessValidationException("Approved organizer profile cannot be deleted");
        }

        User user = organizer.getUser();

        if (user != null) {
            user.setOrganizerDetails(null);
            organizer.setUser(null);
            userRepository.save(user);
        }

        organizerDetailsRepository.delete(organizer);
    }

    public OrganizerDetails submitVerification(OrganizerVerificationDTO request) {

    	UserDetailsDTO user = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User user2 = userRepository.findById(user.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException( "User not found with id : " + user));

        if (request.getGovernmentIdUri() == null|| request.getGovernmentIdUri().trim().isEmpty())
            throw new BusinessValidationException("Government Id document is required");

        if (request.getSelfieVerificationUri() == null || request.getSelfieVerificationUri().trim().isEmpty())
            throw new BusinessValidationException( "Selfie verification document is required");

        OrganizerDetails organizer = organizerDetailsRepository
                .findByUser(user2)
                .orElse(new OrganizerDetails());

        if ("PENDING".equalsIgnoreCase(organizer.getVerificationStatus()))
            throw new BusinessValidationException( "Verification request is already under review");

        if ("APPROVED".equalsIgnoreCase(organizer.getVerificationStatus()))
            throw new BusinessValidationException( "Organizer is already verified");

        organizer.setUser(user2);
        organizer.setGovernmentIdUri(request.getGovernmentIdUri());
        organizer.setSelfieVerificationUri(request.getSelfieVerificationUri());
        organizer.setVerificationStatus("PENDING");

        if (organizer.getCreatedAt() == null) {
            organizer.setCreatedAt(LocalDateTime.now());
        }

        organizer.setUpdatedAt(LocalDateTime.now());

        return organizerDetailsRepository.save(organizer);
    }

    public String getVerificationStatus(String userId) {

        OrganizerDetails organizer = getOrganizerProfile(userId);

        return organizer.getVerificationStatus();
    }

    public List<OrganizerDetails> getPendingOrganizers() {

        return organizerDetailsRepository.findByVerificationStatus("PENDING");
    }

    public List<OrganizerDetails> getRejectedOrganizers() {

        return organizerDetailsRepository.findByVerificationStatus("REJECTED");
    }

    public OrganizerDetails getOrganizerVerificationDetails(
            String organizerId) {

        return organizerDetailsRepository.findById(organizerId)
                .orElseThrow(() -> new ResourceNotFoundException("Organizer details not found with id : "+ organizerId));
    }

    public OrganizerDetails approveOrganizer(String organizerId) {

        OrganizerDetails organizer = organizerDetailsRepository.findById(organizerId)
                .orElseThrow(() -> new ResourceNotFoundException("Organizer details not found with id : " + organizerId));

        if ("APPROVED".equalsIgnoreCase(organizer.getVerificationStatus()))
            throw new BusinessValidationException("Organizer already approved");

        organizer.setVerificationStatus("APPROVED");
        organizer.setVerifiedAt(LocalDateTime.now());
        organizer.setUpdatedAt(LocalDateTime.now());

        return organizerDetailsRepository.save(organizer);
    }

    public OrganizerDetails rejectOrganizer(String organizerId) {

        OrganizerDetails organizer = organizerDetailsRepository.findById(organizerId)
                .orElseThrow(() -> new ResourceNotFoundException( "Organizer details not found with id : "  + organizerId));

        if ("REJECTED".equalsIgnoreCase(organizer.getVerificationStatus()))
            throw new BusinessValidationException("Organizer already rejected");

        organizer.setVerificationStatus("REJECTED");
        organizer.setUpdatedAt(LocalDateTime.now());

        return organizerDetailsRepository.save(organizer);
    }

	public List<OrganizerDetails> getAll() {
		return organizerDetailsRepository.findAll();
	}
}
