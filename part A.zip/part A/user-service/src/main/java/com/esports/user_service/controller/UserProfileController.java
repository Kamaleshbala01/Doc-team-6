package com.esports.user_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.user_service.DTO.UserProfileRequestDTO;
import com.esports.user_service.entity.UserProfile;
import com.esports.user_service.service.UserProfileService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/auth/users/profile")
@RequiredArgsConstructor
public class UserProfileController {

	@Autowired
    private  UserProfileService userProfileService;
	
	
	@PostMapping("/createProfile")
    @PreAuthorize("hasAuthority('USER_PROFILE_CREATE')")
	public ResponseEntity<UserProfile> createProfile( @RequestBody UserProfileRequestDTO request) {

	    return new ResponseEntity<>(
	            userProfileService.createProfile( request),
	            HttpStatus.CREATED);
	}

    @GetMapping("/getProfile")
    @PreAuthorize("hasAuthority('USER_PROFILE_READ')")
    public ResponseEntity<UserProfile> getProfile() {
        return new ResponseEntity<>(userProfileService.getProfile(), HttpStatus.OK);
    }

   

    @PutMapping("/updateProfile")
    @PreAuthorize("hasAuthority('USER_PROFILE_UPDATE')")
    public ResponseEntity<UserProfile> updateProfile( @RequestBody UserProfile profile) {
        return new ResponseEntity<>(userProfileService.updateProfile( profile), HttpStatus.OK);
    }

    @PostMapping("/{userId}/apply-influencer")
    public ResponseEntity<UserProfile> applyInfluencer(@PathVariable String userId) {
        return new ResponseEntity<>(userProfileService.applyInfluencer(userId), HttpStatus.OK);
    }

    @GetMapping("/{userId}/influencer-status")
    public ResponseEntity<String> getInfluencerStatus(@PathVariable String userId) {
        return new ResponseEntity<>(userProfileService.getInfluencerStatus(userId), HttpStatus.OK);
    }

}