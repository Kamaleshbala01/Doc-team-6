package com.esports.user_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.esports.user_service.DTO.InfluencerProfilePublishEvent;
import com.esports.user_service.DTO.NotificationEventDTO;

@Service
public class TestService {
    @Autowired
    private UserEventPublisher publisher;

    public void test() {
        InfluencerProfilePublishEvent influencerEvent = new InfluencerProfilePublishEvent("8ab2ba64-b0ed-41dd-8759-9c5a95f99272","FAILED");
        try {
            NotificationEventDTO event = new NotificationEventDTO(influencerEvent.getUserId(),
                    "Profile status updated By System",
                    "Your profile is " + influencerEvent.getProfileStatus() + "check in become influencer page");
            publisher.publishNotification(event);
        } catch (Exception e) {
            System.out.println("User notification :" + e.getMessage());
        }
    }
}
