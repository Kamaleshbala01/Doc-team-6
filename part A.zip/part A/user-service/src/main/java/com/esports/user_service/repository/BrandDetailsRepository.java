package com.esports.user_service.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.user_service.entity.BrandDetails;
import com.esports.user_service.entity.User;

@Repository
public interface BrandDetailsRepository
        extends JpaRepository<BrandDetails, String> {

    Optional<BrandDetails> findByUser(User user);

    List<BrandDetails> findByVerificationStatus( String verificationStatus);
    
    
    Optional<BrandDetails> findByUserId(String userId);
}