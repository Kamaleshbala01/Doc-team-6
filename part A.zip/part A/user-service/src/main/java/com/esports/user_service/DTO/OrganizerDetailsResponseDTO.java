package com.esports.user_service.DTO;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizerDetailsResponseDTO {

    private String id;
    private String governmentIdUri;
    private String selfieVerificationUri;
    private String verificationStatus;
    private LocalDateTime verifiedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String userId;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getGovernmentIdUri() {
		return governmentIdUri;
	}
	public void setGovernmentIdUri(String governmentIdUri) {
		this.governmentIdUri = governmentIdUri;
	}
	public String getSelfieVerificationUri() {
		return selfieVerificationUri;
	}
	public void setSelfieVerificationUri(String selfieVerificationUri) {
		this.selfieVerificationUri = selfieVerificationUri;
	}
	public String getVerificationStatus() {
		return verificationStatus;
	}
	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}
	public LocalDateTime getVerifiedAt() {
		return verifiedAt;
	}
	public void setVerifiedAt(LocalDateTime verifiedAt) {
		this.verifiedAt = verifiedAt;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public OrganizerDetailsResponseDTO(String id, String governmentIdUri, String selfieVerificationUri,
			String verificationStatus, LocalDateTime verifiedAt, LocalDateTime createdAt, LocalDateTime updatedAt,
			String userId) {
		super();
		this.id = id;
		this.governmentIdUri = governmentIdUri;
		this.selfieVerificationUri = selfieVerificationUri;
		this.verificationStatus = verificationStatus;
		this.verifiedAt = verifiedAt;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.userId = userId;
	}
	public OrganizerDetailsResponseDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
    
}