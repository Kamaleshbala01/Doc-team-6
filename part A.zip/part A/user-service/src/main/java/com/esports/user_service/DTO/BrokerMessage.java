package com.esports.user_service.DTO;


import lombok.Data;

@Data
public class BrokerMessage {
    private Long offset;
    private String type;
    private String topic;
    private Object payload;
	public Long getOffset() {
		return offset;
	}
	public void setOffset(Long offset) {
		this.offset = offset;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public Object getPayload() {
		return payload;
	}
	public void setPayload(Object payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "BrokerMessage [offset=" + offset + ", type=" + type + ", topic=" + topic + ", payload=" + payload + "]";
	}
    
    
    
    
}