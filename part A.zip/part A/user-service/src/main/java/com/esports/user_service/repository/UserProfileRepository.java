package com.esports.user_service.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.esports.user_service.entity.User;
import com.esports.user_service.entity.UserProfile;

public interface UserProfileRepository extends JpaRepository<UserProfile, String> {

    Optional<UserProfile> findByUser(User user);

    Optional<UserProfile> findByUserId(String userId);

}