package com.esports.user_service.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.esports.user_service.DTO.RoleRequestDTO;
import com.esports.user_service.DTO.RoleResponseDTO;
import com.esports.user_service.entity.Permission;
import com.esports.user_service.entity.Role;
import com.esports.user_service.exception.BusinessValidationException;
import com.esports.user_service.exception.ResourceAlreadyExistsException;
import com.esports.user_service.exception.ResourceNotFoundException;
import com.esports.user_service.repository.PermissionRepository;
import com.esports.user_service.repository.RoleRepository;
@Service
public class RoleService {

    private final RoleRepository roleRepository;
    private final PermissionRepository permissionRepository;

    public RoleService(RoleRepository roleRepository,
                       PermissionRepository permissionRepository) {
        this.roleRepository = roleRepository;
        this.permissionRepository = permissionRepository;
    }

    public List<RoleResponseDTO> getAllRoles() {

        return roleRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public RoleResponseDTO getRoleById(String roleId) {

        Role role = roleRepository.findById(roleId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Role not found with id : " + roleId));

        return mapToResponse(role);
    }

    public RoleResponseDTO createRole(RoleRequestDTO request) {

        String roleName = request.getRoleName();

        if (roleName == null || roleName.trim().isEmpty())
            throw new BusinessValidationException(
                    "Role name cannot be null or empty");

        if (roleRepository.existsByRoleName(roleName.trim()))
            throw new ResourceAlreadyExistsException(
                    "Role already exists with name : " + roleName);

        Role role = new Role();
        role.setRoleName(roleName.trim().toUpperCase());
        role.setCreatedAt(LocalDateTime.now());

        return mapToResponse(roleRepository.save(role));
    }

    public RoleResponseDTO updateRole(
            String roleId,
            RoleRequestDTO request) {

        Role existingRole = roleRepository.findById(roleId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Role not found with id : " + roleId));

        String newRoleName = request.getRoleName();

        if (newRoleName == null || newRoleName.trim().isEmpty())
            throw new BusinessValidationException(
                    "Role name cannot be null or empty");

        Role roleByName = roleRepository
                .findByRoleName(newRoleName.trim())
                .orElse(null);

        if (roleByName != null &&
                !roleByName.getId().equals(roleId))
            throw new ResourceAlreadyExistsException(
                    "Role already exists with name : " + newRoleName);

        existingRole.setRoleName(newRoleName.trim().toUpperCase());

        return mapToResponse(roleRepository.save(existingRole));
    }

    public void deleteRole(String roleId) {

        Role role = roleRepository.findById(roleId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Role not found with id : " + roleId));

        if ("SUPER_ADMIN".equalsIgnoreCase(role.getRoleName()))
            throw new BusinessValidationException(
                    "SUPER_ADMIN role cannot be deleted");

        roleRepository.delete(role);
    }

    public Set<Permission> getRolePermissions(String roleId) {

        Role role = roleRepository.findById(roleId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Role not found with id : " + roleId));

        return role.getPermissions();
    }

    public Role assignPermission(
            String roleId,
            String permissionId) {

        Role role = roleRepository.findById(roleId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Role not found with id : " + roleId));

        Permission permission = permissionRepository.findById(permissionId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Permission not found with id : " + permissionId));

        if (role.getPermissions().contains(permission))
            throw new BusinessValidationException(
                    "Permission is already assigned to this role");

        role.getPermissions().add(permission);

        return roleRepository.save(role);
    }

    public Role removePermission(
            String roleId,
            String permissionId) {

        Role role = roleRepository.findById(roleId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Role not found with id : " + roleId));

        Permission permission = permissionRepository.findById(permissionId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Permission not found with id : " + permissionId));

        if (!role.getPermissions().contains(permission))
            throw new BusinessValidationException(
                    "Permission is not assigned to this role");

        role.getPermissions().remove(permission);

        return roleRepository.save(role);
    }

    private RoleResponseDTO mapToResponse(Role role) {

        RoleResponseDTO dto = new RoleResponseDTO();

        dto.setId(role.getId());
        dto.setRoleName(role.getRoleName());
        dto.setCreatedAt(role.getCreatedAt());

        return dto;
    }
}