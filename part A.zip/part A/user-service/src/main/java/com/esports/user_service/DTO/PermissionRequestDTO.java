package com.esports.user_service.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermissionRequestDTO {

    private String permissionName;

	public String getPermissionName() {
		return permissionName;
	}

	public void setPermissionName(String permissionName) {
		this.permissionName = permissionName;
	}

	public PermissionRequestDTO(String permissionName) {
		super();
		this.permissionName = permissionName;
	}

	
    
    
}