package com.esports.user_service.DTO;

import java.time.LocalDateTime;
import java.util.Set;
import lombok.Data;

@Data
public class UserResponseDTO {

    private String userId;
    private String username;
    private String email;
    private String mobileNumber;
    private String status;
    private boolean emailVerified;
    private boolean mobileVerified;
    private LocalDateTime createdAt;

    private Set<String> roles;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isEmailVerified() {
		return emailVerified;
	}

	public void setEmailVerified(boolean emailVerified) {
		this.emailVerified = emailVerified;
	}

	public boolean isMobileVerified() {
		return mobileVerified;
	}

	public void setMobileVerified(boolean mobileVerified) {
		this.mobileVerified = mobileVerified;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public Set<String> getRoles() {
		return roles;
	}

	public void setRoles(Set<String> roles) {
		this.roles = roles;
	}

	public UserResponseDTO(String userId, String username, String email, String mobileNumber, String status,
			boolean emailVerified, boolean mobileVerified, LocalDateTime createdAt, Set<String> roles) {
		super();
		this.userId = userId;
		this.username = username;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.status = status;
		this.emailVerified = emailVerified;
		this.mobileVerified = mobileVerified;
		this.createdAt = createdAt;
		this.roles = roles;
	}

	public UserResponseDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
    
    
    
}
