package com.esports.project.enums;

public enum TournamentFormat {
    SINGLE_ELIMINATION,
    ROUND_ROBIN
}
