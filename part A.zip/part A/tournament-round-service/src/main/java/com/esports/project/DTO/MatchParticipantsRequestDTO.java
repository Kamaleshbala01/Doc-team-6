package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MatchParticipantsRequestDTO {

    private String teamId;
    private String matchDetailsId;
}
