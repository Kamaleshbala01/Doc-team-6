package com.esports.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.MatchParticipants;

@Repository
public interface MatchParticipantsRepo
        extends JpaRepository<MatchParticipants, String> {

    List<MatchParticipants> findByMatchDetails_Id(
            String matchDetailsId);
}
