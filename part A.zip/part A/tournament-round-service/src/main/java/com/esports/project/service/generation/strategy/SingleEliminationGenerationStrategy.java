package com.esports.project.service.generation.strategy;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.TournamentGenerationEvent;
import com.esports.project.entity.MatchDetails;
import com.esports.project.entity.MatchParticipants;
import com.esports.project.entity.RoundDetails;
import com.esports.project.repository.MatchDetailsRepo;
import com.esports.project.repository.MatchParticipantsRepo;
import com.esports.project.repository.RoundDetailsRepo;
import com.esports.project.enums.seedType;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;


@Service
@RequiredArgsConstructor
public class SingleEliminationGenerationStrategy
        implements TournamentGenerationStrategy {

    private final RoundDetailsRepo roundDetailsRepo;
    private final MatchDetailsRepo matchDetailsRepo;
    private final MatchParticipantsRepo matchParticipantsRepo;

    @Override
    @Transactional
    public void generate(
            TournamentGenerationEvent event,
            List<String> participants) {

        int totalTeams = participants.size();

        int bracketSize = getNextPowerOfTwo(totalTeams);

        int totalRounds =
                (int) (Math.log(bracketSize) / Math.log(2));

        List<RoundDetails> rounds = new ArrayList<>();

        /*
         * Create all rounds
         */

        int roundParticipants = bracketSize;

        for (int i = 1; i <= totalRounds; i++) {

            RoundDetails round = new RoundDetails();

            round.setTournamentId(event.getTournamentId());

            round.setRoundName(
                    i == totalRounds
                            ? "Final"
                            : "Round " + i);

            round.setMaximumParticipants(
                    roundParticipants);

            round.setQualifyingCount(
                    roundParticipants / 2);

            round.setCreatedAt(
                    LocalDateTime.now());

            round = roundDetailsRepo.save(round);

            rounds.add(round);

            roundParticipants /= 2;
        }

        /*
         * Create all matches
         */

        List<MatchDetails> roundOneMatches =
                new ArrayList<>();

        int matchesInRound = bracketSize / 2;

        for (int roundIndex = 0;
             roundIndex < rounds.size();
             roundIndex++) {

            RoundDetails round =
                    rounds.get(roundIndex);

            for (int i = 0;
                 i < matchesInRound;
                 i++) {

                MatchDetails match =
                        new MatchDetails();

                match.setRoundDetails(round);

                match = matchDetailsRepo.save(match);

                if (roundIndex == 0) {
                    roundOneMatches.add(match);
                }
            }

            matchesInRound /= 2;
        }

        /*
         * Manual => done
         */

        if (event.getSeedType().toString().equals(seedType.MANUAL.toString())) {
            return;
        }

        /*
         * Random seeding
         */

        List<String> seededTeams =
                new ArrayList<>(participants);

        int byes =
                bracketSize - seededTeams.size();

        for (int i = 0; i < byes; i++) {

            seededTeams.add("BYE");
        }

        int teamIndex = 0;

        for (MatchDetails match : roundOneMatches) {

            createParticipant(
                    match,
                    seededTeams.get(teamIndex++));

            createParticipant(
                    match,
                    seededTeams.get(teamIndex++));
        }
    }

    private void createParticipant(
            MatchDetails match,
            String participant) {

        MatchParticipants mp =
                new MatchParticipants();

        mp.setMatchDetails(match);

        mp.setTeamId(participant);

        matchParticipantsRepo.save(mp);
    }

    private int getNextPowerOfTwo(int n) {

        int power = 1;

        while (power < n) {
            power *= 2;
        }

        return power;
    }
}