package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoundDetailsRequestDTO {

    private String roundName;
    private Integer maximumParticipants;
    private Integer qualifyingCount;
    private String tournamentId;
}