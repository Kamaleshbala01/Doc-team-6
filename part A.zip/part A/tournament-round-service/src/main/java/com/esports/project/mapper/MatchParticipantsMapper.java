package com.esports.project.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

import com.esports.project.DTO.MatchParticipantsRequestDTO;
import com.esports.project.DTO.MatchParticipantsResponseDTO;
import com.esports.project.DTO.MatchParticipantsUpdateDTO;
import com.esports.project.entity.MatchParticipants;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MatchParticipantsMapper {

    MatchParticipants toEntity(
            MatchParticipantsRequestDTO dto);

    @Mapping(
            target = "matchDetailsId",
            source = "matchDetails.id")
    MatchParticipantsResponseDTO toResponseDTO(
            MatchParticipants participant);

    void updateParticipantFromDTO(
            MatchParticipantsUpdateDTO dto,
            @MappingTarget MatchParticipants participant);
}

