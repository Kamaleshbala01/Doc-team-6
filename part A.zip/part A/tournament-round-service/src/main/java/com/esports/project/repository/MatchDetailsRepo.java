package com.esports.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.MatchDetails;

@Repository
public interface MatchDetailsRepo extends
        JpaRepository<MatchDetails, String> {

    List<MatchDetails> findByRoundDetails_Id(
            String roundId);
}