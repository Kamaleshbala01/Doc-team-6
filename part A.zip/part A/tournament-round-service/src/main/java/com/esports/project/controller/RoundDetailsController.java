package com.esports.project.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.RoundDetailsRequestDTO;
import com.esports.project.DTO.RoundDetailsResponseDTO;
import com.esports.project.DTO.RoundDetailsUpdateDTO;
import com.esports.project.service.RoundDetailsService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/round")
public class RoundDetailsController {

    private final RoundDetailsService roundDetailsService;

    public RoundDetailsController(
            RoundDetailsService roundDetailsService) {
        this.roundDetailsService = roundDetailsService;
    }

    /*
     * Create Round
     */
    @PostMapping
//     @PreAuthorize("hasAuthority('ROUND_CREATE')")
    public ResponseEntity<RoundDetailsResponseDTO> createRound(
            @Valid @RequestBody RoundDetailsRequestDTO requestDTO) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(roundDetailsService.createRound(requestDTO));
    }

    /*
     * Get Round By Id
     */
    @GetMapping("/{id}")
//     @PreAuthorize("hasAuthority('ROUND_VIEW')")
    public ResponseEntity<RoundDetailsResponseDTO> getRoundById(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(roundDetailsService.getRoundById(id));
    }

    /*
     * Get All Rounds Of Tournament
     */
    @GetMapping("/tournament/{tournamentId}")
//     @PreAuthorize("hasAuthority('ROUND_VIEW')")
    public ResponseEntity<List<RoundDetailsResponseDTO>>
            getRoundsByTournamentId(
                    @PathVariable String tournamentId) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(roundDetailsService
                        .getRoundsByTournamentId(tournamentId));
    }

    /*
     * Update Round
     */
    @PatchMapping("/{id}")
//     @PreAuthorize("hasAuthority('ROUND_UPDATE')")
    public ResponseEntity<RoundDetailsResponseDTO> updateRound(
            @PathVariable String id,
            @RequestBody RoundDetailsUpdateDTO updateDTO) {

        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(roundDetailsService.updateRound(
                        id,
                        updateDTO));
    }

    /*
     * Delete Round
     */
    @DeleteMapping("/{id}")
//     @PreAuthorize("hasAuthority('ROUND_DELETE')")
    public ResponseEntity<ResponseDTO> deleteRound(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(roundDetailsService.deleteRound(id));
    }
}
