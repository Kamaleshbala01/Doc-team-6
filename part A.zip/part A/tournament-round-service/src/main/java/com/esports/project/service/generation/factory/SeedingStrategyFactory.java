package com.esports.project.service.generation.factory;

import org.springframework.stereotype.Service;

import com.esports.project.enums.seedType;
import com.esports.project.service.generation.seeding.ManualSeedingStrategy;
import com.esports.project.service.generation.seeding.RandomSeedingStrategy;
import com.esports.project.service.generation.strategy.SeedingStrategy;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SeedingStrategyFactory {

    private final RandomSeedingStrategy randomStrategy;
    private final ManualSeedingStrategy manualStrategy;

    public SeedingStrategy getStrategy(
            seedType seedType) {

        return switch (seedType) {

            case RANDOM -> randomStrategy;
            case MANUAL -> manualStrategy;
        };
    }
}