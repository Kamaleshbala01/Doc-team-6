package com.esports.project.DTO;


import java.util.List;

import com.esports.project.enums.TournamentFormat;
import com.esports.project.enums.seedType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TournamentGenerationEvent {

    private String tournamentId;

    private seedType seedType;

    // SINGLE_ELIMINATION or ROUND_ROBIN
    private TournamentFormat tournamentType;

    private List<String> participants;

}