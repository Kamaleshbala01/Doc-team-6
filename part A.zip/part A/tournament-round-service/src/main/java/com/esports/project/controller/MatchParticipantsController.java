package com.esports.project.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.MatchParticipantsRequestDTO;
import com.esports.project.DTO.MatchParticipantsResponseDTO;
import com.esports.project.DTO.MatchParticipantsUpdateDTO;
import com.esports.project.DTO.ResponseDTO;
import com.esports.project.service.MatchParticipantsService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/round/match/participant")
public class MatchParticipantsController {

    private final MatchParticipantsService matchParticipantsService;

    public MatchParticipantsController(
            MatchParticipantsService matchParticipantsService) {
        this.matchParticipantsService = matchParticipantsService;
    }

    /*
     * Create Match Participant
     */
    @PostMapping
//     @PreAuthorize("hasAuthority('MATCH_PARTICIPANT_CREATE')")
    public ResponseEntity<MatchParticipantsResponseDTO> createParticipant(
            @Valid @RequestBody MatchParticipantsRequestDTO requestDTO) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(matchParticipantsService
                        .createParticipant(requestDTO));
    }

    /*
     * Get Participant By Id
     */
    @GetMapping("/{id}")
//     @PreAuthorize("hasAuthority('MATCH_PARTICIPANT_VIEW')")
    public ResponseEntity<MatchParticipantsResponseDTO> getParticipantById(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(matchParticipantsService
                        .getParticipantById(id));
    }

    /*
     * Get All Participants Of A Match
     */
    @GetMapping("/match/{matchId}")
//     @PreAuthorize("hasAuthority('MATCH_PARTICIPANT_VIEW')")
    public ResponseEntity<List<MatchParticipantsResponseDTO>>
            getParticipantsByMatchId(
                    @PathVariable String matchId) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(matchParticipantsService
                        .getParticipantsByMatchId(matchId));
    }

    /*
     * Update Participant Status
     */
    @PatchMapping("/{id}")
//     @PreAuthorize("hasAuthority('MATCH_PARTICIPANT_UPDATE')")
    public ResponseEntity<MatchParticipantsResponseDTO>
            updateParticipant(
                    @PathVariable String id,
                    @RequestBody MatchParticipantsUpdateDTO updateDTO) {

        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(matchParticipantsService
                        .updateParticipant(
                                id,
                                updateDTO));
    }

    /*
     * Delete Participant
     */
    @DeleteMapping("/{id}")
//     @PreAuthorize("hasAuthority('MATCH_PARTICIPANT_DELETE')")
    public ResponseEntity<ResponseDTO> deleteParticipant(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(matchParticipantsService
                        .deleteParticipant(id));
    }
}