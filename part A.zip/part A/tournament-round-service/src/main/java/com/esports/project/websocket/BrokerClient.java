package com.esports.project.websocket;

import java.net.URI;
import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.service.JwtService;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class BrokerClient {

        private final BrokerMessageHandler handler;
        private final JwtService jwtService;

        private WebSocketSession session;

        private final ObjectMapper objectMapper = new ObjectMapper();

        private static final List<String> TOPICS = List.of(
                                "tournament.created",
                                "tournament.updated",
                                "round.generated");

        @PostConstruct
        public void init() {

                connect();
        }

        public synchronized void connect() {

                try {

                        if (session != null &&
                                        session.isOpen()) {

                                return;
                        }

                        String token = jwtService.generateToken(
                                        "round-service");

                        StandardWebSocketClient client = new StandardWebSocketClient();

                        session = client.execute(
                                        handler,
                                        null,
                                        URI.create(
                                                        "ws://localhost:8085/broker?token="
                                                                        + token))
                                        .get();


                        for (String topic : TOPICS) {
                                subscribe(topic);
                        }

                        System.out.println(
                                        "Connected To Broker");

                } catch (Exception ex) {

                        System.out.println(
                                        "Broker unavailable");
                }
        }

        @Scheduled(fixedDelay = 1000 * 60)
        public void reconnect() {

                if (session == null ||
                                !session.isOpen()) {

                        System.out.println(
                                        "Trying to reconnect...");

                        connect();
                }
        }

        public boolean isConnected() {

                return session != null &&
                                session.isOpen();
        }

        public void subscribe(
                        String topic)
                        throws Exception {

                BrokerMessage message = new BrokerMessage();

                message.setType("SUBSCRIBE");
                message.setTopic(topic);

                session.sendMessage(
                                new TextMessage(
                                                objectMapper.writeValueAsString(
                                                                message)));

                System.out.println(
                                "Subscribed -> " + topic);
        }

        public void ack(
                        String topic,
                        Long offset)
                        throws Exception {

                BrokerMessage message = new BrokerMessage();

                message.setType("ACK");
                message.setTopic(topic);
                message.setOffset(offset);

                session.sendMessage(
                                new TextMessage(
                                                objectMapper.writeValueAsString(
                                                                message)));
        }
     public void publish(
                        BrokerMessage message)
                        throws Exception {

                if (session == null ||
                                !session.isOpen()) {
                        throw new RuntimeException(
                                        "Broker connection is closed");
                }
                session.sendMessage(
                                new TextMessage(
                                                objectMapper.writeValueAsString(
                                                                message)));
        }
}