package com.esports.project.service.generation.strategy;

import java.util.List;


public interface SeedingStrategy {
    List<String> process(
            List<String> participants);
}
