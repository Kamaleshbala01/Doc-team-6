package com.esports.project.service.generation.seeding;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.esports.project.service.generation.strategy.SeedingStrategy;

@Service
public class RandomSeedingStrategy
        implements SeedingStrategy {

    @Override
    public List<String> process(
            List<String> participants) {

        Collections.shuffle(participants);

        return participants;
    }
}
