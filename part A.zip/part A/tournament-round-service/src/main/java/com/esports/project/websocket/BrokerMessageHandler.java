package com.esports.project.websocket;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.service.TournamentCreatedConsumer;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class BrokerMessageHandler
        extends TextWebSocketHandler {

    private final TournamentCreatedConsumer consumer;

    private final ObjectMapper objectMapper =
            new ObjectMapper();

    @Override
protected void handleTextMessage(
        WebSocketSession session,
        TextMessage message)
        throws Exception {

    String payload =
            message.getPayload();

    System.out.println(
            "RECEIVED -> " + payload);

    // Ignore non-JSON messages
    if (!payload.trim().startsWith("{")) {

        System.out.println(
                "Ignoring broker status message");

        return;
    }

    BrokerMessage brokerMessage =
            objectMapper.readValue(
                    payload,
                    BrokerMessage.class);

    if ("tournament.created"
            .equals(
                    brokerMessage.getTopic())) {

        consumer.consume(
                brokerMessage);

        BrokerMessage ack =
                new BrokerMessage();

        ack.setType("ACK");
        ack.setTopic(
                brokerMessage.getTopic());

        ack.setOffset(
                brokerMessage.getOffset());

        session.sendMessage(
                new TextMessage(
                        objectMapper
                                .writeValueAsString(
                                        ack)));

        System.out.println(
                "ACK SENT -> "
                        + brokerMessage.getOffset());
    }
}
}