package com.esports.project.service.generation.strategy;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import com.esports.project.DTO.TournamentGenerationEvent;
import com.esports.project.entity.MatchDetails;
import com.esports.project.entity.MatchParticipants;
import com.esports.project.entity.RoundDetails;
import com.esports.project.enums.seedType;
import com.esports.project.repository.MatchDetailsRepo;
import com.esports.project.repository.MatchParticipantsRepo;
import com.esports.project.repository.RoundDetailsRepo;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RoundRobinGenerationStrategy
        implements TournamentGenerationStrategy {

    private final RoundDetailsRepo roundDetailsRepo;
    private final MatchDetailsRepo matchDetailsRepo;
    private final MatchParticipantsRepo matchParticipantsRepo;

    @Override
    @Transactional
    public void generate(
            TournamentGenerationEvent event,
            List<String> participants) {

        List<String> teams =
                new ArrayList<>(participants);

        boolean manual =
               event.getSeedType().toString().equals(seedType.MANUAL.toString());

        /*
         * Add BYE when odd
         */

        if (teams.size() % 2 != 0) {

            teams.add("BYE");
        }

        int roundsCount =
                teams.size() - 1;

        int matchesPerRound =
                teams.size() / 2;

        for (int roundNo = 1;
             roundNo <= roundsCount;
             roundNo++) {

            RoundDetails round =
                    new RoundDetails();

            round.setTournamentId(
                    event.getTournamentId());

            round.setRoundName(
                    "Round " + roundNo);

            round.setMaximumParticipants(
                    participants.size());

            round.setQualifyingCount(participants.size());

            round.setCreatedAt(
                    LocalDateTime.now());

            round = roundDetailsRepo.save(round);

            for (int matchNo = 0;
                 matchNo < matchesPerRound;
                 matchNo++) {

                MatchDetails match =
                        new MatchDetails();

                match.setRoundDetails(round);

                match = matchDetailsRepo.save(match);

                /*
                 * Manual:
                 * only create matches
                 */

                if (manual) {
                    continue;
                }

                String home =
                        teams.get(matchNo);

                String away =
                        teams.get(
                                teams.size() - 1
                                        - matchNo);

                createParticipant(
                        match,
                        home);

                createParticipant(
                        match,
                        away);
            }

            rotate(teams);
        }
    }

    private void rotate(
            List<String> teams) {

        String last =
                teams.remove(
                        teams.size() - 1);

        teams.add(1, last);
    }

    private void createParticipant(
            MatchDetails match,
            String participant) {

        MatchParticipants mp =
                new MatchParticipants();

        mp.setMatchDetails(match);

        mp.setTeamId(participant);

        matchParticipantsRepo.save(mp);
    }
}