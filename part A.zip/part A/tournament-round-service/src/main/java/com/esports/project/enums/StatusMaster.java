package com.esports.project.enums;

public enum StatusMaster {
    ONGOING,
    UPCOMMING,
    CANCELLED,
    POSTPONDED,
    ACTIVE
}
