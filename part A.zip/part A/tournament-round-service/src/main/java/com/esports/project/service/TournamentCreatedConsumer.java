package com.esports.project.service;

import org.springframework.stereotype.Component;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.DTO.TournamentGenerationEvent;
import com.esports.project.service.generation.TournamentGenerationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class TournamentCreatedConsumer {

    private final TournamentGenerationService tournamentGenerationService;
    private final ObjectMapper objectMapper;

    public void consume(BrokerMessage message) {

        System.out.println(
                "Tournament Created Event Received");

        TournamentGenerationEvent event =
                objectMapper.convertValue(
                        message.getPayload(),
                        TournamentGenerationEvent.class);

        tournamentGenerationService.generate(event);
        
        System.out.println("Event Message" + event.toString());
    }
}