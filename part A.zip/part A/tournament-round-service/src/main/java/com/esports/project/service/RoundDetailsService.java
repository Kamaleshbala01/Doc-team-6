package com.esports.project.service;


import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.RoundDetailsRequestDTO;
import com.esports.project.DTO.RoundDetailsResponseDTO;
import com.esports.project.DTO.RoundDetailsUpdateDTO;
import com.esports.project.entity.RoundDetails;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.RoundDetailsMapper;
import com.esports.project.repository.RoundDetailsRepo;

@Service
public class RoundDetailsService {

    private final RoundDetailsRepo roundDetailsRepo;
    private final RoundDetailsMapper roundDetailsMapper;

    @Autowired
    public RoundDetailsService(
            RoundDetailsRepo roundDetailsRepo,
            RoundDetailsMapper roundDetailsMapper) {

        this.roundDetailsRepo = roundDetailsRepo;
        this.roundDetailsMapper = roundDetailsMapper;
    }

    /*
     * Create Round
     */
    public RoundDetailsResponseDTO createRound(
            RoundDetailsRequestDTO requestDTO) {

        RoundDetails round =
                roundDetailsMapper.toEntity(requestDTO);

        round.setCreatedAt(LocalDateTime.now());

        validateRound(round);

        return roundDetailsMapper.toResponseDTO(
                roundDetailsRepo.save(round));
    }

    /*
     * Get Round By Id
     */
    public RoundDetailsResponseDTO getRoundById(
            String id) {

        RoundDetails round =
                roundDetailsRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Round not found with id : "
                                                + id));

        return roundDetailsMapper.toResponseDTO(round);
    }

    /*
     * Get Rounds By Tournament Id
     */
    public List<RoundDetailsResponseDTO> getRoundsByTournamentId(
            String tournamentId) {

        List<RoundDetails> rounds =
                roundDetailsRepo.findByTournamentId(
                        tournamentId);

        return rounds.stream()
                .map(roundDetailsMapper::toResponseDTO)
                .toList();
    }

    /*
     * Update Round
     */
    public RoundDetailsResponseDTO updateRound(
            String id,
            RoundDetailsUpdateDTO updateDTO) {

        RoundDetails round =
                roundDetailsRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Round not found with id : "
                                                + id));

        roundDetailsMapper.updateRoundFromDTO(
                updateDTO,
                round);

        validateRound(round);

        return roundDetailsMapper.toResponseDTO(
                roundDetailsRepo.save(round));
    }

    /*
     * Delete Round
     */
    public ResponseDTO deleteRound(
            String id) {

        RoundDetails round =
                roundDetailsRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Round not found with id : "
                                                + id));

        roundDetailsRepo.delete(round);

        return new ResponseDTO(
                HttpStatus.OK.value(),
                "Round deleted successfully");
    }

    /*
     * Validation
     */
    private void validateRound(
            RoundDetails round) {

        if (round.getRoundName() == null
                || round.getRoundName().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Round name is required");
        }

        if (round.getMaximumParticipants() == null
                || round.getMaximumParticipants() <= 0) {

            throw new IllegalArgumentException(
                    "Maximum participants must be greater than 0");
        }

        if (round.getQualifyingCount() == null
                || round.getQualifyingCount() <= 0) {

            throw new IllegalArgumentException(
                    "Qualifying count must be greater than 0");
        }

        if (round.getQualifyingCount()
                > round.getMaximumParticipants()) {

            throw new IllegalArgumentException(
                    "Qualifying count cannot be greater than maximum participants");
        }

        if (round.getTournamentId() == null
                || round.getTournamentId().isBlank()) {

            throw new IllegalArgumentException(
                    "Tournament Id is required");
        }
    }
}
