package com.esports.project.service.generation;

import java.util.List;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.TournamentGenerationEvent;
import com.esports.project.service.generation.factory.SeedingStrategyFactory;
import com.esports.project.service.generation.factory.TournamentGenerationFactory;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TournamentGenerationService {

    private final SeedingStrategyFactory seedingStrategyFactory;
    private final TournamentGenerationFactory tournamentGenerationFactory;

    @Transactional
    public void generate(TournamentGenerationEvent event) {

        List<String> participants =
                seedingStrategyFactory
                        .getStrategy(event.getSeedType())
                        .process(event.getParticipants());

        tournamentGenerationFactory
                .getStrategy(event.getTournamentType())
                .generate(event, participants);
    }
}
