package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.MatchParticipantsRequestDTO;
import com.esports.project.DTO.MatchParticipantsResponseDTO;
import com.esports.project.DTO.MatchParticipantsUpdateDTO;
import com.esports.project.DTO.ResponseDTO;
import com.esports.project.entity.MatchDetails;
import com.esports.project.entity.MatchParticipants;
import com.esports.project.enums.StatusMaster;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.MatchParticipantsMapper;
import com.esports.project.repository.MatchDetailsRepo;
import com.esports.project.repository.MatchParticipantsRepo;

@ExtendWith(MockitoExtension.class)
class MatchParticipantsServiceTest {

    @Mock
    private MatchParticipantsRepo matchParticipantsRepo;

    @Mock
    private MatchDetailsRepo matchDetailsRepo;

    @Mock
    private MatchParticipantsMapper matchParticipantsMapper;

    @InjectMocks
    private MatchParticipantsService matchParticipantsService;

    @Test
    void createParticipantTest() {

        MatchParticipantsRequestDTO requestDTO =
                new MatchParticipantsRequestDTO();

        requestDTO.setMatchDetailsId("MATCH_1");

        MatchDetails matchDetails =
                new MatchDetails();

        MatchParticipants participant =
                new MatchParticipants();

        participant.setTeamId("TEAM_1");
        participant.setStatus(StatusMaster.ACTIVE);

        MatchParticipantsResponseDTO responseDTO =
                new MatchParticipantsResponseDTO();

        when(matchDetailsRepo.findById("MATCH_1"))
                .thenReturn(Optional.of(matchDetails));

        when(matchParticipantsMapper.toEntity(requestDTO))
                .thenReturn(participant);

        when(matchParticipantsRepo.save(participant))
                .thenReturn(participant);

        when(matchParticipantsMapper.toResponseDTO(participant))
                .thenReturn(responseDTO);

        MatchParticipantsResponseDTO response =
                matchParticipantsService.createParticipant(requestDTO);

        assertNotNull(response);
    }

    @Test
    void createParticipantShouldThrowNotFoundException() {

        MatchParticipantsRequestDTO requestDTO =
                new MatchParticipantsRequestDTO();

        requestDTO.setMatchDetailsId("INVALID_ID");

        when(matchDetailsRepo.findById("INVALID_ID"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> matchParticipantsService.createParticipant(requestDTO));
    }

    @Test
    void getParticipantByIdTest() {

        MatchParticipants participant =
                new MatchParticipants();

        MatchParticipantsResponseDTO responseDTO =
                new MatchParticipantsResponseDTO();

        when(matchParticipantsRepo.findById("1"))
                .thenReturn(Optional.of(participant));

        when(matchParticipantsMapper.toResponseDTO(participant))
                .thenReturn(responseDTO);

        MatchParticipantsResponseDTO response =
                matchParticipantsService.getParticipantById("1");

        assertNotNull(response);
    }

    @Test
    void getParticipantByIdShouldThrowNotFoundException() {

        when(matchParticipantsRepo.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> matchParticipantsService.getParticipantById("1"));
    }

    @Test
    void getParticipantsByMatchIdTest() {

        MatchParticipants participant =
                new MatchParticipants();

        MatchParticipantsResponseDTO responseDTO =
                new MatchParticipantsResponseDTO();

        when(matchParticipantsRepo.findByMatchDetails_Id("MATCH_1"))
                .thenReturn(List.of(participant));

        when(matchParticipantsMapper.toResponseDTO(participant))
                .thenReturn(responseDTO);

        List<MatchParticipantsResponseDTO> response =
                matchParticipantsService.getParticipantsByMatchId("MATCH_1");

        assertEquals(1, response.size());
    }

    @Test
    void updateParticipantTest() {

        MatchParticipants participant =
                new MatchParticipants();

        participant.setTeamId("TEAM_1");
        participant.setStatus(StatusMaster.ACTIVE);
        participant.setMatchDetails(new MatchDetails());

        MatchParticipantsUpdateDTO updateDTO =
                new MatchParticipantsUpdateDTO();

        MatchParticipantsResponseDTO responseDTO =
                new MatchParticipantsResponseDTO();

        when(matchParticipantsRepo.findById("1"))
                .thenReturn(Optional.of(participant));

        when(matchParticipantsRepo.save(participant))
                .thenReturn(participant);

        when(matchParticipantsMapper.toResponseDTO(participant))
                .thenReturn(responseDTO);

        MatchParticipantsResponseDTO response =
                matchParticipantsService.updateParticipant("1", updateDTO);

        assertNotNull(response);
    }

    @Test
    void updateParticipantShouldThrowNotFoundException() {

        MatchParticipantsUpdateDTO updateDTO =
                new MatchParticipantsUpdateDTO();

        when(matchParticipantsRepo.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> matchParticipantsService.updateParticipant("1", updateDTO));
    }

    @Test
    void deleteParticipantTest() {

        MatchParticipants participant =
                new MatchParticipants();

        when(matchParticipantsRepo.findById("1"))
                .thenReturn(Optional.of(participant));

        doNothing().when(matchParticipantsRepo)
                .delete(participant);

        ResponseDTO response =
                matchParticipantsService.deleteParticipant("1");

        assertNotNull(response);

        verify(matchParticipantsRepo)
                .delete(participant);
    }

    @Test
    void deleteParticipantShouldThrowNotFoundException() {

        when(matchParticipantsRepo.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> matchParticipantsService.deleteParticipant("1"));
    }
}