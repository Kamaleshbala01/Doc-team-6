package com.esports.project.service.generation.seeding;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

class ManualSeedingStrategyTest {

    private final ManualSeedingStrategy strategy =
            new ManualSeedingStrategy();

    @Test
    void processTest() {

        List<String> participants =
                List.of("Team1", "Team2", "Team3");

        List<String> result =
                strategy.process(participants);

        assertEquals(participants, result);
    }

    @Test
    void processWithEmptyListTest() {

        List<String> participants =
                Collections.emptyList();

        List<String> result =
                strategy.process(participants);

        assertNotNull(result);
        assertEquals(0, result.size());
    }

    @Test
    void processWithSingleParticipantTest() {

        List<String> participants =
                List.of("Team1");

        List<String> result =
                strategy.process(participants);

        assertEquals(1, result.size());
        assertEquals("Team1", result.get(0));
    }

    @Test
    void processShouldReturnSameReferenceTest() {

        List<String> participants =
                new ArrayList<>();

        participants.add("Team1");
        participants.add("Team2");

        List<String> result =
                strategy.process(participants);

        assertSame(participants, result);
    }

    @Test
    void processWithDuplicateParticipantsTest() {

        List<String> participants =
                List.of("Team1", "Team1", "Team2");

        List<String> result =
                strategy.process(participants);

        assertEquals(participants, result);
    }

    @Test
    void processWithNullListTest() {

        List<String> result =
                strategy.process(null);

        assertEquals(null, result);
    }
}