package com.esports.project.service.generation.strategy;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.TournamentGenerationEvent;
import com.esports.project.entity.MatchDetails;
import com.esports.project.entity.MatchParticipants;
import com.esports.project.entity.RoundDetails;
import com.esports.project.enums.seedType;
import com.esports.project.repository.MatchDetailsRepo;
import com.esports.project.repository.MatchParticipantsRepo;
import com.esports.project.repository.RoundDetailsRepo;

@ExtendWith(MockitoExtension.class)
class RoundRobinGenerationStrategyTest {

    @Mock
    private RoundDetailsRepo roundDetailsRepo;

    @Mock
    private MatchDetailsRepo matchDetailsRepo;

    @Mock
    private MatchParticipantsRepo matchParticipantsRepo;

    @InjectMocks
    private RoundRobinGenerationStrategy roundRobinGenerationStrategy;

    @Test
    void generateRandomSeedTest() {

        TournamentGenerationEvent event =
                new TournamentGenerationEvent();

        event.setTournamentId("T1");
        event.setSeedType(seedType.RANDOM);

        List<String> participants =
                List.of("A", "B", "C", "D");

        when(roundDetailsRepo.save(any(RoundDetails.class)))
                .thenAnswer(i -> i.getArgument(0));

        when(matchDetailsRepo.save(any(MatchDetails.class)))
                .thenAnswer(i -> i.getArgument(0));

        when(matchParticipantsRepo.save(
                any(MatchParticipants.class)))
                .thenAnswer(i -> i.getArgument(0));

        assertDoesNotThrow(() ->
                roundRobinGenerationStrategy.generate(
                        event,
                        participants));

        verify(roundDetailsRepo, atLeastOnce())
                .save(any(RoundDetails.class));

        verify(matchDetailsRepo, atLeastOnce())
                .save(any(MatchDetails.class));

        verify(matchParticipantsRepo, atLeastOnce())
                .save(any(MatchParticipants.class));
    }

    @Test
    void generateManualSeedTest() {

        TournamentGenerationEvent event =
                new TournamentGenerationEvent();

        event.setTournamentId("T1");
        event.setSeedType(seedType.MANUAL);

        List<String> participants =
                List.of("A", "B", "C", "D");

        when(roundDetailsRepo.save(any(RoundDetails.class)))
                .thenAnswer(i -> i.getArgument(0));

        when(matchDetailsRepo.save(any(MatchDetails.class)))
                .thenAnswer(i -> i.getArgument(0));

        assertDoesNotThrow(() ->
                roundRobinGenerationStrategy.generate(
                        event,
                        participants));

        verify(roundDetailsRepo, atLeastOnce())
                .save(any(RoundDetails.class));

        verify(matchDetailsRepo, atLeastOnce())
                .save(any(MatchDetails.class));
    }

    @Test
    void generateOddParticipantsTest() {

        TournamentGenerationEvent event =
                new TournamentGenerationEvent();

        event.setTournamentId("T1");
        event.setSeedType(seedType.RANDOM);

        List<String> participants =
                List.of("A", "B", "C");

        when(roundDetailsRepo.save(any(RoundDetails.class)))
                .thenAnswer(i -> i.getArgument(0));

        when(matchDetailsRepo.save(any(MatchDetails.class)))
                .thenAnswer(i -> i.getArgument(0));

        when(matchParticipantsRepo.save(
                any(MatchParticipants.class)))
                .thenAnswer(i -> i.getArgument(0));

        assertDoesNotThrow(() ->
                roundRobinGenerationStrategy.generate(
                        event,
                        participants));
    }

    @Test
    void generateTwoParticipantsTest() {

        TournamentGenerationEvent event =
                new TournamentGenerationEvent();

        event.setTournamentId("T1");
        event.setSeedType(seedType.RANDOM);

        List<String> participants =
                List.of("A", "B");

        when(roundDetailsRepo.save(any(RoundDetails.class)))
                .thenAnswer(i -> i.getArgument(0));

        when(matchDetailsRepo.save(any(MatchDetails.class)))
                .thenAnswer(i -> i.getArgument(0));

        when(matchParticipantsRepo.save(
                any(MatchParticipants.class)))
                .thenAnswer(i -> i.getArgument(0));

        assertDoesNotThrow(() ->
                roundRobinGenerationStrategy.generate(
                        event,
                        participants));
    }

    @Test
    void generateSingleParticipantTest() {

        TournamentGenerationEvent event =
                new TournamentGenerationEvent();

        event.setTournamentId("T1");
        event.setSeedType(seedType.RANDOM);

        List<String> participants =
                List.of("A");

        when(roundDetailsRepo.save(any(RoundDetails.class)))
                .thenAnswer(i -> i.getArgument(0));

        when(matchDetailsRepo.save(any(MatchDetails.class)))
                .thenAnswer(i -> i.getArgument(0));

        when(matchParticipantsRepo.save(
                any(MatchParticipants.class)))
                .thenAnswer(i -> i.getArgument(0));

        assertDoesNotThrow(() ->
                roundRobinGenerationStrategy.generate(
                        event,
                        participants));
    }

    @Test
    void generateEmptyParticipantsTest() {

        TournamentGenerationEvent event =
                new TournamentGenerationEvent();

        event.setTournamentId("T1");
        event.setSeedType(seedType.RANDOM);

        List<String> participants =
                List.of();

        assertDoesNotThrow(() ->
                roundRobinGenerationStrategy.generate(
                        event,
                        participants));
    }
}