package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.RoundDetailsRequestDTO;
import com.esports.project.DTO.RoundDetailsResponseDTO;
import com.esports.project.DTO.RoundDetailsUpdateDTO;
import com.esports.project.entity.RoundDetails;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.RoundDetailsMapper;
import com.esports.project.repository.RoundDetailsRepo;

@ExtendWith(MockitoExtension.class)
class RoundDetailsServiceTest {

    @Mock
    private RoundDetailsRepo roundDetailsRepo;

    @Mock
    private RoundDetailsMapper roundDetailsMapper;

    @InjectMocks
    private RoundDetailsService roundDetailsService;

    @Test
    void createRoundTest() {

        RoundDetailsRequestDTO requestDTO =
                new RoundDetailsRequestDTO();

        RoundDetails round =
                new RoundDetails();

        round.setRoundName("Round 1");
        round.setMaximumParticipants(10);
        round.setQualifyingCount(5);
        round.setTournamentId("TOUR_1");

        RoundDetailsResponseDTO responseDTO =
                new RoundDetailsResponseDTO();

        when(roundDetailsMapper.toEntity(requestDTO))
                .thenReturn(round);

        when(roundDetailsRepo.save(round))
                .thenReturn(round);

        when(roundDetailsMapper.toResponseDTO(round))
                .thenReturn(responseDTO);

        RoundDetailsResponseDTO response =
                roundDetailsService.createRound(requestDTO);

        assertNotNull(response);
    }

    @Test
    void getRoundByIdTest() {

        RoundDetails round =
                new RoundDetails();

        RoundDetailsResponseDTO responseDTO =
                new RoundDetailsResponseDTO();

        when(roundDetailsRepo.findById("1"))
                .thenReturn(Optional.of(round));

        when(roundDetailsMapper.toResponseDTO(round))
                .thenReturn(responseDTO);

        RoundDetailsResponseDTO response =
                roundDetailsService.getRoundById("1");

        assertNotNull(response);
    }

    @Test
    void getRoundByIdShouldThrowNotFoundException() {

        when(roundDetailsRepo.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> roundDetailsService.getRoundById("1"));
    }

    @Test
    void getRoundsByTournamentIdTest() {

        RoundDetails round =
                new RoundDetails();

        RoundDetailsResponseDTO responseDTO =
                new RoundDetailsResponseDTO();

        when(roundDetailsRepo.findByTournamentId("TOUR_1"))
                .thenReturn(List.of(round));

        when(roundDetailsMapper.toResponseDTO(round))
                .thenReturn(responseDTO);

        List<RoundDetailsResponseDTO> response =
                roundDetailsService.getRoundsByTournamentId("TOUR_1");

        assertEquals(1, response.size());
    }

    @Test
    void updateRoundTest() {

        RoundDetails round =
                new RoundDetails();

        round.setRoundName("Round 1");
        round.setMaximumParticipants(10);
        round.setQualifyingCount(5);
        round.setTournamentId("TOUR_1");

        RoundDetailsUpdateDTO updateDTO =
                new RoundDetailsUpdateDTO();

        RoundDetailsResponseDTO responseDTO =
                new RoundDetailsResponseDTO();

        when(roundDetailsRepo.findById("1"))
                .thenReturn(Optional.of(round));

        when(roundDetailsRepo.save(round))
                .thenReturn(round);

        when(roundDetailsMapper.toResponseDTO(round))
                .thenReturn(responseDTO);

        RoundDetailsResponseDTO response =
                roundDetailsService.updateRound("1", updateDTO);

        assertNotNull(response);
    }

    @Test
    void updateRoundShouldThrowNotFoundException() {

        RoundDetailsUpdateDTO updateDTO =
                new RoundDetailsUpdateDTO();

        when(roundDetailsRepo.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> roundDetailsService.updateRound("1", updateDTO));
    }

    @Test
    void deleteRoundTest() {

        RoundDetails round =
                new RoundDetails();

        when(roundDetailsRepo.findById("1"))
                .thenReturn(Optional.of(round));

        doNothing().when(roundDetailsRepo)
                .delete(round);

        ResponseDTO response =
                roundDetailsService.deleteRound("1");

        assertNotNull(response);

        verify(roundDetailsRepo)
                .delete(round);
    }

    @Test
    void deleteRoundShouldThrowNotFoundException() {

        when(roundDetailsRepo.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> roundDetailsService.deleteRound("1"));
    }
}