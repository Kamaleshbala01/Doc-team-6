package com.esports.project.service.generation;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.TournamentGenerationEvent;
import com.esports.project.enums.TournamentFormat;
import com.esports.project.enums.seedType;
import com.esports.project.service.generation.factory.SeedingStrategyFactory;
import com.esports.project.service.generation.factory.TournamentGenerationFactory;
import com.esports.project.service.generation.strategy.SeedingStrategy;
import com.esports.project.service.generation.strategy.TournamentGenerationStrategy;

@ExtendWith(MockitoExtension.class)
class TournamentGenerationServiceTest {

    @Mock
    private SeedingStrategyFactory seedingStrategyFactory;

    @Mock
    private TournamentGenerationFactory tournamentGenerationFactory;

    @Mock
    private SeedingStrategy seedingStrategy;

    @Mock
    private TournamentGenerationStrategy tournamentGenerationStrategy;

    @InjectMocks
    private TournamentGenerationService tournamentGenerationService;

    @Test
    void generateTest() {

        TournamentGenerationEvent event =
                new TournamentGenerationEvent();

        event.setSeedType(seedType.RANDOM);
        event.setTournamentType(
                TournamentFormat.SINGLE_ELIMINATION);

        List<String> participants =
                List.of("A", "B", "C", "D");

        event.setParticipants(participants);

        when(seedingStrategyFactory.getStrategy(seedType.RANDOM))
                .thenReturn(seedingStrategy);

        when(seedingStrategy.process(participants))
                .thenReturn(participants);

        when(tournamentGenerationFactory.getStrategy(
                TournamentFormat.SINGLE_ELIMINATION))
                .thenReturn(tournamentGenerationStrategy);

        tournamentGenerationService.generate(event);

        verify(seedingStrategyFactory)
                .getStrategy(seedType.RANDOM);

        verify(seedingStrategy)
                .process(participants);

        verify(tournamentGenerationFactory)
                .getStrategy(
                        TournamentFormat.SINGLE_ELIMINATION);

        verify(tournamentGenerationStrategy)
                .generate(event, participants);
    }

    @Test
    void generateWithRoundRobinTest() {

        TournamentGenerationEvent event =
                new TournamentGenerationEvent();

        event.setSeedType(seedType.MANUAL);
        event.setTournamentType(
                TournamentFormat.ROUND_ROBIN);

        List<String> participants =
                List.of("A", "B");

        event.setParticipants(participants);

        when(seedingStrategyFactory.getStrategy(seedType.MANUAL))
                .thenReturn(seedingStrategy);

        when(seedingStrategy.process(participants))
                .thenReturn(participants);

        when(tournamentGenerationFactory.getStrategy(
                TournamentFormat.ROUND_ROBIN))
                .thenReturn(tournamentGenerationStrategy);

        tournamentGenerationService.generate(event);

        verify(tournamentGenerationStrategy)
                .generate(event, participants);
    }

    @Test
    void generateShouldThrowWhenSeedingFails() {

        TournamentGenerationEvent event =
                new TournamentGenerationEvent();

        event.setSeedType(seedType.RANDOM);

        when(seedingStrategyFactory.getStrategy(seedType.RANDOM))
                .thenReturn(seedingStrategy);

        when(seedingStrategy.process(null))
                .thenThrow(new RuntimeException("Seeding Error"));

        assertThrows(
                RuntimeException.class,
                () -> tournamentGenerationService.generate(event));
    }

    @Test
    void generateShouldThrowWhenTournamentGenerationFails() {

        TournamentGenerationEvent event =
                new TournamentGenerationEvent();

        event.setSeedType(seedType.RANDOM);
        event.setTournamentType(
                TournamentFormat.SINGLE_ELIMINATION);

        List<String> participants =
                List.of("A", "B");

        event.setParticipants(participants);

        when(seedingStrategyFactory.getStrategy(seedType.RANDOM))
                .thenReturn(seedingStrategy);

        when(seedingStrategy.process(participants))
                .thenReturn(participants);

        when(tournamentGenerationFactory.getStrategy(
                TournamentFormat.SINGLE_ELIMINATION))
                .thenReturn(tournamentGenerationStrategy);

        org.mockito.Mockito.doThrow(
                new RuntimeException("Generation Error"))
                .when(tournamentGenerationStrategy)
                .generate(event, participants);

        assertThrows(
                RuntimeException.class,
                () -> tournamentGenerationService.generate(event));
    }
}