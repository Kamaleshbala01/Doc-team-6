package com.esports.project.service.generation.seeding;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

class RandomSeedingStrategyTest {

    private final RandomSeedingStrategy strategy =
            new RandomSeedingStrategy();

    @Test
    void processTest() {

        List<String> participants =
                new ArrayList<>();

        participants.add("Team1");
        participants.add("Team2");
        participants.add("Team3");
        participants.add("Team4");

        List<String> result =
                strategy.process(participants);

        assertNotNull(result);
        assertEquals(4, result.size());
    }

    @Test
    void processWithEmptyListTest() {

        List<String> participants =
                new ArrayList<>();

        List<String> result =
                strategy.process(participants);

        assertNotNull(result);
        assertEquals(0, result.size());
    }

    @Test
    void processWithSingleParticipantTest() {

        List<String> participants =
                new ArrayList<>();

        participants.add("Team1");

        List<String> result =
                strategy.process(participants);

        assertEquals(1, result.size());
        assertEquals("Team1", result.get(0));
    }

    @Test
    void processShouldReturnSameReferenceTest() {

        List<String> participants =
                new ArrayList<>();

        participants.add("Team1");
        participants.add("Team2");

        List<String> result =
                strategy.process(participants);

        assertSame(participants, result);
    }

    @Test
    void processWithDuplicateParticipantsTest() {

        List<String> participants =
                new ArrayList<>();

        participants.add("Team1");
        participants.add("Team1");
        participants.add("Team2");

        List<String> result =
                strategy.process(participants);

        assertEquals(3, result.size());
    }

    @Test
    void processWithNullListTest() {

        assertThrows(
                NullPointerException.class,
                () -> strategy.process(null));
    }

    @Test
    void processShouldPreserveParticipantCountTest() {

        List<String> participants =
                new ArrayList<>();

        participants.add("A");
        participants.add("B");
        participants.add("C");
        participants.add("D");
        participants.add("E");

        int originalSize =
                participants.size();

        List<String> result =
                strategy.process(participants);

        assertEquals(originalSize, result.size());
    }

    @Test
    void processShouldContainAllParticipantsTest() {

        List<String> participants =
                new ArrayList<>();

        participants.add("A");
        participants.add("B");
        participants.add("C");
        participants.add("D");

        List<String> original =
                new ArrayList<>(participants);

        List<String> result =
                strategy.process(participants);

        Collections.sort(original);
        Collections.sort(result);

        assertEquals(original, result);
    }
}