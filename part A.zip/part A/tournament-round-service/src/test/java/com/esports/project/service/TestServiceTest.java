// package com.esports.project.service;

// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.Mockito.mock;
// import static org.mockito.Mockito.when;

// import org.junit.jupiter.api.Test;
// import org.springframework.security.core.Authentication;
// import org.springframework.security.core.context.SecurityContext;
// import org.springframework.security.core.context.SecurityContextHolder;

// import com.esports.project.DTO.UserDetailsDTO;
// import com.esports.project.exception.NotFoundException;

// class TestServiceTest {

//     private final TestService testService = new TestService();

//     @Test
//     void throwNotFoundTest() {

//         SecurityContext securityContext = mock(SecurityContext.class);
//         Authentication authentication = mock(Authentication.class);
//         UserDetailsDTO userDetails = new UserDetailsDTO();

//         when(securityContext.getAuthentication())
//                 .thenReturn(authentication);

//         when(authentication.getPrincipal())
//                 .thenReturn(userDetails);

//         SecurityContextHolder.setContext(securityContext);

//         assertThrows(
//                 NotFoundException.class,
//                 () -> testService.throwNotFound());
//     }

//     @Test
//     void throwNotFoundWithNullAuthenticationTest() {

//         SecurityContext securityContext = mock(SecurityContext.class);

//         when(securityContext.getAuthentication())
//                 .thenReturn(null);

//         SecurityContextHolder.setContext(securityContext);

//         assertThrows(
//                 NullPointerException.class,
//                 () -> testService.throwNotFound());
//     }

//     @Test
//     void throwNotFoundWithNullPrincipalTest() {

//         SecurityContext securityContext = mock(SecurityContext.class);
//         Authentication authentication = mock(Authentication.class);

//         when(securityContext.getAuthentication())
//                 .thenReturn(authentication);

//         when(authentication.getPrincipal())
//                 .thenReturn(null);

//         SecurityContextHolder.setContext(securityContext);

//         assertThrows(
//                 NotFoundException.class,
//                 () -> testService.throwNotFound());
//     }

//     @Test
//     void throwNotFoundWithWrongPrincipalTypeTest() {

//         SecurityContext securityContext = mock(SecurityContext.class);
//         Authentication authentication = mock(Authentication.class);

//         when(securityContext.getAuthentication())
//                 .thenReturn(authentication);

//         when(authentication.getPrincipal())
//                 .thenReturn("ADMIN");

//         SecurityContextHolder.setContext(securityContext);

//         assertThrows(
//                 ClassCastException.class,
//                 () -> testService.throwNotFound());
//     }
// }