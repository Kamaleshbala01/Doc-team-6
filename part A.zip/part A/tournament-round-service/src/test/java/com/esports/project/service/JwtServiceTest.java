package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import io.jsonwebtoken.Claims;

class JwtServiceTest {

    private static final String SECRET_KEY =
            "VGhpc0lzQVNlY3JldEtleUZvclRlc3RpbmdQdXJwb3Nlc09ubHkxMjM0NTY3ODkw";

    @Test
    void generateTokenTest() {

        JwtService jwtService = new JwtService();

        ReflectionTestUtils.setField(
                jwtService,
                "secretKey",
                SECRET_KEY);

        String token =
                jwtService.generateToken("testUser");

        assertNotNull(token);
        assertFalse(token.isEmpty());
    }

    @Test
    void validateTokenTest() {

        JwtService jwtService = new JwtService();

        ReflectionTestUtils.setField(
                jwtService,
                "secretKey",
                SECRET_KEY);

        String token =
                jwtService.generateToken("testUser");

        boolean result =
                jwtService.validateToken(token);

        assertTrue(result);
    }

    @Test
    void extractAllClaimsTest() {

        JwtService jwtService = new JwtService();

        ReflectionTestUtils.setField(
                jwtService,
                "secretKey",
                SECRET_KEY);

        String token =
                jwtService.generateToken("testUser");

        Claims claims =
                jwtService.extractAllClaims(token);

        assertNotNull(claims);
        assertEquals("testUser", claims.getSubject());
    }

    @Test
    void generatedTokenContainsSubjectTest() {

        JwtService jwtService = new JwtService();

        ReflectionTestUtils.setField(
                jwtService,
                "secretKey",
                SECRET_KEY);

        String token =
                jwtService.generateToken("TEAM_A");

        Claims claims =
                jwtService.extractAllClaims(token);

        assertEquals(
                "TEAM_A",
                claims.getSubject());
    }

    @Test
    void generatedTokenContainsTokenTypeTest() {

        JwtService jwtService = new JwtService();

        ReflectionTestUtils.setField(
                jwtService,
                "secretKey",
                SECRET_KEY);

        String token =
                jwtService.generateToken("testUser");

        Claims claims =
                jwtService.extractAllClaims(token);

        assertEquals(
                "SERVICE",
                claims.get("token_type"));
    }

    @Test
    void extractAllClaimsShouldThrowExceptionForInvalidToken() {

        JwtService jwtService = new JwtService();

        ReflectionTestUtils.setField(
                jwtService,
                "secretKey",
                SECRET_KEY);

        assertThrows(
                Exception.class,
                () -> jwtService.extractAllClaims("invalid-token"));
    }

    @Test
    void validateInvalidTokenShouldThrowException() {

        JwtService jwtService = new JwtService();

        ReflectionTestUtils.setField(
                jwtService,
                "secretKey",
                SECRET_KEY);

        assertThrows(
                Exception.class,
                () -> jwtService.validateToken("invalid-token"));
    }
}