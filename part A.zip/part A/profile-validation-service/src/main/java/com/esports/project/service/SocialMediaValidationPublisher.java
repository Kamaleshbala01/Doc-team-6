package com.esports.project.service;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.DTO.SocialMediaValidationResultEvent;
import com.esports.project.websocket.PublisherBrokerClient;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SocialMediaValidationPublisher {

    private final PublisherBrokerClient brokerClient;

    public void publishValidationCompleted(
            SocialMediaValidationResultEvent result)
            throws Exception {

        BrokerMessage message =
                new BrokerMessage();

        message.setType("PUBLISH");
        message.setTopic("validation.validationcompleted");
        message.setPayload(result);

        brokerClient.publish(message);
    }
}