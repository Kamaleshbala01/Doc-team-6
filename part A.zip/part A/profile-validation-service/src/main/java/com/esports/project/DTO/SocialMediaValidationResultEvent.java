package com.esports.project.DTO;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SocialMediaValidationResultEvent {

    private String id;

    private Long followersCount;

    private Long subscriberCount;

    private Long totalViews;

    private Long totalLikes;

    private Long totalComments;

    private BigDecimal viewSubscriptionRatio;

    private BigDecimal viewCommentRatio;

    private BigDecimal engagementRate;

    private BigDecimal genuineInfluencerScore;

    private String influencerRating;

    private String status;

}
