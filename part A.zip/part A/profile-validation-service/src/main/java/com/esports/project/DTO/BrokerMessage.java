package com.esports.project.DTO;


import lombok.Data;

@Data
public class BrokerMessage {
    private String type;
    private String topic;
    private Long offset;
    private Object payload;
}
