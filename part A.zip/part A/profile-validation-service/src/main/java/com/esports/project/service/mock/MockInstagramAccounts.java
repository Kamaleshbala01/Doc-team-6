package com.esports.project.service.mock;

import java.util.Map;

public class MockInstagramAccounts {

    public static final Map<String, Long> ACCOUNTS =
            Map.of(
                    "cristiano", 700_000_000L,
                    "leomessi", 540_000_000L,
                    "virat.kohli", 320_000_000L,
                    "therock", 420_000_000L,
                    "selenagomez", 500_000_000L,
                    "aliaabhatt", 90_000_000L,
                    "shraddhakapoor", 95_000_000L,
                    "deepikapadukone", 82_000_000L,
                    "msdhoni", 50_000_000L,
                    "narendramodi", 105_000_000L
            );
}
