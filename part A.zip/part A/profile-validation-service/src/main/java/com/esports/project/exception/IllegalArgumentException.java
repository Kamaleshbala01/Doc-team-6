package com.esports.project.exception;

public class IllegalArgumentException extends CustomException {
    public IllegalArgumentException(String message){
        super(message);
    }
    
}
