package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentRegistrationRequestDTO;
import com.esports.project.DTO.TournamentRegistrationResponseDTO;
import com.esports.project.DTO.TournamentRegistrationUpdateDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.entity.TournamentRegistration;
import com.esports.project.enums.StatusMaster;
import com.esports.project.exception.IllegalArgumentException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentRegistrationMapper;
import com.esports.project.repository.TournamentRegistrationRepo;
import com.esports.project.repository.TournamentRepo;

@ExtendWith(MockitoExtension.class)
class TournamentRegistrationServiceTest {

    @Mock
    private TournamentRegistrationRepo tournamentRegistrationRepo;

    @Mock
    private TournamentRepo tournamentRepo;

    @Mock
    private TournamentRegistrationMapper tournamentRegistrationMapper;

    @InjectMocks
    private TournamentRegistrationService service;

    private Tournament tournament;
    private TournamentRegistration registration;
    private TournamentRegistrationRequestDTO requestDTO;
    private TournamentRegistrationResponseDTO responseDTO;

    @BeforeEach
    void setUp() {

        tournament = new Tournament();
        tournament.setId("T1");

        registration = new TournamentRegistration();
        registration.setId("R1");
        registration.setTournament(tournament);
        registration.setTeamId("TEAM1");
        registration.setRegistrationStatus(StatusMaster.REGISTERED);
        registration.setRegistrationDate(LocalDateTime.now());

        requestDTO = new TournamentRegistrationRequestDTO();
        requestDTO.setTournamentId("T1");
        requestDTO.setTeamId("TEAM1");

        responseDTO = new TournamentRegistrationResponseDTO();
    }

    @Test
    void createRegistration_ShouldCreateSuccessfully() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentRegistrationRepo
                .existsByTournament_IdAndTeamId("T1", "TEAM1"))
                .thenReturn(false);

        when(tournamentRegistrationMapper.toEntity(requestDTO))
                .thenReturn(registration);

        when(tournamentRegistrationRepo.save(any()))
                .thenReturn(registration);

        when(tournamentRegistrationMapper.toResponseDTO(registration))
                .thenReturn(responseDTO);

        TournamentRegistrationResponseDTO result =
                service.createRegistration(requestDTO);

        assertNotNull(result);

        verify(tournamentRegistrationRepo)
                .save(any(TournamentRegistration.class));
    }

    @Test
    void createRegistration_ShouldThrowNotFound_WhenTournamentMissing() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.createRegistration(requestDTO));
    }

    @Test
    void createRegistration_ShouldThrowException_WhenAlreadyRegistered() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentRegistrationRepo
                .existsByTournament_IdAndTeamId("T1", "TEAM1"))
                .thenReturn(true);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.createRegistration(requestDTO));
    }

    @Test
    void createRegistration_ShouldThrowValidationError_WhenTeamMissing() {

        registration.setTeamId(null);

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentRegistrationRepo
                .existsByTournament_IdAndTeamId("T1", "TEAM1"))
                .thenReturn(false);

        when(tournamentRegistrationMapper.toEntity(requestDTO))
                .thenReturn(registration);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.createRegistration(requestDTO));
    }

    @Test
    void getRegistrationById_ShouldReturnRegistration() {

        when(tournamentRegistrationRepo.findById("R1"))
                .thenReturn(Optional.of(registration));

        when(tournamentRegistrationMapper.toResponseDTO(registration))
                .thenReturn(responseDTO);

        TournamentRegistrationResponseDTO result =
                service.getRegistrationById("R1");

        assertNotNull(result);
    }

    @Test
    void getRegistrationById_ShouldThrowNotFound() {

        when(tournamentRegistrationRepo.findById("R1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getRegistrationById("R1"));
    }

    @Test
    void updateRegistration_ShouldUpdateSuccessfully() {

        TournamentRegistrationUpdateDTO updateDTO =
                new TournamentRegistrationUpdateDTO();

        when(tournamentRegistrationRepo.findById("R1"))
                .thenReturn(Optional.of(registration));

        doNothing().when(tournamentRegistrationMapper)
                .updateRegistrationFromDTO(updateDTO, registration);

        when(tournamentRegistrationRepo.save(any()))
                .thenReturn(registration);

        when(tournamentRegistrationMapper.toResponseDTO(registration))
                .thenReturn(responseDTO);

        TournamentRegistrationResponseDTO result =
                service.updateRegistration("R1", updateDTO);

        assertNotNull(result);

        verify(tournamentRegistrationMapper)
                .updateRegistrationFromDTO(updateDTO, registration);

        verify(tournamentRegistrationRepo)
                .save(registration);
    }

    @Test
    void updateRegistration_ShouldThrowNotFound() {

        TournamentRegistrationUpdateDTO updateDTO =
                new TournamentRegistrationUpdateDTO();

        when(tournamentRegistrationRepo.findById("R1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.updateRegistration("R1", updateDTO));
    }

    @Test
    void deleteRegistration_ShouldDeleteSuccessfully() {

        when(tournamentRegistrationRepo.findById("R1"))
                .thenReturn(Optional.of(registration));

        ResponseDTO response =
                service.deleteRegistration("R1");

        assertNotNull(response);

        verify(tournamentRegistrationRepo)
                .delete(registration);
    }

    @Test
    void deleteRegistration_ShouldThrowNotFound() {

        when(tournamentRegistrationRepo.findById("R1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.deleteRegistration("R1"));
    }

//     @Test
//     void getTournamentRegistrations_ShouldThrowNotFound() {

//         when(tournamentRepo.existsById("T1"))
//                 .thenReturn(false);

//         assertThrows(
//                 NotFoundException.class,
//                 () -> service.getTournamentRegistrations("T1", null));
//     }
}