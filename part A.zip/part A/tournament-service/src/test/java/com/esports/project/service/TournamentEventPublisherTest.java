package com.esports.project.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.DTO.TournamentGenerationEvent;
import com.esports.project.websocket.BrokerClient;

@ExtendWith(MockitoExtension.class)
class TournamentEventPublisherTest {

    @Mock
    private BrokerClient brokerClient;

    @InjectMocks
    private TournamentEventPublisher publisher;

    @Test
    void publishTournamentCreated_ShouldPublishCorrectMessage() throws Exception {

        TournamentGenerationEvent event =
                new TournamentGenerationEvent();

        publisher.publishTournamentCreated(event);

        ArgumentCaptor<BrokerMessage> captor =
                ArgumentCaptor.forClass(BrokerMessage.class);

        verify(brokerClient, times(1))
                .publish(captor.capture());

        BrokerMessage message = captor.getValue();

        org.junit.jupiter.api.Assertions.assertEquals(
                "PUBLISH",
                message.getType());

        org.junit.jupiter.api.Assertions.assertEquals(
                "tournament.created",
                message.getTopic());

        org.junit.jupiter.api.Assertions.assertEquals(
                event,
                message.getPayload());
    }
}