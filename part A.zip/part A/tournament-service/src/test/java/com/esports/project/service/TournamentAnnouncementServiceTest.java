package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentAnnouncementRequestDTO;
import com.esports.project.DTO.TournamentAnnouncementResponseDTO;
import com.esports.project.DTO.TournamentAnnouncementUpdateDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.entity.TournamentAnnouncement;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentAnnouncementMapper;
import com.esports.project.repository.TournamentAnnouncementRepo;
import com.esports.project.repository.TournamentRepo;

@ExtendWith(MockitoExtension.class)
class TournamentAnnouncementServiceTest {

    @Mock
    private TournamentAnnouncementRepo tournamentAnnouncementRepo;

    @Mock
    private TournamentRepo tournamentRepo;

    @Mock
    private TournamentAnnouncementMapper tournamentAnnouncementMapper;

    @InjectMocks
    private TournamentAnnouncementService service;

    private Tournament tournament;
    private TournamentAnnouncement announcement;
    private TournamentAnnouncementRequestDTO requestDTO;
    private TournamentAnnouncementResponseDTO responseDTO;

    @BeforeEach
    void setUp() {

        tournament = new Tournament();
        tournament.setId("T1");

        announcement = new TournamentAnnouncement();
        announcement.setId("A1");
        announcement.setTitle("Tournament Started");
        announcement.setContent("Registration is open");
        announcement.setTournament(tournament);

        requestDTO = new TournamentAnnouncementRequestDTO();
        requestDTO.setTournamentId("T1");

        responseDTO = new TournamentAnnouncementResponseDTO();
    }

    @Test
    void createAnnouncement_ShouldCreateSuccessfully() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentAnnouncementMapper.toEntity(requestDTO))
                .thenReturn(announcement);

        when(tournamentAnnouncementRepo.save(any(TournamentAnnouncement.class)))
                .thenReturn(announcement);

        when(tournamentAnnouncementMapper.toResponseDTO(announcement))
                .thenReturn(responseDTO);

        TournamentAnnouncementResponseDTO result =
                service.createAnnouncement(requestDTO);

        assertNotNull(result);

        verify(tournamentRepo).findById("T1");
        verify(tournamentAnnouncementRepo).save(any());
    }

    @Test
    void createAnnouncement_ShouldThrowNotFound_WhenTournamentMissing() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.createAnnouncement(requestDTO));
    }

    @Test
    void createAnnouncement_ShouldThrowException_WhenTitleEmpty() {

        announcement.setTitle("");

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentAnnouncementMapper.toEntity(requestDTO))
                .thenReturn(announcement);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.createAnnouncement(requestDTO));
    }

    @Test
    void getAnnouncementById_ShouldReturnAnnouncement() {

        when(tournamentAnnouncementRepo.findById("A1"))
                .thenReturn(Optional.of(announcement));

        when(tournamentAnnouncementMapper.toResponseDTO(announcement))
                .thenReturn(responseDTO);

        TournamentAnnouncementResponseDTO result =
                service.getAnnouncementById("A1");

        assertNotNull(result);
    }

    @Test
    void getAnnouncementById_ShouldThrowNotFound() {

        when(tournamentAnnouncementRepo.findById("A1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getAnnouncementById("A1"));
    }

    @Test
    void getAnnouncementsByTournamentId_ShouldReturnList() {

        when(tournamentRepo.existsById("T1"))
                .thenReturn(true);

        when(tournamentAnnouncementRepo.findByTournament_Id("T1"))
                .thenReturn(Collections.singletonList(announcement));

        when(tournamentAnnouncementMapper.toResponseDTO(announcement))
                .thenReturn(responseDTO);

        assertEquals(
                1,
                service.getAnnouncementsByTournamentId("T1").size());
    }

    @Test
    void getAnnouncementsByTournamentId_ShouldThrowNotFound() {

        when(tournamentRepo.existsById("T1"))
                .thenReturn(false);

        assertThrows(
                NotFoundException.class,
                () -> service.getAnnouncementsByTournamentId("T1"));
    }

    @Test
    void updateAnnouncement_ShouldUpdateSuccessfully() {

        TournamentAnnouncementUpdateDTO updateDTO =
                new TournamentAnnouncementUpdateDTO();

        updateDTO.setTitle("Updated Title");

        when(tournamentAnnouncementRepo.findById("A1"))
                .thenReturn(Optional.of(announcement));

        when(tournamentAnnouncementRepo.save(any(TournamentAnnouncement.class)))
                .thenReturn(announcement);

        when(tournamentAnnouncementMapper.toResponseDTO(any()))
                .thenReturn(responseDTO);

        TournamentAnnouncementResponseDTO result =
                service.updateAnnouncement("A1", updateDTO);

        assertNotNull(result);

        verify(tournamentAnnouncementRepo).save(any());
    }

    @Test
    void updateAnnouncement_ShouldThrowNotFound() {

        TournamentAnnouncementUpdateDTO updateDTO =
                new TournamentAnnouncementUpdateDTO();

        when(tournamentAnnouncementRepo.findById("A1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.updateAnnouncement("A1", updateDTO));
    }

    @Test
    void deleteAnnouncement_ShouldDeleteSuccessfully() {

        when(tournamentAnnouncementRepo.findById("A1"))
                .thenReturn(Optional.of(announcement));

        ResponseDTO response =
                service.deleteAnnouncement("A1");

        assertNotNull(response);

        verify(tournamentAnnouncementRepo)
                .delete(announcement);
    }

    @Test
    void deleteAnnouncement_ShouldThrowNotFound() {

        when(tournamentAnnouncementRepo.findById("A1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.deleteAnnouncement("A1"));
    }
}