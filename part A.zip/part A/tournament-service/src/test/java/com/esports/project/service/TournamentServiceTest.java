package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentRequestDTO;
import com.esports.project.DTO.TournamentResponseDTO;
import com.esports.project.DTO.TournamentUpdateDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.enums.SeedType;
import com.esports.project.enums.StatusMaster;
import com.esports.project.enums.TournamentCategory;
import com.esports.project.enums.TournamentType;
import com.esports.project.enums.TournamentVerification;
import com.esports.project.exception.IllegalArgumentException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentMapper;
import com.esports.project.repository.TournamentRepo;

@ExtendWith(MockitoExtension.class)
class TournamentServiceTest {

    @Mock
    private TournamentRepo tournamentRepo;

    @Mock
    private TournamentMapper tournamentMapper;

    @Mock
    private TournamentEventPublisher tournamentEventPublisher;

    @InjectMocks
    private TournamentService tournamentService;

    private Tournament tournament;
    private TournamentResponseDTO responseDTO;

    @BeforeEach
    void setUp() {

        UserDetailsDTO user =
                new UserDetailsDTO(
                        "USER1",
                        "testuser",
                        List.of("ADMIN"),
                        List.of());

        SecurityContextHolder.getContext()
                .setAuthentication(
                        new UsernamePasswordAuthenticationToken(
                                user,
                                null));

        tournament = new Tournament();

        tournament.setId("T1");
        tournament.setName("Tournament");
        tournament.setDescription("Tournament Description");
        tournament.setUserId("USER1");

        tournament.setRegistrationStartDate(
                LocalDateTime.now().plusDays(1));
        tournament.setRegistrationEndDate(
                LocalDateTime.now().plusDays(2));
        tournament.setTournamentStartDate(
                LocalDateTime.now().plusDays(3));
        tournament.setTournamentEndDate(
                LocalDateTime.now().plusDays(4));

        tournament.setTournamentCategory(
                TournamentCategory.BRACKETS);

        tournament.setTournamentType(
                TournamentType.SINGLE_ELIMINATION);

        tournament.setSeedingTypeId(
                SeedType.RANDOM);

        tournament.setVerificationRequired(
                TournamentVerification.NO);

        tournament.setMaximumTeams(16);
        tournament.setMaximumPlayersPerTeam(5);
        tournament.setEntryFee(BigDecimal.ZERO);

        tournament.setStatus(StatusMaster.UPCOMMING);
        tournament.setIsDeleted(false);
        tournament.setIsLocked(false);

        responseDTO = new TournamentResponseDTO();
    }

    @AfterEach
    void cleanup() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void createTournament_ShouldCreateSuccessfully() {

        TournamentRequestDTO request =
                new TournamentRequestDTO();

        request.setName("Tournament");
        request.setDescription("Description");

        request.setRegistrationStartDate(
                LocalDateTime.now().plusDays(1));

        request.setRegistrationEndDate(
                LocalDateTime.now().plusDays(2));

        request.setTournamentStartDate(
                LocalDateTime.now().plusDays(3));

        request.setTournamentEndDate(
                LocalDateTime.now().plusDays(4));

        request.setTournamentCategory(
                TournamentCategory.BRACKETS);

        request.setTournamentType(
                TournamentType.SINGLE_ELIMINATION);

        when(tournamentMapper.toEntity(request))
                .thenReturn(tournament);

        when(tournamentRepo.save(any()))
                .thenReturn(tournament);

        when(tournamentMapper.toResponseDTO(tournament))
                .thenReturn(responseDTO);

        TournamentResponseDTO result =
                tournamentService.createTournament(request);

        assertNotNull(result);
    }

    @Test
    void createTournament_ShouldThrowPastDateError() {

        TournamentRequestDTO request =
                new TournamentRequestDTO();

        request.setRegistrationStartDate(
                LocalDateTime.now().minusDays(1));

        assertThrows(
                IllegalArgumentException.class,
                () -> tournamentService.createTournament(request));
    }

    @Test
    void createTournament_ShouldThrowTypeCategoryMismatch() {

        TournamentRequestDTO request =
                new TournamentRequestDTO();

        request.setRegistrationStartDate(
                LocalDateTime.now().plusDays(1));

        request.setRegistrationEndDate(
                LocalDateTime.now().plusDays(2));

        request.setTournamentStartDate(
                LocalDateTime.now().plusDays(3));

        request.setTournamentEndDate(
                LocalDateTime.now().plusDays(4));

        request.setTournamentType(
                TournamentType.SINGLE_ELIMINATION);

        request.setTournamentCategory(
                TournamentCategory.LEADERBOARD);

        assertThrows(
                IllegalArgumentException.class,
                () -> tournamentService.createTournament(request));
    }

    @Test
    void patchUpdateTournament_ShouldUpdateSuccessfully() {

        TournamentUpdateDTO updateDTO =
                new TournamentUpdateDTO();

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        doNothing().when(tournamentMapper)
                .updateTournamentFromDto(
                        updateDTO,
                        tournament);

        when(tournamentRepo.save(tournament))
                .thenReturn(tournament);

        when(tournamentMapper.toResponseDTO(tournament))
                .thenReturn(responseDTO);

        TournamentResponseDTO result =
                tournamentService.patchUpdateTournament(
                        "T1",
                        updateDTO);

        assertNotNull(result);
    }

    @Test
    void patchUpdateTournament_ShouldThrowOwnershipException() {

        tournament.setUserId("OTHER_USER");

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        assertThrows(
                IllegalArgumentException.class,
                () -> tournamentService.patchUpdateTournament(
                        "T1",
                        new TournamentUpdateDTO()));
    }

    @Test
    void patchUpdateTournament_ShouldThrowNotFound() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> tournamentService.patchUpdateTournament(
                        "T1",
                        new TournamentUpdateDTO()));
    }

    @Test
    void getMyTournaments_ShouldReturnList() {

        when(tournamentRepo.findByUserId("USER1"))
                .thenReturn(List.of(tournament));

        when(tournamentMapper.toResponseDTO(tournament))
                .thenReturn(responseDTO);

        List<TournamentResponseDTO> result =
                tournamentService.getMyTournaments();

        assertEquals(1, result.size());
    }

    @Test
    void getMyTournamentById_ShouldReturnTournament() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentMapper.toResponseDTO(tournament))
                .thenReturn(responseDTO);

        TournamentResponseDTO result =
                tournamentService.getMyTournamentById("T1");

        assertNotNull(result);
    }

    @Test
    void getMyTournamentById_ShouldThrowNotFound() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> tournamentService.getMyTournamentById("T1"));
    }

    @Test
    void softDeleteTournament_ShouldDeleteSuccessfully() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        ResponseDTO result =
                tournamentService.softDeleteTournament("T1");

        assertEquals(200, result.getStatus());

        verify(tournamentRepo).save(tournament);
    }

    @Test
    void lockMyTournament_ShouldLockSuccessfully()
            throws Exception {

        when(tournamentRepo.findByIdWithRegistrations("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentRepo.save(any()))
                .thenReturn(tournament);

        doNothing()
                .when(tournamentEventPublisher)
                .publishTournamentCreated(any());

        ResponseDTO result =
                tournamentService.lockMyTournament("T1");

        assertEquals(200, result.getStatus());
    }

    @Test
    void lockMyTournament_ShouldReturnAlreadyLocked() {

        tournament.setIsLocked(true);

        when(tournamentRepo.findByIdWithRegistrations("T1"))
                .thenReturn(Optional.of(tournament));

        ResponseDTO result =
                tournamentService.lockMyTournament("T1");

        assertEquals(400, result.getStatus());
    }

    @Test
    void lockMyTournament_ShouldHandlePublisherFailure()
            throws Exception {

        when(tournamentRepo.findByIdWithRegistrations("T1"))
                .thenReturn(Optional.of(tournament));

        doThrow(new RuntimeException("Broker Error"))
                .when(tournamentEventPublisher)
                .publishTournamentCreated(any());

        ResponseDTO result =
                tournamentService.lockMyTournament("T1");

        assertEquals(500, result.getStatus());
    }

    @Test
    void lockMyTournament_ShouldThrowNotFound() {

        when(tournamentRepo.findByIdWithRegistrations("T1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> tournamentService.lockMyTournament("T1"));
    }
    @Test
void createTournament_ShouldThrow_WhenRegistrationEndBeforeStart() {

    TournamentRequestDTO dto = new TournamentRequestDTO();

    dto.setRegistrationStartDate(
            LocalDateTime.now().plusDays(2));

    dto.setRegistrationEndDate(
            LocalDateTime.now().plusDays(1));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.createTournament(dto));
}

@Test
void createTournament_ShouldThrow_WhenTournamentStartBeforeRegistrationEnd() {

    TournamentRequestDTO dto = new TournamentRequestDTO();

    dto.setRegistrationStartDate(
            LocalDateTime.now().plusDays(1));

    dto.setRegistrationEndDate(
            LocalDateTime.now().plusDays(5));

    dto.setTournamentStartDate(
            LocalDateTime.now().plusDays(2));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.createTournament(dto));
}

@Test
void createTournament_ShouldThrow_WhenTournamentEndBeforeTournamentStart() {

    TournamentRequestDTO dto = new TournamentRequestDTO();

    dto.setRegistrationStartDate(
            LocalDateTime.now().plusDays(1));

    dto.setRegistrationEndDate(
            LocalDateTime.now().plusDays(2));

    dto.setTournamentStartDate(
            LocalDateTime.now().plusDays(5));

    dto.setTournamentEndDate(
            LocalDateTime.now().plusDays(4));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.createTournament(dto));
}

@Test
void getMyTournamentById_ShouldThrowOwnershipException() {

    tournament.setUserId("OTHER_USER");

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.getMyTournamentById("T1"));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenTournamentNameMissing() {

    tournament.setName(null);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenDescriptionMissing() {

    tournament.setDescription(null);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenRegistrationStartDateMissing() {

    tournament.setRegistrationStartDate(null);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenRegistrationEndDateMissing() {

    tournament.setRegistrationEndDate(null);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenTournamentStartDateMissing() {

    tournament.setTournamentStartDate(null);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenTournamentEndDateMissing() {

    tournament.setTournamentEndDate(null);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenTournamentCategoryMissing() {

    tournament.setTournamentCategory(null);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenTournamentTypeMissing() {

    tournament.setTournamentType(null);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenSeedTypeMissing() {

    tournament.setSeedingTypeId(null);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenVerificationMissing() {

    tournament.setVerificationRequired(null);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenMaximumTeamsInvalid() {

    tournament.setMaximumTeams(0);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenMaximumPlayersInvalid() {

    tournament.setMaximumPlayersPerTeam(0);

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenEntryFeeNegative() {

    tournament.setEntryFee(
            new BigDecimal("-10"));

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}

@Test
void patchUpdateTournament_ShouldThrow_WhenUserIdMissing() {

    tournament.setUserId("");

    when(tournamentRepo.findById("T1"))
            .thenReturn(Optional.of(tournament));

    assertThrows(
            IllegalArgumentException.class,
            () -> tournamentService.patchUpdateTournament(
                    "T1",
                    new TournamentUpdateDTO()));
}
}