// package com.esports.project.controller;

// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.eq;
// import static org.mockito.Mockito.when;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
// import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

// import java.util.List;

// import org.junit.jupiter.api.Test;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
// import org.springframework.boot.test.mock.mockito.MockBean;
// import org.springframework.data.domain.PageImpl;
// import org.springframework.http.MediaType;
// import org.springframework.test.web.servlet.MockMvc;

// import com.esports.project.DTO.ResponseDTO;
// import com.esports.project.DTO.TournamentAnnouncementRequestDTO;
// import com.esports.project.DTO.TournamentAnnouncementResponseDTO;
// import com.esports.project.DTO.TournamentAnnouncementUpdateDTO;
// import com.esports.project.service.TournamentAnnouncementService;
// import com.fasterxml.jackson.databind.ObjectMapper;

// @WebMvcTest(TournamentAnnouncementController.class)
// class TournamentAnnouncementControllerTest {

//     @Autowired
//     private MockMvc mockMvc;

//     @MockBean
//     private TournamentAnnouncementService tournamentAnnouncementService;

//     @Autowired
//     private ObjectMapper objectMapper;

//     @Test
//     void createAnnouncement_ShouldReturnCreated()
//             throws Exception {

//         TournamentAnnouncementRequestDTO request =
//                 new TournamentAnnouncementRequestDTO();

//         TournamentAnnouncementResponseDTO response =
//                 new TournamentAnnouncementResponseDTO();

//         when(tournamentAnnouncementService
//                 .createAnnouncement(any()))
//                 .thenReturn(response);

//         mockMvc.perform(
//                 post("/tournament-announcement")
//                         .contentType(MediaType.APPLICATION_JSON)
//                         .content(objectMapper.writeValueAsString(request)))
//                 .andExpect(status().isCreated());
//     }

//     @Test
//     void getAnnouncementById_ShouldReturnOk()
//             throws Exception {

//         TournamentAnnouncementResponseDTO response =
//                 new TournamentAnnouncementResponseDTO();

//         when(tournamentAnnouncementService
//                 .getAnnouncementById("A1"))
//                 .thenReturn(response);

//         mockMvc.perform(
//                 get("/tournament-announcement/A1"))
//                 .andExpect(status().isOk());
//     }

//     @Test
//     void getAnnouncementsByTournamentId_ShouldReturnOk()
//             throws Exception {

//         when(tournamentAnnouncementService
//                 .getAnnouncementsByTournamentId("T1"))
//                 .thenReturn(
//                         List.of(
//                                 new TournamentAnnouncementResponseDTO()));

//         mockMvc.perform(
//                 get("/tournament-announcement/tournament/T1"))
//                 .andExpect(status().isOk());
//     }

//     @Test
//     void updateAnnouncement_ShouldReturnAccepted()
//             throws Exception {

//         TournamentAnnouncementUpdateDTO dto =
//                 new TournamentAnnouncementUpdateDTO();

//         TournamentAnnouncementResponseDTO response =
//                 new TournamentAnnouncementResponseDTO();

//         when(tournamentAnnouncementService
//                 .updateAnnouncement(
//                         eq("A1"),
//                         any(TournamentAnnouncementUpdateDTO.class)))
//                 .thenReturn(response);

//         mockMvc.perform(
//                 patch("/tournament-announcement/A1")
//                         .contentType(MediaType.APPLICATION_JSON)
//                         .content(
//                                 objectMapper.writeValueAsString(dto)))
//                 .andExpect(status().isAccepted());
//     }

//     @Test
//     void deleteAnnouncement_ShouldReturnOk()
//             throws Exception {

//         when(tournamentAnnouncementService
//                 .deleteAnnouncement("A1"))
//                 .thenReturn(
//                         new ResponseDTO(
//                                 200,
//                                 "Deleted"));

//         mockMvc.perform(
//                 delete("/tournament-announcement/A1"))
//                 .andExpect(status().isOk());
//     }

//     @Test
//     void getTournamentAnnouncements_ShouldReturnOk()
//             throws Exception {

//         when(tournamentAnnouncementService
//                 .getTournamentAnnouncements(
//                         eq("T1"),
//                         any()))
//                 .thenReturn(
//                         new PageImpl<>(
//                                 List.of(
//                                         new TournamentAnnouncementResponseDTO())));

//         mockMvc.perform(
//                 get("/tournament-announcement/tournament/T1/page")
//                         .param("page", "0")
//                         .param("size", "10"))
//                 .andExpect(status().isOk());
//     }

//     @Test
//     void filterAnnouncements_ShouldReturnOk()
//             throws Exception {

//         when(tournamentAnnouncementService
//                 .filterAnnouncements(
//                         eq("Title"),
//                         eq("T1"),
//                         any()))
//                 .thenReturn(
//                         new PageImpl<>(
//                                 List.of(
//                                         new TournamentAnnouncementResponseDTO())));

//         mockMvc.perform(
//                 get("/tournament-announcement/filter")
//                         .param("title", "Title")
//                         .param("tournamentId", "T1")
//                         .param("page", "0")
//                         .param("size", "10"))
//                 .andExpect(status().isOk());
//     }

//     @Test
//     void filterAnnouncements_ShouldReturnOk_WhenOptionalParamsMissing()
//             throws Exception {

//         when(tournamentAnnouncementService
//                 .filterAnnouncements(
//                         any(),
//                         any(),
//                         any()))
//                 .thenReturn(
//                         new PageImpl<>(
//                                 List.of()));

//         mockMvc.perform(
//                 get("/tournament-announcement/filter"))
//                 .andExpect(status().isOk());
//     }
// }