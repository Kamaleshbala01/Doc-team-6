package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentFAQRequestDTO;
import com.esports.project.DTO.TournamentFAQResponseDTO;
import com.esports.project.DTO.TournamentFAQUpdateDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.entity.TournamentFAQ;
import com.esports.project.exception.IllegalArgumentException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentFAQMapper;
import com.esports.project.repository.TournamentFAQRepo;
import com.esports.project.repository.TournamentRepo;

@ExtendWith(MockitoExtension.class)
class TournamentFAQServiceTest {

    @Mock
    private TournamentFAQRepo tournamentFAQRepo;

    @Mock
    private TournamentRepo tournamentRepo;

    @Mock
    private TournamentFAQMapper tournamentFAQMapper;

    @InjectMocks
    private TournamentFAQService service;

    private Tournament tournament;
    private TournamentFAQ faq;
    private TournamentFAQRequestDTO requestDTO;
    private TournamentFAQResponseDTO responseDTO;
    private UserDetailsDTO userDetails;

    @BeforeEach
    void setUp() {

        userDetails = new UserDetailsDTO(null, null, null, null);
        userDetails.setUserId("USER1");

        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(
                        userDetails,
                        null));

        tournament = new Tournament();
        tournament.setId("T1");
        tournament.setUserId("HOST1");

        faq = new TournamentFAQ();
        faq.setId("FAQ1");
        faq.setQuestion("When does tournament start?");
        faq.setTournament(tournament);
        faq.setUserId("USER1");

        requestDTO = new TournamentFAQRequestDTO();
        requestDTO.setTournamentId("T1");

        responseDTO = new TournamentFAQResponseDTO();
    }

    @AfterEach
    void cleanup() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void createFAQ_ShouldCreateSuccessfully() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentFAQMapper.toEntity(requestDTO))
                .thenReturn(faq);

        when(tournamentFAQRepo.save(any(TournamentFAQ.class)))
                .thenReturn(faq);

        when(tournamentFAQMapper.toResponseDTO(faq))
                .thenReturn(responseDTO);

        TournamentFAQResponseDTO result =
                service.createFAQ(requestDTO);

        assertNotNull(result);

        verify(tournamentFAQRepo).save(any());
    }

    @Test
    void createFAQ_ShouldThrowNotFound() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.createFAQ(requestDTO));
    }

    @Test
    void createFAQ_ShouldThrowValidationError() {

        faq.setQuestion("");

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentFAQMapper.toEntity(requestDTO))
                .thenReturn(faq);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.createFAQ(requestDTO));
    }

    @Test
    void getFAQById_ShouldReturnFAQ() {

        when(tournamentFAQRepo.findById("FAQ1"))
                .thenReturn(Optional.of(faq));

        when(tournamentFAQMapper.toResponseDTO(faq))
                .thenReturn(responseDTO);

        TournamentFAQResponseDTO result =
                service.getFAQById("FAQ1");

        assertNotNull(result);
    }

    @Test
    void getFAQById_ShouldThrowNotFound() {

        when(tournamentFAQRepo.findById("FAQ1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getFAQById("FAQ1"));
    }

    @Test
    void answerFAQ_ShouldAnswerSuccessfully() {

        userDetails.setUserId("HOST1");

        TournamentFAQUpdateDTO updateDTO =
                new TournamentFAQUpdateDTO();
        updateDTO.setAnswer("Tomorrow at 10 AM");

        when(tournamentFAQRepo.findById("FAQ1"))
                .thenReturn(Optional.of(faq));

        when(tournamentFAQRepo.save(any(TournamentFAQ.class)))
                .thenReturn(faq);

        when(tournamentFAQMapper.toResponseDTO(any()))
                .thenReturn(responseDTO);

        TournamentFAQResponseDTO result =
                service.answerFAQ("FAQ1", updateDTO);

        assertNotNull(result);

        verify(tournamentFAQRepo).save(any());
    }

    @Test
    void answerFAQ_ShouldThrowIfNotHost() {

        TournamentFAQUpdateDTO updateDTO =
                new TournamentFAQUpdateDTO();
        updateDTO.setAnswer("Test");

        when(tournamentFAQRepo.findById("FAQ1"))
                .thenReturn(Optional.of(faq));

        assertThrows(
                IllegalArgumentException.class,
                () -> service.answerFAQ("FAQ1", updateDTO));
    }

    @Test
    void answerFAQ_ShouldThrowNotFound() {

        TournamentFAQUpdateDTO updateDTO =
                new TournamentFAQUpdateDTO();

        when(tournamentFAQRepo.findById("FAQ1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.answerFAQ("FAQ1", updateDTO));
    }

    @Test
    void deleteFAQ_ShouldDeleteSuccessfully() {

        when(tournamentFAQRepo.findById("FAQ1"))
                .thenReturn(Optional.of(faq));

        ResponseDTO response =
                service.deleteFAQ("FAQ1");

        assertNotNull(response);

        verify(tournamentFAQRepo).delete(faq);
    }

    @Test
    void deleteFAQ_ShouldThrowNotFound() {

        when(tournamentFAQRepo.findById("FAQ1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.deleteFAQ("FAQ1"));
    }

    @Test
    void getTournamentFAQs_ShouldThrowNotFound() {

        when(tournamentRepo.existsById("T1"))
                .thenReturn(false);

        assertThrows(
                NotFoundException.class,
                () -> service.getTournamentFAQs("T1", null));
    }
}