package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentRulesRequestDTO;
import com.esports.project.DTO.TournamentRulesResponseDTO;
import com.esports.project.DTO.TournamentRulesUpdateDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.entity.TournamentRules;
import com.esports.project.enums.RulesCategory;
import com.esports.project.exception.IllegalArgumentException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentRulesMapper;
import com.esports.project.repository.TournamentRepo;
import com.esports.project.repository.TournamentRulesRepo;

@ExtendWith(MockitoExtension.class)
class TournamentRulesServiceTest {

    @Mock
    private TournamentRulesRepo tournamentRulesRepo;

    @Mock
    private TournamentRepo tournamentRepo;

    @Mock
    private TournamentRulesMapper tournamentRulesMapper;

    @InjectMocks
    private TournamentRulesService service;

    private Tournament tournament;
    private TournamentRules rule;
    private TournamentRulesRequestDTO requestDTO;
    private TournamentRulesResponseDTO responseDTO;

    @BeforeEach
    void setUp() {

        tournament = new Tournament();
        tournament.setId("T1");

        rule = new TournamentRules();
        rule.setId("R1");
        rule.setCategory(RulesCategory.DISCIPLINARY_RULE);
        rule.setRuleText("No cheating allowed");
        rule.setTournament(tournament);

        requestDTO = new TournamentRulesRequestDTO();
        requestDTO.setTournamentId("T1");

        responseDTO = new TournamentRulesResponseDTO();
    }

    @Test
    void createRule_ShouldCreateSuccessfully() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentRulesMapper.toEntity(requestDTO))
                .thenReturn(rule);

        when(tournamentRulesRepo.save(any(TournamentRules.class)))
                .thenReturn(rule);

        when(tournamentRulesMapper.toResponseDTO(rule))
                .thenReturn(responseDTO);

        TournamentRulesResponseDTO result =
                service.createRule(requestDTO);

        assertNotNull(result);

        verify(tournamentRulesRepo)
                .save(any(TournamentRules.class));
    }

    @Test
    void createRule_ShouldThrowNotFound_WhenTournamentMissing() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.createRule(requestDTO));
    }

    @Test
    void createRule_ShouldThrowValidationError_WhenCategoryMissing() {

        rule.setCategory(null);

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentRulesMapper.toEntity(requestDTO))
                .thenReturn(rule);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.createRule(requestDTO));
    }

    @Test
    void createRule_ShouldThrowValidationError_WhenRuleTextMissing() {

        rule.setRuleText("");

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentRulesMapper.toEntity(requestDTO))
                .thenReturn(rule);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.createRule(requestDTO));
    }

    @Test
    void getRuleById_ShouldReturnRule() {

        when(tournamentRulesRepo.findById("R1"))
                .thenReturn(Optional.of(rule));

        when(tournamentRulesMapper.toResponseDTO(rule))
                .thenReturn(responseDTO);

        TournamentRulesResponseDTO result =
                service.getRuleById("R1");

        assertNotNull(result);
    }

    @Test
    void getRuleById_ShouldThrowNotFound() {

        when(tournamentRulesRepo.findById("R1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getRuleById("R1"));
    }

    @Test
    void updateRule_ShouldUpdateSuccessfully() {

        TournamentRulesUpdateDTO updateDTO =
                new TournamentRulesUpdateDTO();

        when(tournamentRulesRepo.findById("R1"))
                .thenReturn(Optional.of(rule));

        doNothing().when(tournamentRulesMapper)
                .updateRuleFromDTO(updateDTO, rule);

        when(tournamentRulesRepo.save(any(TournamentRules.class)))
                .thenReturn(rule);

        when(tournamentRulesMapper.toResponseDTO(rule))
                .thenReturn(responseDTO);

        TournamentRulesResponseDTO result =
                service.updateRule("R1", updateDTO);

        assertNotNull(result);

        verify(tournamentRulesMapper)
                .updateRuleFromDTO(updateDTO, rule);

        verify(tournamentRulesRepo)
                .save(rule);
    }

    @Test
    void updateRule_ShouldThrowNotFound() {

        TournamentRulesUpdateDTO updateDTO =
                new TournamentRulesUpdateDTO();

        when(tournamentRulesRepo.findById("R1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.updateRule("R1", updateDTO));
    }

    @Test
    void deleteRule_ShouldDeleteSuccessfully() {

        when(tournamentRulesRepo.findById("R1"))
                .thenReturn(Optional.of(rule));

        ResponseDTO response =
                service.deleteRule("R1");

        assertNotNull(response);

        verify(tournamentRulesRepo)
                .delete(rule);
    }

    @Test
    void deleteRule_ShouldThrowNotFound() {

        when(tournamentRulesRepo.findById("R1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.deleteRule("R1"));
    }

    @Test
    void getTournamentRules_ShouldThrowNotFound() {

        when(tournamentRepo.existsById("T1"))
                .thenReturn(false);

        assertThrows(
                NotFoundException.class,
                () -> service.getTournamentRules("T1", null));
    }
}