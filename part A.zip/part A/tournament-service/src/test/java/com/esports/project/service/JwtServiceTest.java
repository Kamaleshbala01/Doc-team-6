package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

class JwtServiceTest {

    private JwtService jwtService;

    /*
     * Base64 encoded secret key
     * Must be at least 256 bits for HS256
     */
    private static final String TEST_SECRET =
            "VGhpc0lzQVNlY3JldEtleUZvclRlc3RpbmdQdXJwb3Nlc09ubHkxMjM0NTY=";

    @BeforeEach
    void setUp() {
        jwtService = new JwtService();

        ReflectionTestUtils.setField(
                jwtService,
                "secretKey",
                TEST_SECRET
        );
    }

    @Test
    void shouldGenerateToken() {

        String token = jwtService.generateToken("kamalesh");

        assertNotNull(token);
        assertFalse(token.isEmpty());
    }

    @Test
    void shouldValidateGeneratedToken() {

        String token = jwtService.generateToken("kamalesh");

        boolean valid = jwtService.validateToken(token);

        assertTrue(valid);
    }

    @Test
    void shouldExtractSubject() {

        String token = jwtService.generateToken("kamalesh");

        String subject =
                jwtService.extractAllClaims(token).getSubject();

        assertEquals("kamalesh", subject);
    }

    @Test
    void shouldContainTokenTypeClaim() {

        String token = jwtService.generateToken("kamalesh");

        String tokenType =
                jwtService.extractAllClaims(token)
                          .get("token_type", String.class);

        assertEquals("SERVICE", tokenType);
    }

    @Test
    void shouldContainExpirationDate() {

        String token = jwtService.generateToken("kamalesh");

        assertNotNull(
                jwtService.extractAllClaims(token)
                          .getExpiration()
        );
    }

    @Test
    void shouldThrowExceptionForInvalidToken() {

        assertThrows(
                Exception.class,
                () -> jwtService.validateToken("invalid-token")
        );
    }
}
