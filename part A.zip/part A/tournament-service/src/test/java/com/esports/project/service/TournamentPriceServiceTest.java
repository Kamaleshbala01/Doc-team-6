package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentPriceRequestDTO;
import com.esports.project.DTO.TournamentPriceResponseDTO;
import com.esports.project.DTO.TournamentPriceUpdateDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.entity.TournamentPrice;
import com.esports.project.enums.PriceCategory;
import com.esports.project.exception.IllegalArgumentException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentPriceMapper;
import com.esports.project.repository.TournamentPriceRepo;
import com.esports.project.repository.TournamentRepo;

@ExtendWith(MockitoExtension.class)
class TournamentPriceServiceTest {

    @Mock
    private TournamentPriceRepo tournamentPriceRepo;

    @Mock
    private TournamentRepo tournamentRepo;

    @Mock
    private TournamentPriceMapper tournamentPriceMapper;

    @InjectMocks
    private TournamentPriceService service;

    private Tournament tournament;
    private TournamentPrice price;
    private TournamentPriceRequestDTO requestDTO;
    private TournamentPriceResponseDTO responseDTO;

    @BeforeEach
    void setUp() {

        tournament = new Tournament();
        tournament.setId("T1");

        price = new TournamentPrice();
        price.setId("P1");
        price.setTournament(tournament);
        price.setRankOrder(1);
        price.setPrizeAmount(new BigDecimal("1000"));
        price.setPrizeCategory(PriceCategory.FIRST_PRICE);

        requestDTO = new TournamentPriceRequestDTO();
        requestDTO.setTournamentId("T1");

        responseDTO = new TournamentPriceResponseDTO();
    }

    @Test
    void createPrice_ShouldCreateSuccessfully() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentPriceMapper.toEntity(requestDTO))
                .thenReturn(price);

        when(tournamentPriceRepo.save(any(TournamentPrice.class)))
                .thenReturn(price);

        when(tournamentPriceMapper.toResponseDTO(price))
                .thenReturn(responseDTO);

        TournamentPriceResponseDTO result =
                service.createPrice(requestDTO);

        assertNotNull(result);

        verify(tournamentPriceRepo)
                .save(any(TournamentPrice.class));
    }

    @Test
    void createPrice_ShouldThrowNotFound_WhenTournamentMissing() {

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.createPrice(requestDTO));
    }

    @Test
    void createPrice_ShouldThrowValidationError_WhenCategoryMissing() {

        price.setPrizeCategory(null);

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentPriceMapper.toEntity(requestDTO))
                .thenReturn(price);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.createPrice(requestDTO));
    }

    @Test
    void createPrice_ShouldThrowValidationError_WhenRankInvalid() {

        price.setRankOrder(0);

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentPriceMapper.toEntity(requestDTO))
                .thenReturn(price);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.createPrice(requestDTO));
    }

    @Test
    void createPrice_ShouldThrowValidationError_WhenAmountNegative() {

        price.setPrizeAmount(
                new BigDecimal("-50"));

        when(tournamentRepo.findById("T1"))
                .thenReturn(Optional.of(tournament));

        when(tournamentPriceMapper.toEntity(requestDTO))
                .thenReturn(price);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.createPrice(requestDTO));
    }

    @Test
    void getPriceById_ShouldReturnPrice() {

        when(tournamentPriceRepo.findById("P1"))
                .thenReturn(Optional.of(price));

        when(tournamentPriceMapper.toResponseDTO(price))
                .thenReturn(responseDTO);

        TournamentPriceResponseDTO result =
                service.getPriceById("P1");

        assertNotNull(result);
    }

    @Test
    void getPriceById_ShouldThrowNotFound() {

        when(tournamentPriceRepo.findById("P1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getPriceById("P1"));
    }

    @Test
    void updatePrice_ShouldUpdateSuccessfully() {

        TournamentPriceUpdateDTO updateDTO =
                new TournamentPriceUpdateDTO();

        when(tournamentPriceRepo.findById("P1"))
                .thenReturn(Optional.of(price));

        doNothing().when(tournamentPriceMapper)
                .updatePriceFromDTO(updateDTO, price);

        when(tournamentPriceRepo.save(any(TournamentPrice.class)))
                .thenReturn(price);

        when(tournamentPriceMapper.toResponseDTO(price))
                .thenReturn(responseDTO);

        TournamentPriceResponseDTO result =
                service.updatePrice("P1", updateDTO);

        assertNotNull(result);

        verify(tournamentPriceMapper)
                .updatePriceFromDTO(updateDTO, price);

        verify(tournamentPriceRepo)
                .save(price);
    }

    @Test
    void updatePrice_ShouldThrowNotFound() {

        TournamentPriceUpdateDTO updateDTO =
                new TournamentPriceUpdateDTO();

        when(tournamentPriceRepo.findById("P1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.updatePrice("P1", updateDTO));
    }

    @Test
    void deletePrice_ShouldDeleteSuccessfully() {

        when(tournamentPriceRepo.findById("P1"))
                .thenReturn(Optional.of(price));

        ResponseDTO response =
                service.deletePrice("P1");

        assertNotNull(response);

        verify(tournamentPriceRepo)
                .delete(price);
    }

    @Test
    void deletePrice_ShouldThrowNotFound() {

        when(tournamentPriceRepo.findById("P1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.deletePrice("P1"));
    }

    @Test
    void getTournamentPrices_ShouldThrowNotFound() {

        when(tournamentRepo.existsById("T1"))
                .thenReturn(false);

        assertThrows(
                NotFoundException.class,
                () -> service.getTournamentPrices("T1", null));
    }
}