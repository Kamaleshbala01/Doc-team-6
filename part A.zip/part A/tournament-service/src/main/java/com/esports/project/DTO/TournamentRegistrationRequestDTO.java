package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentRegistrationRequestDTO {

    private String tournamentId;
    private String teamId;
}
