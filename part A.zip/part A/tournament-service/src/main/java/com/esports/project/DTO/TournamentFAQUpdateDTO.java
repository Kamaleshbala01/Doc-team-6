package com.esports.project.DTO;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentFAQUpdateDTO {
    private String answer;
}