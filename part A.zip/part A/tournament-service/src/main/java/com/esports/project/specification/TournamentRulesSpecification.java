package com.esports.project.specification;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.esports.project.entity.TournamentRules;
import com.esports.project.enums.RulesCategory;

import jakarta.persistence.criteria.Predicate;

public class TournamentRulesSpecification {

    public static Specification<TournamentRules> filter(
            String tournamentId,
            String category) {

        return (root, query, cb) -> {

            List<Predicate> predicates =
                    new ArrayList<>();

            if (tournamentId != null
                    && !tournamentId.isBlank()) {

                predicates.add(
                        cb.equal(
                                root.get("tournament")
                                        .get("id"),
                                tournamentId));
            }

            if (category != null
                    && !category.isBlank()) {

                predicates.add(
                        cb.equal(
                                root.get("category"),
                                RulesCategory.valueOf(
                                        category.toUpperCase())));
            }

            return cb.and(
                    predicates.toArray(
                            new Predicate[0]));
        };
    }
}