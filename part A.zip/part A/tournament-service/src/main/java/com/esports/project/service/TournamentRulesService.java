package com.esports.project.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentRulesRequestDTO;
import com.esports.project.DTO.TournamentRulesResponseDTO;
import com.esports.project.DTO.TournamentRulesUpdateDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.entity.TournamentRules;
import com.esports.project.exception.IllegalArgumentException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentRulesMapper;
import com.esports.project.repository.TournamentRepo;
import com.esports.project.repository.TournamentRulesRepo;
import com.esports.project.specification.TournamentRulesSpecification;

@Service
public class TournamentRulesService {

    private final TournamentRulesRepo tournamentRulesRepo;
    private final TournamentRepo tournamentRepo;
    private final TournamentRulesMapper tournamentRulesMapper;

    @Autowired
    public TournamentRulesService(
            TournamentRulesRepo tournamentRulesRepo,
            TournamentRepo tournamentRepo,
            TournamentRulesMapper tournamentRulesMapper) {

        this.tournamentRulesRepo = tournamentRulesRepo;
        this.tournamentRepo = tournamentRepo;
        this.tournamentRulesMapper = tournamentRulesMapper;
    }

    /*
     * Create Rule
     */
    public TournamentRulesResponseDTO createRule(
            TournamentRulesRequestDTO requestDTO) {

        Tournament tournament = tournamentRepo
                .findById(requestDTO.getTournamentId())
                .orElseThrow(() -> new NotFoundException(
                        "Tournament not found with id : "
                                + requestDTO.getTournamentId()));

        TournamentRules rule =
                tournamentRulesMapper.toEntity(requestDTO);

        rule.setTournament(tournament);
        rule.setCreatedAt(LocalDateTime.now());

        validateRule(rule);

        return tournamentRulesMapper.toResponseDTO(
                tournamentRulesRepo.save(rule));
    }

    /*
     * Get Rule By Id
     */
    public TournamentRulesResponseDTO getRuleById(
            String id) {

        TournamentRules rule =
                tournamentRulesRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Rule not found with id : "
                                                + id));

        return tournamentRulesMapper.toResponseDTO(rule);
    }

    /*
     * Get Rules For Tournament
     */
    public Page<TournamentRulesResponseDTO>
    getTournamentRules(
            String tournamentId,
            Pageable pageable) {

        if (!tournamentRepo.existsById(tournamentId)) {
            throw new NotFoundException(
                    "Tournament not found with id : "
                            + tournamentId);
        }

        return tournamentRulesRepo
                .findByTournament_Id(
                        tournamentId,
                        pageable)
                .map(tournamentRulesMapper::toResponseDTO);
    }

    /*
     * Update Rule
     */
    public TournamentRulesResponseDTO updateRule(
            String id,
            TournamentRulesUpdateDTO updateDTO) {

        TournamentRules rule =
                tournamentRulesRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Rule not found with id : "
                                                + id));

        tournamentRulesMapper.updateRuleFromDTO(
                updateDTO,
                rule);

        rule.setUpdatedAt(LocalDateTime.now());

        validateRule(rule);

        return tournamentRulesMapper.toResponseDTO(
                tournamentRulesRepo.save(rule));
    }

    /*
     * Delete Rule
     */
    public ResponseDTO deleteRule(String id) {

        TournamentRules rule =
                tournamentRulesRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Rule not found with id : "
                                                + id));

        tournamentRulesRepo.delete(rule);

        return new ResponseDTO(
                HttpStatus.OK.value(),
                "Tournament rule deleted successfully");
    }

    /*
     * Filter Rules
     */
    public Page<TournamentRulesResponseDTO> filterRules(
            String tournamentId,
            String category,
            String ruleText,
            Pageable pageable) {

        Specification<TournamentRules> specification =
                TournamentRulesSpecification.filter(
                        tournamentId,
                        category);

        return tournamentRulesRepo
                .findAll(specification, pageable)
                .map(tournamentRulesMapper::toResponseDTO);
    }

    /*
     * Validation
     */
    private void validateRule(
            TournamentRules rule) {

        if (rule.getCategory() == null) {
            throw new IllegalArgumentException(
                    "Rule category is required");
        }

        if (rule.getRuleText() == null
                || rule.getRuleText().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Rule text is required");
        }

        if (rule.getTournament() == null) {

            throw new IllegalArgumentException(
                    "Tournament is required");
        }
    }
}