package com.esports.project.DTO;

import java.time.LocalDateTime;

import com.esports.project.enums.StatusMaster;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentRegistrationResponseDTO {

    private String id;

    private StatusMaster registrationStatus;

    private LocalDateTime registrationDate;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private String teamId;

    private String tournamentId;

    private String tournamentName;
}