package com.esports.project.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentRulesRequestDTO;
import com.esports.project.DTO.TournamentRulesResponseDTO;
import com.esports.project.DTO.TournamentRulesUpdateDTO;
import com.esports.project.service.TournamentRulesService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/tournament/rules")
public class TournamentRulesController {

    private final TournamentRulesService tournamentRulesService;

    public TournamentRulesController(
            TournamentRulesService tournamentRulesService) {
        this.tournamentRulesService = tournamentRulesService;
    }

    /*
     * Create Tournament Rule
     */
    @PostMapping
//     @PreAuthorize("hasAuthority('TOURNAMENT_RULE_CREATE')")
    public ResponseEntity<TournamentRulesResponseDTO> createRule(
            @Valid @RequestBody TournamentRulesRequestDTO requestDTO) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(tournamentRulesService.createRule(requestDTO));
    }

    /*
     * Get Rule By Id
     */
    @GetMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_RULE_VIEW')")
    public ResponseEntity<TournamentRulesResponseDTO> getRuleById(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentRulesService.getRuleById(id));
    }

    /*
     * Get All Rules Of Tournament
     */
    @GetMapping("/tournament/{tournamentId}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_RULE_VIEW')")
    public ResponseEntity<Page<TournamentRulesResponseDTO>>
            getTournamentRules(
                    @PathVariable String tournamentId,
                    @RequestParam(defaultValue = "0") int page,
                    @RequestParam(defaultValue = "10") int size) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentRulesService.getTournamentRules(
                        tournamentId,
                        PageRequest.of(page, size)));
    }

    /*
     * Update Rule
     */
    @PatchMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_RULE_UPDATE')")
    public ResponseEntity<TournamentRulesResponseDTO> updateRule(
            @PathVariable String id,
            @RequestBody TournamentRulesUpdateDTO updateDTO) {

        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(tournamentRulesService.updateRule(
                        id,
                        updateDTO));
    }

    /*
     * Delete Rule
     */
    @DeleteMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_RULE_DELETE')")
    public ResponseEntity<ResponseDTO> deleteRule(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentRulesService.deleteRule(id));
    }

    /*
     * Filter Rules
     */
    @GetMapping("/filter")
//     @PreAuthorize("hasAuthority('TOURNAMENT_RULE_VIEW')")
    public Page<TournamentRulesResponseDTO> filterRules(

            @RequestParam(required = false)
            String tournamentId,

            @RequestParam(required = false)
            String category,

            @RequestParam(required = false)
            String ruleText,

            @RequestParam(defaultValue = "0")
            int page,

            @RequestParam(defaultValue = "10")
            int size) {

        return tournamentRulesService.filterRules(
                tournamentId,
                category,
                ruleText,
                PageRequest.of(page, size));
    }
}