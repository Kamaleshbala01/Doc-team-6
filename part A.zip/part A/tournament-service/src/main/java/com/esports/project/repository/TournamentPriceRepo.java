package com.esports.project.repository;


import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.TournamentPrice;

@Repository
public interface TournamentPriceRepo extends
        JpaRepository<TournamentPrice, String>,
        JpaSpecificationExecutor<TournamentPrice> {

    List<TournamentPrice> findByTournament_Id(
            String tournamentId);

    Page<TournamentPrice> findByTournament_Id(
            String tournamentId,
            Pageable pageable);
}