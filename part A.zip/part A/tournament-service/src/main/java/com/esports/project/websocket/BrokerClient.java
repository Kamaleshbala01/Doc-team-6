package com.esports.project.websocket;

import java.net.URI;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.service.JwtService;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class BrokerClient {

        private final BrokerClientHandler handler;
        private final JwtService jwtService;

        private WebSocketSession session;

        private final ObjectMapper objectMapper = new ObjectMapper();

        @PostConstruct
        public void connect() {
                tryConnect();
        }

        @Scheduled(fixedDelay = 1000 * 60)
        public void reconnect() {
                if(session == null || !session.isOpen())
                tryConnect();
        }

        private synchronized void tryConnect() {

                if (session != null &&
                                session.isOpen()) {
                        return;
                }

                try {

                        String token = jwtService.generateToken(
                                        "tournament-service");

                        session = new StandardWebSocketClient()
                                        .execute(
                                                        handler,
                                                        null,
                                                        URI.create(
                                                                        "ws://localhost:8085/broker?token="
                                                                                        + token))
                                        .get();

                        System.out.println(
                                        "Connected To Broker");

                } catch (Exception ex) {

                        System.out.println(
                                        "Broker unavailable");
                }
        }

        public void publish(
                        BrokerMessage message)
                        throws Exception {

                if (session == null ||
                                !session.isOpen()) {

                        throw new RuntimeException(
                                        "Broker connection is closed");
                }

                session.sendMessage(
                                new TextMessage(
                                                objectMapper.writeValueAsString(
                                                                message)));
        }
}