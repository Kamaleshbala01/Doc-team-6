package com.esports.project.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.esports.project.DTO.BrokerMessage;
import com.esports.project.DTO.TournamentGenerationEvent;
import com.esports.project.websocket.BrokerClient;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TournamentEventPublisher {

    private final BrokerClient brokerClient;

    public void publishTournamentCreated(
            TournamentGenerationEvent tournament)
            throws Exception {

        if(tournament.getParticipants() == null) tournament.setParticipants(List.of());

        BrokerMessage message =
                new BrokerMessage();

        message.setType(
                "PUBLISH");

        message.setTopic(
                "tournament.created");

        message.setPayload(tournament);

        System.out.println("Tournament Event : " + message.toString());

        brokerClient.publish(
                message);
    }
}
