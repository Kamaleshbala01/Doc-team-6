package com.esports.project.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

import com.esports.project.DTO.TournamentRegistrationRequestDTO;
import com.esports.project.DTO.TournamentRegistrationResponseDTO;
import com.esports.project.DTO.TournamentRegistrationUpdateDTO;
import com.esports.project.entity.TournamentRegistration;

@Mapper(
    componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface TournamentRegistrationMapper {

    TournamentRegistration toEntity(
            TournamentRegistrationRequestDTO dto);

    @Mapping(target = "tournamentId",
            source = "tournament.id")
    @Mapping(target = "tournamentName",
            source = "tournament.name")
    TournamentRegistrationResponseDTO toResponseDTO(
            TournamentRegistration registration);

    void updateRegistrationFromDTO(
            TournamentRegistrationUpdateDTO dto,
            @MappingTarget
            TournamentRegistration registration);
}
