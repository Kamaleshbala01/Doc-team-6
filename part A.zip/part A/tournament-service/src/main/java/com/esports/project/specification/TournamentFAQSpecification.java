package com.esports.project.specification;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.esports.project.entity.TournamentFAQ;
import com.esports.project.enums.StatusMaster;

import jakarta.persistence.criteria.Predicate;

public class TournamentFAQSpecification {

    public static Specification<TournamentFAQ> filter(
            String tournamentId,
            String question,
            String status) {

        return (root, query, cb) -> {

            List<Predicate> predicates = new ArrayList<>();

            if (tournamentId != null && !tournamentId.isBlank()) {
                predicates.add(
                        cb.equal(
                                root.get("tournament").get("id"),
                                tournamentId));
            }

            if (question != null && !question.isBlank()) {
                predicates.add(
                        cb.like(
                                cb.lower(root.get("question")),
                                "%" + question.toLowerCase() + "%"));
            }

            if (status != null && !status.isBlank()) {
                predicates.add(
                        cb.equal(
                                root.get("status"),
                                StatusMaster.valueOf(status.toUpperCase())));
            }

            return cb.and(
                    predicates.toArray(new Predicate[0]));
        };
    }
}
