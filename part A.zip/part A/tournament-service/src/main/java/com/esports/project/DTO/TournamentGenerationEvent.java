package com.esports.project.DTO;


import java.util.List;

import com.esports.project.enums.SeedType;
import com.esports.project.enums.TournamentType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TournamentGenerationEvent {

    private String tournamentId;

    private SeedType seedType;

    private TournamentType tournamentType;
    private List<String> participants;
}
