package com.esports.project.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentPriceRequestDTO;
import com.esports.project.DTO.TournamentPriceResponseDTO;
import com.esports.project.DTO.TournamentPriceUpdateDTO;
import com.esports.project.service.TournamentPriceService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/tournament/price")
public class TournamentPriceController {

    private final TournamentPriceService tournamentPriceService;

    public TournamentPriceController(
            TournamentPriceService tournamentPriceService) {
        this.tournamentPriceService = tournamentPriceService;
    }

    /*
     * Create Tournament Prize
     */
    @PostMapping
//     @PreAuthorize("hasAuthority('TOURNAMENT_PRIZE_CREATE')")
    public ResponseEntity<TournamentPriceResponseDTO> createPrice(
            @Valid @RequestBody TournamentPriceRequestDTO requestDTO) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(tournamentPriceService.createPrice(requestDTO));
    }

    /*
     * Get Prize By Id
     */
    @GetMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_PRIZE_VIEW')")
    public ResponseEntity<TournamentPriceResponseDTO> getPriceById(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentPriceService.getPriceById(id));
    }

    /*
     * Get All Prizes For Tournament
     */
    @GetMapping("/tournament/{tournamentId}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_PRIZE_VIEW')")
    public ResponseEntity<Page<TournamentPriceResponseDTO>>
            getTournamentPrices(
                    @PathVariable String tournamentId,
                    @RequestParam(defaultValue = "0") int page,
                    @RequestParam(defaultValue = "10") int size) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentPriceService.getTournamentPrices(
                        tournamentId,
                        PageRequest.of(page, size)));
    }

    /*
     * Update Prize
     */
    @PatchMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_PRIZE_UPDATE')")
    public ResponseEntity<TournamentPriceResponseDTO> updatePrice(
            @PathVariable String id,
            @RequestBody TournamentPriceUpdateDTO updateDTO) {

        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(tournamentPriceService.updatePrice(
                        id,
                        updateDTO));
    }

    /*
     * Delete Prize
     */
    @DeleteMapping("/{id}")
//     @PreAuthorize("hasAuthority('TOURNAMENT_PRIZE_DELETE')")
    public ResponseEntity<ResponseDTO> deletePrice(
            @PathVariable String id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(tournamentPriceService.deletePrice(id));
    }

    /*
     * Filter Prizes
     */
    @GetMapping("/filter")
//     @PreAuthorize("hasAuthority('TOURNAMENT_PRIZE_VIEW')")
    public Page<TournamentPriceResponseDTO> filterPrices(
            @RequestParam(required = false) String tournamentId,
            @RequestParam(required = false) String prizeCategory,
            @RequestParam(required = false) Integer rankOrder,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        return tournamentPriceService.filterPrices(
                tournamentId,
                prizeCategory,
                rankOrder,
                PageRequest.of(page, size));
    }
}
