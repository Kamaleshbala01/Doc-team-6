package com.esports.project.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentGenerationEvent;
import com.esports.project.DTO.TournamentRequestDTO;
import com.esports.project.DTO.TournamentResponseDTO;
import com.esports.project.DTO.TournamentUpdateDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.enums.SeedType;
import com.esports.project.enums.StatusMaster;
import com.esports.project.enums.TournamentType;
import com.esports.project.exception.IllegalArgumentException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentMapper;
import com.esports.project.repository.TournamentRepo;
import com.esports.project.specification.TournamentSpecification;

import jakarta.transaction.Transactional;

@Service
public class TournamentService {
    private final TournamentRepo tournamentRepo;
    private final TournamentMapper tournamentMapper;
    private final TournamentEventPublisher tournamentEventPublisher;

    @Autowired
    public TournamentService(TournamentRepo tournamentRepo, TournamentMapper tournamentMapper,
            TournamentEventPublisher tournamentEventPublisher) {
        this.tournamentRepo = tournamentRepo;
        this.tournamentMapper = tournamentMapper;
        this.tournamentEventPublisher = tournamentEventPublisher;
    }

    public TournamentResponseDTO createTournament(TournamentRequestDTO tournamentRequestDTO) {
        UserDetailsDTO userDetailsDTO = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication()
                .getPrincipal();
        validateTournamentDates(tournamentRequestDTO.getRegistrationStartDate(),
                tournamentRequestDTO.getRegistrationEndDate(),
                tournamentRequestDTO.getTournamentStartDate(),
                tournamentRequestDTO.getTournamentEndDate());

        validateTournamentDetails(tournamentRequestDTO);

        Tournament tournament = tournamentMapper.toEntity(tournamentRequestDTO);

        tournament.setCreatedAt(LocalDateTime.now());
        tournament.setStatus(StatusMaster.UPCOMMING);
        tournament.setUserId(userDetailsDTO.getUserId());

        return tournamentMapper.toResponseDTO(tournamentRepo.save(tournament));
    }

    public TournamentResponseDTO patchUpdateTournament(String id, TournamentUpdateDTO tournamentUpdateDTO) {
        UserDetailsDTO userDetailsDTO = (UserDetailsDTO) SecurityContextHolder
                                                                    .getContext()
                                                                    .getAuthentication()
                                                                    .getPrincipal();
        Optional<Tournament> tournament = tournamentRepo.findById(id);
        if (!tournament.isPresent())
            throw new NotFoundException("Tournament not found with id : " + id);
        if (!tournament.get().getUserId().equals(userDetailsDTO.getUserId()))
            throw new IllegalArgumentException("You are not allowed to update the tournaemnt that not belongs to you");
        validateTournamentDates(
                tournament.get().getRegistrationStartDate(),
                tournamentUpdateDTO.getRegistrationEndDate(),
                tournamentUpdateDTO.getTournamentStartDate(),
                tournamentUpdateDTO.getTournamentEndDate());

        tournamentMapper.updateTournamentFromDto(tournamentUpdateDTO, tournament.get());
        validateTournament(tournament.get());
        tournament.get().setUpdatedAt(LocalDateTime.now());
        return tournamentMapper.toResponseDTO(tournamentRepo.save(tournament.get()));
    }

    public List<TournamentResponseDTO> getMyTournaments() {
        UserDetailsDTO user = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (user == null)
            throw new NotFoundException("User Id is missing on tournament");

        List<Tournament> tournaments = tournamentRepo.findByUserId(user.getUserId());
        List<TournamentResponseDTO> tournamentResponseDTOs = tournaments.stream()
                .filter(tournament -> (tournament.getIsDeleted() == null || tournament.getIsDeleted() == false))
                .map(tournament -> tournamentMapper.toResponseDTO(tournament))
                .toList();
        return tournamentResponseDTOs;
    }

    public TournamentResponseDTO getMyTournamentById(String id) {
        UserDetailsDTO user = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (user == null)
            throw new NotFoundException("User Id not present in jwt");

        Optional<Tournament> tournament = tournamentRepo.findById(id);
        if (!tournament.isPresent())
            throw new NotFoundException("Tourament not find with id : " + id);
        if (!user.getUserId().equals(tournament.get().getUserId()))
            throw new IllegalArgumentException("Tournament is not belongs to you");

        return tournamentMapper.toResponseDTO(tournament.get());
    }

    public ResponseDTO softDeleteTournament(String id) {
        UserDetailsDTO user = (UserDetailsDTO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (user == null)
            throw new NotFoundException("User Id not present in jwt");

        Optional<Tournament> tournament = tournamentRepo.findById(id);
        if (!tournament.isPresent())
            throw new NotFoundException("Tourament not find with id : " + id);

        tournament.get().setIsDeleted(true);
        tournamentRepo.save(tournament.get());
        return new ResponseDTO(HttpStatus.OK.value(), "Tournament deleted id : " + id);
    }

    // filter

    public Page<TournamentResponseDTO> getTournaments(
            String name,
            String tournamentType,
            String category,
            String seedType,
            String status,
            Pageable pageable) {

        Specification<Tournament> specification = TournamentSpecification.filter(
                name,
                tournamentType,
                category,
                seedType,
                status);

        return tournamentRepo
                .findAll(specification, pageable)
                .map(tournamentMapper::toResponseDTO);
    }

        @Transactional
    public ResponseDTO lockMyTournament(String id) {

        Tournament tournament =
                tournamentRepo
                        .findByIdWithRegistrations(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Tournament not found with id : " + id));

        try {

            if (Boolean.TRUE.equals(tournament.getIsLocked())) {

                throw new IllegalArgumentException(
                        "Tournament already locked");
            }

            tournament.setIsLocked(true);

            tournamentRepo.save(tournament);

        //     TournamentGenerationEvent event =
        // new TournamentGenerationEvent(
        //         "TOURNAMENT_001",
        //         SeedType.RANDOM,
        //         TournamentType.SINGLE_ELIMINATION,
        //         List.of(
        //                 "TEAM_001",
        //                 "TEAM_002",
        //                 "TEAM_003",
        //                 "TEAM_004",
        //                 "TEAM_005",
        //                 "TEAM_006",
        //                 "TEAM_007",
        //                 "TEAM_008"
        //         )
        // );

            List<String> participants = tournament.getTournamentRegistrations()
                                                        .stream()
                                                        .map(reg -> reg.getTeamId())
                                                        .toList();

             TournamentGenerationEvent event =
                                    new TournamentGenerationEvent(
                                            tournament.getId(),
                                            tournament.getSeedingTypeId(),
                                            tournament.getTournamentType(),
                                            participants);
            tournamentEventPublisher
                    .publishTournamentCreated(event);
            // tournamentEventPublisher.publishTournamentCreated(event);
            return new ResponseDTO(
                    HttpStatus.OK.value(),
                    "Tournament is locked and brackets will be generated shortly");

        } catch (Exception e) {

            tournament.setIsLocked(false);

            return new ResponseDTO(
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    e.getMessage());
        }
    }

    /*
     * Helper functions
     */
    private void validateTournamentDates(LocalDateTime registrationStartDate,
            LocalDateTime registrationEndDate,
            LocalDateTime tournamentStartDate,
            LocalDateTime tournamentEndDate) {

        if (registrationStartDate != null &&
                registrationStartDate.isBefore(LocalDateTime.now())) {

            throw new IllegalArgumentException(
                    "Tournament registration start date cannot be in the past");
        }

        if (registrationStartDate != null &&
                registrationEndDate != null &&
                !registrationEndDate.isAfter(registrationStartDate)) {

            throw new IllegalArgumentException(
                    "Tournament registration end date must be before registration start date");
        }

        if (registrationEndDate != null &&
                tournamentStartDate != null &&
                !tournamentStartDate.isAfter(registrationEndDate)) {

            throw new IllegalArgumentException(
                    "Tournament match start date must be after registration end date");
        }

        if (tournamentStartDate != null &&
                tournamentEndDate != null &&
                !tournamentEndDate.isAfter(tournamentStartDate)) {

            throw new IllegalArgumentException(
                    "Tournament match end date must be after match start date");
        }
    }

    private void validateTournamentDetails(TournamentRequestDTO tournamentRequestDTO) {
        if (!tournamentRequestDTO.getTournamentType()
                .getCategory()
                .equals(tournamentRequestDTO.getTournamentCategory().toString()))
            throw new IllegalArgumentException("Tournametn type and category are not matches");
    }

    private void validateTournament(Tournament tournament) {
        // Name
        if (tournament.getName() == null || tournament.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Tournament name is required");
        }

        // Description
        if (tournament.getDescription() == null || tournament.getDescription().trim().isEmpty()) {
            throw new IllegalArgumentException("Tournament description is required");
        }

        // Dates
        if (tournament.getRegistrationStartDate() == null) {
            throw new IllegalArgumentException("Registration start date is required");
        }

        if (tournament.getRegistrationEndDate() == null) {
            throw new IllegalArgumentException("Registration end date is required");
        }

        if (tournament.getTournamentStartDate() == null) {
            throw new IllegalArgumentException("Tournament start date is required");
        }

        if (tournament.getTournamentEndDate() == null) {
            throw new IllegalArgumentException("Tournament end date is required");
        }

        if (tournament.getRegistrationStartDate()
                .isAfter(tournament.getRegistrationEndDate())) {
            throw new IllegalArgumentException(
                    "Registration start date must be before registration end date");
        }

        if (tournament.getRegistrationEndDate()
                .isAfter(tournament.getTournamentStartDate())) {
            throw new IllegalArgumentException(
                    "Registration must end before tournament starts");
        }

        if (tournament.getTournamentStartDate()
                .isAfter(tournament.getTournamentEndDate())) {
            throw new IllegalArgumentException(
                    "Tournament start date must be before tournament end date");
        }

        // Enums
        if (tournament.getTournamentCategory() == null) {
            throw new IllegalArgumentException("Tournament category is required");
        }

        if (tournament.getTournamentType() == null) {
            throw new IllegalArgumentException("Tournament type is required");
        }

        if (tournament.getSeedingTypeId() == null) {
            throw new IllegalArgumentException("Seeding type is required");
        }

        if (tournament.getVerificationRequired() == null) {
            throw new IllegalArgumentException("Verification type is required");
        }

        // Numbers
        if (tournament.getMaximumTeams() == null
                || tournament.getMaximumTeams() <= 0) {
            throw new IllegalArgumentException(
                    "Maximum teams must be greater than 0");
        }

        if (tournament.getMaximumPlayersPerTeam() == null
                || tournament.getMaximumPlayersPerTeam() <= 0) {
            throw new IllegalArgumentException(
                    "Maximum players per team must be greater than 0");
        }

        if (tournament.getEntryFee() == null
                || tournament.getEntryFee().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException(
                    "Entry fee cannot be negative");
        }
        // Foreign Keys
        if (tournament.getUserId() == null
                || tournament.getUserId().trim().isEmpty()) {
            throw new IllegalArgumentException("User ID is required");
        }
    }
}
