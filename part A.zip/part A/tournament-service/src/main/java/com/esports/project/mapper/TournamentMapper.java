package com.esports.project.mapper;

import java.util.List;

import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

import com.esports.project.DTO.TournamentGenerationEvent;
import com.esports.project.DTO.TournamentRequestDTO;
import com.esports.project.DTO.TournamentResponseDTO;
import com.esports.project.DTO.TournamentUpdateDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.entity.TournamentRegistration;

@Mapper(componentModel = "spring",unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TournamentMapper {
     Tournament toEntity(TournamentRequestDTO dto);
     TournamentResponseDTO toResponseDTO(Tournament tournament);  
     
     @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
     void updateTournamentFromDto(TournamentUpdateDTO dto,@MappingTarget Tournament tournament);


    @Mapping(target = "tournamentId", source = "id")
    @Mapping(target = "seedType", source = "seedingTypeId")
    TournamentGenerationEvent toEvent(
            Tournament tournament);

    default List<String> map(
            List<TournamentRegistration> registrations) {

        return registrations.stream()
                .map(TournamentRegistration::getTeamId)
                .toList();
    }
}
