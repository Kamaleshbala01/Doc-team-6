package com.esports.project.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentPriceRequestDTO;
import com.esports.project.DTO.TournamentPriceResponseDTO;
import com.esports.project.DTO.TournamentPriceUpdateDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.entity.TournamentPrice;
import com.esports.project.exception.IllegalArgumentException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentPriceMapper;
import com.esports.project.repository.TournamentPriceRepo;
import com.esports.project.repository.TournamentRepo;
import com.esports.project.specification.TournamentPriceSpecification;

@Service
public class TournamentPriceService {

    private final TournamentPriceRepo tournamentPriceRepo;
    private final TournamentRepo tournamentRepo;
    private final TournamentPriceMapper tournamentPriceMapper;

    @Autowired
    public TournamentPriceService(
            TournamentPriceRepo tournamentPriceRepo,
            TournamentRepo tournamentRepo,
            TournamentPriceMapper tournamentPriceMapper) {

        this.tournamentPriceRepo = tournamentPriceRepo;
        this.tournamentRepo = tournamentRepo;
        this.tournamentPriceMapper = tournamentPriceMapper;
    }

    /*
     * Create Prize
     */
    public TournamentPriceResponseDTO createPrice(
            TournamentPriceRequestDTO requestDTO) {

        Tournament tournament = tournamentRepo
                .findById(requestDTO.getTournamentId())
                .orElseThrow(() -> new NotFoundException(
                        "Tournament not found with id : "
                                + requestDTO.getTournamentId()));

        TournamentPrice price =
                tournamentPriceMapper.toEntity(requestDTO);

        price.setTournament(tournament);
        price.setCreatedAt(LocalDateTime.now());

        validatePrice(price);

        return tournamentPriceMapper.toResponseDTO(
                tournamentPriceRepo.save(price));
    }

    /*
     * Get Prize By Id
     */
    public TournamentPriceResponseDTO getPriceById(
            String id) {

        TournamentPrice price = tournamentPriceRepo
                .findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Prize not found with id : " + id));

        return tournamentPriceMapper.toResponseDTO(price);
    }

    /*
     * Get Tournament Prizes
     */
    public Page<TournamentPriceResponseDTO>
    getTournamentPrices(
            String tournamentId,
            Pageable pageable) {

        if (!tournamentRepo.existsById(tournamentId)) {
            throw new NotFoundException(
                    "Tournament not found with id : "
                            + tournamentId);
        }

        return tournamentPriceRepo
                .findByTournament_Id(
                        tournamentId,
                        pageable)
                .map(tournamentPriceMapper::toResponseDTO);
    }

    /*
     * Update Prize
     */
    public TournamentPriceResponseDTO updatePrice(
            String id,
            TournamentPriceUpdateDTO updateDTO) {

        TournamentPrice price = tournamentPriceRepo
                .findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Prize not found with id : " + id));

        tournamentPriceMapper.updatePriceFromDTO(
                updateDTO,
                price);

        price.setUpdatedAt(LocalDateTime.now());

        validatePrice(price);

        return tournamentPriceMapper.toResponseDTO(
                tournamentPriceRepo.save(price));
    }

    /*
     * Delete Prize
     */
    public ResponseDTO deletePrice(String id) {

        TournamentPrice price = tournamentPriceRepo
                .findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Prize not found with id : " + id));

        tournamentPriceRepo.delete(price);

        return new ResponseDTO(
                HttpStatus.OK.value(),
                "Tournament prize deleted successfully");
    }

    /*
     * Filter Prizes
     */
    public Page<TournamentPriceResponseDTO> filterPrices(
            String tournamentId,
            String prizeCategory,
            Integer rankOrder,
            Pageable pageable) {

        Specification<TournamentPrice> specification =
                TournamentPriceSpecification.filter(
                        tournamentId,
                        prizeCategory,
                        rankOrder);

        return tournamentPriceRepo
                .findAll(specification, pageable)
                .map(tournamentPriceMapper::toResponseDTO);
    }

    /*
     * Validation
     */
    private void validatePrice(
            TournamentPrice price) {

        if (price.getPrizeCategory() == null) {
            throw new IllegalArgumentException(
                    "Prize category is required");
        }

        if (price.getRankOrder() == null
                || price.getRankOrder() <= 0) {

            throw new IllegalArgumentException(
                    "Rank order must be greater than 0");
        }

        if (price.getPrizeAmount() == null) {

            throw new IllegalArgumentException(
                    "Prize amount is required");
        }

        if (price.getPrizeAmount()
                .compareTo(BigDecimal.ZERO) < 0) {

            throw new IllegalArgumentException(
                    "Prize amount cannot be negative");
        }

        if (price.getTournament() == null) {

            throw new IllegalArgumentException(
                    "Tournament is required");
        }
    }
}
