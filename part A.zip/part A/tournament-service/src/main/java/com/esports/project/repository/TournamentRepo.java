package com.esports.project.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.Tournament;

@Repository
public interface TournamentRepo extends JpaRepository<Tournament,String>,JpaSpecificationExecutor<Tournament>{
    List<Tournament> findByUserId(String userId);
    @Query("""
            SELECT DISTINCT t
            FROM Tournament t
            LEFT JOIN FETCH t.tournamentRegistrations tr
            WHERE t.id = :id
            """)
    Optional<Tournament> findByIdWithRegistrations(
            @Param("id") String id);
}
