package com.esports.project.DTO;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentAnnouncementResponseDTO {

    private String id;

    private String title;

    private String content;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private String tournamentId;

    private String tournamentName;
}