package com.esports.project.enums;

public enum StatusMaster {
    ONGOING(StatusType.TOURNAMENT),
    UPCOMMING(StatusType.TOURNAMENT),
    CANCELLED(StatusType.TOURNAMENT),
    POSTPONDED(StatusType.TOURNAMENT),
    REGISTERED(StatusType.REGISTRATION);

    private StatusType statusType;

    private StatusMaster(StatusType statusType){
        this.statusType = statusType;
    }

    public String getStatusType(){
        return statusType.toString();
    }
}
