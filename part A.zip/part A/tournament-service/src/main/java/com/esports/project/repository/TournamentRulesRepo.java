package com.esports.project.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.TournamentRules;

@Repository
public interface TournamentRulesRepo extends
        JpaRepository<TournamentRules, String>,
        JpaSpecificationExecutor<TournamentRules> {

    List<TournamentRules> findByTournament_Id(
            String tournamentId);

    Page<TournamentRules> findByTournament_Id(
            String tournamentId,
            Pageable pageable);
}