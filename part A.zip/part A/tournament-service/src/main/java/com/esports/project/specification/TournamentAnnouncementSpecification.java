package com.esports.project.specification;


import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.esports.project.entity.TournamentAnnouncement;

import jakarta.persistence.criteria.Predicate;

public class TournamentAnnouncementSpecification {

    public static Specification<TournamentAnnouncement> filter(
            String tournamentId) {

        return (root, query, cb) -> {

            List<Predicate> predicates = new ArrayList<>();

            if (tournamentId != null && !tournamentId.isBlank()) {
                predicates.add(
                        cb.equal(
                                root.get("tournament").get("id"),
                                tournamentId));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
