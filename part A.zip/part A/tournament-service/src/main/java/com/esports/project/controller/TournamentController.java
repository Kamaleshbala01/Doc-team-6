package com.esports.project.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentRequestDTO;
import com.esports.project.DTO.TournamentResponseDTO;
import com.esports.project.DTO.TournamentUpdateDTO;
import com.esports.project.DTO.WebSocketInfoResponse;
import com.esports.project.service.TournamentService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/tournament")
public class TournamentController {

    private final TournamentService tournamentService;

    public TournamentController(TournamentService tournamentService){
        this.tournamentService = tournamentService;
    }

    @PostMapping()
    // @PreAuthorize("hasAuthority('TOURNAMENT_CREATE')")
    public ResponseEntity<TournamentResponseDTO> createTournament(@Valid @RequestBody TournamentRequestDTO tournamentRequestDTO){
        return ResponseEntity.status(HttpStatus.CREATED).body(tournamentService.createTournament(tournamentRequestDTO));
    }

    @GetMapping("/my")
    // @PreAuthorize("hasAuthority('TOURNAMENT_VIEW_OWN')")
    public ResponseEntity<List<TournamentResponseDTO>> getMyTournaments(){
        return ResponseEntity.status(HttpStatus.OK).body(tournamentService.getMyTournaments());
    }

    @GetMapping("/{id}/my")
    // @PreAuthorize("hasAuthority('TOURNAMENT_VIEW_OWN')")
    public ResponseEntity<TournamentResponseDTO> getMyTournamentById(@PathVariable String id){
        return ResponseEntity.status(HttpStatus.OK).body(tournamentService.getMyTournamentById(id));
    }

    @PatchMapping("/{id}")
    // @PreAuthorize("hasAuthority('TOURNAMENT_UPDATE')")
    public ResponseEntity<TournamentResponseDTO> patchUpdateTournament(@PathVariable String id,@RequestBody TournamentUpdateDTO updateDTO){
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(tournamentService.patchUpdateTournament(id,updateDTO));
    }

    @DeleteMapping("/{id}/soft")
    // @PreAuthorize("hasAuthority('TOURNAMENT_DELETE')")
    public ResponseEntity<ResponseDTO> softDeleteTournament(@PathVariable String id){
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(tournamentService.softDeleteTournament(id));
    }

    // filter

    @GetMapping("/filter")
    // @PreAuthorize("hasAuthority('TOURNAMENT_VIEW')")
    public Page<TournamentResponseDTO> getTournaments(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String tournamentType,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String seedType,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        return tournamentService.getTournaments(
                name,
                tournamentType,
                category,
                seedType,
                status,
                PageRequest.of(page, size)
        );
    }

    // test socket

     @GetMapping("/broker/details")
    public WebSocketInfoResponse getBrokerDetails(
            @RequestParam String service) {

        return WebSocketInfoResponse.builder()
                .websocketUrl("ws://localhost:8080/broker?service=" + service)
                .service(service)
                .publishDestination("/app/trade")
                .subscribeDestination("/topic/trades")
                .jwtRequired(true)
                .build();
    }

    @GetMapping("/{id}/lock")
    // @PreAuthorize("hasAuthority('TOURNAMENT_LOCK')")
    public ResponseEntity<ResponseDTO> lockMyTournament(@PathVariable String id){
        return ResponseEntity.status(HttpStatus.OK).body(tournamentService.lockMyTournament(id));
    }
}
