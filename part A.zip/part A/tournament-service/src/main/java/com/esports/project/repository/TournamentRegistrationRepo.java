package com.esports.project.repository;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.TournamentRegistration;

@Repository
public interface TournamentRegistrationRepo extends
        JpaRepository<TournamentRegistration, String>,
        JpaSpecificationExecutor<TournamentRegistration> {

    List<TournamentRegistration> findByTournament_Id(
            String tournamentId);

    Page<TournamentRegistration> findByTournament_Id(
            String tournamentId,
            Pageable pageable);

    boolean existsByTournament_IdAndTeamId(
            String tournamentId,
            String teamId);
}
