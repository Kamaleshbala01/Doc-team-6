package com.esports.project.specification;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.esports.project.entity.TournamentPrice;
import com.esports.project.enums.PriceCategory;

import jakarta.persistence.criteria.Predicate;

public class TournamentPriceSpecification {

    public static Specification<TournamentPrice> filter(
            String tournamentId,
            String prizeCategory,
            Integer rankOrder) {

        return (root, query, cb) -> {

            List<Predicate> predicates = new ArrayList<>();

            if (tournamentId != null
                    && !tournamentId.isBlank()) {

                predicates.add(
                        cb.equal(
                                root.get("tournament")
                                        .get("id"),
                                tournamentId));
            }

            if (prizeCategory != null
                    && !prizeCategory.isBlank()) {

                predicates.add(
                        cb.equal(
                                root.get("prizeCategory"),
                                PriceCategory.valueOf(
                                        prizeCategory.toUpperCase())));
            }

            if (rankOrder != null) {

                predicates.add(
                        cb.equal(
                                root.get("rankOrder"),
                                rankOrder));
            }

            return cb.and(
                    predicates.toArray(
                            new Predicate[0]));
        };
    }
}