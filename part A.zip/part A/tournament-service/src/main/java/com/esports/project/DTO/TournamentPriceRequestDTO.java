package com.esports.project.DTO;

import java.math.BigDecimal;

import com.esports.project.enums.PriceCategory;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentPriceRequestDTO {

    private PriceCategory prizeCategory;
    private Integer rankOrder;
    private BigDecimal prizeAmount;
    private String prizeDescription;
    private String tournamentId;
}