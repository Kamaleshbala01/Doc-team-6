package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentAnnouncementUpdateDTO {

    private String title;
    private String content;

}