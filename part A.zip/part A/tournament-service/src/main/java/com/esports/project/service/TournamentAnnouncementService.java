package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentAnnouncementRequestDTO;
import com.esports.project.DTO.TournamentAnnouncementResponseDTO;
import com.esports.project.DTO.TournamentAnnouncementUpdateDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.entity.TournamentAnnouncement;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentAnnouncementMapper;
import com.esports.project.repository.TournamentAnnouncementRepo;
import com.esports.project.repository.TournamentRepo;
import com.esports.project.specification.TournamentAnnouncementSpecification;

@Service
public class TournamentAnnouncementService {

    private final TournamentAnnouncementRepo tournamentAnnouncementRepo;
    private final TournamentRepo tournamentRepo;
    private final TournamentAnnouncementMapper tournamentAnnouncementMapper;

    @Autowired
    public TournamentAnnouncementService(
            TournamentAnnouncementRepo tournamentAnnouncementRepo,
            TournamentRepo tournamentRepo,
            TournamentAnnouncementMapper tournamentAnnouncementMapper) {

        this.tournamentAnnouncementRepo = tournamentAnnouncementRepo;
        this.tournamentRepo = tournamentRepo;
        this.tournamentAnnouncementMapper = tournamentAnnouncementMapper;
    }

    public TournamentAnnouncementResponseDTO createAnnouncement(
            TournamentAnnouncementRequestDTO requestDTO) {

        Tournament tournament = tournamentRepo.findById(
                requestDTO.getTournamentId())
                .orElseThrow(() -> new NotFoundException(
                        "Tournament not found with id : "
                                + requestDTO.getTournamentId()));

        TournamentAnnouncement announcement = tournamentAnnouncementMapper.toEntity(requestDTO);

        announcement.setTournament(tournament);
        announcement.setCreatedAt(LocalDateTime.now());

        validateAnnouncement(announcement);

        return tournamentAnnouncementMapper.toResponseDTO(
                tournamentAnnouncementRepo.save(announcement));
    }

    public TournamentAnnouncementResponseDTO getAnnouncementById(
            String id) {

        TournamentAnnouncement announcement = tournamentAnnouncementRepo.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Announcement not found with id : "
                                + id));

        return tournamentAnnouncementMapper.toResponseDTO(
                announcement);
    }

    public List<TournamentAnnouncementResponseDTO> getAnnouncementsByTournamentId(
            String tournamentId) {

        if (!tournamentRepo.existsById(tournamentId)) {
            throw new NotFoundException(
                    "Tournament not found with id : "
                            + tournamentId);
        }

        return tournamentAnnouncementRepo
                .findByTournament_Id(tournamentId)
                .stream()
                .map(tournamentAnnouncementMapper::toResponseDTO)
                .toList();
    }

    public TournamentAnnouncementResponseDTO updateAnnouncement(
            String id,
            TournamentAnnouncementUpdateDTO updateDTO) {

        TournamentAnnouncement announcement = tournamentAnnouncementRepo.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Announcement not found with id : "
                                + id));

        if (updateDTO.getTitle() != null) {
            announcement.setTitle(updateDTO.getTitle());
        }

        if (updateDTO.getContent() != null) {
            announcement.setContent(updateDTO.getContent());
        }

        announcement.setUpdatedAt(LocalDateTime.now());

        validateAnnouncement(announcement);

        return tournamentAnnouncementMapper.toResponseDTO(
                tournamentAnnouncementRepo.save(announcement));
    }

    public ResponseDTO deleteAnnouncement(String id) {

        TournamentAnnouncement announcement = tournamentAnnouncementRepo.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Announcement not found with id : "
                                + id));

        tournamentAnnouncementRepo.delete(announcement);

        return new ResponseDTO(
                HttpStatus.OK.value(),
                "Announcement deleted successfully");
    }

    public Page<TournamentAnnouncementResponseDTO> getTournamentAnnouncements(
            String tournamentId,
            Pageable pageable) {

        if (!tournamentRepo.existsById(tournamentId)) {
            throw new NotFoundException(
                    "Tournament not found with id : "
                            + tournamentId);
        }

        return tournamentAnnouncementRepo
                .findByTournament_Id(
                        tournamentId,
                        pageable)
                .map(
                        tournamentAnnouncementMapper::toResponseDTO);
    }

    public Page<TournamentAnnouncementResponseDTO>
filterAnnouncements(
        String title,
        String tournamentId,
        Pageable pageable) {

    Specification<TournamentAnnouncement>
            specification =
            TournamentAnnouncementSpecification
                    .filter(tournamentId);

    return tournamentAnnouncementRepo
            .findAll(specification, pageable)
            .map(
                    tournamentAnnouncementMapper::toResponseDTO);
}

    private void validateAnnouncement(
            TournamentAnnouncement announcement) {

        if (announcement.getTitle() == null ||
                announcement.getTitle().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Announcement title is required");
        }

        if (announcement.getContent() == null ||
                announcement.getContent().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Announcement content is required");
        }

        if (announcement.getTournament() == null) {

            throw new IllegalArgumentException(
                    "Tournament is required");
        }
    }

}