package com.esports.project.DTO;

import com.esports.project.enums.RulesCategory;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentRulesUpdateDTO {

    private RulesCategory category;

    private String ruleText;
}