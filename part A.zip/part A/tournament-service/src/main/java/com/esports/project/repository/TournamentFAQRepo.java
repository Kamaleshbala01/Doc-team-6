package com.esports.project.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.TournamentFAQ;

@Repository
public interface TournamentFAQRepo extends
        JpaRepository<TournamentFAQ, String>,
        JpaSpecificationExecutor<TournamentFAQ> {

    List<TournamentFAQ> findByTournament_Id(
            String tournamentId);

    Page<TournamentFAQ> findByTournament_Id(
            String tournamentId,
            Pageable pageable);
}
