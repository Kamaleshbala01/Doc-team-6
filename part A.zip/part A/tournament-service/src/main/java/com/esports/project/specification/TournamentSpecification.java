package com.esports.project.specification;

import java.util.List;
import java.util.ArrayList;

import org.springframework.data.jpa.domain.Specification;

import com.esports.project.entity.Tournament;

import jakarta.persistence.criteria.Predicate;

public class TournamentSpecification {

    public static Specification<Tournament> filter(
            String name,
            String tournamentType,
            String category,
            String seedType,
            String status) {

        return (root, query, cb) -> {

            List<Predicate> predicates = new ArrayList<>();

            if (name != null && !name.isBlank()) {
                predicates.add(
                    cb.like(
                        cb.lower(root.get("name")),
                        "%" + name.toLowerCase() + "%"
                    )
                );
            }

            if (tournamentType != null) {
                predicates.add(
                    cb.equal(root.get("tournamentType"), tournamentType)
                );
            }

            if (category != null) {
                predicates.add(
                    cb.equal(root.get("tournamentCategory"), category)
                );
            }
            if (seedType != null) {
                predicates.add(
                    cb.equal(root.get("seedingTypeId"), seedType)
                );
            }

            if (status != null) {
                predicates.add(
                    cb.equal(root.get("status"), status)
                );
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}

