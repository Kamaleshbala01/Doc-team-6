package com.esports.project.entity;

import java.time.LocalDateTime;

import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tournament_registration")
public class TournamentRegistration {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private StatusMaster registrationStatus;

    private LocalDateTime registrationDate;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt; 


    @Column(name = "team_id")
    private String teamId;

    /*
     * Relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "tournament_id")
    @JsonBackReference(value = "tournament-registration")
    private Tournament tournament;

}
