package com.esports.project.specification;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.esports.project.entity.TournamentRegistration;
import com.esports.project.enums.StatusMaster;

import jakarta.persistence.criteria.Predicate;

public class TournamentRegistrationSpecification {

    public static Specification<TournamentRegistration> filter(
            String tournamentId,
            String teamId,
            String registrationStatus) {

        return (root, query, cb) -> {

            List<Predicate> predicates =
                    new ArrayList<>();

            if (tournamentId != null &&
                    !tournamentId.isBlank()) {

                predicates.add(
                        cb.equal(
                                root.get("tournament")
                                        .get("id"),
                                tournamentId));
            }

            if (teamId != null &&
                    !teamId.isBlank()) {

                predicates.add(
                        cb.equal(
                                root.get("teamId"),
                                teamId));
            }

            if (registrationStatus != null &&
                    !registrationStatus.isBlank()) {

                predicates.add(
                        cb.equal(
                                root.get("registrationStatus"),
                                StatusMaster.valueOf(
                                        registrationStatus
                                                .toUpperCase())));
            }

            return cb.and(
                    predicates.toArray(
                            new Predicate[0]));
        };
    };
}