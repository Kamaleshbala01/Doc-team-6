package com.esports.project.enums;

public enum PriceCategory {
    FIRST_PRICE(1),
    SECOND_PRICE(2),
    THIRD_PRICE(3),
    MVP(4);

    private int displayOrder;

    private PriceCategory(int displayOrder){
        this.displayOrder = displayOrder;
    }

    public int getDisplayOrder(){
        return displayOrder;
    }
}
