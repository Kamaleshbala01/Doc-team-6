package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentRegistrationRequestDTO;
import com.esports.project.DTO.TournamentRegistrationResponseDTO;
import com.esports.project.DTO.TournamentRegistrationUpdateDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.entity.TournamentRegistration;
import com.esports.project.enums.StatusMaster;
import com.esports.project.exception.IllegalArgumentException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentRegistrationMapper;
import com.esports.project.repository.TournamentRegistrationRepo;
import com.esports.project.repository.TournamentRepo;
import com.esports.project.specification.TournamentRegistrationSpecification;

@Service
public class TournamentRegistrationService {

    private final TournamentRegistrationRepo tournamentRegistrationRepo;
    private final TournamentRepo tournamentRepo;
    private final TournamentRegistrationMapper tournamentRegistrationMapper;

    @Autowired
    public TournamentRegistrationService(
            TournamentRegistrationRepo tournamentRegistrationRepo,
            TournamentRepo tournamentRepo,
            TournamentRegistrationMapper tournamentRegistrationMapper) {

        this.tournamentRegistrationRepo = tournamentRegistrationRepo;
        this.tournamentRepo = tournamentRepo;
        this.tournamentRegistrationMapper = tournamentRegistrationMapper;
    }

    /*
     * Create Registration
     */
    public TournamentRegistrationResponseDTO createRegistration(
            TournamentRegistrationRequestDTO requestDTO) {

        Tournament tournament = tournamentRepo
                .findById(requestDTO.getTournamentId())
                .orElseThrow(() -> new NotFoundException(
                        "Tournament not found with id : "
                                + requestDTO.getTournamentId()));

        if (tournamentRegistrationRepo
                .existsByTournament_IdAndTeamId(
                        requestDTO.getTournamentId(),
                        requestDTO.getTeamId())) {

            throw new IllegalArgumentException(
                    "Team already registered for this tournament");
        }

        TournamentRegistration registration =
                tournamentRegistrationMapper.toEntity(requestDTO);

        registration.setTournament(tournament);
        registration.setRegistrationStatus(StatusMaster.REGISTERED);
        registration.setRegistrationDate(LocalDateTime.now());
        registration.setCreatedAt(LocalDateTime.now());

        validateRegistration(registration);

        return tournamentRegistrationMapper.toResponseDTO(
                tournamentRegistrationRepo.save(registration));
    }

    /*
     * Get Registration By Id
     */
    public TournamentRegistrationResponseDTO getRegistrationById(
            String id) {

        TournamentRegistration registration =
                tournamentRegistrationRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Registration not found with id : "
                                                + id));

        return tournamentRegistrationMapper
                .toResponseDTO(registration);
    }

    /*
     * Get Tournament Registrations
     */
    public List<TournamentRegistrationResponseDTO>
    getTournamentRegistrations(
            String tournamentId) {

        if (!tournamentRepo.existsById(tournamentId)) {

            throw new NotFoundException(
                    "Tournament not found with id : "
                            + tournamentId);
        }

        List<TournamentRegistration> ans =  tournamentRegistrationRepo
                .findByTournament_Id(tournamentId);

                System.out.println(ans);

                return ans.stream().map(reg -> tournamentRegistrationMapper.toResponseDTO(reg)).toList();
                

                
    }

    /*
     * Update Registration
     */
    public TournamentRegistrationResponseDTO updateRegistration(
            String id,
            TournamentRegistrationUpdateDTO updateDTO) {

        TournamentRegistration registration =
                tournamentRegistrationRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Registration not found with id : "
                                                + id));

        tournamentRegistrationMapper
                .updateRegistrationFromDTO(
                        updateDTO,
                        registration);

        registration.setUpdatedAt(LocalDateTime.now());

        validateRegistration(registration);

        return tournamentRegistrationMapper.toResponseDTO(
                tournamentRegistrationRepo.save(registration));
    }

    /*
     * Delete Registration
     */
    public ResponseDTO deleteRegistration(String id) {

        TournamentRegistration registration =
                tournamentRegistrationRepo.findById(id)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Registration not found with id : "
                                                + id));

        tournamentRegistrationRepo.delete(registration);

        return new ResponseDTO(
                HttpStatus.OK.value(),
                "Tournament registration deleted successfully");
    }

    /*
     * Filter Registrations
     */
    public Page<TournamentRegistrationResponseDTO>
    filterRegistrations(
            String tournamentId,
            String teamId,
            String registrationStatus,
            Pageable pageable) {

        Specification<TournamentRegistration> specification =
                TournamentRegistrationSpecification.filter(
                        tournamentId,
                        teamId,
                        registrationStatus);

        return tournamentRegistrationRepo
                .findAll(specification, pageable)
                .map(tournamentRegistrationMapper::toResponseDTO);
    }

    /*
     * Validation
     */
    private void validateRegistration(
            TournamentRegistration registration) {

        if (registration.getTournament() == null) {
            throw new IllegalArgumentException(
                    "Tournament is required");
        }

        if (registration.getTeamId() == null
                || registration.getTeamId().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Team Id is required");
        }

        if (registration.getRegistrationStatus() == null) {

            throw new IllegalArgumentException(
                    "Registration status is required");
        }

        if (registration.getRegistrationDate() == null) {

            throw new IllegalArgumentException(
                    "Registration date is required");
        }
    }
}
