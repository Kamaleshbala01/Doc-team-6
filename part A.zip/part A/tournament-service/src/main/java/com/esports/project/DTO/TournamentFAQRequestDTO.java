package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TournamentFAQRequestDTO {
    private String question;
    private String tournamentId;
}
