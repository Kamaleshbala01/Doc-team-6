package com.esports.project.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.esports.project.DTO.ResponseDTO;
import com.esports.project.DTO.TournamentFAQRequestDTO;
import com.esports.project.DTO.TournamentFAQResponseDTO;
import com.esports.project.DTO.TournamentFAQUpdateDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.entity.Tournament;
import com.esports.project.entity.TournamentFAQ;
import com.esports.project.exception.IllegalArgumentException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.mapper.TournamentFAQMapper;
import com.esports.project.repository.TournamentFAQRepo;
import com.esports.project.repository.TournamentRepo;
import com.esports.project.specification.TournamentFAQSpecification;

import org.springframework.http.HttpStatus;

@Service
public class TournamentFAQService {

    private final TournamentFAQRepo tournamentFAQRepo;
    private final TournamentRepo tournamentRepo;
    private final TournamentFAQMapper tournamentFAQMapper;

    @Autowired
    public TournamentFAQService(
            TournamentFAQRepo tournamentFAQRepo,
            TournamentRepo tournamentRepo,
            TournamentFAQMapper tournamentFAQMapper) {

        this.tournamentFAQRepo = tournamentFAQRepo;
        this.tournamentRepo = tournamentRepo;
        this.tournamentFAQMapper = tournamentFAQMapper;
    }

    /*
     * Create FAQ
     * Only question is provided initially.
     */
    public TournamentFAQResponseDTO createFAQ(
            TournamentFAQRequestDTO requestDTO) {

        UserDetailsDTO userDetailsDTO =
                (UserDetailsDTO) SecurityContextHolder
                        .getContext()
                        .getAuthentication()
                        .getPrincipal();

        Tournament tournament = tournamentRepo
                .findById(requestDTO.getTournamentId())
                .orElseThrow(() -> new NotFoundException(
                        "Tournament not found with id : "
                                + requestDTO.getTournamentId()));

        TournamentFAQ faq =
                tournamentFAQMapper.toEntity(requestDTO);

        faq.setTournament(tournament);
        faq.setUserId(userDetailsDTO.getUserId());
        faq.setCreatedAt(LocalDateTime.now());

        // Initially unanswered
        faq.setAnswer(null);

        validateFAQ(faq);

        return tournamentFAQMapper.toResponseDTO(
                tournamentFAQRepo.save(faq));
    }

    /*
     * Get FAQ By Id
     */
    public TournamentFAQResponseDTO getFAQById(
            String id) {

        TournamentFAQ faq = tournamentFAQRepo.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "FAQ not found with id : " + id));

        return tournamentFAQMapper.toResponseDTO(faq);
    }

    /*
     * Get Tournament FAQs
     */
    public Page<TournamentFAQResponseDTO> getTournamentFAQs(
            String tournamentId,
            Pageable pageable) {

        if (!tournamentRepo.existsById(tournamentId)) {
            throw new NotFoundException(
                    "Tournament not found with id : "
                            + tournamentId);
        }

        return tournamentFAQRepo
                .findByTournament_Id(tournamentId, pageable)
                .map(tournamentFAQMapper::toResponseDTO);
    }

    /*
     * Tournament host answers FAQ
     */
    public TournamentFAQResponseDTO answerFAQ(
            String id,
            TournamentFAQUpdateDTO updateDTO) {

        UserDetailsDTO userDetailsDTO =
                (UserDetailsDTO) SecurityContextHolder
                        .getContext()
                        .getAuthentication()
                        .getPrincipal();

        TournamentFAQ faq = tournamentFAQRepo.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "FAQ not found with id : " + id));

        /*
         * Host validation
         */
        if (!faq.getTournament()
                .getUserId()
                .equals(userDetailsDTO.getUserId())) {

            throw new IllegalArgumentException(
                    "Only tournament host can answer FAQs");
        }

        if (updateDTO.getAnswer() != null) {
            faq.setAnswer(updateDTO.getAnswer());
        }

        faq.setUpdatedAt(LocalDateTime.now());

        validateFAQ(faq);

        return tournamentFAQMapper.toResponseDTO(
                tournamentFAQRepo.save(faq));
    }

    /*
     * Delete FAQ
     */
    public ResponseDTO deleteFAQ(String id) {

        TournamentFAQ faq = tournamentFAQRepo.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "FAQ not found with id : " + id));

        tournamentFAQRepo.delete(faq);

        return new ResponseDTO(
                HttpStatus.OK.value(),
                "FAQ deleted successfully");
    }

    /*
     * Filter FAQs
     */
    public Page<TournamentFAQResponseDTO> filterFAQ(
            String tournamentId,
            String question,
            String status,
            Pageable pageable) {

        Specification<TournamentFAQ> specification =
                TournamentFAQSpecification.filter(
                        tournamentId,
                        question,
                        status);

        return tournamentFAQRepo
                .findAll(specification, pageable)
                .map(tournamentFAQMapper::toResponseDTO);
    }

    /*
     * Validation
     */
    private void validateFAQ(TournamentFAQ faq) {

        if (faq.getQuestion() == null
                || faq.getQuestion().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Question is required");
        }

        if (faq.getTournament() == null) {

            throw new IllegalArgumentException(
                    "Tournament is required");
        }

        if (faq.getUserId() == null
                || faq.getUserId().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "User id is required");
        }
    }
}