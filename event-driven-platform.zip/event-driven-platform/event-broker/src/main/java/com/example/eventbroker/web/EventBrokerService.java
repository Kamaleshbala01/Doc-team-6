package com.example.eventbroker.web;

import com.example.events.common.EventEnvelope;
import com.example.eventbroker.store.EventStoreMapper;
import com.example.eventbroker.store.EventStoreRecord;
import com.example.eventbroker.store.EventStoreRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * THE BROKER'S CORE: persist-then-broadcast, in that order.
 *
 * WHY PERSIST BEFORE BROADCAST:
 *   If we broadcast first and persistence failed afterward, a live
 *   subscriber could process an event that a replaying subscriber (or one
 *   that reconnects a second later) would never see - a durability/replay
 *   inconsistency. Persisting first and only broadcasting on success
 *   guarantees the event log (Postgres) is always the source of truth: what
 *   went out live is always a subset of what's in the log.
 *
 * SOLID:
 *   Single Responsibility - this class's only job is "durably record an
 *   event, then fan it out live". It knows nothing about specific event
 *   types or payload shapes (those stay opaque JSON strings all the way
 *   through), which is what lets the broker support arbitrary future event
 *   types with zero code changes - the same Open/Closed benefit Kafka gives
 *   you by being payload-agnostic.
 */
@Service
public class EventBrokerService {

    private static final Logger log = LoggerFactory.getLogger(EventBrokerService.class);

    private final EventStoreRepository repository;
    private final SimpMessagingTemplate messagingTemplate;

    public EventBrokerService(EventStoreRepository repository, SimpMessagingTemplate messagingTemplate) {
        this.repository = repository;
        this.messagingTemplate = messagingTemplate;
    }

    @Transactional
    public EventEnvelope publish(EventEnvelope incoming) {
        EventStoreRecord record = EventStoreMapper.toRecord(incoming);
        EventStoreRecord saved = repository.save(record);
        EventEnvelope persisted = EventStoreMapper.toEnvelope(saved);

        log.info("Persisted event [{}] from [{}] as offset={}",
                persisted.getEventType(), persisted.getSourceService(), persisted.getOffset());

        String destination = "/topic/events/" + persisted.getEventType();
        messagingTemplate.convertAndSend(destination, persisted);

        log.info("Broadcast event offset={} to {}", persisted.getOffset(), destination);
        return persisted;
    }
}
