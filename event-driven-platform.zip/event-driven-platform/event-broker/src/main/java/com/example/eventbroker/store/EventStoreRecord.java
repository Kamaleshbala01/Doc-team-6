package com.example.eventbroker.store;

import jakarta.persistence.*;

import java.time.Instant;

/**
 * The broker's durable event log, backed by PostgreSQL - this table IS the
 * "Kafka topic log" in our simplified system. Every published event gets
 * one row here, and the auto-increment `id` column doubles as the offset
 * consumers replay from.
 */
@Entity
@Table(name = "event_store")
public class EventStoreRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // doubles as the "offset"

    @Column(name = "event_id", nullable = false, unique = true)
    private String eventId;

    @Column(name = "event_type", nullable = false)
    private String eventType;

    @Column(name = "source_service", nullable = false)
    private String sourceService;

    @Column(name = "payload_json", nullable = false, length = 8000)
    private String payloadJson;

    @Column(name = "published_at", nullable = false)
    private Instant publishedAt;

    protected EventStoreRecord() {
        // JPA
    }

    public EventStoreRecord(String eventId, String eventType, String sourceService,
                             String payloadJson, Instant publishedAt) {
        this.eventId = eventId;
        this.eventType = eventType;
        this.sourceService = sourceService;
        this.payloadJson = payloadJson;
        this.publishedAt = publishedAt;
    }

    public Long getId() { return id; }
    public String getEventId() { return eventId; }
    public String getEventType() { return eventType; }
    public String getSourceService() { return sourceService; }
    public String getPayloadJson() { return payloadJson; }
    public Instant getPublishedAt() { return publishedAt; }
}
