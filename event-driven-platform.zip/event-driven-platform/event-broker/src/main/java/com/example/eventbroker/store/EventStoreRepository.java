package com.example.eventbroker.store;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EventStoreRepository extends JpaRepository<EventStoreRecord, Long> {

    /** Powers replay: everything of this type published after the caller's last known offset, in order. */
    List<EventStoreRecord> findByEventTypeAndIdGreaterThanOrderByIdAsc(String eventType, Long sinceOffset);
}
