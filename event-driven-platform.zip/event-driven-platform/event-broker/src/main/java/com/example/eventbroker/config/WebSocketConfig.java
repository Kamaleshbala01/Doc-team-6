package com.example.eventbroker.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * The broker exposes TWO STOMP endpoints on purpose:
 *
 *   /ws-broker  - plain WebSocket (no SockJS). Used by other microservices
 *                 connecting as Java STOMP clients (see
 *                 EventBusConnectionManager in eventbus-client-starter).
 *                 Backend-to-backend traffic never needs SockJS's
 *                 browser-compatibility fallbacks.
 *
 *   /ws         - SockJS-wrapped. Reserved for browser dashboards that might
 *                 want to watch broker activity directly (optional, not
 *                 required by any service in this demo, but included so a
 *                 future admin UI has somewhere to connect).
 *
 * Both endpoints share the same message broker, so a message broadcast to
 * /topic/events/{eventType} reaches anything subscribed via either endpoint.
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws-broker").setAllowedOriginPatterns("*");
        registry.addEndpoint("/ws").setAllowedOriginPatterns("*").withSockJS();
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.enableSimpleBroker("/topic");
        registry.setApplicationDestinationPrefixes("/app");
    }
}
