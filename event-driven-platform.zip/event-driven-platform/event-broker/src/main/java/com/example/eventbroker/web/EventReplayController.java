package com.example.eventbroker.web;

import com.example.events.common.EventEnvelope;
import com.example.eventbroker.store.EventStoreMapper;
import com.example.eventbroker.store.EventStoreRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * The replay/catch-up read path. Called by ReplayClient (in
 * eventbus-client-starter) on every service startup and reconnect, with the
 * caller's own last-committed offset for that event type. This is the
 * mechanism that makes the system durable instead of pure fire-and-forget.
 */
@RestController
public class EventReplayController {

    private final EventStoreRepository repository;

    public EventReplayController(EventStoreRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/api/events/replay")
    public List<EventEnvelope> replay(@RequestParam String eventType,
                                       @RequestParam(defaultValue = "0") long sinceOffset) {
        return repository.findByEventTypeAndIdGreaterThanOrderByIdAsc(eventType, sinceOffset)
                .stream()
                .map(EventStoreMapper::toEnvelope)
                .toList();
    }
}
