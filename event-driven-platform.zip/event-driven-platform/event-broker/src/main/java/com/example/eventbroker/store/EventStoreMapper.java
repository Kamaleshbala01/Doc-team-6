package com.example.eventbroker.store;

import com.example.events.common.EventEnvelope;

/**
 * Converts between the wire-format EventEnvelope (shared with client
 * services via events-common) and the broker's internal JPA entity.
 * Keeping this mapping in one small class means the persistence model can
 * evolve independently of the wire contract.
 */
public final class EventStoreMapper {
    private EventStoreMapper() {}

    public static EventStoreRecord toRecord(EventEnvelope envelope) {
        return new EventStoreRecord(
                envelope.getEventId(),
                envelope.getEventType(),
                envelope.getSourceService(),
                envelope.getPayloadJson(),
                envelope.getTimestamp());
    }

    public static EventEnvelope toEnvelope(EventStoreRecord record) {
        return new EventEnvelope(
                record.getId(),
                record.getEventId(),
                record.getEventType(),
                record.getSourceService(),
                record.getPublishedAt(),
                record.getPayloadJson());
    }
}
