package com.example.eventbroker.web;

import com.example.events.common.EventEnvelope;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * The single write path into the broker. Every producer microservice's
 * EventBusPublisher (from eventbus-client-starter) POSTs here.
 */
@RestController
public class EventPublishController {

    private final EventBrokerService brokerService;

    public EventPublishController(EventBrokerService brokerService) {
        this.brokerService = brokerService;
    }

    @PostMapping("/api/events")
    public EventEnvelope publish(@RequestBody EventEnvelope envelope) {
        return brokerService.publish(envelope);
    }
}
