package com.example.tournament.service;

import com.example.events.common.EventTypes;
import com.example.events.common.payload.TournamentRegistrationClosedPayload;
import com.example.eventbus.client.core.EventBusPublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The producer's business logic. Notice it depends only on
 * EventBusPublisher (from the SDK) - it has never heard of match-service,
 * notification-service, or the broker's internal implementation. This is
 * the exact same decoupling the in-JVM version had, just carried across
 * process boundaries by the SDK + broker instead of an in-memory bus.
 */
@Service
public class TournamentService {

    private static final Logger log = LoggerFactory.getLogger(TournamentService.class);

    private final EventBusPublisher eventBusPublisher;
    private final Map<String, TournamentRecord> tournaments = new ConcurrentHashMap<>();

    public TournamentService(EventBusPublisher eventBusPublisher) {
        this.eventBusPublisher = eventBusPublisher;
    }

    public TournamentRecord createDemoTournament(String id, String name, List<String> teamIds) {
        TournamentRecord record = new TournamentRecord(id, name, teamIds, false);
        tournaments.put(id, record);
        log.info("Created tournament [{}] '{}' with {} team(s)", id, name, teamIds.size());
        return record;
    }

    public TournamentRecord closeRegistration(String tournamentId) {
        TournamentRecord record = tournaments.get(tournamentId);
        if (record == null) {
            throw new IllegalArgumentException("Unknown tournament id: " + tournamentId);
        }
        if (record.registrationClosed()) {
            log.warn("Registration already closed for [{}]", tournamentId);
            return record;
        }

        TournamentRecord closed = record.withClosed(true);
        tournaments.put(tournamentId, closed);
        log.info("Registration closed for [{}] '{}'", tournamentId, record.name());

        TournamentRegistrationClosedPayload payload = new TournamentRegistrationClosedPayload(
                closed.id(), closed.name(), closed.teamIds());

        eventBusPublisher.publish(EventTypes.TOURNAMENT_REGISTRATION_CLOSED, payload);

        return closed;
    }

    public TournamentRecord get(String id) {
        TournamentRecord record = tournaments.get(id);
        if (record == null) {
            throw new IllegalArgumentException("Unknown tournament id: " + id);
        }
        return record;
    }

    public record TournamentRecord(String id, String name, List<String> teamIds, boolean registrationClosed) {
        TournamentRecord withClosed(boolean closed) {
            return new TournamentRecord(id, name, teamIds, closed);
        }
    }
}
