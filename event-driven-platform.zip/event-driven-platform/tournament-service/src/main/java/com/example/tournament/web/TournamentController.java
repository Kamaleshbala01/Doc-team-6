package com.example.tournament.web;

import com.example.tournament.service.TournamentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tournaments")
public class TournamentController {

    private final TournamentService tournamentService;

    public TournamentController(TournamentService tournamentService) {
        this.tournamentService = tournamentService;
    }

    @PostMapping
    public TournamentService.TournamentRecord create(@RequestBody CreateTournamentRequest request) {
        return tournamentService.createDemoTournament(request.id(), request.name(), request.teamIds());
    }

    @PostMapping("/{id}/close-registration")
    public TournamentService.TournamentRecord closeRegistration(@PathVariable String id) {
        return tournamentService.closeRegistration(id);
    }

    @GetMapping("/{id}")
    public TournamentService.TournamentRecord get(@PathVariable String id) {
        return tournamentService.get(id);
    }

    public record CreateTournamentRequest(String id, String name, List<String> teamIds) {}
}
