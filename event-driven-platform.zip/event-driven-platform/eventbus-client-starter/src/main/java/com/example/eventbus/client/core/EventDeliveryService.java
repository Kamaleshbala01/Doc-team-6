package com.example.eventbus.client.core;

import com.example.events.common.EventEnvelope;
import com.example.eventbus.client.offset.ConsumerOffsetService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Single choke point through which every event - whether arriving live over
 * STOMP or fetched during replay - is deserialized, dispatched to the
 * matching EventHandler, and offset-committed.
 *
 * WHY IT EXISTS:
 *   Without this, StompDeliveryListener and ReplayRunner would each
 *   duplicate "find handler for type -> deserialize -> call -> commit
 *   offset" logic, and could easily drift out of sync (e.g. one committing
 *   offsets and the other forgetting to). Centralizing it here also means
 *   idempotency/ordering guarantees only need to be reasoned about once.
 *
 * SOLID:
 *   - Single Responsibility: dispatch + offset bookkeeping, nothing else.
 *   - Open/Closed: new EventHandler beans plug in automatically via the
 *     injected Map<String, EventHandler<?>> - no changes needed here.
 */
@Service
public class EventDeliveryService {

    private static final Logger log = LoggerFactory.getLogger(EventDeliveryService.class);

    private final Map<String, EventHandler<?>> handlersByEventType;
    private final ObjectMapper objectMapper;
    private final ConsumerOffsetService offsetService;

    public EventDeliveryService(List<EventHandler<?>> handlers,
                                 ObjectMapper objectMapper,
                                 ConsumerOffsetService offsetService) {
        this.objectMapper = objectMapper;
        this.offsetService = offsetService;
        this.handlersByEventType = new java.util.HashMap<>();
        for (EventHandler<?> handler : handlers) {
            this.handlersByEventType.put(handler.eventType(), handler);
            log.info("Registered EventHandler [{}] for event type [{}]",
                    handler.getClass().getSimpleName(), handler.eventType());
        }
    }

    public java.util.Set<String> registeredEventTypes() {
        return handlersByEventType.keySet();
    }

    /**
     * Deserializes and dispatches a single event to its handler, then
     * commits the offset. Exceptions from the handler are caught and logged
     * so one bad event can't wedge replay or the STOMP session - matching
     * the isolation guarantee from the in-JVM version's AsyncEventDispatcher.
     */
    @SuppressWarnings("unchecked")
    public <T> void deliver(EventEnvelope envelope) {
        EventHandler<T> handler = (EventHandler<T>) handlersByEventType.get(envelope.getEventType());
        if (handler == null) {
            log.debug("No handler registered here for event type [{}] - ignoring (offset={})",
                    envelope.getEventType(), envelope.getOffset());
            return;
        }
        try {
            T payload = objectMapper.readValue(envelope.getPayloadJson(), handler.payloadType());
            log.info("Delivering event [{}] (eventId={}, offset={}) to handler [{}]",
                    envelope.getEventType(), envelope.getEventId(), envelope.getOffset(),
                    handler.getClass().getSimpleName());
            handler.handle(payload);
            if (envelope.getOffset() != null) {
                offsetService.commit(envelope.getEventType(), envelope.getOffset());
            }
        } catch (Exception ex) {
            log.error("Handler [{}] failed processing event [{}] (eventId={}): {}",
                    handler.getClass().getSimpleName(), envelope.getEventType(), envelope.getEventId(),
                    ex.getMessage(), ex);
        }
    }
}
