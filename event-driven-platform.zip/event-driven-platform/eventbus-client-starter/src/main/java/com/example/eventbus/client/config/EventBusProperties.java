package com.example.eventbus.client.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Binds `eventbus.*` properties from application.yml in each consuming
 * microservice - the broker's REST base URL, its STOMP endpoint URL, and
 * this service's own name (used as sourceService when publishing, and as
 * the consumer identity for offset tracking).
 */
@ConfigurationProperties(prefix = "eventbus")
public class EventBusProperties {

    /** e.g. http://localhost:9000 */
    private String brokerRestUrl = "http://localhost:9000";

    /** e.g. ws://localhost:9000/ws-broker */
    private String brokerWsUrl = "ws://localhost:9000/ws-broker";

    /** Logical name of this microservice, e.g. "match-service". */
    private String serviceName;

    /** Milliseconds to wait before retrying a dropped STOMP connection. */
    private long reconnectDelayMs = 5000;

    public String getBrokerRestUrl() { return brokerRestUrl; }
    public void setBrokerRestUrl(String brokerRestUrl) { this.brokerRestUrl = brokerRestUrl; }
    public String getBrokerWsUrl() { return brokerWsUrl; }
    public void setBrokerWsUrl(String brokerWsUrl) { this.brokerWsUrl = brokerWsUrl; }
    public String getServiceName() { return serviceName; }
    public void setServiceName(String serviceName) { this.serviceName = serviceName; }
    public long getReconnectDelayMs() { return reconnectDelayMs; }
    public void setReconnectDelayMs(long reconnectDelayMs) { this.reconnectDelayMs = reconnectDelayMs; }
}
