package com.example.eventbus.client.replay;

import com.example.events.common.EventEnvelope;
import com.example.eventbus.client.config.EventBusProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

/**
 * Fetches events this service missed while offline, by calling the broker's
 * GET /api/events/replay endpoint with (eventType, sinceOffset).
 *
 * WHY IT EXISTS:
 *   This is what makes the system durable rather than pure fire-and-forget:
 *   the broker persisted every event to Postgres, so a service that was down
 *   (deployment, crash, network partition) can catch up in full on restart,
 *   in order, before it starts processing live traffic.
 *
 * SOLID: Single Responsibility - HTTP retrieval only; delivery/dispatch is
 * handled by EventDeliveryService.
 */
public class ReplayClient {

    private static final Logger log = LoggerFactory.getLogger(ReplayClient.class);

    private final RestTemplate restTemplate;
    private final EventBusProperties properties;

    public ReplayClient(RestTemplate restTemplate, EventBusProperties properties) {
        this.restTemplate = restTemplate;
        this.properties = properties;
    }

    public List<EventEnvelope> fetchMissed(String eventType, long sinceOffset) {
        String url = UriComponentsBuilder.fromHttpUrl(properties.getBrokerRestUrl() + "/api/events/replay")
                .queryParam("eventType", eventType)
                .queryParam("sinceOffset", sinceOffset)
                .toUriString();

        log.info("Requesting replay for event type [{}] since offset {}", eventType, sinceOffset);

        ResponseEntity<EventEnvelope[]> response = restTemplate.exchange(url, HttpMethod.GET, null, EventEnvelope[].class);
        EventEnvelope[] body = response.getBody();
        List<EventEnvelope> missed = body == null ? List.of() : List.of(body);

        log.info("Replay returned {} missed event(s) for [{}]", missed.size(), eventType);
        return missed;
    }
}
