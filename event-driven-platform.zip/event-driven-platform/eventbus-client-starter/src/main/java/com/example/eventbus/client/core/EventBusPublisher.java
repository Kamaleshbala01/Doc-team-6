package com.example.eventbus.client.core;

import com.example.events.common.EventEnvelope;
import com.example.eventbus.client.config.EventBusProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

/**
 * What a PRODUCER microservice injects to publish events - the cross-process
 * equivalent of the in-JVM EventPublisher interface.
 *
 * WHY REST (not STOMP) FOR PUBLISHING:
 *   Publishing needs a synchronous acknowledgement that the broker actually
 *   persisted the event (durability guarantee) before the producer moves on.
 *   A plain HTTP POST with a 200 response gives us that ack trivially. STOMP
 *   SEND frames are fire-and-forget by design, which is the wrong tool for
 *   "did this get durably stored". The broker then takes care of broadcasting
 *   over STOMP to whoever is listening.
 *
 * SOLID: Single Responsibility - serialize payload, POST it, done. Contains
 * no knowledge of who (if anyone) is subscribed.
 */
public class EventBusPublisher {

    private static final Logger log = LoggerFactory.getLogger(EventBusPublisher.class);

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    private final EventBusProperties properties;

    public EventBusPublisher(RestTemplate restTemplate, ObjectMapper objectMapper, EventBusProperties properties) {
        this.restTemplate = restTemplate;
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    /**
     * Serializes the payload, wraps it in an EventEnvelope, and POSTs it to
     * the broker's /api/events endpoint. Blocks until the broker
     * acknowledges durable persistence.
     */
    public void publish(String eventType, Object payload) {
        try {
            String payloadJson = objectMapper.writeValueAsString(payload);
            EventEnvelope envelope = EventEnvelope.newEvent(eventType, properties.getServiceName(), payloadJson);

            log.info("Publishing event [{}] (eventId={}) to broker at {}",
                    eventType, envelope.getEventId(), properties.getBrokerRestUrl());

            EventEnvelope persisted = restTemplate.postForObject(
                    properties.getBrokerRestUrl() + "/api/events", envelope, EventEnvelope.class);

            log.info("Broker acknowledged event [{}] with offset={}", eventType,
                    persisted != null ? persisted.getOffset() : "unknown");
        } catch (Exception ex) {
            log.error("Failed to publish event [{}]: {}", eventType, ex.getMessage(), ex);
            throw new IllegalStateException("Failed to publish event " + eventType, ex);
        }
    }
}
