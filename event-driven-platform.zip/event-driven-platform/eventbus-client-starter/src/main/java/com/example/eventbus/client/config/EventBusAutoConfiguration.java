package com.example.eventbus.client.config;

import com.example.eventbus.client.core.EventBusConnectionManager;
import com.example.eventbus.client.core.EventBusPublisher;
import com.example.eventbus.client.core.EventDeliveryService;
import com.example.eventbus.client.core.EventHandler;
import com.example.eventbus.client.offset.ConsumerOffset;
import com.example.eventbus.client.offset.ConsumerOffsetService;
import com.example.eventbus.client.replay.ReplayClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;

/**
 * THE AUTO-WIRING ENTRY POINT for any microservice that adds
 * eventbus-client-starter as a dependency.
 *
 * WHY IT EXISTS:
 *   This is what makes the SDK "drop-in": a consuming service needs only
 *   (a) this jar on the classpath, (b) `eventbus.*` properties in its
 *   application.yml, and (c) zero or more @Component beans implementing
 *   EventHandler<T>. Everything else - the publisher, the offset repository,
 *   the replay client, the STOMP connection manager - is registered here
 *   automatically, discovered via Spring Boot's auto-configuration mechanism
 *   (see META-INF/spring/...AutoConfiguration.imports).
 *
 * SOLID:
 *   Dependency Inversion Principle - every consuming service depends only on
 *   the abstractions (EventHandler, EventBusPublisher), never on how the
 *   transport/offset machinery is implemented underneath.
 */
@AutoConfiguration
@EnableConfigurationProperties(EventBusProperties.class)
@EnableJpaRepositories(basePackageClasses = ConsumerOffsetService.class)
@EntityScan(basePackageClasses = ConsumerOffset.class)
public class EventBusAutoConfiguration {

    @Bean
    public RestTemplate eventBusRestTemplate() {
        return new RestTemplate();
    }

    @Bean
    public EventBusPublisher eventBusPublisher(RestTemplate eventBusRestTemplate,
                                                ObjectMapper objectMapper,
                                                EventBusProperties properties) {
        return new EventBusPublisher(eventBusRestTemplate, objectMapper, properties);
    }

    @Bean
    public ReplayClient replayClient(RestTemplate eventBusRestTemplate, EventBusProperties properties) {
        return new ReplayClient(eventBusRestTemplate, properties);
    }

    @Bean
    public EventDeliveryService eventDeliveryService(List<EventHandler<?>> handlers,
                                                       ObjectMapper objectMapper,
                                                       ConsumerOffsetService offsetService) {
        // If no EventHandler beans exist in this service (e.g. a pure
        // producer like tournament-service), this resolves to an empty list
        // and the connection manager simply never connects to the broker.
        return new EventDeliveryService(
                handlers != null ? handlers : Collections.emptyList(), objectMapper, offsetService);
    }

    @Bean
    public EventBusConnectionManager eventBusConnectionManager(EventBusProperties properties,
                                                                 EventDeliveryService deliveryService,
                                                                 ReplayClient replayClient,
                                                                 ConsumerOffsetService offsetService) {
        return new EventBusConnectionManager(properties, deliveryService, replayClient, offsetService);
    }
}
