package com.example.eventbus.client.core;

import com.example.events.common.EventEnvelope;
import com.example.eventbus.client.config.EventBusProperties;
import com.example.eventbus.client.offset.ConsumerOffsetService;
import com.example.eventbus.client.replay.ReplayClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.*;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

/**
 * THE CLIENT-SIDE HEART OF THE SDK.
 *
 * Runs the full connection lifecycle for a consuming microservice:
 *   1. On ApplicationReadyEvent, for every locally registered EventHandler,
 *      call the broker's replay endpoint to catch up on anything missed
 *      while this service was down.
 *   2. Open a STOMP session over plain WebSocket to the broker.
 *   3. Subscribe to /topic/events/{eventType} for every registered handler.
 *   4. On disconnect (broker restart, network blip), automatically retry
 *      the connection after a delay, replaying again first (to close any
 *      gap that opened during the outage) before resubscribing.
 *
 * WHY REPLAY-THEN-SUBSCRIBE, EVERY TIME (not just at startup):
 *   A dropped connection is functionally identical to being offline - events
 *   published during the gap are only in Postgres, not something we saw
 *   live. Re-running catch-up on every (re)connect closes that gap
 *   deterministically instead of hoping nothing was missed.
 *
 * SOLID:
 *   Single Responsibility - transport lifecycle only. Actual payload
 *   dispatch is delegated to EventDeliveryService.
 */
public class EventBusConnectionManager implements ApplicationListener<ApplicationReadyEvent> {

    private static final Logger log = LoggerFactory.getLogger(EventBusConnectionManager.class);

    private final EventBusProperties properties;
    private final EventDeliveryService deliveryService;
    private final ReplayClient replayClient;
    private final ConsumerOffsetService offsetService;
    private final WebSocketStompClient stompClient;
    private final ThreadPoolTaskScheduler taskScheduler;

    public EventBusConnectionManager(EventBusProperties properties,
                                      EventDeliveryService deliveryService,
                                      ReplayClient replayClient,
                                      ConsumerOffsetService offsetService) {
        this.properties = properties;
        this.deliveryService = deliveryService;
        this.replayClient = replayClient;
        this.offsetService = offsetService;

        this.taskScheduler = new ThreadPoolTaskScheduler();
        this.taskScheduler.setPoolSize(2);
        this.taskScheduler.setThreadNamePrefix("eventbus-stomp-");
        this.taskScheduler.initialize();

        this.stompClient = new WebSocketStompClient(new StandardWebSocketClient());
        this.stompClient.setMessageConverter(new MappingJackson2MessageConverter());
        this.stompClient.setTaskScheduler(taskScheduler);
    }

    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        Set<String> eventTypes = deliveryService.registeredEventTypes();
        if (eventTypes.isEmpty()) {
            log.info("No EventHandler beans registered - this service will not connect to the broker.");
            return;
        }
        connectWithCatchUp();
    }

    private void connectWithCatchUp() {
        replayMissedEvents();
        connectStomp();
    }

    private void replayMissedEvents() {
        for (String eventType : deliveryService.registeredEventTypes()) {
            try {
                long lastOffset = offsetService.getLastProcessedOffset(eventType);
                List<EventEnvelope> missed = replayClient.fetchMissed(eventType, lastOffset);
                missed.forEach(deliveryService::deliver);
            } catch (Exception ex) {
                log.error("Catch-up replay failed for [{}]: {}", eventType, ex.getMessage(), ex);
            }
        }
    }

    private void connectStomp() {
        StompSessionHandler handler = new StompSessionHandlerAdapter() {
            @Override
            public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
                log.info("Connected to Event Broker at {} as service [{}]",
                        properties.getBrokerWsUrl(), properties.getServiceName());
                for (String eventType : deliveryService.registeredEventTypes()) {
                    session.subscribe("/topic/events/" + eventType, new StompFrameHandler() {
                        @Override
                        public Type getPayloadType(StompHeaders headers) {
                            return EventEnvelope.class;
                        }

                        @Override
                        public void handleFrame(StompHeaders headers, Object payload) {
                            deliveryService.deliver((EventEnvelope) payload);
                        }
                    });
                    log.info("Subscribed live to /topic/events/{}", eventType);
                }
            }

            @Override
            public void handleTransportError(StompSession session, Throwable exception) {
                log.warn("STOMP transport error, will retry connection in {}ms: {}",
                        properties.getReconnectDelayMs(), exception.getMessage());
                scheduleReconnect();
            }

            @Override
            public void handleException(StompSession session, StompCommand command, StompHeaders headers,
                                         byte[] payload, Throwable exception) {
                log.error("STOMP frame handling error: {}", exception.getMessage(), exception);
            }
        };

        CompletableFuture<StompSession> future =
                stompClient.connectAsync(properties.getBrokerWsUrl(), handler);

        future.exceptionally(ex -> {
            log.warn("Could not connect to Event Broker, will retry in {}ms: {}",
                    properties.getReconnectDelayMs(), ex.getMessage());
            scheduleReconnect();
            return null;
        });
    }

    private void scheduleReconnect() {
        taskScheduler.schedule(this::connectWithCatchUp,
                new java.util.Date(System.currentTimeMillis() + properties.getReconnectDelayMs()));
    }
}
