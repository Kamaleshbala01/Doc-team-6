package com.example.eventbus.client.core;

/**
 * Implemented by any @Component in a consuming microservice that wants to
 * react to a given event type. This is the cross-process equivalent of the
 * in-JVM EventSubscriber from the monolith version - same idea, just
 * operating on a deserialized payload instead of a Java object passed by
 * reference.
 *
 * A service registers interest simply by declaring a Spring bean that
 * implements this interface - EventBusAutoConfiguration discovers all of
 * them and wires up STOMP subscriptions + replay automatically. The
 * producer service never needs to know this class exists.
 *
 * @param <T> the payload type this handler consumes (from events-common)
 */
public interface EventHandler<T> {

    /** The event type name this handler wants to receive (see EventTypes). */
    String eventType();

    /** The payload class to deserialize incoming JSON into. */
    Class<T> payloadType();

    /**
     * Business logic to run when the event arrives - whether live (via
     * STOMP) or during replay (catching up after being offline). Should be
     * idempotent where possible, since replay + live delivery can overlap
     * at the boundary.
     */
    void handle(T payload);
}
