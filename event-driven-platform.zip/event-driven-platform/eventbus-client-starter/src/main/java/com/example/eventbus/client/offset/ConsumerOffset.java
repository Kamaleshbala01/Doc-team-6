package com.example.eventbus.client.offset;

import jakarta.persistence.*;

/**
 * Tracks, per (eventType), the highest broker offset this service has
 * successfully processed. Persisted in THIS service's own database - not
 * the broker's - exactly like a Kafka consumer group's committed offset
 * lives in Kafka's __consumer_offsets topic, but scoped per consumer group.
 *
 * WHY IT EXISTS:
 *   Without this, a service restarting after downtime has no way to know
 *   what it already processed vs. what it missed. This table is what makes
 *   replay possible: on startup we ask the broker for "everything after
 *   offset X" instead of replaying the entire event history every time.
 */
@Entity
@Table(name = "consumer_offset", uniqueConstraints = @UniqueConstraint(columnNames = "event_type"))
public class ConsumerOffset {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "event_type", nullable = false)
    private String eventType;

    @Column(name = "last_processed_offset", nullable = false)
    private long lastProcessedOffset;

    protected ConsumerOffset() {
        // JPA
    }

    public ConsumerOffset(String eventType, long lastProcessedOffset) {
        this.eventType = eventType;
        this.lastProcessedOffset = lastProcessedOffset;
    }

    public Long getId() { return id; }
    public String getEventType() { return eventType; }
    public long getLastProcessedOffset() { return lastProcessedOffset; }
    public void setLastProcessedOffset(long lastProcessedOffset) { this.lastProcessedOffset = lastProcessedOffset; }
}
