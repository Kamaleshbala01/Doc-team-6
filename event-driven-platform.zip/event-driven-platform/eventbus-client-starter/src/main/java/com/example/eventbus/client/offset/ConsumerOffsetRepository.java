package com.example.eventbus.client.offset;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ConsumerOffsetRepository extends JpaRepository<ConsumerOffset, Long> {
    Optional<ConsumerOffset> findByEventType(String eventType);
}
