package com.example.eventbus.client.offset;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Small transactional façade over ConsumerOffsetRepository so callers never
 * touch the entity/repository directly. Guarantees the "read offset, process
 * event, commit offset" sequence stays consistent.
 *
 * SOLID: Single Responsibility - offset read/commit only.
 */
@Service
public class ConsumerOffsetService {

    private final ConsumerOffsetRepository repository;

    public ConsumerOffsetService(ConsumerOffsetRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public long getLastProcessedOffset(String eventType) {
        return repository.findByEventType(eventType)
                .map(ConsumerOffset::getLastProcessedOffset)
                .orElse(0L);
    }

    @Transactional
    public void commit(String eventType, long offset) {
        ConsumerOffset record = repository.findByEventType(eventType)
                .orElseGet(() -> new ConsumerOffset(eventType, 0L));
        if (offset > record.getLastProcessedOffset()) {
            record.setLastProcessedOffset(offset);
            repository.save(record);
        }
    }
}
