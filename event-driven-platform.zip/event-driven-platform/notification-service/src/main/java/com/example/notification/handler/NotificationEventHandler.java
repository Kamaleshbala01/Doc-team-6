package com.example.notification.handler;

import com.example.events.common.EventTypes;
import com.example.events.common.payload.TournamentRegistrationClosedPayload;
import com.example.eventbus.client.core.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Independent subscriber #2 to the SAME event match-service also consumes -
 * running in its own process, with its own offset tracking, its own replay
 * cadence. Neither subscriber knows the other exists, exactly like two
 * independent Kafka consumer groups reading the same topic.
 */
@Component
public class NotificationEventHandler implements EventHandler<TournamentRegistrationClosedPayload> {

    private static final Logger log = LoggerFactory.getLogger(NotificationEventHandler.class);

    private final Map<String, List<String>> notificationsByUser = new ConcurrentHashMap<>();

    @Override
    public String eventType() {
        return EventTypes.TOURNAMENT_REGISTRATION_CLOSED;
    }

    @Override
    public Class<TournamentRegistrationClosedPayload> payloadType() {
        return TournamentRegistrationClosedPayload.class;
    }

    @Override
    public void handle(TournamentRegistrationClosedPayload payload) {
        log.info("[notification-service] Notifying {} team(s) for tournament [{}]",
                payload.getRegisteredTeamIds().size(), payload.getTournamentId());

        String message = "Registration closed for '" + payload.getTournamentName() + "'. Matches are being generated.";
        for (String teamId : payload.getRegisteredTeamIds()) {
            notificationsByUser
                    .computeIfAbsent(teamId, k -> new CopyOnWriteArrayList<>())
                    .add(message);
        }
    }

    public List<String> getNotifications(String userId) {
        return notificationsByUser.getOrDefault(userId, List.of());
    }
}
