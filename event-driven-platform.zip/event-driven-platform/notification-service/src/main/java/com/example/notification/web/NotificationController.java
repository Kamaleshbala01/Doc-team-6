package com.example.notification.web;

import com.example.notification.handler.NotificationEventHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class NotificationController {

    private final NotificationEventHandler handler;

    public NotificationController(NotificationEventHandler handler) {
        this.handler = handler;
    }

    @GetMapping("/api/notifications/{userId}")
    public List<String> getNotifications(@PathVariable String userId) {
        return handler.getNotifications(userId);
    }
}
