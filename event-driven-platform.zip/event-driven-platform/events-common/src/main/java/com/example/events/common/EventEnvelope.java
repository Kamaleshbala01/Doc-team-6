package com.example.events.common;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.UUID;

/**
 * The wire format for every event that crosses the broker.
 *
 * WHY IT EXISTS:
 *   This is the cross-process equivalent of the in-JVM `Event` interface
 *   from the single-app version. Because services are now separate
 *   processes/JARs, we cannot pass a Java object by reference - everything
 *   must be serialized. EventEnvelope is that serialization contract:
 *   metadata (id, type, topic, source, timestamp, a numeric offset assigned
 *   by the broker) plus a JSON-serialized payload string.
 *
 *   The payload is kept as a raw JSON string (rather than a generic Object)
 *   so the broker never needs to know about payload classes like
 *   TournamentRegistrationClosedPayload - it just stores and forwards bytes,
 *   exactly like a Kafka broker does with an opaque byte[] value. Only the
 *   producer and consumer, who share this events-common jar, know how to
 *   serialize/deserialize the payload type for a given eventType.
 */
public class EventEnvelope {

    private Long offset;              // assigned by the broker (like a Kafka offset), null until persisted
    private final String eventId;     // globally unique id, assigned by the producer
    private final String eventType;   // e.g. "TournamentRegistrationClosedEvent" - used for topic routing
    private final String sourceService; // which microservice published this
    private final Instant timestamp;
    private final String payloadJson; // JSON-serialized payload

    @JsonCreator
    public EventEnvelope(
            @JsonProperty("offset") Long offset,
            @JsonProperty("eventId") String eventId,
            @JsonProperty("eventType") String eventType,
            @JsonProperty("sourceService") String sourceService,
            @JsonProperty("timestamp") Instant timestamp,
            @JsonProperty("payloadJson") String payloadJson) {
        this.offset = offset;
        this.eventId = eventId;
        this.eventType = eventType;
        this.sourceService = sourceService;
        this.timestamp = timestamp;
        this.payloadJson = payloadJson;
    }

    /** Convenience factory used by producers - offset is assigned later, by the broker. */
    public static EventEnvelope newEvent(String eventType, String sourceService, String payloadJson) {
        return new EventEnvelope(null, UUID.randomUUID().toString(), eventType, sourceService, Instant.now(), payloadJson);
    }

    public Long getOffset() { return offset; }
    public void setOffset(Long offset) { this.offset = offset; }
    public String getEventId() { return eventId; }
    public String getEventType() { return eventType; }
    public String getSourceService() { return sourceService; }
    public Instant getTimestamp() { return timestamp; }
    public String getPayloadJson() { return payloadJson; }

    @Override
    public String toString() {
        return "EventEnvelope{offset=" + offset + ", eventId='" + eventId + "', eventType='" + eventType +
                "', sourceService='" + sourceService + "', timestamp=" + timestamp + "}";
    }
}
