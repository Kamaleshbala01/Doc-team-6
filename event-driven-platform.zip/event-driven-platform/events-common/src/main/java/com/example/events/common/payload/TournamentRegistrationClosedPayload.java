package com.example.events.common.payload;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Shared payload contract for {@code EventTypes.TOURNAMENT_REGISTRATION_CLOSED}.
 * Both the producer (tournament-service) and every consumer (match-service,
 * notification-service, ...) depend on this class from events-common, so
 * they always agree on the event's shape - this is our lightweight stand-in
 * for a Kafka Avro/Protobuf schema.
 */
public class TournamentRegistrationClosedPayload {

    private final String tournamentId;
    private final String tournamentName;
    private final List<String> registeredTeamIds;

    @JsonCreator
    public TournamentRegistrationClosedPayload(
            @JsonProperty("tournamentId") String tournamentId,
            @JsonProperty("tournamentName") String tournamentName,
            @JsonProperty("registeredTeamIds") List<String> registeredTeamIds) {
        this.tournamentId = tournamentId;
        this.tournamentName = tournamentName;
        this.registeredTeamIds = registeredTeamIds;
    }

    public String getTournamentId() { return tournamentId; }
    public String getTournamentName() { return tournamentName; }
    public List<String> getRegisteredTeamIds() { return registeredTeamIds; }
}
