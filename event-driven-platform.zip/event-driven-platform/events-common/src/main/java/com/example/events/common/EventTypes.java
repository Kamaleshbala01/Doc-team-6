package com.example.events.common;

/**
 * Shared registry of event type names. Both producers and consumers
 * reference these constants instead of hardcoding strings, the same way
 * Kafka topic names are usually centralized in a shared constants class or
 * schema registry subject name.
 */
public final class EventTypes {
    private EventTypes() {}

    public static final String TOURNAMENT_REGISTRATION_CLOSED = "TournamentRegistrationClosedEvent";
}
