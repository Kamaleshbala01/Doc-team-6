# Cross-Service Event Bus on Spring Boot + WebSocket (No Kafka/RabbitMQ/Redis)

A Kafka-style publish-subscribe system where **producers and consumers are
separate microservices/JVMs**, built only with Spring Boot 3.x, Java 17,
Spring WebSocket (STOMP), Spring Data JPA and PostgreSQL. No external broker.

This is the evolution of the earlier single-JVM "in-memory Event Bus" demo:
that version worked because publisher and subscribers were beans in one
Spring context. Here they are **separate deployables** that only ever talk
to a central **Event Broker** service.

---

## 1. Architecture at a glance

```
                     ┌─────────────────────┐
   POST /api/events  │                      │  STOMP broadcast
  ───────────────────▶     event-broker     │────────────────────▶
                     │  (Postgres event_store)│    /topic/events/{type}
                     └─────────────────────┘
                              ▲     ▲
                 GET /replay  │     │  STOMP subscribe
              ┌───────────────┘     └───────────────┐
              │                                      │
     ┌────────────────┐                    ┌──────────────────┐
     │  match-service   │                    │ notification-service│
     │ (own Postgres:   │                    │ (own Postgres:     │
     │  consumer_offset)│                    │  consumer_offset)   │
     └────────────────┘                    └──────────────────┘

     ┌───────────────────┐
     │ tournament-service  │  ── publishes only, no subscriptions
     │ (H2, no offsets needed) │
     └───────────────────┘
```

Every service that needs to publish or subscribe includes one shared
dependency, **`eventbus-client-starter`**, which is the whole SDK: a
publisher, a STOMP client with auto-reconnect, and durable offset tracking
for replay. Nobody hand-wires WebSocket code in a business service.

---

## 2. Modules

```
event-driven-platform/                 (Maven reactor, packaging=pom)
├── events-common/                     shared event contracts (the "schema registry")
│   └── EventEnvelope, EventTypes, payload/TournamentRegistrationClosedPayload
│
├── eventbus-client-starter/           the SDK every microservice depends on
│   ├── core/
│   │   ├── EventHandler<T>            interface consumers implement
│   │   ├── EventBusPublisher          REST client producers use to publish
│   │   ├── EventDeliveryService       dispatch + offset commit (shared by live + replay)
│   │   └── EventBusConnectionManager  STOMP client lifecycle: replay -> subscribe -> reconnect
│   ├── offset/
│   │   ├── ConsumerOffset             JPA entity - last processed offset per event type
│   │   ├── ConsumerOffsetRepository
│   │   └── ConsumerOffsetService
│   ├── replay/
│   │   └── ReplayClient               calls the broker's GET /api/events/replay
│   └── config/
│       ├── EventBusProperties         eventbus.* application.yml bindings
│       └── EventBusAutoConfiguration  wires all of the above automatically
│
├── event-broker/                      the central hub (its own deployable, port 9000)
│   ├── store/  EventStoreRecord, EventStoreRepository, EventStoreMapper   (Postgres log)
│   ├── web/    EventBrokerService, EventPublishController, EventReplayController
│   ├── config/ WebSocketConfig        /ws-broker (services) + /ws (SockJS, browsers)
│   └── exception/ BrokerExceptionHandler
│
├── tournament-service/                PRODUCER example (port 8081)
│   └── TournamentService publishes via EventBusPublisher; no EventHandler beans
│
├── match-service/                     CONSUMER example #1 (port 8082)
│   └── MatchEventHandler implements EventHandler<TournamentRegistrationClosedPayload>
│
└── notification-service/              CONSUMER example #2 (port 8083)
    └── NotificationEventHandler implements EventHandler<TournamentRegistrationClosedPayload>
```

---

## 3. Mermaid Diagrams

### 3.1 Publish Event Flow (producer -> broker)

```mermaid
sequenceDiagram
    participant Client
    participant TC as TournamentController
    participant TS as TournamentService
    participant Pub as EventBusPublisher (SDK)
    participant Broker as event-broker (/api/events)
    participant DB as Postgres (event_store)

    Client->>TC: POST /api/tournaments/t1/close-registration
    TC->>TS: closeRegistration("t1")
    TS->>Pub: publish(TOURNAMENT_REGISTRATION_CLOSED, payload)
    Pub->>Broker: HTTP POST EventEnvelope (JSON)
    Broker->>DB: INSERT INTO event_store
    DB-->>Broker: generated offset (id)
    Broker-->>Pub: 200 OK, EventEnvelope with offset
    Pub-->>TS: return
    Note over TS,Pub: tournament-service never talks to match-service<br/>or notification-service directly.
```

### 3.2 Subscribe Event Flow (consumer startup: replay then live)

```mermaid
sequenceDiagram
    participant App as match-service (startup)
    participant Mgr as EventBusConnectionManager (SDK)
    participant Offset as ConsumerOffsetService (local Postgres)
    participant Replay as ReplayClient (SDK)
    participant Broker as event-broker
    participant Handler as MatchEventHandler

    App->>Mgr: ApplicationReadyEvent
    Mgr->>Offset: getLastProcessedOffset(TOURNAMENT_REGISTRATION_CLOSED)
    Offset-->>Mgr: e.g. offset=12
    Mgr->>Replay: fetchMissed(eventType, sinceOffset=12)
    Replay->>Broker: GET /api/events/replay?eventType=...&sinceOffset=12
    Broker-->>Replay: [events with offset 13, 14, 15]
    loop each missed event
        Mgr->>Handler: handle(payload)
        Mgr->>Offset: commit(eventType, offset)
    end
    Mgr->>Broker: CONNECT /ws-broker (STOMP)
    Mgr->>Broker: SUBSCRIBE /topic/events/TOURNAMENT_REGISTRATION_CLOSED
    Note over Mgr,Broker: Now live - matches tournament-service's<br/>publish calls in real time.
```

### 3.3 Internal Broker Flow (persist-then-broadcast + multi-subscriber fan-out)

```mermaid
flowchart TD
    A[EventPublishController<br/>POST /api/events] --> B[EventBrokerService.publish]
    B --> C[EventStoreRepository.save<br/>Postgres event_store]
    C -->|offset assigned| D[SimpMessagingTemplate.convertAndSend]
    D --> E["/topic/events/{eventType}"]
    E --> F1[match-service STOMP session]
    E --> F2[notification-service STOMP session]
    E --> F3[any future subscriber - zero broker changes needed]
    F1 --> G1[MatchEventHandler.handle]
    F2 --> G2[NotificationEventHandler.handle]
    G1 --> H1[match-service commits its own offset]
    G2 --> H2[notification-service commits its own offset]
```

### 3.4 Reconnect / Catch-Up Flow (durability guarantee)

```mermaid
sequenceDiagram
    participant Match as match-service
    participant Broker as event-broker
    participant DB as Postgres (event_store)

    Note over Match,Broker: match-service goes down (deploy, crash, network blip)
    Broker->>DB: 3 more events published while match-service is offline
    Note over Match: match-service restarts
    Match->>Broker: GET /api/events/replay?eventType=...&sinceOffset=<last committed>
    Broker->>DB: query offset > sinceOffset
    DB-->>Broker: 3 missed events, in order
    Broker-->>Match: [event13, event14, event15]
    Match->>Match: process each, commit offset after each
    Match->>Broker: STOMP CONNECT + SUBSCRIBE (resume live)
```

---

## 4. Class-by-Class Explanation

| Class | Why it exists | Responsibility | SOLID |
|---|---|---|---|
| `EventEnvelope` | Wire format between all processes | id/type/source/timestamp/offset + raw JSON payload | SRP, ISP |
| `EventTypes` | Central topic-name registry | Shared constants | SRP |
| `TournamentRegistrationClosedPayload` | Shared schema (like an Avro contract) | Typed payload both producer and consumers compile against | SRP |
| `EventHandler<T>` | What a consumer implements | `eventType()`, `payloadType()`, `handle()` | OCP, DIP |
| `EventBusPublisher` | What a producer injects | Serialize + HTTP POST to broker, block for durability ack | SRP |
| `EventDeliveryService` | Single dispatch chokepoint | Deserialize, invoke matching handler, commit offset, isolate handler exceptions | SRP, OCP |
| `EventBusConnectionManager` | The STOMP client lifecycle | Replay-then-subscribe on startup and on every reconnect | SRP |
| `ConsumerOffset(+Repository/Service)` | Durable per-service progress marker | Track/commit last processed offset per event type, in THIS service's own DB | SRP |
| `ReplayClient` | Catch-up HTTP client | Calls broker's replay endpoint | SRP |
| `EventBusAutoConfiguration` | Zero-boilerplate wiring | Registers every SDK bean when the starter jar is on the classpath | DIP |
| `EventStoreRecord`/`Repository`/`Mapper` | Broker's durable log | Persist every event; offset = row id; power replay queries | SRP |
| `EventBrokerService` | Broker's core logic | Persist-then-broadcast, in that order (durability guarantee) | SRP, OCP |
| `EventPublishController` / `EventReplayController` | Broker's public API | Write path / read-catch-up path | SRP |
| `WebSocketConfig` (broker) | Transport wiring | `/ws-broker` for services, `/ws` (SockJS) reserved for browser dashboards | SRP |
| `TournamentService` | Producer's business logic | Own tournament state, publish via `EventBusPublisher` | SRP, DIP |
| `MatchEventHandler` / `NotificationEventHandler` | Consumer business logic | React to the same event independently, in separate processes | SRP, LSP |

---

## 5. Running it

1. Create the Postgres databases: `event_broker_db`, `match_service_db`,
   `notification_service_db` (or adjust each `application.yml`).
   `tournament-service` uses an in-memory H2 DB since it has no offsets to
   persist (pure publisher).
2. From the reactor root: `mvn clean install` (installs `events-common` and
   `eventbus-client-starter` into your local `.m2` so the other modules can
   depend on them).
3. Start in this order: `event-broker` (9000) → `match-service` (8082) →
   `notification-service` (8083) → `tournament-service` (8081).
4. Create a tournament and close registration:
   ```bash
   curl -X POST localhost:8081/api/tournaments \
     -H "Content-Type: application/json" \
     -d '{"id":"t1","name":"Summer Cup","teamIds":["teamA","teamB","teamC","teamD"]}'

   curl -X POST localhost:8081/api/tournaments/t1/close-registration
   ```
5. Check both consumers reacted independently:
   ```bash
   curl localhost:8082/api/matches/t1
   curl localhost:8083/api/notifications/teamA
   ```
6. **Test durability:** stop `match-service`, close registration on another
   tournament, restart `match-service` — watch its logs replay the missed
   event on startup before it reconnects live.

---

## 6. Custom Cross-Service Event Bus vs. Apache Kafka

**Similarities**
- Central broker persists messages and fans them out to independent consumers.
- Consumers track their own offset and can replay from where they left off.
- Producers and consumers are fully decoupled — neither knows the other's identity or count.
- New consumers can subscribe to an existing event type with zero producer changes.

**Differences**

| Aspect | This system | Kafka |
|---|---|---|
| Persistence model | Single Postgres table per broker instance | Distributed, partitioned, segment-based commit log |
| Broker scaling | One broker process (vertical scaling only) | Horizontally scalable cluster of brokers |
| Ordering | Global order per event type (single table) | Per-partition order only; cross-partition order is not guaranteed |
| Delivery semantics | At-least-once (replay can redeliver if a crash happens between `handle()` and offset commit) | Configurable: at-least-once, at-most-once, exactly-once |
| Consumer groups | One committed offset per (service, event type) — no built-in group rebalancing | Native consumer groups with partition rebalancing across multiple instances |
| Transport | WebSocket/STOMP (long-lived TCP, text/binary frames) | Custom binary TCP protocol, purpose-built for throughput |
| Retention | Every event kept forever unless you add cleanup (simple to add) | Configurable retention/compaction policies out of the box |
| Schema management | Shared Java jar (`events-common`) | Often paired with a schema registry (Avro/Protobuf) supporting cross-language evolution |
| Operational cost | Just Postgres + your own JVMs | Requires running/operating a Kafka cluster (or a managed service) |

**Advantages of this approach**
- Zero new infrastructure beyond Postgres, which most teams already run.
- Simple to reason about and debug — it's just HTTP + STOMP + SQL.
- Good fit when you have a handful of services and moderate event volume.

**Limitations**
- Single broker instance is a scaling and availability bottleneck — no
  built-in leader election, replication, or partitioning.
- No consumer-group-style parallelism: if you run two instances of
  match-service, both would currently process every event (no partition
  assignment), unlike Kafka where they'd split the load automatically.
- At-least-once only; achieving exactly-once requires the consumer's
  `handle()` logic to be idempotent (same as Kafka in practice, but Kafka at
  least offers transactional exactly-once as an option).
- No cross-datacenter replication or tiered storage.

**When to use this custom system**
- A small-to-mid number of internal microservices in one deployment
  environment/datacenter, moderate throughput, and a team that wants to
  avoid operating Kafka.
- Cases where "Postgres is already our source of truth" and adding a second
  storage system (Kafka) is organizationally costly.

**When Kafka is the better choice**
- High throughput or many consumer instances needing automatic load-balanced
  partition assignment.
- Strict ordering guarantees at scale, exactly-once processing, or
  multi-datacenter replication.
- A polyglot organization needing a schema registry and clients in many
  languages beyond Java.
- Long-term event retention for stream processing / event sourcing / analytics.
