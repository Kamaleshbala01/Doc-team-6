package com.example.match.handler;

import com.example.events.common.EventTypes;
import com.example.events.common.payload.TournamentRegistrationClosedPayload;
import com.example.eventbus.client.core.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * THE ONLY CLASS match-service needed to write to become a subscriber.
 *
 * Because this is a @Component implementing EventHandler<T>,
 * EventBusAutoConfiguration (from eventbus-client-starter) discovers it
 * automatically, subscribes to /topic/events/TournamentRegistrationClosedEvent
 * on the broker, replays anything missed on startup, and calls handle()
 * for every event - live or replayed - going forward. tournament-service
 * (the publisher) has zero knowledge this class, or this entire
 * microservice, exists.
 */
@Component
public class MatchEventHandler implements EventHandler<TournamentRegistrationClosedPayload> {

    private static final Logger log = LoggerFactory.getLogger(MatchEventHandler.class);

    private final Map<String, List<Map<String, String>>> bracketsByTournament = new ConcurrentHashMap<>();

    @Override
    public String eventType() {
        return EventTypes.TOURNAMENT_REGISTRATION_CLOSED;
    }

    @Override
    public Class<TournamentRegistrationClosedPayload> payloadType() {
        return TournamentRegistrationClosedPayload.class;
    }

    @Override
    public void handle(TournamentRegistrationClosedPayload payload) {
        log.info("[match-service] Generating bracket for tournament [{}]", payload.getTournamentId());

        List<Map<String, String>> matches = generateBracket(payload.getRegisteredTeamIds());
        bracketsByTournament.put(payload.getTournamentId(), matches);

        log.info("[match-service] Generated {} match(es) for tournament [{}]",
                matches.size(), payload.getTournamentId());
    }

    public List<Map<String, String>> getBracket(String tournamentId) {
        return bracketsByTournament.getOrDefault(tournamentId, List.of());
    }

    private List<Map<String, String>> generateBracket(List<String> teamIds) {
        List<Map<String, String>> matches = new ArrayList<>();
        for (int i = 0; i < teamIds.size() - 1; i += 2) {
            matches.add(Map.of(
                    "matchId", "match-" + (i / 2 + 1),
                    "teamA", teamIds.get(i),
                    "teamB", teamIds.get(i + 1)));
        }
        if (teamIds.size() % 2 != 0) {
            matches.add(Map.of("matchId", "match-bye", "teamA", teamIds.get(teamIds.size() - 1), "teamB", "BYE"));
        }
        return matches;
    }
}
