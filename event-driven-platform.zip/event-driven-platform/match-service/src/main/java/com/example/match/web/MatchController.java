package com.example.match.web;

import com.example.match.handler.MatchEventHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class MatchController {

    private final MatchEventHandler matchEventHandler;

    public MatchController(MatchEventHandler matchEventHandler) {
        this.matchEventHandler = matchEventHandler;
    }

    @GetMapping("/api/matches/{tournamentId}")
    public List<Map<String, String>> getBracket(@PathVariable String tournamentId) {
        return matchEventHandler.getBracket(tournamentId);
    }
}
