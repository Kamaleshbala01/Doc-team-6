package com.esports.platform.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Entity mapping for the "TournamentPrize" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "TournamentPrize")
public class TournamentPrize {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "tournamentId")
    private Integer tournamentId;

    @Column(name = "prizeCategoryId")
    private Integer prizeCategoryId;

    @Column(name = "positionName")
    private String positionName;

    @Column(name = "rankOrder")
    private Integer rankOrder;

    @Column(name = "prizeAmount")
    private BigDecimal prizeAmount;

    @Column(name = "prizeDescription", columnDefinition = "TEXT")
    private String prizeDescription;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

    public TournamentPrize() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTournamentId() {
        return tournamentId;
    }

    public void setTournamentId(Integer tournamentId) {
        this.tournamentId = tournamentId;
    }

    public Integer getPrizeCategoryId() {
        return prizeCategoryId;
    }

    public void setPrizeCategoryId(Integer prizeCategoryId) {
        this.prizeCategoryId = prizeCategoryId;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public Integer getRankOrder() {
        return rankOrder;
    }

    public void setRankOrder(Integer rankOrder) {
        this.rankOrder = rankOrder;
    }

    public BigDecimal getPrizeAmount() {
        return prizeAmount;
    }

    public void setPrizeAmount(BigDecimal prizeAmount) {
        this.prizeAmount = prizeAmount;
    }

    public String getPrizeDescription() {
        return prizeDescription;
    }

    public void setPrizeDescription(String prizeDescription) {
        this.prizeDescription = prizeDescription;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TournamentPrize)) return false;
        TournamentPrize that = (TournamentPrize) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "TournamentPrize{" +
                "id=" + id +
                '}';
    }
}