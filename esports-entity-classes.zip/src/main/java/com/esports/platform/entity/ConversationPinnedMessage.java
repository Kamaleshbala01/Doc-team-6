package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity mapping for the "ConversationPinnedMessage" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "ConversationPinnedMessage")
public class ConversationPinnedMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "conversationId", nullable = false)
    private Integer conversationId;

    @Column(name = "messageId", nullable = false)
    private Long messageId;

    @Column(name = "pinnedBy")
    private Integer pinnedBy;

    @Column(name = "pinnedAt")
    private LocalDateTime pinnedAt;

    public ConversationPinnedMessage() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getConversationId() {
        return conversationId;
    }

    public void setConversationId(Integer conversationId) {
        this.conversationId = conversationId;
    }

    public Long getMessageId() {
        return messageId;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public Integer getPinnedBy() {
        return pinnedBy;
    }

    public void setPinnedBy(Integer pinnedBy) {
        this.pinnedBy = pinnedBy;
    }

    public LocalDateTime getPinnedAt() {
        return pinnedAt;
    }

    public void setPinnedAt(LocalDateTime pinnedAt) {
        this.pinnedAt = pinnedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ConversationPinnedMessage)) return false;
        ConversationPinnedMessage that = (ConversationPinnedMessage) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "ConversationPinnedMessage{" +
                "id=" + id +
                '}';
    }
}