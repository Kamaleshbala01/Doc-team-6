package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity mapping for the "SocialMediaPlatform" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "SocialMediaPlatform")
public class SocialMediaPlatform {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "platformName")
    private String platformName;

    @Column(name = "urlPrefix")
    private String urlPrefix;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    public SocialMediaPlatform() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPlatformName() {
        return platformName;
    }

    public void setPlatformName(String platformName) {
        this.platformName = platformName;
    }

    public String getUrlPrefix() {
        return urlPrefix;
    }

    public void setUrlPrefix(String urlPrefix) {
        this.urlPrefix = urlPrefix;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SocialMediaPlatform)) return false;
        SocialMediaPlatform that = (SocialMediaPlatform) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "SocialMediaPlatform{" +
                "id=" + id +
                '}';
    }
}