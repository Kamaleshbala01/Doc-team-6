package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity mapping for the "UserPresence" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "UserPresence")
public class UserPresence {

    @Id
    @Column(name = "userId")
    private Integer userId;

    @Column(name = "isOnline")
    private Boolean isOnline;

    @Column(name = "currentSocketId")
    private String currentSocketId;

    @Column(name = "lastSeenAt")
    private LocalDateTime lastSeenAt;

    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

    public UserPresence() {
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Boolean getIsOnline() {
        return isOnline;
    }

    public void setIsOnline(Boolean isOnline) {
        this.isOnline = isOnline;
    }

    public String getCurrentSocketId() {
        return currentSocketId;
    }

    public void setCurrentSocketId(String currentSocketId) {
        this.currentSocketId = currentSocketId;
    }

    public LocalDateTime getLastSeenAt() {
        return lastSeenAt;
    }

    public void setLastSeenAt(LocalDateTime lastSeenAt) {
        this.lastSeenAt = lastSeenAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UserPresence)) return false;
        UserPresence that = (UserPresence) o;
        return userId != null && userId.equals(that.userId);
    }

    @Override
    public int hashCode() {
        return userId != null ? userId.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "UserPresence{" +
                "userId=" + userId +
                '}';
    }
}