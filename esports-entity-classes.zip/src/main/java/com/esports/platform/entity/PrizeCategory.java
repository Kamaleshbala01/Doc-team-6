package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity mapping for the "PrizeCategory" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "PrizeCategory")
public class PrizeCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    public PrizeCategory() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PrizeCategory)) return false;
        PrizeCategory that = (PrizeCategory) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "PrizeCategory{" +
                "id=" + id +
                '}';
    }
}