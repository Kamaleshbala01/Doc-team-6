package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity mapping for the "ConversationSettings" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "ConversationSettings")
public class ConversationSettings {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "conversationId", unique = true)
    private Integer conversationId;

    @Column(name = "allowMemberMessaging")
    private Boolean allowMemberMessaging;

    @Column(name = "allowMemberInvite")
    private Boolean allowMemberInvite;

    @Column(name = "onlyAdminCanPost")
    private Boolean onlyAdminCanPost;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

    public ConversationSettings() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getConversationId() {
        return conversationId;
    }

    public void setConversationId(Integer conversationId) {
        this.conversationId = conversationId;
    }

    public Boolean getAllowMemberMessaging() {
        return allowMemberMessaging;
    }

    public void setAllowMemberMessaging(Boolean allowMemberMessaging) {
        this.allowMemberMessaging = allowMemberMessaging;
    }

    public Boolean getAllowMemberInvite() {
        return allowMemberInvite;
    }

    public void setAllowMemberInvite(Boolean allowMemberInvite) {
        this.allowMemberInvite = allowMemberInvite;
    }

    public Boolean getOnlyAdminCanPost() {
        return onlyAdminCanPost;
    }

    public void setOnlyAdminCanPost(Boolean onlyAdminCanPost) {
        this.onlyAdminCanPost = onlyAdminCanPost;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ConversationSettings)) return false;
        ConversationSettings that = (ConversationSettings) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "ConversationSettings{" +
                "id=" + id +
                '}';
    }
}