package com.esports.platform.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Entity mapping for the "SocialMediaAccount" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "SocialMediaAccount")
public class SocialMediaAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "userId", nullable = false)
    private Integer userId;

    @Column(name = "platformId", nullable = false)
    private Integer platformId;

    @Column(name = "accountName")
    private String accountName;

    @Column(name = "profileUrl")
    private String profileUrl;

    @Column(name = "followersCount")
    private Long followersCount;

    @Column(name = "subscriberCount")
    private Long subscriberCount;

    @Column(name = "viewSubscriptionRatio")
    private BigDecimal viewSubscriptionRatio;

    @Column(name = "viewCommentRatio")
    private BigDecimal viewCommentRatio;

    @Column(name = "acceptanceStatusId")
    private Integer acceptanceStatusId;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

    public SocialMediaAccount() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Integer platformId) {
        this.platformId = platformId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getProfileUrl() {
        return profileUrl;
    }

    public void setProfileUrl(String profileUrl) {
        this.profileUrl = profileUrl;
    }

    public Long getFollowersCount() {
        return followersCount;
    }

    public void setFollowersCount(Long followersCount) {
        this.followersCount = followersCount;
    }

    public Long getSubscriberCount() {
        return subscriberCount;
    }

    public void setSubscriberCount(Long subscriberCount) {
        this.subscriberCount = subscriberCount;
    }

    public BigDecimal getViewSubscriptionRatio() {
        return viewSubscriptionRatio;
    }

    public void setViewSubscriptionRatio(BigDecimal viewSubscriptionRatio) {
        this.viewSubscriptionRatio = viewSubscriptionRatio;
    }

    public BigDecimal getViewCommentRatio() {
        return viewCommentRatio;
    }

    public void setViewCommentRatio(BigDecimal viewCommentRatio) {
        this.viewCommentRatio = viewCommentRatio;
    }

    public Integer getAcceptanceStatusId() {
        return acceptanceStatusId;
    }

    public void setAcceptanceStatusId(Integer acceptanceStatusId) {
        this.acceptanceStatusId = acceptanceStatusId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SocialMediaAccount)) return false;
        SocialMediaAccount that = (SocialMediaAccount) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "SocialMediaAccount{" +
                "id=" + id +
                '}';
    }
}