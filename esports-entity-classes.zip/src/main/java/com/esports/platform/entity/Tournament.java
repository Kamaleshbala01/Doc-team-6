package com.esports.platform.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Entity mapping for the "Tournament" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "Tournament")
public class Tournament {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "organizerId")
    private Integer organizerId;

    @Column(name = "name")
    private String name;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "registrationStartDate")
    private LocalDateTime registrationStartDate;

    @Column(name = "registrationEndDate")
    private LocalDateTime registrationEndDate;

    @Column(name = "tournamentStartDate")
    private LocalDateTime tournamentStartDate;

    @Column(name = "tournamentEndDate")
    private LocalDateTime tournamentEndDate;

    @Column(name = "bannerFileId")
    private Integer bannerFileId;

    @Column(name = "categoryId")
    private Integer categoryId;

    @Column(name = "tournamentTypeId")
    private Integer tournamentTypeId;

    @Column(name = "maximumTeams")
    private Integer maximumTeams;

    @Column(name = "maximumPlayersPerTeam")
    private Integer maximumPlayersPerTeam;

    @Column(name = "seedingTypeId")
    private Integer seedingTypeId;

    @Column(name = "entryFee")
    private BigDecimal entryFee;

    @Column(name = "verificationRequired")
    private Boolean verificationRequired;

    @Column(name = "packageId")
    private Integer packageId;

    @Column(name = "status")
    private String status;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

    public Tournament() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrganizerId() {
        return organizerId;
    }

    public void setOrganizerId(Integer organizerId) {
        this.organizerId = organizerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getRegistrationStartDate() {
        return registrationStartDate;
    }

    public void setRegistrationStartDate(LocalDateTime registrationStartDate) {
        this.registrationStartDate = registrationStartDate;
    }

    public LocalDateTime getRegistrationEndDate() {
        return registrationEndDate;
    }

    public void setRegistrationEndDate(LocalDateTime registrationEndDate) {
        this.registrationEndDate = registrationEndDate;
    }

    public LocalDateTime getTournamentStartDate() {
        return tournamentStartDate;
    }

    public void setTournamentStartDate(LocalDateTime tournamentStartDate) {
        this.tournamentStartDate = tournamentStartDate;
    }

    public LocalDateTime getTournamentEndDate() {
        return tournamentEndDate;
    }

    public void setTournamentEndDate(LocalDateTime tournamentEndDate) {
        this.tournamentEndDate = tournamentEndDate;
    }

    public Integer getBannerFileId() {
        return bannerFileId;
    }

    public void setBannerFileId(Integer bannerFileId) {
        this.bannerFileId = bannerFileId;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public Integer getTournamentTypeId() {
        return tournamentTypeId;
    }

    public void setTournamentTypeId(Integer tournamentTypeId) {
        this.tournamentTypeId = tournamentTypeId;
    }

    public Integer getMaximumTeams() {
        return maximumTeams;
    }

    public void setMaximumTeams(Integer maximumTeams) {
        this.maximumTeams = maximumTeams;
    }

    public Integer getMaximumPlayersPerTeam() {
        return maximumPlayersPerTeam;
    }

    public void setMaximumPlayersPerTeam(Integer maximumPlayersPerTeam) {
        this.maximumPlayersPerTeam = maximumPlayersPerTeam;
    }

    public Integer getSeedingTypeId() {
        return seedingTypeId;
    }

    public void setSeedingTypeId(Integer seedingTypeId) {
        this.seedingTypeId = seedingTypeId;
    }

    public BigDecimal getEntryFee() {
        return entryFee;
    }

    public void setEntryFee(BigDecimal entryFee) {
        this.entryFee = entryFee;
    }

    public Boolean getVerificationRequired() {
        return verificationRequired;
    }

    public void setVerificationRequired(Boolean verificationRequired) {
        this.verificationRequired = verificationRequired;
    }

    public Integer getPackageId() {
        return packageId;
    }

    public void setPackageId(Integer packageId) {
        this.packageId = packageId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Tournament)) return false;
        Tournament that = (Tournament) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Tournament{" +
                "id=" + id +
                '}';
    }
}