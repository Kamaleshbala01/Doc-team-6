package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity mapping for the "AffiliateLink" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "AffiliateLink")
public class AffiliateLink {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "affiliateCampaignId", nullable = false)
    private Integer affiliateCampaignId;

    @Column(name = "assignedUserId", nullable = false)
    private Integer assignedUserId;

    @Column(name = "assignedUserType")
    private String assignedUserType;

    @Column(name = "linkName")
    private String linkName;

    @Column(name = "destinationUrl", nullable = false)
    private String destinationUrl;

    @Column(name = "shortCode", nullable = false, unique = true)
    private String shortCode;

    @Column(name = "status")
    private String status;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

    public AffiliateLink() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAffiliateCampaignId() {
        return affiliateCampaignId;
    }

    public void setAffiliateCampaignId(Integer affiliateCampaignId) {
        this.affiliateCampaignId = affiliateCampaignId;
    }

    public Integer getAssignedUserId() {
        return assignedUserId;
    }

    public void setAssignedUserId(Integer assignedUserId) {
        this.assignedUserId = assignedUserId;
    }

    public String getAssignedUserType() {
        return assignedUserType;
    }

    public void setAssignedUserType(String assignedUserType) {
        this.assignedUserType = assignedUserType;
    }

    public String getLinkName() {
        return linkName;
    }

    public void setLinkName(String linkName) {
        this.linkName = linkName;
    }

    public String getDestinationUrl() {
        return destinationUrl;
    }

    public void setDestinationUrl(String destinationUrl) {
        this.destinationUrl = destinationUrl;
    }

    public String getShortCode() {
        return shortCode;
    }

    public void setShortCode(String shortCode) {
        this.shortCode = shortCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AffiliateLink)) return false;
        AffiliateLink that = (AffiliateLink) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "AffiliateLink{" +
                "id=" + id +
                '}';
    }
}