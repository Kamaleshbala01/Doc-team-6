package com.esports.entity;

import java.time.LocalDateTime;


public class TournamentOrganizerDetails {
    private Integer id;
    private Integer userId;
    private String mobileNumber;
    private String governmentIdUri;
    private String selfieVerificationUri;
    private String verificationStatus;
    private LocalDateTime verifiedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public TournamentOrganizerDetails() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getGovernmentIdUri() {
        return governmentIdUri;
    }

    public void setGovernmentIdUri(String governmentIdUri) {
        this.governmentIdUri = governmentIdUri;
    }

    public String getSelfieVerificationUri() {
        return selfieVerificationUri;
    }

    public void setSelfieVerificationUri(String selfieVerificationUri) {
        this.selfieVerificationUri = selfieVerificationUri;
    }

    public String getVerificationStatus() {
        return verificationStatus;
    }

    public void setVerificationStatus(String verificationStatus) {
        this.verificationStatus = verificationStatus;
    }

    public LocalDateTime getVerifiedAt() {
        return verifiedAt;
    }

    public void setVerifiedAt(LocalDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TournamentOrganizerDetails)) return false;
        TournamentOrganizerDetails that = (TournamentOrganizerDetails) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "TournamentOrganizerDetails{" +
                "id=" + id +
                '}';
    }
}