package com.esports.entity;

import java.time.LocalDateTime;

public class ConversationSettings {
    private Integer id;
    private Integer conversationId;
    private Boolean allowMemberMessaging;
    private Boolean allowMemberInvite;
    private Boolean onlyAdminCanPost;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public ConversationSettings() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getConversationId() {
        return conversationId;
    }

    public void setConversationId(Integer conversationId) {
        this.conversationId = conversationId;
    }

    public Boolean getAllowMemberMessaging() {
        return allowMemberMessaging;
    }

    public void setAllowMemberMessaging(Boolean allowMemberMessaging) {
        this.allowMemberMessaging = allowMemberMessaging;
    }

    public Boolean getAllowMemberInvite() {
        return allowMemberInvite;
    }

    public void setAllowMemberInvite(Boolean allowMemberInvite) {
        this.allowMemberInvite = allowMemberInvite;
    }

    public Boolean getOnlyAdminCanPost() {
        return onlyAdminCanPost;
    }

    public void setOnlyAdminCanPost(Boolean onlyAdminCanPost) {
        this.onlyAdminCanPost = onlyAdminCanPost;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ConversationSettings)) return false;
        ConversationSettings that = (ConversationSettings) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "ConversationSettings{" +
                "id=" + id +
                '}';
    }
}