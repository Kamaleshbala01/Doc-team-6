package com.esports.entity;

import java.time.LocalDateTime;

public class MatchDetails {
    private Integer id;
    private Integer roundId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String status;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getRoundId() {
        return roundId;
    }
    public void setRoundId(Integer roundId) {
        this.roundId = roundId;
    }
    public LocalDateTime getStartTime() {
        return startTime;
    }
    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }
    public LocalDateTime getEndTime() {
        return endTime;
    }
    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    
}
