package com.esports.entity;

import java.time.LocalDateTime;

public class WatchHistory {
    private Integer id;
    private Integer userId;
    private Integer matchId;
    private LocalDateTime createdAt;

    
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getUserId() {
        return userId;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public Integer getMatchId() {
        return matchId;
    }
    public void setMatchId(Integer matchId) {
        this.matchId = matchId;
    }
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
