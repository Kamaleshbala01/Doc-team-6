package com.esports.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;


public class Campaign {

    private Integer id;
    private Integer brandId;
    private Integer campaignTypeId;
    private String campaignName;
    private Integer gameId;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private String description;
    private Integer campaignThumbnailFileId;
    private BigDecimal totalBudget;
    private BigDecimal influencerCost;
    private BigDecimal additionalExpenses;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public Campaign() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBrandId() {
        return brandId;
    }

    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

    public Integer getCampaignTypeId() {
        return campaignTypeId;
    }

    public void setCampaignTypeId(Integer campaignTypeId) {
        this.campaignTypeId = campaignTypeId;
    }

    public String getCampaignName() {
        return campaignName;
    }

    public void setCampaignName(String campaignName) {
        this.campaignName = campaignName;
    }

    public Integer getGameId() {
        return gameId;
    }

    public void setGameId(Integer gameId) {
        this.gameId = gameId;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getCampaignThumbnailFileId() {
        return campaignThumbnailFileId;
    }

    public void setCampaignThumbnailFileId(Integer campaignThumbnailFileId) {
        this.campaignThumbnailFileId = campaignThumbnailFileId;
    }

    public BigDecimal getTotalBudget() {
        return totalBudget;
    }

    public void setTotalBudget(BigDecimal totalBudget) {
        this.totalBudget = totalBudget;
    }

    public BigDecimal getInfluencerCost() {
        return influencerCost;
    }

    public void setInfluencerCost(BigDecimal influencerCost) {
        this.influencerCost = influencerCost;
    }

    public BigDecimal getAdditionalExpenses() {
        return additionalExpenses;
    }

    public void setAdditionalExpenses(BigDecimal additionalExpenses) {
        this.additionalExpenses = additionalExpenses;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Campaign)) return false;
        Campaign that = (Campaign) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Campaign [id=" + id + ", brandId=" + brandId + ", campaignTypeId=" + campaignTypeId + ", campaignName="
                + campaignName + ", gameId=" + gameId + ", startDate=" + startDate + ", endDate=" + endDate
                + ", description=" + description + ", campaignThumbnailFileId=" + campaignThumbnailFileId
                + ", totalBudget=" + totalBudget + ", influencerCost=" + influencerCost + ", additionalExpenses="
                + additionalExpenses + ", status=" + status + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt
                + "]";
    }

    
}