package com.esports.entity;

import java.time.LocalDateTime;

public class TournamentCategory {

    private Integer id;
    private String categoryName;
    private LocalDateTime createdAt;

    public TournamentCategory() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TournamentCategory)) return false;
        TournamentCategory that = (TournamentCategory) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "TournamentCategory [id=" + id + ", categoryName=" + categoryName + ", createdAt=" + createdAt + "]";
    }

    
}