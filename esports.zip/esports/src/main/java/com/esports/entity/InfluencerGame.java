package com.esports.entity;

import java.time.LocalDateTime;

public class InfluencerGame {
    
    private Integer id;
    private Integer influencerId;
    private Integer gameId;
    private Boolean isPrimary;
    private LocalDateTime createdAt;

    public InfluencerGame() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getInfluencerId() {
        return influencerId;
    }

    public void setInfluencerId(Integer influencerId) {
        this.influencerId = influencerId;
    }

    public Integer getGameId() {
        return gameId;
    }

    public void setGameId(Integer gameId) {
        this.gameId = gameId;
    }

    public Boolean getIsPrimary() {
        return isPrimary;
    }

    public void setIsPrimary(Boolean isPrimary) {
        this.isPrimary = isPrimary;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InfluencerGame)) return false;
        InfluencerGame that = (InfluencerGame) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "InfluencerGame{" +
                "id=" + id +
                '}';
    }
}