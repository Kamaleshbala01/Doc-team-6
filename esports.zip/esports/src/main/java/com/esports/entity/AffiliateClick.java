package com.esports.entity;


import java.time.LocalDateTime;


public class AffiliateClick {
    private Long id;
    private Integer affiliateLinkId;
    private String sessionId;
    private String visitorIp;
    private String country;
    private String city;
    private String deviceType;
    private String browser;
    private String refererUrl;
    private LocalDateTime clickedAt;

    public AffiliateClick() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getAffiliateLinkId() {
        return affiliateLinkId;
    }

    public void setAffiliateLinkId(Integer affiliateLinkId) {
        this.affiliateLinkId = affiliateLinkId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getVisitorIp() {
        return visitorIp;
    }

    public void setVisitorIp(String visitorIp) {
        this.visitorIp = visitorIp;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getBrowser() {
        return browser;
    }

    public void setBrowser(String browser) {
        this.browser = browser;
    }

    public String getRefererUrl() {
        return refererUrl;
    }

    public void setRefererUrl(String refererUrl) {
        this.refererUrl = refererUrl;
    }

    public LocalDateTime getClickedAt() {
        return clickedAt;
    }

    public void setClickedAt(LocalDateTime clickedAt) {
        this.clickedAt = clickedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AffiliateClick)) return false;
        AffiliateClick that = (AffiliateClick) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "AffiliateClick [id=" + id + ", affiliateLinkId=" + affiliateLinkId + ", sessionId=" + sessionId
                + ", visitorIp=" + visitorIp + ", country=" + country + ", city=" + city + ", deviceType=" + deviceType
                + ", browser=" + browser + ", refererUrl=" + refererUrl + ", clickedAt=" + clickedAt + "]";
    }

    
}