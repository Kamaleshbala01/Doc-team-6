package com.esports.entity;


public class CampaignPlatform {

    private Integer id;
    private Integer campaignId;
    private Integer platformId;

    public CampaignPlatform() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }

    public Integer getPlatformId() {
        return platformId;
    }

    public void setPlatformId(Integer platformId) {
        this.platformId = platformId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CampaignPlatform)) return false;
        CampaignPlatform that = (CampaignPlatform) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "CampaignPlatform [id=" + id + ", campaignId=" + campaignId + ", platformId=" + platformId + "]";
    }

    
}