package com.esports.entity;


import java.time.LocalDateTime;

public class AffiliateLink {
    private Integer id;
    private Integer campaignId;
    private Integer assignedUserId;
    private String assignedUserType;
    private String linkName;
    private String destinationUrl;
    private String shortCode;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public AffiliateLink() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }

    public Integer getAssignedUserId() {
        return assignedUserId;
    }

    public void setAssignedUserId(Integer assignedUserId) {
        this.assignedUserId = assignedUserId;
    }

    public String getAssignedUserType() {
        return assignedUserType;
    }

    public void setAssignedUserType(String assignedUserType) {
        this.assignedUserType = assignedUserType;
    }

    public String getLinkName() {
        return linkName;
    }

    public void setLinkName(String linkName) {
        this.linkName = linkName;
    }

    public String getDestinationUrl() {
        return destinationUrl;
    }

    public void setDestinationUrl(String destinationUrl) {
        this.destinationUrl = destinationUrl;
    }

    public String getShortCode() {
        return shortCode;
    }

    public void setShortCode(String shortCode) {
        this.shortCode = shortCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AffiliateLink)) return false;
        AffiliateLink that = (AffiliateLink) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "AffiliateLink [id=" + id + ", campaignId=" + campaignId + ", assignedUserId=" + assignedUserId
                + ", assignedUserType=" + assignedUserType + ", linkName=" + linkName + ", destinationUrl="
                + destinationUrl + ", shortCode=" + shortCode + ", status=" + status + ", createdAt=" + createdAt
                + ", updatedAt=" + updatedAt + "]";
    }

    
}