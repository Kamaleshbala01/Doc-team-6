package com.esports.entity;

public class MatchParticipants {
    private Integer id;
    private Integer matchId;
    private Integer teamId;
    private String status; // status store value like QUALIFIED or WON or LOSS etc,....
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getMatchId() {
        return matchId;
    }
    public void setMatchId(Integer matchId) {
        this.matchId = matchId;
    }
    public Integer getTeamId() {
        return teamId;
    }
    public void setTeamId(Integer teamId) {
        this.teamId = teamId;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
}
