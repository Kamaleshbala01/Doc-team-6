package com.esports.entity;

public class RoundDetails {
    private Integer id;
    private Integer tournamentId;
    private String roundName;
    private Integer maximumParticipants;
    private Integer qualifyingCount;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getTournamentId() {
        return tournamentId;
    }
    public void setTournamentId(Integer tournamentId) {
        this.tournamentId = tournamentId;
    }
    public String getRoundName() {
        return roundName;
    }
    public void setRoundName(String roundName) {
        this.roundName = roundName;
    }
    public Integer getMaximumParticipants() {
        return maximumParticipants;
    }
    public void setMaximumParticipants(Integer maximumParticipants) {
        this.maximumParticipants = maximumParticipants;
    }
    public Integer getQualifyingCount() {
        return qualifyingCount;
    }
    public void setQualifyingCount(Integer qualifyingCount) {
        this.qualifyingCount = qualifyingCount;
    }

    
}
