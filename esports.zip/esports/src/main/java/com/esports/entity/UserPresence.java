package com.esports.entity;

import java.time.LocalDateTime;


public class UserPresence {

    private Integer userId;
    private Boolean isOnline;
    private String currentSocketId;
    private LocalDateTime lastSeenAt;
    private LocalDateTime updatedAt;

    public UserPresence() {
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Boolean getIsOnline() {
        return isOnline;
    }

    public void setIsOnline(Boolean isOnline) {
        this.isOnline = isOnline;
    }

    public String getCurrentSocketId() {
        return currentSocketId;
    }

    public void setCurrentSocketId(String currentSocketId) {
        this.currentSocketId = currentSocketId;
    }

    public LocalDateTime getLastSeenAt() {
        return lastSeenAt;
    }

    public void setLastSeenAt(LocalDateTime lastSeenAt) {
        this.lastSeenAt = lastSeenAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UserPresence)) return false;
        UserPresence that = (UserPresence) o;
        return userId != null && userId.equals(that.userId);
    }

    @Override
    public int hashCode() {
        return userId != null ? userId.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "UserPresence{" +
                "userId=" + userId +
                '}';
    }
}