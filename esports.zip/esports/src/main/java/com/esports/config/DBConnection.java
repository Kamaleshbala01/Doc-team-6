package com.esports.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final DBConnection INSTANCE = new DBConnection();

    private final String url ="jdbc:postgresql://10.23.240.29:5432/Gaming__eSports_db";
    private final String password = "eSports_Tata@123";
    private final String username = "Gaming__eSports_user";

    private DBConnection() {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("PostgreSQL Driver not found", e);
        }
    }

    public static DBConnection getInstance() {
        return INSTANCE;
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }
}
