package com.esports.project.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.Message;

@Repository
public interface MessageRepository extends JpaRepository<Message,String> {

    public List<Message> findByConversation_Id(String conversationId);

    Page<Message> findByConversation_IdOrderByCreatedAtDesc(String conversationId,Pageable pageable);
}
