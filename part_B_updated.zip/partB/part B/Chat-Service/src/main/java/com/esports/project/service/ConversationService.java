package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.esports.project.entity.Conversation;
import com.esports.project.repository.ConversationRepository;

import jakarta.validation.ValidationException;

import com.esports.project.exception.NotFoundException;

@Service
public class ConversationService {
    
    private final ConversationRepository conversationRepository;

    public ConversationService(ConversationRepository conversationRepository)
    {
        this.conversationRepository = conversationRepository;
    }

    public Conversation createConversation(Conversation conversation)
    {
        if (conversation.getName() == null || conversation.getName().isBlank())
        {
            throw new ValidationException("Conversation name is required");
        }
        if (conversation.getCreatedBy() == null || conversation.getCreatedBy().isBlank())
        {
            throw new ValidationException("Created By is required");
        }
        if (conversation.getConversationType() == null || conversation.getConversationType().isBlank())
        {
            throw new ValidationException("Conversation Type is Required");
        }
        conversation.setCreatedAt(LocalDateTime.now());
        return conversationRepository.save(conversation);
    }

    public Conversation getConversationById(String id)
    {
        return conversationRepository.findById(id).orElseThrow(()->new NotFoundException("Conversation Not Found :"+id));
    }

    public List<Conversation> getAllConversations()
    {
        return conversationRepository.findAll();
    }

    public void deleteConversation(String id)
    {
        if (!conversationRepository.existsById(id))
        {
            throw new NotFoundException("Conversation Not Found :"+id);
        }
        conversationRepository.deleteById(id);
    }

    public Conversation updateConversation(Conversation conversation)
    {
        if (conversation.getId() == null)
        {
            throw new ValidationException("Conversation Id is required");
        }
        Conversation existingConversation = conversationRepository.findById(conversation.getId()).orElseThrow(()-> new NotFoundException("Conversation not found :"+conversation.getId()));

        existingConversation.setName(conversation.getName());
        existingConversation.setDescription(conversation.getDescription());
        existingConversation.setUpdatedAt(LocalDateTime.now());

        return conversationRepository.save(existingConversation);
    }
}
