package com.esports.project.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.esports.project.DTO.ExceptionDTO;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@ControllerAdvice
public class GlobalExceptionHandler {
    
    public GlobalExceptionHandler(HttpSession httpSession){}


    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ExceptionDTO> handleNotFoundException(final NotFoundException exception,HttpServletRequest request){
        ExceptionDTO exceptionMessage = new ExceptionDTO(
                                            HttpStatus.NOT_FOUND.value(),
                                            HttpStatus.NOT_FOUND.getReasonPhrase(),
                                            exception.getMessage(),
                                            request.getRequestURI());

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(exceptionMessage);
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ExceptionDTO> handleValidationException(ValidationException exception,HttpServletRequest request)
    {
        ExceptionDTO exceptMessage = new ExceptionDTO(
            HttpStatus.BAD_REQUEST.value(),
            HttpStatus.BAD_REQUEST.getReasonPhrase(),
            exception.getMessage(),
            request.getRequestURI());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exceptMessage);
    }
    
}
