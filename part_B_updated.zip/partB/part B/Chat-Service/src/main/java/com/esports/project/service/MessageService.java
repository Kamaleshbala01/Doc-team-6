package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.esports.project.entity.Message;
import com.esports.project.exception.NotFoundException;
import com.esports.project.exception.ValidationException;
import com.esports.project.repository.MessageRepository;

@Service
public class MessageService {

    private final MessageRepository messages;

    public MessageService(MessageRepository messages)
    {
        this.messages = messages;
    }

    public Message getMessageById(String id)
    {
        return messages.findById(id).orElseThrow(()->new NotFoundException("Message Not Found :"+id));
    }

    public List<Message> getAllMessages()
    {
        return messages.findAll();
    }

    public List<Message> getMessagesByConversationId(String id)
    {
        return messages.findByConversation_Id(id);
    }

    public Message addMessage(Message message)
    {
        if (message.getConversation() == null || message.getConversation().getId() == null || message.getConversation().getId().isBlank())
        {
            throw new ValidationException("Conversation Id is missing");
        }
        if (message.getContent() == null || message.getContent().isBlank())
        {
            throw new ValidationException("Message content is required");
        }
        message.setIsDeleted(false);
        message.setIsEdited(false);
        message.setCreatedAt(LocalDateTime.now());
        return messages.save(message);
    }

    public Message updateMessage(Message message)
    {
        if (message.getId() == null)
        {
            throw new ValidationException("Message Id is required");
        }
        Message existingMessage = messages.findById(message.getId()).orElseThrow(()-> new NotFoundException("Message not found :"+message.getId()));

        existingMessage.setContent(message.getContent());
        existingMessage.setEditedAt(LocalDateTime.now());
        existingMessage.setIsEdited(true);

        return messages.save(existingMessage);
    }

    public void deleteMessage(String id)
    {
        Message deletedMessage = messages.findById(id).orElseThrow(()-> new NotFoundException("Message not found :"+id));
        deletedMessage.setContent("This Message Was Deleted");
        deletedMessage.setDeletedAt(LocalDateTime.now());
        deletedMessage.setIsDeleted(true);

        messages.save(deletedMessage);
    
    
    }

    public void deleteALL()
    {
        messages.deleteAll();
    }

    public Page<Message> getPagedMessagesByConversationId(String id,Pageable pageable)
    {
        return messages.findByConversation_IdOrderByCreatedAtDesc(id, pageable);
    }
}

