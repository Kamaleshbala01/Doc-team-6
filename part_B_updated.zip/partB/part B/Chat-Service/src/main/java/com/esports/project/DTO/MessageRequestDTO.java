package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MessageRequestDTO {

    private String id;
    private String conversationId;
    private String content;
}
