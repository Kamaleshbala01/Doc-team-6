package com.esports.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.Conversation;

@Repository
public interface ConversationRepository extends JpaRepository<Conversation,String>{
    
}
