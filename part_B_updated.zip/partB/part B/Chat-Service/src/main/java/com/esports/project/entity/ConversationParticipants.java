package com.esports.project.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Index;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "conversation_participants", indexes = { @Index(name = "idx_conversation_participants_conversation_id", columnList = "conversation_id"), @Index(name = "idx_conversation_participants_participant", columnList = "participant") })
public class ConversationParticipants {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private Boolean isAdmin;
    private Boolean isMuted;
    private LocalDateTime joinedAt;
    private LocalDateTime leftAt;
    private LocalDateTime createdAt;


    // conversation mapping

    @ManyToOne
    @JoinColumn(name = "conversation_id")
    @JsonBackReference(value = "conversation-participants")
    private Conversation conversation;

    // participant mapping
    private String participant;
}
