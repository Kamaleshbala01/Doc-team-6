package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConversationParticipantResponseDTO {

    private String id;
    private String conversationId;
    private String participant;
    private boolean isAdmin;
    private boolean isMuted;
}
