package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ConversationRequestDTO {

    private String id;
    private String conversationType;
    private String name;
    private String description;
    private String createdBy;
}
