package com.esports.project.mapper;

import org.springframework.stereotype.Component;

import com.esports.project.DTO.MessageRequestDTO;
import com.esports.project.DTO.MessageResponseDTO;
import com.esports.project.entity.Conversation;
import com.esports.project.entity.Message;
import com.esports.project.exception.NotFoundException;
import com.esports.project.repository.ConversationRepository;

@Component
public class MessageMapper {

    private final ConversationRepository cr;

    public MessageMapper(ConversationRepository cr)
    {
        this.cr = cr;

    }

    public Message toCreateEntity(MessageRequestDTO dto)
    {
        Message message = new Message();
        message.setContent(dto.getContent());

        Conversation conversation = cr.findById(dto.getConversationId()).orElseThrow(
            ()-> new NotFoundException("Conversation not found :"+dto.getConversationId())
        );
        message.setConversation(conversation);
        return message;
    }

    public Message toUpdateEntity(MessageRequestDTO dto)
    {
        Message message = new Message();
        message.setContent(dto.getContent());
        message.setId(dto.getId());
        return message;
    }

    public MessageResponseDTO toResponseEntity(Message message)
    {
        MessageResponseDTO dto = new MessageResponseDTO();

        dto.setContent(message.getContent());
        dto.setConversationId(message.getConversation().getId());
        dto.setId(message.getId());
        dto.setDeleted(message.getIsDeleted());
        dto.setEdited(message.getIsEdited());
        dto.setSender(message.getSender());

        return dto;
    }


}
