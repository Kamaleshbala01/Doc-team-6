package com.esports.project.controller;

//import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
//import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
/*import org.springframework.web.bind.annotation.PostMapping; //Using WebSocket to send messages here
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;*/
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//import com.esports.project.DTO.MessageRequestDTO;
import com.esports.project.DTO.MessageResponseDTO;
//import com.esports.project.entity.Message;
import com.esports.project.mapper.MessageMapper;
import com.esports.project.service.MessageService;


@RestController
@RequestMapping("/chat/message")
public class MessageController {

    private final MessageService ms;
    private final MessageMapper mm;

    public MessageController(MessageService ms,MessageMapper mm)
    {
        this.ms = ms;
        this.mm = mm;
    }
    
    /*@GetMapping
    public List<MessageResponseDTO> getAllMessages()
    {
        return ms.getAllMessages().stream().map(mm :: toResponseEntity).toList(); 
    }*/

    @GetMapping("/{id}")
    public MessageResponseDTO getMessageById(@PathVariable String id)
    {
        return mm.toResponseEntity(ms.getMessageById(id));
    }

    /*@GetMapping("/conversation/{conversation_id}")
    public List<MessageResponseDTO> getMessagesByConversationId(@PathVariable String conversation_id)
    {
        return ms.getMessagesByConversationId(conversation_id).stream().map(mm :: toResponseEntity).toList();
    }

    @PostMapping
    public MessageResponseDTO addMessage(@RequestBody MessageRequestDTO dto)
    {
        Message message = mm.toCreateEntity(dto);
        return mm.toResponseEntity(ms.addMessage(message));
    }

    @PutMapping
    public MessageResponseDTO updateMessage(@RequestBody MessageRequestDTO dto)
    {
        Message message = mm.toUpdateEntity(dto);
        return mm.toResponseEntity(ms.updateMessage(message));
    }

    @DeleteMapping("/{id}")
    public void deleteMessageById(@PathVariable String id)
    {
        ms.deleteMessage(id);
    }

    @DeleteMapping
    public void deleteMessages()
    {
        ms.deleteALL();
    }*/

    @GetMapping("/conversation/{id}")
    public Page<MessageResponseDTO> getMessagesByConversationId(@PathVariable String id,Pageable page)
    {
        return ms.getPagedMessagesByConversationId(id,page).map(mm::toResponseEntity);
    }
}
