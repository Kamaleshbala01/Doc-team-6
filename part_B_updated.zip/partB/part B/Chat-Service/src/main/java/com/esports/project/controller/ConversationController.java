package com.esports.project.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.ConversationRequestDTO;
import com.esports.project.DTO.ConversationResponseDTO;
import com.esports.project.entity.Conversation;
import com.esports.project.mapper.ConversationMapper;
import com.esports.project.service.ConversationService;



@RestController
@RequestMapping("/chat/conversation")
public class ConversationController {

    private final ConversationService conversationService;
    private final ConversationMapper conversationMapper;

    public ConversationController(ConversationService conversationService,ConversationMapper conversationMapper)
    {
        this.conversationService = conversationService;
        this.conversationMapper = conversationMapper;
    }

    @PostMapping
    public ConversationResponseDTO createConversation(@RequestBody ConversationRequestDTO dto)
    {
        Conversation conversation = conversationMapper.toCreateEntity(dto);
        return conversationMapper.toResponseEntity(conversationService.createConversation(conversation));
    }

    @GetMapping("/{id}")
    public ConversationResponseDTO getConversationById(@PathVariable String id)
    {
        return conversationMapper.toResponseEntity(conversationService.getConversationById(id));
    }

    @GetMapping
    public List<ConversationResponseDTO> getAllConversations()
    {
        return conversationService.getAllConversations().stream().map(conversationMapper::toResponseEntity).toList();
    }

    @DeleteMapping("/{id}")
    public void deleteConversation(@PathVariable String id)
    {
        conversationService.deleteConversation(id);
    }

    @PutMapping
    public ConversationResponseDTO updateConversation(@RequestBody ConversationRequestDTO dto)
    {
        Conversation conversation = conversationMapper.toUpdateEntity(dto);
        return conversationMapper.toResponseEntity(conversationService.updateConversation(conversation));
    }
}
