package com.esports.project.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;
//import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Index;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "message_read_status", indexes = { @Index(name = "idx_message_read_status_message_id", columnList = "message_id"), @Index(name = "idx_message_read_status_read_by", columnList = "read_by") })
public class MessageReadStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private LocalDateTime readAt;

    /*
     * Relationship mapping
     */

    // message mapping
    @ManyToOne
    @JoinColumn(name = "message_id")
    @JsonBackReference(value = "message-message-read-status")
    private Message message;

    private String readBy;
}
