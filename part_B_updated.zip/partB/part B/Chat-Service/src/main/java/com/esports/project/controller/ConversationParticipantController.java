package com.esports.project.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.entity.ConversationParticipants;
import com.esports.project.service.ChatParticipantService;

@RestController
@RequestMapping("/chat/participant")
public class ConversationParticipantController {

    private final ChatParticipantService chatParticipantService;

    public ConversationParticipantController(ChatParticipantService chatParticipantService)
    {
        this.chatParticipantService = chatParticipantService;
    }

    @GetMapping
    public List<ConversationParticipants> getAllParticipants()
    {
        return chatParticipantService.getAllParticipants();
    }

    @GetMapping("/{id}")
    public ConversationParticipants getParticipantById(@PathVariable String id)
    {
        return chatParticipantService.getParticipantById(id);
    }

    @GetMapping("/user/{participant}")
    public List<ConversationParticipants> getConverationByParticipants(@PathVariable String participant)
    {
        return chatParticipantService.getConversationsByParticipant(participant);
    }

    @PostMapping
    public ConversationParticipants addParticipant(@RequestBody ConversationParticipants participant)
    {
        return chatParticipantService.addParticipant(participant);
    }

    @PutMapping
    public ConversationParticipants updateParticipantById(@RequestBody ConversationParticipants participant)
    {
        return chatParticipantService.updateParticipant(participant);
    }

    @DeleteMapping("/{id}")
    public void deleteParticipantById(@PathVariable String id)
    {
        chatParticipantService.removeParticipant(id);
    }


}
