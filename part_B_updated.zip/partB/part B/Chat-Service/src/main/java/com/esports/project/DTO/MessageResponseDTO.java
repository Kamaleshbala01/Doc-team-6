package com.esports.project.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MessageResponseDTO {

    private String id;
    private String conversationId;
    private String sender;
    private String content;
    private boolean isEdited;
    private boolean isDeleted;
}
