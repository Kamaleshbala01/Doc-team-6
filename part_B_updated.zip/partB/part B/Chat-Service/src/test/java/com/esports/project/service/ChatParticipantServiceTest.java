package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.entity.ConversationParticipants;
import com.esports.project.exception.NotFoundException;
import com.esports.project.repository.ConversationParticipantsRepository;

@ExtendWith(MockitoExtension.class)
class ChatParticipantServiceTest {

    @Mock
    private ConversationParticipantsRepository conversationParticipants;

    @InjectMocks
    private ChatParticipantService service;

    @Test
    void shouldAddParticipant()
    {
        ConversationParticipants participant =
                new ConversationParticipants();

        when(conversationParticipants.save(any()))
                .thenAnswer(invocation ->
                        invocation.getArgument(0));

        ConversationParticipants result =
                service.addParticipant(participant);

        assertNotNull(result);
        assertNotNull(result.getCreatedAt());
        assertNotNull(result.getJoinedAt());
    }

    @Test
    void shouldGetAllParticipants()
    {
        when(conversationParticipants.findAll())
                .thenReturn(List.of(
                        new ConversationParticipants(),
                        new ConversationParticipants()));

        List<ConversationParticipants> result =
                service.getAllParticipants();

        assertEquals(2, result.size());
    }

    @Test
    void shouldGetParticipantById()
    {
        ConversationParticipants participant =
                new ConversationParticipants();

        participant.setId("123");

        when(conversationParticipants.findById("123"))
                .thenReturn(Optional.of(participant));

        ConversationParticipants result =
                service.getParticipantById("123");

        assertEquals("123", result.getId());
    }

    @Test
    void shouldThrowWhenParticipantNotFound()
    {
        when(conversationParticipants.findById("123"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getParticipantById("123"));
    }

    @Test
    void shouldUpdateParticipant()
    {
        ConversationParticipants existing =
                new ConversationParticipants();

        existing.setId("123");
        existing.setIsAdmin(false);
        existing.setIsMuted(false);

        ConversationParticipants update =
                new ConversationParticipants();

        update.setId("123");
        update.setIsAdmin(true);
        update.setIsMuted(true);
        update.setLeftAt(LocalDateTime.now());

        when(conversationParticipants.findById("123"))
                .thenReturn(Optional.of(existing));

        when(conversationParticipants.save(any()))
                .thenAnswer(invocation ->
                        invocation.getArgument(0));

        ConversationParticipants result =
                service.updateParticipant(update);

        assertTrue(result.getIsAdmin());
        assertTrue(result.getIsMuted());
        assertNotNull(result.getLeftAt());
    }

    @Test
    void shouldThrowWhenUpdatingMissingParticipant()
    {
        ConversationParticipants participant =
                new ConversationParticipants();

        participant.setId("123");

        when(conversationParticipants.findById("123"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.updateParticipant(participant));
    }

    @Test
    void shouldRemoveParticipant()
    {
        when(conversationParticipants.existsById("123"))
                .thenReturn(true);

        service.removeParticipant("123");

        verify(conversationParticipants)
                .deleteById("123");
    }

    @Test
    void shouldThrowWhenRemovingMissingParticipant()
    {
        when(conversationParticipants.existsById("123"))
                .thenReturn(false);

        assertThrows(
                NotFoundException.class,
                () -> service.removeParticipant("123"));
    }

    @Test
    void shouldReturnConversationsByParticipant()
    {
        when(conversationParticipants.findByParticipant("alan"))
                .thenReturn(List.of(
                        new ConversationParticipants(),
                        new ConversationParticipants()));

        List<ConversationParticipants> result =
                service.getConversationsByParticipant("alan");

        assertEquals(2, result.size());
    }

    @Test
    void shouldReturnParticipantsByConversationId()
    {
        when(conversationParticipants.findByConversation_Id("conv-1"))
                .thenReturn(List.of(
                        new ConversationParticipants(),
                        new ConversationParticipants(),
                        new ConversationParticipants()));

        List<ConversationParticipants> result =
                service.getParticipantsByConversationId("conv-1");

        assertEquals(3, result.size());
    }
}