package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.entity.Conversation;
import com.esports.project.exception.NotFoundException;
import com.esports.project.repository.ConversationRepository;

import jakarta.validation.ValidationException;

@ExtendWith(MockitoExtension.class)
class ConversationServiceTest {

    @Mock
    private ConversationRepository conversationRepository;

    @InjectMocks
    private ConversationService service;

    @Test
    void shouldCreateConversation()
    {
        Conversation conversation =
                new Conversation();

        conversation.setName("General");
        conversation.setCreatedBy("alan");
        conversation.setConversationType("GROUP");

        when(conversationRepository.save(any()))
                .thenAnswer(invocation ->
                        invocation.getArgument(0));

        Conversation result =
                service.createConversation(conversation);

        assertNotNull(result);
        assertNotNull(result.getCreatedAt());
        assertEquals(
                "General",
                result.getName());
    }

    @Test
    void shouldThrowWhenNameMissing()
    {
        Conversation conversation =
                new Conversation();

        conversation.setCreatedBy("alan");
        conversation.setConversationType("GROUP");

        assertThrows(
                ValidationException.class,
                () -> service.createConversation(conversation));
    }

    @Test
    void shouldThrowWhenCreatedByMissing()
    {
        Conversation conversation =
                new Conversation();

        conversation.setName("General");
        conversation.setConversationType("GROUP");

        assertThrows(
                ValidationException.class,
                () -> service.createConversation(conversation));
    }

    @Test
    void shouldThrowWhenConversationTypeMissing()
    {
        Conversation conversation =
                new Conversation();

        conversation.setName("General");
        conversation.setCreatedBy("alan");

        assertThrows(
                ValidationException.class,
                () -> service.createConversation(conversation));
    }

    @Test
    void shouldGetConversationById()
    {
        Conversation conversation =
                new Conversation();

        conversation.setId("123");

        when(conversationRepository.findById("123"))
                .thenReturn(Optional.of(conversation));

        Conversation result =
                service.getConversationById("123");

        assertEquals(
                "123",
                result.getId());
    }

    @Test
    void shouldThrowWhenConversationNotFound()
    {
        when(conversationRepository.findById("123"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getConversationById("123"));
    }

    @Test
    void shouldGetAllConversations()
    {
        when(conversationRepository.findAll())
                .thenReturn(List.of(
                        new Conversation(),
                        new Conversation()));

        List<Conversation> result =
                service.getAllConversations();

        assertEquals(2, result.size());
    }

    @Test
    void shouldDeleteConversation()
    {
        when(conversationRepository.existsById("123"))
                .thenReturn(true);

        service.deleteConversation("123");

        verify(conversationRepository)
                .deleteById("123");
    }

    @Test
    void shouldThrowWhenDeletingMissingConversation()
    {
        when(conversationRepository.existsById("123"))
                .thenReturn(false);

        assertThrows(
                NotFoundException.class,
                () -> service.deleteConversation("123"));
    }

    @Test
    void shouldUpdateConversation()
    {
        Conversation existing =
                new Conversation();

        existing.setId("123");
        existing.setName("Old");

        Conversation update =
                new Conversation();

        update.setId("123");
        update.setName("New");
        update.setDescription("Updated");

        when(conversationRepository.findById("123"))
                .thenReturn(Optional.of(existing));

        when(conversationRepository.save(any()))
                .thenAnswer(invocation ->
                        invocation.getArgument(0));

        Conversation result =
                service.updateConversation(update);

        assertEquals(
                "New",
                result.getName());

        assertEquals(
                "Updated",
                result.getDescription());

        assertNotNull(
                result.getUpdatedAt());
    }

    @Test
    void shouldThrowWhenUpdatingWithoutId()
    {
        Conversation conversation =
                new Conversation();

        assertThrows(
                ValidationException.class,
                () -> service.updateConversation(conversation));
    }

    @Test
    void shouldThrowWhenUpdatingMissingConversation()
    {
        Conversation conversation =
                new Conversation();

        conversation.setId("123");

        when(conversationRepository.findById("123"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.updateConversation(conversation));
    }
}