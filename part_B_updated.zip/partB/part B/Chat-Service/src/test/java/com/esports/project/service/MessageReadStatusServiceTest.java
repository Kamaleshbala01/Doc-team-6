package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

//import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.entity.Message;
import com.esports.project.entity.MessageReadStatus;
import com.esports.project.exception.NotFoundException;
import com.esports.project.exception.ValidationException;
import com.esports.project.repository.MessageReadStatusRepository;

@ExtendWith(MockitoExtension.class)
class MessageReadStatusServiceTest {

    @Mock
    private MessageReadStatusRepository repository;

    @InjectMocks
    private MessageReadStatusService service;

    @Test
    void shouldGetAllMessageReadStatuses()
    {
        when(repository.findAll())
                .thenReturn(List.of(
                        new MessageReadStatus(),
                        new MessageReadStatus()));

        List<MessageReadStatus> result =
                service.getAllMessageReadStatus();

        assertEquals(2, result.size());
    }

    @Test
    void shouldGetStatusById()
    {
        MessageReadStatus status =
                new MessageReadStatus();

        status.setId("123");

        when(repository.findById("123"))
                .thenReturn(Optional.of(status));

        MessageReadStatus result =
                service.getStatusById("123");

        assertEquals("123", result.getId());
    }

    @Test
    void shouldThrowWhenStatusNotFound()
    {
        when(repository.findById("123"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.getStatusById("123"));
    }

    @Test
    void shouldGetStatusesByMessageId()
    {
        when(repository.findByMessage_Id("message-1"))
                .thenReturn(List.of(
                        new MessageReadStatus(),
                        new MessageReadStatus(),
                        new MessageReadStatus()));

        List<MessageReadStatus> result =
                service.getByMessageId("message-1");

        assertEquals(3, result.size());
    }

    @Test
    void shouldAddMessageReadStatus()
    {
        MessageReadStatus status =
                new MessageReadStatus();

        Message message =
                new Message();

        status.setMessage(message);

        when(repository.save(any()))
                .thenAnswer(invocation ->
                        invocation.getArgument(0));

        MessageReadStatus result =
                service.addMessageReadStatus(status);

        assertNotNull(result);
    }

    @Test
    void shouldThrowWhenMessageMissing()
    {
        MessageReadStatus status =
                new MessageReadStatus();

        assertThrows(
                ValidationException.class,
                () -> service.addMessageReadStatus(status));
    }

    @Test
    void shouldUpdateMessageReadStatus()
    {
        MessageReadStatus existing =
                new MessageReadStatus();

        existing.setId("123");

        MessageReadStatus update =
                new MessageReadStatus();

        update.setId("123");
        update.setReadBy("alan");

        when(repository.findById("123"))
                .thenReturn(Optional.of(existing));

        when(repository.save(any()))
                .thenAnswer(invocation ->
                        invocation.getArgument(0));

        MessageReadStatus result =
                service.updateMessageReadStatus(update);

        assertEquals(
                "alan",
                result.getReadBy());

        assertNotNull(
                result.getReadAt());
    }

    @Test
    void shouldThrowWhenUpdatingMissingStatus()
    {
        MessageReadStatus update =
                new MessageReadStatus();

        update.setId("123");

        when(repository.findById("123"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> service.updateMessageReadStatus(update));
    }

    @Test
    void shouldDeleteMessageReadStatus()
    {
        when(repository.existsById("123"))
                .thenReturn(true);

        service.deleteMessageReadStatus("123");

        verify(repository)
                .deleteById("123");
    }

    @Test
    void shouldThrowWhenDeletingMissingStatus()
    {
        when(repository.existsById("123"))
                .thenReturn(false);

        assertThrows(
                NotFoundException.class,
                () -> service.deleteMessageReadStatus("123"));
    }
}