package com.esport.project.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.CreateSubscriptionPlanRequestDTO;
import com.esports.project.DTO.SubscriptionPlanResponseDTO;
import com.esports.project.DTO.UpdateSubscriptionPlanRequestDTO;
import com.esports.project.entity.SubscriptionPlan;
import com.esports.project.enums.SubscriptionType;
import com.esports.project.exception.NotFoundException;
import com.esports.project.repository.SubscriptionPlanRepository;
import com.esports.project.service.impl.SubscriptionPlanServiceImpl;

@ExtendWith(MockitoExtension.class)
class SubscriptionPlanServiceImplTest {

    @Mock
    private SubscriptionPlanRepository subscriptionPlanRepository;

    @InjectMocks
    private SubscriptionPlanServiceImpl subscriptionPlanService;

    private SubscriptionPlan subscriptionPlan;

    @BeforeEach
    void setUp() {

        subscriptionPlan = new SubscriptionPlan();
        subscriptionPlan.setId("PLAN001");
        subscriptionPlan.setName("Premium Brand Plan");
        subscriptionPlan.setUserType(SubscriptionType.BRAND);
        subscriptionPlan.setPrice(BigDecimal.valueOf(999));
        subscriptionPlan.setDurationDays(30);
    }

    // ==================================================
    // CREATE PLAN
    // ==================================================

    @Test
    void createPlan_Positive() {

        CreateSubscriptionPlanRequestDTO request =
                new CreateSubscriptionPlanRequestDTO();

        request.setName("Premium Brand Plan");
        request.setUserType(SubscriptionType.BRAND);
        request.setPrice(BigDecimal.valueOf(999));
        request.setDurationDays(30);

        when(subscriptionPlanRepository.save(any()))
                .thenReturn(subscriptionPlan);

        SubscriptionPlanResponseDTO response =
                subscriptionPlanService.createPlan(request);

        assertNotNull(response);
        assertEquals("PLAN001", response.getId());
        assertEquals("Premium Brand Plan", response.getName());
        assertEquals(SubscriptionType.BRAND, response.getUserType());
        assertEquals(BigDecimal.valueOf(999), response.getPrice());
        assertEquals(30, response.getDurationDays());

        verify(subscriptionPlanRepository).save(any());
    }

    @Test
    void createPlan_ZeroPrice_EdgeCase() {

        CreateSubscriptionPlanRequestDTO request =
                new CreateSubscriptionPlanRequestDTO();

        request.setName("Free Plan");
        request.setUserType(SubscriptionType.INFLUENCER);
        request.setPrice(BigDecimal.ZERO);
        request.setDurationDays(1);

        when(subscriptionPlanRepository.save(any()))
                .thenReturn(subscriptionPlan);

        assertDoesNotThrow(
                () -> subscriptionPlanService.createPlan(request));
    }

    @Test
    void createPlan_LongDuration_EdgeCase() {

        CreateSubscriptionPlanRequestDTO request =
                new CreateSubscriptionPlanRequestDTO();

        request.setName("Annual Plan");
        request.setUserType(SubscriptionType.ORGANIZER);
        request.setPrice(BigDecimal.valueOf(9999));
        request.setDurationDays(365);

        when(subscriptionPlanRepository.save(any()))
                .thenReturn(subscriptionPlan);

        assertDoesNotThrow(
                () -> subscriptionPlanService.createPlan(request));
    }

    // ==================================================
    // UPDATE PLAN
    // ==================================================

    @Test
    void updatePlan_NameOnly() {

        UpdateSubscriptionPlanRequestDTO request =
                new UpdateSubscriptionPlanRequestDTO();

        request.setName("Updated Plan");

        when(subscriptionPlanRepository.findById("PLAN001"))
                .thenReturn(Optional.of(subscriptionPlan));

        when(subscriptionPlanRepository.save(any()))
                .thenReturn(subscriptionPlan);

        assertNotNull(
                subscriptionPlanService.updatePlan(
                        "PLAN001",
                        request));

        verify(subscriptionPlanRepository).save(any());
    }

    @Test
    void updatePlan_UserTypeOnly() {

        UpdateSubscriptionPlanRequestDTO request =
                new UpdateSubscriptionPlanRequestDTO();

        request.setUserType(SubscriptionType.ORGANIZER);

        when(subscriptionPlanRepository.findById("PLAN001"))
                .thenReturn(Optional.of(subscriptionPlan));

        when(subscriptionPlanRepository.save(any()))
                .thenReturn(subscriptionPlan);

        assertDoesNotThrow(
                () -> subscriptionPlanService.updatePlan(
                        "PLAN001",
                        request));
    }

    @Test
    void updatePlan_PriceOnly() {

        UpdateSubscriptionPlanRequestDTO request =
                new UpdateSubscriptionPlanRequestDTO();

        request.setPrice(BigDecimal.valueOf(1999));

        when(subscriptionPlanRepository.findById("PLAN001"))
                .thenReturn(Optional.of(subscriptionPlan));

        when(subscriptionPlanRepository.save(any()))
                .thenReturn(subscriptionPlan);

        assertDoesNotThrow(
                () -> subscriptionPlanService.updatePlan(
                        "PLAN001",
                        request));
    }

    @Test
    void updatePlan_DurationOnly() {

        UpdateSubscriptionPlanRequestDTO request =
                new UpdateSubscriptionPlanRequestDTO();

        request.setDurationDays(180);

        when(subscriptionPlanRepository.findById("PLAN001"))
                .thenReturn(Optional.of(subscriptionPlan));

        when(subscriptionPlanRepository.save(any()))
                .thenReturn(subscriptionPlan);

        assertDoesNotThrow(
                () -> subscriptionPlanService.updatePlan(
                        "PLAN001",
                        request));
    }

    @Test
    void updatePlan_AllFields() {

        UpdateSubscriptionPlanRequestDTO request =
                new UpdateSubscriptionPlanRequestDTO();

        request.setName("Ultimate Plan");
        request.setUserType(SubscriptionType.INFLUENCER);
        request.setPrice(BigDecimal.valueOf(2999));
        request.setDurationDays(365);

        when(subscriptionPlanRepository.findById("PLAN001"))
                .thenReturn(Optional.of(subscriptionPlan));

        when(subscriptionPlanRepository.save(any()))
                .thenReturn(subscriptionPlan);

        assertNotNull(
                subscriptionPlanService.updatePlan(
                        "PLAN001",
                        request));
    }

    @Test
    void updatePlan_AllFieldsNull_EdgeCase() {

        UpdateSubscriptionPlanRequestDTO request =
                new UpdateSubscriptionPlanRequestDTO();

        when(subscriptionPlanRepository.findById("PLAN001"))
                .thenReturn(Optional.of(subscriptionPlan));

        when(subscriptionPlanRepository.save(any()))
                .thenReturn(subscriptionPlan);

        assertDoesNotThrow(
                () -> subscriptionPlanService.updatePlan(
                        "PLAN001",
                        request));
    }

    @Test
    void updatePlan_NotFound_Negative() {

        UpdateSubscriptionPlanRequestDTO request =
                new UpdateSubscriptionPlanRequestDTO();

        when(subscriptionPlanRepository.findById("INVALID"))
                .thenReturn(Optional.empty());

        NotFoundException exception =
                assertThrows(
                        NotFoundException.class,
                        () -> subscriptionPlanService.updatePlan(
                                "INVALID",
                                request));

        assertTrue(
                exception.getMessage().contains(
                        "Subscription Plan not found"));
    }

    // ==================================================
    // DELETE PLAN
    // ==================================================

    @Test
    void deletePlan_Positive() {

        when(subscriptionPlanRepository.findById("PLAN001"))
                .thenReturn(Optional.of(subscriptionPlan));

        subscriptionPlanService.deletePlan("PLAN001");

        verify(subscriptionPlanRepository)
                .delete(subscriptionPlan);
    }

    @Test
    void deletePlan_NotFound_Negative() {

        when(subscriptionPlanRepository.findById("INVALID"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> subscriptionPlanService.deletePlan("INVALID"));
    }

    // ==================================================
    // GET ALL PLANS
    // ==================================================

    @Test
    void getAllPlans_Positive() {

        when(subscriptionPlanRepository.findAll())
                .thenReturn(Arrays.asList(subscriptionPlan));

        assertEquals(
                1,
                subscriptionPlanService.getAllPlans().size());
    }

    @Test
    void getAllPlans_Empty_Negative() {

        when(subscriptionPlanRepository.findAll())
                .thenReturn(Collections.emptyList());

        assertThrows(
                NotFoundException.class,
                () -> subscriptionPlanService.getAllPlans());
    }

    @Test
    void getAllPlans_Multiple_EdgeCase() {

        SubscriptionPlan plan2 = new SubscriptionPlan();
        plan2.setId("PLAN002");
        plan2.setUserType(SubscriptionType.ORGANIZER);

        SubscriptionPlan plan3 = new SubscriptionPlan();
        plan3.setId("PLAN003");
        plan3.setUserType(SubscriptionType.INFLUENCER);

        when(subscriptionPlanRepository.findAll())
                .thenReturn(Arrays.asList(
                        subscriptionPlan,
                        plan2,
                        plan3));

        assertEquals(
                3,
                subscriptionPlanService.getAllPlans().size());
    }

    // ==================================================
    // GET BY USER TYPE
    // ==================================================

    @Test
    void getPlansByUserType_Positive() {

        when(subscriptionPlanRepository.findByUserType(
                SubscriptionType.BRAND))
                .thenReturn(Arrays.asList(subscriptionPlan));

        assertEquals(
                1,
                subscriptionPlanService.getPlansByUserType(
                        SubscriptionType.BRAND).size());
    }

    @Test
    void getPlansByUserType_NotFound_Negative() {

        when(subscriptionPlanRepository.findByUserType(
                SubscriptionType.BRAND))
                .thenReturn(Collections.emptyList());

        assertThrows(
                NotFoundException.class,
                () -> subscriptionPlanService.getPlansByUserType(
                        SubscriptionType.BRAND));
    }

    @Test
    void getPlansByUserType_Organizer_EdgeCase() {

        subscriptionPlan.setUserType(
                SubscriptionType.ORGANIZER);

        when(subscriptionPlanRepository.findByUserType(
                SubscriptionType.ORGANIZER))
                .thenReturn(Arrays.asList(subscriptionPlan));

        var response =
                subscriptionPlanService.getPlansByUserType(
                        SubscriptionType.ORGANIZER);

        assertEquals(
                SubscriptionType.ORGANIZER,
                response.get(0).getUserType());
    }
}