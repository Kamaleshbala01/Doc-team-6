package com.esports.project.service.interfaces;
import java.util.List;

import com.esports.project.DTO.CreateSubscriptionPlanRequestDTO;
import com.esports.project.DTO.SubscriptionPlanResponseDTO;
import com.esports.project.DTO.UpdateSubscriptionPlanRequestDTO;
import com.esports.project.enums.SubscriptionType;



public interface SubscriptionPlanService {

    SubscriptionPlanResponseDTO createPlan(
            CreateSubscriptionPlanRequestDTO request);

    SubscriptionPlanResponseDTO updatePlan(
            String planId,
            UpdateSubscriptionPlanRequestDTO request);

    void deletePlan(String planId);

    List<SubscriptionPlanResponseDTO> getAllPlans();

    List<SubscriptionPlanResponseDTO> getPlansByUserType(
            SubscriptionType userType);
}
