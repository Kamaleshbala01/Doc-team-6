package com.esports.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.CreateSubscriptionRequestDTO;
import com.esports.project.DTO.SubscriptionFilterDTO;
import com.esports.project.DTO.UserSubscriptionResponseDTO;
import com.esports.project.enums.SubscriptionType;
import com.esports.project.service.interfaces.UserSubscriptionService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/payment/subscriptions")
@RequiredArgsConstructor
public class UserSubscriptionController {

    @Autowired
    private UserSubscriptionService userSubscriptionService;

    /**
     * Create subscription
     * Accessible by Brand/Influencer
     */
    @PostMapping
    @PreAuthorize("hasAuthority('SUBSCRIPTION_CREATE')")
    public ResponseEntity<UserSubscriptionResponseDTO> createSubscription(
            @Valid @RequestBody CreateSubscriptionRequestDTO request) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(userSubscriptionService.createSubscription(request));
    }

    /**
     * Get subscription by Id
     * User can only view their own subscription
     */
    @GetMapping("/{subscriptionId}")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_VIEW')")
    public ResponseEntity<UserSubscriptionResponseDTO> getSubscriptionById(
            @PathVariable String subscriptionId,
            @RequestParam String userId) {

        return ResponseEntity.ok(
                userSubscriptionService.getSubscriptionById(subscriptionId, userId)
        );
    }

    /**
     * Get all subscriptions of a user
     */
    @GetMapping("/user/{userId}")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_VIEW_USER')")
    public ResponseEntity<List<UserSubscriptionResponseDTO>> getSubscriptionsByUserId(
            @PathVariable String userId) {

        return ResponseEntity.ok(
                userSubscriptionService.getSubscriptionsByUserId(userId)
        );
    }

    /**
     * Admin - Cancel subscription
     */
    @PutMapping("/{subscriptionId}/cancel")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_CANCEL')")
    public ResponseEntity<UserSubscriptionResponseDTO> cancelSubscription(
            @PathVariable String subscriptionId) {

        return ResponseEntity.ok(
                userSubscriptionService.cancelSubscription(subscriptionId)
        );
    }

    /**
     * Admin - View all subscriptions
     */
    @GetMapping("/all")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_VIEW_ALL')")
    public ResponseEntity<List<UserSubscriptionResponseDTO>> getAllSubscriptions() {

        return ResponseEntity.ok(
                userSubscriptionService.getAllSubscriptions()
        );
    }

    /**
     * Admin - View subscriptions based on plan
     */
    @GetMapping("/plan/{planId}")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_VIEW_BY_PLAN')")
    public ResponseEntity<List<UserSubscriptionResponseDTO>> getSubscriptionsByPlan(
            @PathVariable String planId) {

        return ResponseEntity.ok(
                userSubscriptionService.getSubscriptionsByPlan(planId)
        );
    }

    /**
     * Admin - View Brand subscriptions
     */
    @GetMapping("/brands")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_VIEW_BRANDS')")
    public ResponseEntity<List<UserSubscriptionResponseDTO>> getBrandSubscriptions() {

        return ResponseEntity.ok(
                userSubscriptionService.getSubscriptionsByUserType(
                        SubscriptionType.BRAND)
        );
    }

    /**
     * Admin - View Influencer subscriptions
     */
    @GetMapping("/influencers")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_VIEW_INFLUENCERS')")
    public ResponseEntity<List<UserSubscriptionResponseDTO>> getInfluencerSubscriptions() {

        return ResponseEntity.ok(
                userSubscriptionService.getSubscriptionsByUserType(
                        SubscriptionType.INFLUENCER)
        );
    }

    /**
     * Admin - View expired subscriptions
     */
    @GetMapping("/expired")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_VIEW_EXPIRED')")
    public ResponseEntity<List<UserSubscriptionResponseDTO>> getExpiredSubscriptions() {

        return ResponseEntity.ok(
                userSubscriptionService.getExpiredSubscriptions()
        );
    }

    /**
     * Admin - View active subscriptions
     */
    @GetMapping("/active")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_VIEW_ACTIVE')")
    public ResponseEntity<List<UserSubscriptionResponseDTO>> getActiveSubscriptions() {

        return ResponseEntity.ok(
                userSubscriptionService.getActiveSubscriptions()
        );
    }

    /**
     * Admin - Combined filters
     */
    @GetMapping("/filter")
    @PreAuthorize("hasAuthority('SUBSCRIPTION_FILTER')")
    public ResponseEntity<List<UserSubscriptionResponseDTO>> filterSubscriptions(
            @RequestBody SubscriptionFilterDTO filterDTO) {

        return ResponseEntity.ok(
                userSubscriptionService.filterSubscriptions(filterDTO)
        );
    }
}