package com.esports.project.service.interfaces;

import java.util.List;

import com.esports.project.DTO.TournamentRegistrationPaymentRequestDTO;
import com.esports.project.DTO.TournamentRegistrationPaymentResponseDTO;
import com.esports.project.entity.TournamentRegistrationPayment;
import com.esports.project.enums.TournamentPaymentStatus;

public interface TournamentRegistrationPaymentServiceInterface {

	TournamentRegistrationPaymentResponseDTO registerTournamentPayment(TournamentRegistrationPaymentRequestDTO requestDTO);

    TournamentPaymentStatus getTournamentPaymentStatus(String registrationId);

    List<TournamentRegistrationPayment> getPaymentHistory(String userId);
    
    TournamentRegistrationPayment raiseCancellationRequest(
            String registrationId);

    List<TournamentRegistrationPayment> getCancellationRequests();

    TournamentRegistrationPayment approveCancellation(
            String registrationId);

    TournamentRegistrationPayment rejectCancellation(
            String registrationId);

    TournamentPaymentStatus getCancellationStatus(
            String registrationId);
}