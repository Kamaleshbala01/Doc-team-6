package com.esports.project.enums;

public enum TournamentPaymentStatus {

    PENDING,
    SUCCESS,
    FAILED,

    PENDING_CANCELLATION,
    CANCELLED,
    CANCELLATION_REJECTED
}