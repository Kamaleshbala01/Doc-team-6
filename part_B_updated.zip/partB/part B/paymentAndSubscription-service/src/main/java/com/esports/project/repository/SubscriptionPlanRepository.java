package com.esports.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.SubscriptionPlan;
import com.esports.project.enums.SubscriptionType;

@Repository
public interface SubscriptionPlanRepository extends JpaRepository<SubscriptionPlan, String>{
      List<SubscriptionPlan> findByUserType(SubscriptionType userType);
}

