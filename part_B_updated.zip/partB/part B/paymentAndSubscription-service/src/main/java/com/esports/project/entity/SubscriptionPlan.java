package com.esports.project.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.esports.project.enums.SubscriptionType;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Index;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "subscription_plans", indexes = { @Index(name = "idx_subscription_plans_user_type", columnList = "user_type") })
public class SubscriptionPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String name;

    @Enumerated(EnumType.STRING)
    private SubscriptionType userType;
    private BigDecimal price;
    private Integer durationDays;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    /*
     * Subscription  mapping
     */

    @OneToMany(mappedBy = "subscriptionPlan",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-subscription")
    private List<UserSubscription> userSubscriptions;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public SubscriptionType getUserType() {
		return userType;
	}

	public void setUserType(SubscriptionType userType) {
		this.userType = userType;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getDurationDays() {
		return durationDays;
	}

	public void setDurationDays(Integer durationDays) {
		this.durationDays = durationDays;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<UserSubscription> getUserSubscriptions() {
		return userSubscriptions;
	}

	public void setUserSubscriptions(List<UserSubscription> userSubscriptions) {
		this.userSubscriptions = userSubscriptions;
	}
    
    
}
