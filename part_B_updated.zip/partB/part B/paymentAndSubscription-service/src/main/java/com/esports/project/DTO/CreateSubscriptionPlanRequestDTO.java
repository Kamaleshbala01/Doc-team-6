package com.esports.project.DTO;



import java.math.BigDecimal;

import com.esports.project.enums.SubscriptionType;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class CreateSubscriptionPlanRequestDTO {

    @NotBlank
    private String name;

    @NotNull
    private SubscriptionType userType;

    @NotNull
    private BigDecimal price;

    @NotNull
    private Integer durationDays;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public SubscriptionType getUserType() {
		return userType;
	}

	public void setUserType(SubscriptionType userType) {
		this.userType = userType;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getDurationDays() {
		return durationDays;
	}

	public void setDurationDays(Integer durationDays) {
		this.durationDays = durationDays;
	}
    
    
}
