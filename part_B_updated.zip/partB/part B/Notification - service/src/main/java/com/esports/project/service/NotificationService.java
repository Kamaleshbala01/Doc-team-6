package com.esports.project.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.esports.project.entity.Notification;
import com.esports.project.repository.NotificationRepository;
import com.esports.project.DTO.NotificationEventDTO;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

   public void createNotification(NotificationEventDTO request) {
        Notification notification = new Notification();
        notification.setTitle(request.getTitle());
        notification.setUserId(request.getUserId());
        notification.setMessage(request.getMessage());
        notification.setCreatedAt(LocalDateTime.now());
        notificationRepository.save(notification);
    }

    public List<Notification> getAllNotifications() {
        return notificationRepository.findAll();
    }

    public Notification getNotificationById(String id) {
        return notificationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Notification not found"));
    }

    public Notification updateNotification(String id, Notification notification) {

        Notification existing = getNotificationById(id);

        existing.setTitle(notification.getTitle());
        existing.setMessage(notification.getMessage());
        existing.setIsRead(notification.getIsRead());

        return notificationRepository.save(existing);
    }

    public void deleteNotification(String id) {
        notificationRepository.deleteById(id);
    }

    public Notification markAsRead(String id) {

        Notification notification = getNotificationById(id);
        notification.setIsRead(true);

        return notificationRepository.save(notification);
    }

    public List<Notification> getNotificationsByUser(String userId) {
        return notificationRepository.findByUserId(userId);
    }
}