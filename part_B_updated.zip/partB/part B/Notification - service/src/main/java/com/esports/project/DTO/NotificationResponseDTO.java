package com.esports.project.DTO;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NotificationResponseDTO {

    private String id;

    private String title;

    private String message;

    private Boolean isRead;

    private LocalDateTime createdAt;

    private String userId;
}