package com.esports.project.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Index;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "notifications", indexes = { @Index(name = "idx_notifications_user_id", columnList = "user_id"), @Index(name = "idx_notifications_is_read", columnList = "is_read") })
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String title;
    private String message;
    private Boolean isRead;
    private LocalDateTime createdAt;


    private String userId;
}
