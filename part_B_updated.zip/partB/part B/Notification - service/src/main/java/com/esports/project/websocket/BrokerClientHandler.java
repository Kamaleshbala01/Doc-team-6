package com.esports.project.websocket;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.esports.project.DTO.NotificationEventDTO;
import com.esports.project.service.NotificationService;
import com.esports.project.DTO.BrokerMessage;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class BrokerClientHandler
                extends TextWebSocketHandler {

        private final ObjectMapper objectMapper;
        private final NotificationService notification;

        @Override
        protected void handleTextMessage(
                        WebSocketSession session,
                        TextMessage message)
                        throws Exception {

                String payload = message.getPayload();

                System.out.println(
                                "RECEIVED -> " + payload);

                // Ignore broker status messages
                if (!payload.trim().startsWith("{")) {

                        System.out.println(
                                        "Ignoring broker status message");

                        return;
                }

                BrokerMessage brokerMessage = objectMapper.readValue(
                                payload,
                                BrokerMessage.class);

                if (brokerMessage.getTopic().endsWith(".notification")) {

                        NotificationEventDTO event = objectMapper.convertValue(
                                        brokerMessage.getPayload(),
                                        NotificationEventDTO.class);

                        try {
                                notification.createNotification(event);

                        } catch (Exception e) {
                                System.out.println("Social media Event subscribtion : " + e.getMessage());

                        } finally {
                                BrokerMessage ack = new BrokerMessage();

                                ack.setType("ACK");
                                ack.setTopic(
                                                brokerMessage.getTopic());

                                ack.setOffset(
                                                brokerMessage.getOffset());

                                session.sendMessage(
                                                new TextMessage(
                                                                objectMapper.writeValueAsString(
                                                                                ack)));

                                System.out.println(
                                                "ACK SENT -> "
                                                                + brokerMessage.getOffset());
                        }

                }
        }
}