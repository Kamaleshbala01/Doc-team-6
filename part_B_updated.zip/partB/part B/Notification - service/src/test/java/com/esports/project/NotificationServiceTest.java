package com.esports.project;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.esports.project.DTO.NotificationRequestDTO;
import com.esports.project.DTO.NotificationResponseDTO;
import com.esports.project.entity.Notification;
import com.esports.project.repository.NotificationRepository;
import com.esports.project.service.NotificationService;

@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {

    @Mock
    private NotificationRepository notificationRepository;

    @InjectMocks
    private NotificationService notificationService;




   @Test
void testGetAllNotifications() {

    List<Notification> notifications = List.of(
            mock(Notification.class),
            mock(Notification.class));

    when(notificationRepository.findAll())
            .thenReturn(notifications);

    List<Notification> result =
            notificationService.getAllNotifications();

    assertEquals(2, result.size());

    verify(notificationRepository).findAll();
}

   @Test
void testGetNotificationByIdSuccess() {

    Notification notification = mock(Notification.class);

    when(notificationRepository.findById("NOTIF001"))
            .thenReturn(Optional.of(notification));

    Notification result =
            notificationService.getNotificationById("NOTIF001");

    assertNotNull(result);

    verify(notificationRepository)
            .findById("NOTIF001");
}

    @Test
void testGetNotificationByIdNotFound() {

    when(notificationRepository.findById("NOTIF001"))
            .thenReturn(Optional.empty());

    RuntimeException exception =
            assertThrows(RuntimeException.class,
                    () -> notificationService.getNotificationById("NOTIF001"));

    assertEquals("Notification not found",
            exception.getMessage());
}


 

    @Test
void testGetNotificationsByUser() {

    List<Notification> notifications = List.of(
            mock(Notification.class),
            mock(Notification.class));

    when(notificationRepository.findByUserId("USER001"))
            .thenReturn(notifications);

    List<Notification> result =
            notificationService.getNotificationsByUser("USER001");

    assertEquals(2, result.size());

    verify(notificationRepository)
            .findByUserId("USER001");
}
}