package com.example.eventbus.core;

import com.example.eventbus.exception.EventBusException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The heart of the system: an in-memory, thread-safe, asynchronous
 * publish-subscribe broker - the "Kafka topic router" equivalent.
 *
 * DESIGN:
 *   - subscribers is a Map<eventClass, list-of-subscribers>. Each event type
 *     is effectively its own "topic".
 *   - ConcurrentHashMap + CopyOnWriteArrayList: subscription changes are rare,
 *     publishes are frequent, so we optimize reads (iteration during publish)
 *     over writes (subscribe/unsubscribe), while remaining fully thread-safe
 *     without external locking.
 *   - publish() never blocks the publisher: it hands each subscriber off to
 *     AsyncEventDispatcher, which runs on the TaskExecutor thread pool.
 *
 * WHY IT EXISTS:
 *   This is the concrete "broker" behind the EventBus abstraction - the only
 *   class that actually knows about the subscription registry.
 *
 * SOLID:
 *   - Single Responsibility Principle: registry management + fan-out, nothing
 *     else (no business logic, no WebSocket knowledge).
 *   - Open/Closed Principle: supports unlimited new event types and
 *     subscribers without modification.
 *   - Liskov Substitution Principle: fully honors the EventBus/EventPublisher
 *     contracts so it can be swapped for another implementation (e.g. a real
 *     Kafka-backed one) without breaking callers.
 */
@Component
public class InMemoryEventBus implements EventBus {

    private static final Logger log = LoggerFactory.getLogger(InMemoryEventBus.class);

    private final Map<Class<?>, List<EventSubscriber<?>>> subscribers = new ConcurrentHashMap<>();
    private final AsyncEventDispatcher dispatcher;

    public InMemoryEventBus(AsyncEventDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    @Override
    public <T extends Event> void subscribe(Class<T> eventType, EventSubscriber<T> subscriber) {
        Objects.requireNonNull(eventType, "eventType must not be null");
        Objects.requireNonNull(subscriber, "subscriber must not be null");

        subscribers
                .computeIfAbsent(eventType, k -> new CopyOnWriteArrayList<>())
                .add(subscriber);

        log.info("Registered subscriber [{}] for event type [{}]",
                subscriber.getClass().getSimpleName(), eventType.getSimpleName());
    }

    @Override
    public <T extends Event> void unsubscribe(Class<T> eventType, EventSubscriber<T> subscriber) {
        List<EventSubscriber<?>> list = subscribers.get(eventType);
        if (list != null) {
            list.remove(subscriber);
            log.info("Unregistered subscriber [{}] for event type [{}]",
                    subscriber.getClass().getSimpleName(), eventType.getSimpleName());
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void publish(Event event) {
        if (event == null) {
            throw new EventBusException("Cannot publish a null event");
        }

        List<EventSubscriber<?>> matching = subscribers.get(event.getClass());
        if (matching == null || matching.isEmpty()) {
            log.warn("No subscribers registered for event type [{}] (eventId={})",
                    event.getEventType(), event.getEventId());
            return;
        }

        log.info("Publishing event [{}] (eventId={}) to {} subscriber(s)",
                event.getEventType(), event.getEventId(), matching.size());

        for (EventSubscriber<?> subscriber : matching) {
            // The publisher's thread returns immediately; each subscriber runs
            // independently on the shared TaskExecutor pool.
            dispatcher.dispatch((EventSubscriber<Event>) subscriber, event);
        }
    }

    /** Package-visible helper for tests/metrics: how many subscribers a type currently has. */
    int subscriberCount(Class<?> eventType) {
        List<EventSubscriber<?>> list = subscribers.get(eventType);
        return list == null ? 0 : list.size();
    }
}
