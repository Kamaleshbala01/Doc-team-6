package com.example.eventbus.websocket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

/**
 * Single, reusable gateway from backend event processing to connected STOMP
 * clients. Every subscriber that needs to push a real-time UI update goes
 * through this class instead of touching SimpMessagingTemplate directly.
 *
 * WHY IT EXISTS:
 *   Centralizing topic-name construction ("/topic/tournament/{id}" etc.) in
 *   one place avoids typos/duplication across five different subscribers
 *   and gives us one spot to add logging or payload shaping later.
 *
 * SOLID:
 *   Single Responsibility Principle - this class's only job is "format and
 *   send a message to a STOMP topic".
 */
@Component
public class WebSocketBroadcaster {

    private static final Logger log = LoggerFactory.getLogger(WebSocketBroadcaster.class);

    private final SimpMessagingTemplate messagingTemplate;

    public WebSocketBroadcaster(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    public void broadcastTournamentUpdate(String tournamentId, Object payload) {
        String destination = "/topic/tournament/" + tournamentId;
        log.debug("Broadcasting to {} -> {}", destination, payload);
        messagingTemplate.convertAndSend(destination, payload);
    }

    public void broadcastMatchUpdate(String matchIdOrTournamentId, Object payload) {
        String destination = "/topic/match/" + matchIdOrTournamentId;
        log.debug("Broadcasting to {} -> {}", destination, payload);
        messagingTemplate.convertAndSend(destination, payload);
    }

    public void broadcastNotification(String userId, Object payload) {
        String destination = "/topic/notification/" + userId;
        log.debug("Broadcasting to {} -> {}", destination, payload);
        messagingTemplate.convertAndSend(destination, payload);
    }
}
