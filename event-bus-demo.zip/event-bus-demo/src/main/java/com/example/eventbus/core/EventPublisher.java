package com.example.eventbus.core;

/**
 * Narrow contract for components that only need to PUBLISH events and must
 * never be able to subscribe or manage subscriptions.
 *
 * WHY IT EXISTS:
 *   TournamentService should not have access to subscribe()/unsubscribe().
 *   By injecting EventPublisher instead of the full EventBus, we guarantee
 *   at compile time that publishers cannot accidentally register listeners
 *   or reach into other services' subscriptions.
 *
 * SOLID:
 *   Interface Segregation Principle - publishers see only the "publish"
 *   slice of the bus's API surface.
 */
public interface EventPublisher {

    /**
     * Publish an event to the bus. Dispatch to subscribers happens
     * asynchronously; this method returns immediately (fire-and-forget from
     * the publisher's point of view).
     */
    void publish(Event event);
}
