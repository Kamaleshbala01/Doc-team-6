package com.example.eventbus.notification;

import com.example.eventbus.core.EventSubscriber;
import com.example.eventbus.events.TournamentRegistrationClosedEvent;
import com.example.eventbus.websocket.WebSocketBroadcaster;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * SUBSCRIBER #2: notifies every registered team/user that registration has
 * closed, pushing each notification to that user's own STOMP topic.
 *
 * WHY IT EXISTS:
 *   Shows the SAME event fanning out to a completely different concern
 *   (user-facing notifications) in parallel with match generation - neither
 *   subscriber is aware of, or depends on, the other.
 *
 * SOLID:
 *   Single Responsibility Principle - only builds and delivers notifications.
 */
@Component
public class NotificationSubscriber implements EventSubscriber<TournamentRegistrationClosedEvent> {

    private static final Logger log = LoggerFactory.getLogger(NotificationSubscriber.class);

    private final WebSocketBroadcaster broadcaster;

    public NotificationSubscriber(WebSocketBroadcaster broadcaster) {
        this.broadcaster = broadcaster;
    }

    @Override
    public void onEvent(TournamentRegistrationClosedEvent event) {
        log.info("[NotificationSubscriber] Notifying {} team(s) for tournament [{}]",
                event.getRegisteredTeamIds().size(), event.getTournamentId());

        for (String teamId : event.getRegisteredTeamIds()) {
            String message = "Registration closed for '" + event.getTournamentName() + "'. Matches are being generated.";
            broadcaster.broadcastNotification(teamId, Map.of(
                    "tournamentId", event.getTournamentId(),
                    "userId", teamId,
                    "message", message
            ));
        }
    }

    @Override
    public Class<TournamentRegistrationClosedEvent> getEventType() {
        return TournamentRegistrationClosedEvent.class;
    }
}
