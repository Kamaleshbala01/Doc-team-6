package com.example.eventbus.exception;

/**
 * Raised for event-bus-level failures (e.g. invalid registration).
 * Deliberately NOT thrown for a single subscriber's failure during
 * dispatch - see AsyncEventDispatcher, which isolates subscriber
 * exceptions so one bad listener can never break the others or the
 * publisher.
 */
public class EventBusException extends RuntimeException {

    public EventBusException(String message) {
        super(message);
    }

    public EventBusException(String message, Throwable cause) {
        super(message, cause);
    }
}
