package com.example.eventbus.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Declares the dedicated thread pool used to run subscriber callbacks.
 *
 * WHY A DEDICATED POOL:
 *   Using a named executor ("eventTaskExecutor") instead of Spring's default
 *   SimpleAsyncTaskExecutor gives us bounded concurrency (core/max pool size
 *   + queue capacity), so a burst of events can't spawn unbounded threads.
 *   This is our stand-in for Kafka's consumer thread pool.
 *
 * SOLID:
 *   Single Responsibility Principle - this class's only job is executor
 *   configuration; it knows nothing about events or subscribers.
 */
@Configuration
@EnableAsync
public class AsyncConfig {

    @Value("${eventbus.executor.core-pool-size:8}")
    private int corePoolSize;

    @Value("${eventbus.executor.max-pool-size:16}")
    private int maxPoolSize;

    @Value("${eventbus.executor.queue-capacity:200}")
    private int queueCapacity;

    @Value("${eventbus.executor.thread-name-prefix:event-bus-}")
    private String threadNamePrefix;

    @Bean(name = "eventTaskExecutor")
    public Executor eventTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setThreadNamePrefix(threadNamePrefix);
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(10);
        executor.initialize();
        return executor;
    }
}
