package com.example.eventbus.tournament;

import com.example.eventbus.core.EventPublisher;
import com.example.eventbus.events.TournamentRegistrationClosedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * THE PUBLISHER in our worked example.
 *
 * WHY IT EXISTS:
 *   Owns the tournament registration lifecycle. When registration closes it
 *   publishes a TournamentRegistrationClosedEvent and moves on - it never
 *   calls MatchService, NotificationService, LiveScoreService or
 *   AuditService directly, and has no import/reference to any of them
 *   anywhere in this class. That decoupling is the entire point of the
 *   architecture.
 *
 * SOLID:
 *   - Single Responsibility Principle: owns tournament state only.
 *   - Dependency Inversion Principle: depends on EventPublisher (the
 *     narrowest possible abstraction), not on EventBus and definitely not
 *     on any subscriber.
 */
@Service
public class TournamentService {

    private static final Logger log = LoggerFactory.getLogger(TournamentService.class);

    private final EventPublisher eventPublisher;
    private final Map<String, TournamentRecord> tournaments = new ConcurrentHashMap<>();

    public TournamentService(EventPublisher eventPublisher) {
        this.eventPublisher = eventPublisher;
    }

    /** Seeds a demo tournament with some registered teams. */
    public TournamentRecord createDemoTournament(String tournamentId, String name, List<String> teamIds) {
        TournamentRecord record = new TournamentRecord(tournamentId, name, teamIds, false);
        tournaments.put(tournamentId, record);
        log.info("Created tournament [{}] '{}' with {} registered teams", tournamentId, name, teamIds.size());
        return record;
    }

    /**
     * Closes registration for the given tournament and publishes the event.
     * This method returns as soon as publish() returns - it does NOT wait
     * for Match/Notification/LiveScore/Audit to finish (they run async).
     */
    public TournamentRecord closeRegistration(String tournamentId) {
        TournamentRecord record = tournaments.get(tournamentId);
        if (record == null) {
            throw new IllegalArgumentException("Unknown tournament id: " + tournamentId);
        }
        if (record.registrationClosed()) {
            log.warn("Registration already closed for tournament [{}]", tournamentId);
            return record;
        }

        TournamentRecord closed = record.withClosed(true);
        tournaments.put(tournamentId, closed);

        log.info("Registration closed for tournament [{}] '{}'", tournamentId, record.name());

        TournamentRegistrationClosedEvent event = new TournamentRegistrationClosedEvent(
                closed.id(), closed.name(), closed.teamIds());

        eventPublisher.publish(event);

        return closed;
    }

    public TournamentRecord get(String tournamentId) {
        TournamentRecord record = tournaments.get(tournamentId);
        if (record == null) {
            throw new IllegalArgumentException("Unknown tournament id: " + tournamentId);
        }
        return record;
    }

    /** Simple immutable snapshot of a tournament's state. */
    public record TournamentRecord(String id, String name, List<String> teamIds, boolean registrationClosed) {
        TournamentRecord withClosed(boolean closed) {
            return new TournamentRecord(id, name, teamIds, closed);
        }
    }
}
