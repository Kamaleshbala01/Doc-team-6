package com.example.eventbus.core;

/**
 * Contract implemented by any component that wants to react to a specific
 * event type.
 *
 * WHY IT EXISTS:
 *   The EventBus must be able to hold a heterogeneous collection of
 *   subscribers (Match, Notification, LiveScore, Audit...) and dispatch to
 *   each one without knowing their concrete class. This generic interface
 *   is what makes that possible - it is the "plug" every listener uses to
 *   connect to the bus.
 *
 * SOLID:
 *   - Open/Closed Principle: new subscribers can be added for existing or
 *     new event types without ever touching the EventBus implementation.
 *   - Dependency Inversion Principle: the EventBus depends on this
 *     abstraction, never on concrete subscriber classes.
 *
 * @param <T> the concrete event type this subscriber is interested in
 */
public interface EventSubscriber<T extends Event> {

    /**
     * Called by the bus when an event of type T is published.
     * Implementations should be self-contained: no exception thrown here
     * should be able to affect any other subscriber.
     */
    void onEvent(T event);

    /**
     * The concrete event class this subscriber listens for. Used by the
     * bus's registration mechanism to index this subscriber correctly.
     */
    Class<T> getEventType();
}
