package com.example.eventbus.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * Configures the STOMP-over-WebSocket (with SockJS fallback) message broker
 * used to push real-time updates to browser clients once an event has been
 * processed by its subscribers.
 *
 * TOPICS:
 *   /topic/tournament/{id}   - tournament lifecycle updates
 *   /topic/match/{id}        - match generation / score updates
 *   /topic/notification/{userId} - per-user notifications
 *
 * WHY IT EXISTS:
 *   This is the "last mile" of the architecture: after the in-memory Event
 *   Bus has fanned an event out to backend subscribers, those subscribers
 *   use SimpMessagingTemplate (backed by this broker) to notify any
 *   connected browser clients in real time - no polling required.
 *
 * SOLID:
 *   Single Responsibility Principle - this class only wires transport
 *   (STOMP/SockJS/broker prefixes); it contains no business logic.
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws")
                .setAllowedOriginPatterns("*")
                .withSockJS();
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        // Broker for messages FROM server TO clients (broadcast topics).
        registry.enableSimpleBroker("/topic");
        // Prefix for messages FROM clients TO server-side @MessageMapping handlers.
        registry.setApplicationDestinationPrefixes("/app");
    }
}
