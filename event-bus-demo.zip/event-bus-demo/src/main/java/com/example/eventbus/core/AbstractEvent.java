package com.example.eventbus.core;

import java.time.Instant;
import java.util.UUID;

/**
 * Convenience base class implementing the repetitive parts of {@link Event}.
 *
 * WHY IT EXISTS:
 *   Every concrete event needs an id, a timestamp and a type name. Without
 *   this base class every event would re-implement identical boilerplate.
 *
 * SOLID:
 *   Single Responsibility Principle - this class has exactly one job:
 *   supply the envelope metadata. Domain-specific payload lives in subclasses.
 */
public abstract class AbstractEvent implements Event {

    private final String eventId;
    private final Instant timestamp;

    protected AbstractEvent() {
        this.eventId = UUID.randomUUID().toString();
        this.timestamp = Instant.now();
    }

    @Override
    public String getEventId() {
        return eventId;
    }

    @Override
    public Instant getTimestamp() {
        return timestamp;
    }

    @Override
    public String getEventType() {
        return this.getClass().getSimpleName();
    }
}
