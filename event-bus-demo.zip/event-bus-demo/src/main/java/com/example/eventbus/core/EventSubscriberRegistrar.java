package com.example.eventbus.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * THE REGISTRATION MECHANISM.
 *
 * WHY IT EXISTS:
 *   The requirement states every subscriber "executes independently without
 *   the publisher knowing about them". If TournamentService (the publisher)
 *   had to manually call eventBus.subscribe(...) for every listener, it would
 *   need to know about MatchService, NotificationService, etc. - breaking
 *   the whole point of pub/sub.
 *
 *   Instead, Spring collects every bean implementing EventSubscriber<?> into
 *   a List<EventSubscriber<?>> (constructor injection), and once the
 *   application context is fully up (ApplicationReadyEvent), this class
 *   walks that list and registers each one against the bus using its own
 *   declared getEventType(). Subscribers plug themselves into the bus simply
 *   by existing as a @Component - nobody else needs to know they exist.
 *
 * SOLID:
 *   - Open/Closed Principle: adding a brand-new subscriber for a brand-new
 *     event type requires zero changes to this class, the bus, or the
 *     publisher - just add a new @Component.
 *   - Dependency Inversion Principle: this class depends only on the
 *     EventBus and EventSubscriber abstractions.
 */
@Component
public class EventSubscriberRegistrar {

    private static final Logger log = LoggerFactory.getLogger(EventSubscriberRegistrar.class);

    private final EventBus eventBus;
    private final List<EventSubscriber<?>> subscribers;

    public EventSubscriberRegistrar(EventBus eventBus, List<EventSubscriber<?>> subscribers) {
        this.eventBus = eventBus;
        this.subscribers = subscribers;
    }

    @EventListener(ApplicationReadyEvent.class)
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void registerAllSubscribers() {
        log.info("Auto-registering {} discovered EventSubscriber bean(s)...", subscribers.size());
        for (EventSubscriber<?> subscriber : subscribers) {
            eventBus.subscribe((Class) subscriber.getEventType(), (EventSubscriber) subscriber);
        }
        log.info("Event Bus subscriber auto-registration complete.");
    }
}
