package com.example.eventbus.match;

import com.example.eventbus.core.EventSubscriber;
import com.example.eventbus.events.TournamentRegistrationClosedEvent;
import com.example.eventbus.websocket.WebSocketBroadcaster;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * SUBSCRIBER #1: reacts to registration closing by generating the match
 * bracket, then broadcasts the new matches over /topic/match/{tournamentId}.
 *
 * WHY IT EXISTS:
 *   Demonstrates a subscriber that both (a) performs its own domain logic
 *   (bracket generation) and (b) triggers a real-time UI update - all
 *   without TournamentService knowing this class exists.
 *
 * SOLID:
 *   - Single Responsibility Principle: match generation + its own broadcast.
 *   - Liskov Substitution Principle: fully honors EventSubscriber's contract,
 *     so the bus can treat it identically to any other subscriber.
 */
@Component
public class MatchSubscriber implements EventSubscriber<TournamentRegistrationClosedEvent> {

    private static final Logger log = LoggerFactory.getLogger(MatchSubscriber.class);

    private final WebSocketBroadcaster broadcaster;

    public MatchSubscriber(WebSocketBroadcaster broadcaster) {
        this.broadcaster = broadcaster;
    }

    @Override
    public void onEvent(TournamentRegistrationClosedEvent event) {
        log.info("[MatchSubscriber] Generating matches for tournament [{}]", event.getTournamentId());

        List<Map<String, String>> matches = generateSingleEliminationBracket(event.getRegisteredTeamIds());

        log.info("[MatchSubscriber] Generated {} match(es) for tournament [{}]",
                matches.size(), event.getTournamentId());

        broadcaster.broadcastMatchUpdate(event.getTournamentId(), Map.of(
                "tournamentId", event.getTournamentId(),
                "matches", matches
        ));
    }

    @Override
    public Class<TournamentRegistrationClosedEvent> getEventType() {
        return TournamentRegistrationClosedEvent.class;
    }

    private List<Map<String, String>> generateSingleEliminationBracket(List<String> teamIds) {
        List<Map<String, String>> matches = new ArrayList<>();
        for (int i = 0; i < teamIds.size() - 1; i += 2) {
            matches.add(Map.of(
                    "matchId", "match-" + (i / 2 + 1),
                    "teamA", teamIds.get(i),
                    "teamB", teamIds.get(i + 1)
            ));
        }
        if (teamIds.size() % 2 != 0) {
            matches.add(Map.of(
                    "matchId", "match-bye",
                    "teamA", teamIds.get(teamIds.size() - 1),
                    "teamB", "BYE"
            ));
        }
        return matches;
    }
}
