package com.example.eventbus.core;

/**
 * Full Event Bus contract: publishing plus subscription management.
 * This is the "Kafka broker" of our lightweight system - the single place
 * that knows how to route an event from its publisher to every interested
 * subscriber.
 *
 * WHY IT EXISTS:
 *   Separating this from EventPublisher lets infrastructure code (the
 *   subscriber auto-registrar) depend on the full bus, while domain
 *   services only ever see the narrower EventPublisher slice.
 *
 * SOLID:
 *   - Dependency Inversion Principle: both publishers and subscribers
 *     depend on this abstraction, never on the concrete InMemoryEventBus.
 *   - Interface Segregation Principle: extends EventPublisher rather than
 *     duplicating publish(), so any code that only needs to publish can
 *     still be typed against the smaller interface.
 */
public interface EventBus extends EventPublisher {

    /**
     * Register a subscriber for a specific event type. Multiple subscribers
     * may register for the same event type - each will be invoked
     * independently when that event is published.
     */
    <T extends Event> void subscribe(Class<T> eventType, EventSubscriber<T> subscriber);

    /**
     * Remove a previously registered subscriber.
     */
    <T extends Event> void unsubscribe(Class<T> eventType, EventSubscriber<T> subscriber);
}
