package com.example.eventbus.core;

import java.time.Instant;

/**
 * Base contract for every domain event flowing through the Event Bus.
 *
 * WHY IT EXISTS:
 *   The bus, publisher, and subscribers must depend on an abstraction, not
 *   on concrete event classes. This interface is that abstraction - it is
 *   the "envelope" every event must provide, regardless of its payload.
 *
 * SOLID:
 *   Interface Segregation Principle - callers of the bus only need to know
 *   about eventId/timestamp/eventType, never about a specific event's
 *   internal fields.
 */
public interface Event {

    /** Unique identifier for this event instance (useful for tracing/audit). */
    String getEventId();

    /** When the event was created. */
    Instant getTimestamp();

    /** Human-readable type name, e.g. "TournamentRegistrationClosedEvent". */
    String getEventType();
}
