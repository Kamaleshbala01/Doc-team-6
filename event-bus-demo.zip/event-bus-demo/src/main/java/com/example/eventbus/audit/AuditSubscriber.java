package com.example.eventbus.audit;

import com.example.eventbus.core.EventSubscriber;
import com.example.eventbus.events.TournamentRegistrationClosedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Instant;

/**
 * SUBSCRIBER #4: writes a durable audit trail row to PostgreSQL for every
 * TournamentRegistrationClosedEvent processed.
 *
 * WHY IT EXISTS:
 *   Demonstrates a subscriber whose reaction is persistence rather than
 *   another broadcast - proving the bus is agnostic to what a subscriber
 *   actually does with an event.
 *
 * SOLID:
 *   Single Responsibility Principle - audit persistence only.
 */
@Component
public class AuditSubscriber implements EventSubscriber<TournamentRegistrationClosedEvent> {

    private static final Logger log = LoggerFactory.getLogger(AuditSubscriber.class);

    private final AuditLogRepository auditLogRepository;

    public AuditSubscriber(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    @Override
    public void onEvent(TournamentRegistrationClosedEvent event) {
        log.info("[AuditSubscriber] Recording audit log for event [{}]", event.getEventId());

        String details = "Tournament '" + event.getTournamentName() + "' (" + event.getTournamentId() +
                ") closed registration with " + event.getRegisteredTeamIds().size() + " team(s)";

        AuditLog entry = new AuditLog(event.getEventId(), event.getEventType(), details, Instant.now());
        auditLogRepository.save(entry);
    }

    @Override
    public Class<TournamentRegistrationClosedEvent> getEventType() {
        return TournamentRegistrationClosedEvent.class;
    }
}
