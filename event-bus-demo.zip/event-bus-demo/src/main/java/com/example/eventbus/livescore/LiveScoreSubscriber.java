package com.example.eventbus.livescore;

import com.example.eventbus.core.EventSubscriber;
import com.example.eventbus.events.TournamentRegistrationClosedEvent;
import com.example.eventbus.websocket.WebSocketBroadcaster;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SUBSCRIBER #3: initializes an empty scoreboard for the tournament so the
 * Live Score UI has something to subscribe to as soon as matches exist.
 *
 * SOLID:
 *   Single Responsibility Principle - scoreboard initialization only.
 */
@Component
public class LiveScoreSubscriber implements EventSubscriber<TournamentRegistrationClosedEvent> {

    private static final Logger log = LoggerFactory.getLogger(LiveScoreSubscriber.class);

    private final WebSocketBroadcaster broadcaster;
    private final Map<String, String> scoreboards = new ConcurrentHashMap<>();

    public LiveScoreSubscriber(WebSocketBroadcaster broadcaster) {
        this.broadcaster = broadcaster;
    }

    @Override
    public void onEvent(TournamentRegistrationClosedEvent event) {
        log.info("[LiveScoreSubscriber] Initializing scoreboard for tournament [{}]", event.getTournamentId());

        scoreboards.put(event.getTournamentId(), "INITIALIZED");

        broadcaster.broadcastTournamentUpdate(event.getTournamentId(), Map.of(
                "tournamentId", event.getTournamentId(),
                "status", "SCOREBOARD_READY"
        ));
    }

    @Override
    public Class<TournamentRegistrationClosedEvent> getEventType() {
        return TournamentRegistrationClosedEvent.class;
    }
}
