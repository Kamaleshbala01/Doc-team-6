package com.example.eventbus.audit;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Standard Spring Data JPA repository for AuditLog rows in PostgreSQL.
 * SOLID: Interface Segregation - exposes only the CRUD surface callers need.
 */
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
}
