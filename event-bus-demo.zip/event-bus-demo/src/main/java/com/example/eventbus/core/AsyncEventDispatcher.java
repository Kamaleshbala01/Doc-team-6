package com.example.eventbus.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * Invokes a single subscriber's onEvent() on a background thread.
 *
 * WHY IT EXISTS AS ITS OWN BEAN:
 *   Spring's @Async only works through a proxy. If InMemoryEventBus called
 *   an @Async method on itself (this.dispatch(...)), the proxy would be
 *   bypassed (the classic "self-invocation" pitfall) and the call would run
 *   synchronously. Extracting the @Async method into a separate bean forces
 *   the call to go through the Spring proxy, so it actually executes on the
 *   TaskExecutor thread pool.
 *
 * WHY EXCEPTIONS ARE CAUGHT HERE:
 *   Requirement: "every subscriber executes independently". If subscriber A
 *   throws, subscribers B, C, D must still run, and the publisher must never
 *   see the exception (publish() already returned). So we catch, log, and
 *   swallow at this boundary - this is the isolation wall between listeners.
 *
 * SOLID:
 *   Single Responsibility Principle - this class's only job is "safely run
 *   one subscriber asynchronously".
 */
@Component
public class AsyncEventDispatcher {

    private static final Logger log = LoggerFactory.getLogger(AsyncEventDispatcher.class);

    @Async("eventTaskExecutor")
    public <T extends Event> void dispatch(EventSubscriber<T> subscriber, T event) {
        String subscriberName = subscriber.getClass().getSimpleName();
        try {
            log.debug("[{}] handling {} (eventId={}) on thread {}",
                    subscriberName, event.getEventType(), event.getEventId(),
                    Thread.currentThread().getName());
            subscriber.onEvent(event);
            log.debug("[{}] finished handling {} (eventId={})",
                    subscriberName, event.getEventType(), event.getEventId());
        } catch (Exception ex) {
            // Isolation boundary: one bad subscriber must never affect others.
            log.error("Subscriber [{}] failed while handling event {} (eventId={}): {}",
                    subscriberName, event.getEventType(), event.getEventId(), ex.getMessage(), ex);
        }
    }
}
