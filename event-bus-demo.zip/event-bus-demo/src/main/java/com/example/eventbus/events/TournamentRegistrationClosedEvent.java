package com.example.eventbus.events;

import com.example.eventbus.core.AbstractEvent;

import java.util.List;

/**
 * Fired by TournamentService the moment registration closes for a
 * tournament. Carries just enough data for subscribers to act
 * independently, without them needing to call back into TournamentService.
 *
 * WHY IT EXISTS:
 *   This is the "message contract" between the publisher (TournamentService)
 *   and every subscriber (Match, Notification, LiveScore, Audit). Because it
 *   is immutable and self-contained, subscribers never need a reference back
 *   to the tournament service itself.
 *
 * SOLID:
 *   Single Responsibility Principle - carries data only, no behavior.
 */
public class TournamentRegistrationClosedEvent extends AbstractEvent {

    private final String tournamentId;
    private final String tournamentName;
    private final List<String> registeredTeamIds;

    public TournamentRegistrationClosedEvent(String tournamentId,
                                              String tournamentName,
                                              List<String> registeredTeamIds) {
        super();
        this.tournamentId = tournamentId;
        this.tournamentName = tournamentName;
        this.registeredTeamIds = List.copyOf(registeredTeamIds);
    }

    public String getTournamentId() {
        return tournamentId;
    }

    public String getTournamentName() {
        return tournamentName;
    }

    public List<String> getRegisteredTeamIds() {
        return registeredTeamIds;
    }

    @Override
    public String toString() {
        return "TournamentRegistrationClosedEvent{" +
                "tournamentId='" + tournamentId + '\'' +
                ", tournamentName='" + tournamentName + '\'' +
                ", teams=" + registeredTeamIds.size() +
                '}';
    }
}
