package com.example.eventbus.tournament;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST entry point used to drive the demo: create a tournament, then close
 * registration to kick off the whole event-driven cascade.
 *
 * SOLID: Single Responsibility Principle - HTTP <-> service translation only.
 */
@RestController
@RequestMapping("/api/tournaments")
public class TournamentController {

    private final TournamentService tournamentService;

    public TournamentController(TournamentService tournamentService) {
        this.tournamentService = tournamentService;
    }

    @PostMapping
    public TournamentService.TournamentRecord create(@RequestBody CreateTournamentRequest request) {
        return tournamentService.createDemoTournament(request.id(), request.name(), request.teamIds());
    }

    @PostMapping("/{id}/close-registration")
    public TournamentService.TournamentRecord closeRegistration(@PathVariable("id") String id) {
        return tournamentService.closeRegistration(id);
    }

    @GetMapping("/{id}")
    public TournamentService.TournamentRecord get(@PathVariable("id") String id) {
        return tournamentService.get(id);
    }

    public record CreateTournamentRequest(String id, String name, List<String> teamIds) {}
}
