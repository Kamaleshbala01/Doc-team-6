package com.example.eventbus.audit;

import jakarta.persistence.*;

import java.time.Instant;

/**
 * Persistent record of every event the system has processed, written by
 * AuditSubscriber. Backed by PostgreSQL per the architecture requirement
 * that this project use Postgres (not just in-memory state) for durable
 * data.
 */
@Entity
@Table(name = "audit_log")
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "event_id", nullable = false)
    private String eventId;

    @Column(name = "event_type", nullable = false)
    private String eventType;

    @Column(name = "details", length = 2000)
    private String details;

    @Column(name = "recorded_at", nullable = false)
    private Instant recordedAt;

    protected AuditLog() {
        // JPA
    }

    public AuditLog(String eventId, String eventType, String details, Instant recordedAt) {
        this.eventId = eventId;
        this.eventType = eventType;
        this.details = details;
        this.recordedAt = recordedAt;
    }

    public Long getId() {
        return id;
    }

    public String getEventId() {
        return eventId;
    }

    public String getEventType() {
        return eventType;
    }

    public String getDetails() {
        return details;
    }

    public Instant getRecordedAt() {
        return recordedAt;
    }
}
