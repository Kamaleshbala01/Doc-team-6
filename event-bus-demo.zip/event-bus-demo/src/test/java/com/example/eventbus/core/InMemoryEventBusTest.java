package com.example.eventbus.core;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests the bus in isolation, without booting the full Spring context, by
 * driving InMemoryEventBus + AsyncEventDispatcher directly. Because
 * AsyncEventDispatcher's @Async annotation only takes effect through a
 * Spring AOP proxy, these tests call dispatch() synchronously and instead
 * assert on the *routing* and *isolation* behavior of the bus, which is
 * proxy-independent.
 */
class InMemoryEventBusTest {

    static class TestEvent extends AbstractEvent {
        private final String payload;
        TestEvent(String payload) { this.payload = payload; }
        String getPayload() { return payload; }
    }

    static class OtherEvent extends AbstractEvent {
    }

    private InMemoryEventBus eventBus;
    private AsyncEventDispatcher dispatcher;

    @BeforeEach
    void setUp() {
        dispatcher = new AsyncEventDispatcher();
        eventBus = new InMemoryEventBus(dispatcher);
    }

    @Test
    void multipleSubscribersAllReceiveTheSameEvent() throws InterruptedException {
        AtomicInteger subscriberACount = new AtomicInteger();
        AtomicInteger subscriberBCount = new AtomicInteger();

        EventSubscriber<TestEvent> subscriberA = new EventSubscriber<>() {
            @Override public void onEvent(TestEvent event) { subscriberACount.incrementAndGet(); }
            @Override public Class<TestEvent> getEventType() { return TestEvent.class; }
        };
        EventSubscriber<TestEvent> subscriberB = new EventSubscriber<>() {
            @Override public void onEvent(TestEvent event) { subscriberBCount.incrementAndGet(); }
            @Override public Class<TestEvent> getEventType() { return TestEvent.class; }
        };

        eventBus.subscribe(TestEvent.class, subscriberA);
        eventBus.subscribe(TestEvent.class, subscriberB);

        eventBus.publish(new TestEvent("hello"));

        // AsyncEventDispatcher.dispatch is called directly (no proxy in this
        // unit test), so execution is synchronous - assertions can run immediately.
        assertEquals(1, subscriberACount.get());
        assertEquals(1, subscriberBCount.get());
    }

    @Test
    void onlySubscribersOfMatchingEventTypeAreInvoked() {
        AtomicInteger testEventCount = new AtomicInteger();
        AtomicInteger otherEventCount = new AtomicInteger();

        eventBus.subscribe(TestEvent.class, new EventSubscriber<>() {
            @Override public void onEvent(TestEvent event) { testEventCount.incrementAndGet(); }
            @Override public Class<TestEvent> getEventType() { return TestEvent.class; }
        });
        eventBus.subscribe(OtherEvent.class, new EventSubscriber<>() {
            @Override public void onEvent(OtherEvent event) { otherEventCount.incrementAndGet(); }
            @Override public Class<OtherEvent> getEventType() { return OtherEvent.class; }
        });

        eventBus.publish(new TestEvent("payload"));

        assertEquals(1, testEventCount.get());
        assertEquals(0, otherEventCount.get());
    }

    @Test
    void aFailingSubscriberDoesNotPreventOthersFromRunning() {
        AtomicInteger healthySubscriberCount = new AtomicInteger();

        EventSubscriber<TestEvent> failingSubscriber = new EventSubscriber<>() {
            @Override public void onEvent(TestEvent event) { throw new RuntimeException("boom"); }
            @Override public Class<TestEvent> getEventType() { return TestEvent.class; }
        };
        EventSubscriber<TestEvent> healthySubscriber = new EventSubscriber<>() {
            @Override public void onEvent(TestEvent event) { healthySubscriberCount.incrementAndGet(); }
            @Override public Class<TestEvent> getEventType() { return TestEvent.class; }
        };

        eventBus.subscribe(TestEvent.class, failingSubscriber);
        eventBus.subscribe(TestEvent.class, healthySubscriber);

        // Must not throw - AsyncEventDispatcher swallows subscriber exceptions.
        eventBus.publish(new TestEvent("payload"));

        assertEquals(1, healthySubscriberCount.get());
    }

    @Test
    void unsubscribeStopsFurtherDelivery() {
        AtomicInteger count = new AtomicInteger();
        EventSubscriber<TestEvent> subscriber = new EventSubscriber<>() {
            @Override public void onEvent(TestEvent event) { count.incrementAndGet(); }
            @Override public Class<TestEvent> getEventType() { return TestEvent.class; }
        };

        eventBus.subscribe(TestEvent.class, subscriber);
        eventBus.publish(new TestEvent("first"));
        eventBus.unsubscribe(TestEvent.class, subscriber);
        eventBus.publish(new TestEvent("second"));

        assertEquals(1, count.get());
    }

    @Test
    void publishingWithNoSubscribersDoesNotThrow() {
        eventBus.publish(new TestEvent("nobody listening"));
        // No exception = pass.
    }

    @Test
    void publishingNullEventThrows() {
        try {
            eventBus.publish(null);
            assertTrue(false, "Expected EventBusException");
        } catch (com.example.eventbus.exception.EventBusException expected) {
            assertTrue(expected.getMessage().contains("null"));
        }
    }
}
