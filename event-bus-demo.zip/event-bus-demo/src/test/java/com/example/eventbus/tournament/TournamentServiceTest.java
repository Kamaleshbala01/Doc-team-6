package com.example.eventbus.tournament;

import com.example.eventbus.core.EventPublisher;
import com.example.eventbus.events.TournamentRegistrationClosedEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/**
 * Verifies TournamentService's contract with the bus in isolation: it must
 * publish exactly one TournamentRegistrationClosedEvent with correct data,
 * and it must do so through the EventPublisher abstraction only (proven by
 * mocking EventPublisher - if TournamentService needed anything more
 * specific, this test would fail to compile).
 */
class TournamentServiceTest {

    private EventPublisher eventPublisher;
    private TournamentService tournamentService;

    @BeforeEach
    void setUp() {
        eventPublisher = mock(EventPublisher.class);
        tournamentService = new TournamentService(eventPublisher);
    }

    @Test
    void closingRegistrationPublishesEventWithCorrectData() {
        tournamentService.createDemoTournament("t1", "Summer Cup", List.of("teamA", "teamB", "teamC"));

        tournamentService.closeRegistration("t1");

        ArgumentCaptor<TournamentRegistrationClosedEvent> captor =
                ArgumentCaptor.forClass(TournamentRegistrationClosedEvent.class);
        verify(eventPublisher).publish(captor.capture());

        TournamentRegistrationClosedEvent event = captor.getValue();
        assertEquals("t1", event.getTournamentId());
        assertEquals("Summer Cup", event.getTournamentName());
        assertEquals(3, event.getRegisteredTeamIds().size());
    }

    @Test
    void closingRegistrationTwiceOnlyPublishesOnce() {
        tournamentService.createDemoTournament("t1", "Summer Cup", List.of("teamA", "teamB"));

        tournamentService.closeRegistration("t1");
        tournamentService.closeRegistration("t1"); // should be a no-op the second time

        verify(eventPublisher).publish(org.mockito.ArgumentMatchers.any(TournamentRegistrationClosedEvent.class));
    }

    @Test
    void closingRegistrationForUnknownTournamentThrows() {
        assertThrows(IllegalArgumentException.class, () -> tournamentService.closeRegistration("does-not-exist"));
    }
}
