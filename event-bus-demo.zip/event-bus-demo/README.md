# Lightweight Event Bus on Spring Boot + WebSocket (No Kafka/RabbitMQ/Redis)

A from-scratch, in-memory publish-subscribe Event Bus built purely with
Spring Boot 3.x, Java 17, Spring WebSocket (STOMP + SockJS) and PostgreSQL —
no external broker. This document explains the architecture step by step,
then hands you the complete, runnable source.

---

## 1. Event-Driven Architecture (EDA) and Publish-Subscribe, explained

**Event-Driven Architecture** is a design style where components communicate
by producing and reacting to *events* — immutable facts about something that
already happened ("registration closed"), rather than by calling each other's
methods directly. The producer doesn't invoke the consumer; it just
announces a fact and moves on.

**Publish-Subscribe (pub/sub)** is the messaging pattern that implements
this: publishers send events to a *topic* (or, in our case, an event type),
and any number of subscribers listening to that topic receive a copy,
independently and concurrently. The publisher never holds a reference to
any subscriber, and subscribers never call each other.

Why this matters for a system like a tournament platform:

- **Decoupling** — Tournament, Match, Notification, LiveScore and Audit can
  be developed, deployed, and tested independently. Tournament code never
  imports Match/Notification/etc.
- **Extensibility** — adding a 5th subscriber (say, a Billing service) means
  writing one new class. Zero existing code changes.
- **Resilience** — if Notification's logic throws an exception, Match and
  Audit still run. One consumer's failure cannot cascade into the publisher
  or into other consumers.
- **Real Kafka does this at massive scale**, with durability, partitioning,
  replay, and cross-process delivery. Our Event Bus mimics the *programming
  model* of Kafka (publish once, many independent consumers) but runs
  in-process, in memory, using Spring's `@Async` + a `TaskExecutor` instead
  of a broker.

---

## 2. Folder Structure

```
event-bus-demo/
├── pom.xml
├── README.md
├── src/main/java/com/example/eventbus/
│   ├── EventBusDemoApplication.java
│   ├── config/
│   │   ├── AsyncConfig.java            # TaskExecutor bean, @EnableAsync
│   │   └── WebSocketConfig.java        # STOMP + SockJS broker config
│   ├── core/                            # <-- the generic Event Bus engine
│   │   ├── Event.java
│   │   ├── AbstractEvent.java
│   │   ├── EventPublisher.java
│   │   ├── EventSubscriber.java
│   │   ├── EventBus.java
│   │   ├── InMemoryEventBus.java
│   │   ├── AsyncEventDispatcher.java
│   │   └── EventSubscriberRegistrar.java
│   ├── events/
│   │   └── TournamentRegistrationClosedEvent.java
│   ├── tournament/                      # PUBLISHER
│   │   ├── TournamentService.java
│   │   └── TournamentController.java
│   ├── match/                           # SUBSCRIBER #1
│   │   └── MatchSubscriber.java
│   ├── notification/                    # SUBSCRIBER #2
│   │   └── NotificationSubscriber.java
│   ├── livescore/                       # SUBSCRIBER #3
│   │   └── LiveScoreSubscriber.java
│   ├── audit/                           # SUBSCRIBER #4 (persists to Postgres)
│   │   ├── AuditLog.java
│   │   ├── AuditLogRepository.java
│   │   └── AuditSubscriber.java
│   ├── websocket/
│   │   └── WebSocketBroadcaster.java    # wraps SimpMessagingTemplate
│   └── exception/
│       ├── EventBusException.java
│       └── GlobalExceptionHandler.java
├── src/main/resources/application.yml
└── src/test/java/com/example/eventbus/
    ├── core/InMemoryEventBusTest.java
    └── tournament/TournamentServiceTest.java
```

---

## 3. Mermaid Diagrams

### 3.1 Publish Event Flow

```mermaid
sequenceDiagram
    participant Client as REST Client
    participant Ctrl as TournamentController
    participant Svc as TournamentService
    participant Pub as EventPublisher (interface)
    participant Bus as InMemoryEventBus

    Client->>Ctrl: POST /api/tournaments/{id}/close-registration
    Ctrl->>Svc: closeRegistration(id)
    Svc->>Svc: mark registration closed
    Svc->>Pub: publish(TournamentRegistrationClosedEvent)
    Pub->>Bus: publish(event)
    Bus-->>Svc: returns immediately (fire-and-forget)
    Svc-->>Ctrl: TournamentRecord
    Ctrl-->>Client: 200 OK
```

### 3.2 Subscribe Event Flow (auto-registration at startup)

```mermaid
sequenceDiagram
    participant Spring as Spring Context
    participant Reg as EventSubscriberRegistrar
    participant Bus as InMemoryEventBus
    participant Match as MatchSubscriber
    participant Notif as NotificationSubscriber
    participant Live as LiveScoreSubscriber
    participant Audit as AuditSubscriber

    Spring->>Spring: ApplicationReadyEvent fired
    Spring->>Reg: registerAllSubscribers()
    Reg->>Bus: subscribe(TournamentRegistrationClosedEvent, MatchSubscriber)
    Reg->>Bus: subscribe(TournamentRegistrationClosedEvent, NotificationSubscriber)
    Reg->>Bus: subscribe(TournamentRegistrationClosedEvent, LiveScoreSubscriber)
    Reg->>Bus: subscribe(TournamentRegistrationClosedEvent, AuditSubscriber)
    Note over Reg,Bus: Subscribers register themselves via Spring DI.<br/>TournamentService never appears in this flow.
```

### 3.3 Internal Event Bus Flow (fan-out + isolation)

```mermaid
flowchart TD
    A[TournamentService.closeRegistration] -->|publish event| B[InMemoryEventBus.publish]
    B --> C{Lookup subscribers<br/>for event.getClass}
    C -->|found list| D[AsyncEventDispatcher.dispatch x N]
    C -->|none found| Z[Log warning, return]
    D --> E1[Thread Pool: MatchSubscriber.onEvent]
    D --> E2[Thread Pool: NotificationSubscriber.onEvent]
    D --> E3[Thread Pool: LiveScoreSubscriber.onEvent]
    D --> E4[Thread Pool: AuditSubscriber.onEvent]
    E1 -->|exception?| F1[Caught + logged, others unaffected]
    E2 -->|exception?| F2[Caught + logged, others unaffected]
    E3 --> G3[WebSocketBroadcaster]
    E1 --> G1[WebSocketBroadcaster]
    E2 --> G2[WebSocketBroadcaster]
    E4 --> H[AuditLogRepository.save -> PostgreSQL]
```

### 3.4 WebSocket Broadcast Flow

```mermaid
sequenceDiagram
    participant Sub as Subscriber (Match/Notif/LiveScore)
    participant WSB as WebSocketBroadcaster
    participant SMT as SimpMessagingTemplate
    participant Broker as STOMP Broker (/topic)
    participant Client as Browser (SockJS+STOMP client)

    Client->>Broker: CONNECT /ws (SockJS)
    Client->>Broker: SUBSCRIBE /topic/match/{tournamentId}
    Sub->>WSB: broadcastMatchUpdate(tournamentId, payload)
    WSB->>SMT: convertAndSend("/topic/match/{id}", payload)
    SMT->>Broker: route message
    Broker->>Client: push payload to subscribed client
```

---

## 4. Class-by-Class Explanation

| Class | Why it exists | Responsibility | Role in EDA | SOLID principle |
|---|---|---|---|---|
| `Event` | Common contract every event must satisfy | Expose id/timestamp/type | The universal "envelope" the bus routes on | ISP |
| `AbstractEvent` | Avoid repeating id/timestamp code | Generate id + timestamp | Base for all concrete events | SRP |
| `EventPublisher` | Narrow write-only contract | Expose `publish()` only | What publishers depend on | ISP, DIP |
| `EventSubscriber<T>` | Generic listener contract | `onEvent()` + `getEventType()` | What every listener implements | OCP, DIP |
| `EventBus` | Full contract: publish + manage subscriptions | Union of publish + subscribe/unsubscribe | The abstraction infra code depends on | DIP, ISP |
| `InMemoryEventBus` | Concrete broker | Registry (`Map<Class,List<Subscriber>>`) + fan-out on publish | The "Kafka broker" stand-in | SRP, OCP, LSP |
| `AsyncEventDispatcher` | Work around `@Async` self-invocation; isolate subscriber failures | Run one subscriber off-thread, catch its exceptions | Guarantees independent, concurrent, failure-isolated execution | SRP |
| `EventSubscriberRegistrar` | Publisher must never know subscribers exist | Discover all `EventSubscriber` beans and auto-subscribe them at startup | Wires the whole system together with zero manual coupling | OCP, DIP |
| `TournamentRegistrationClosedEvent` | The concrete message contract | Carry tournament id/name/team ids | The "fact" being announced | SRP |
| `TournamentService` | The publisher | Own tournament state, publish the event | Fires the trigger; has zero subscriber knowledge | SRP, DIP |
| `TournamentController` | REST entrypoint | Translate HTTP <-> service | Drives the demo | SRP |
| `MatchSubscriber` | Subscriber #1 | Generate bracket, broadcast to `/topic/match/{id}` | Independent reaction #1 | SRP, LSP |
| `NotificationSubscriber` | Subscriber #2 | Build+push per-user notifications | Independent reaction #2 | SRP |
| `LiveScoreSubscriber` | Subscriber #3 | Initialize scoreboard, broadcast readiness | Independent reaction #3 | SRP |
| `AuditSubscriber` / `AuditLog` / `AuditLogRepository` | Subscriber #4 | Persist a durable audit row to PostgreSQL | Independent reaction #4 (persistence, not broadcast) | SRP |
| `WebSocketBroadcaster` | Single gateway to STOMP clients | Format destination + `convertAndSend` | The "last mile" real-time push | SRP |
| `WebSocketConfig` | Wire STOMP/SockJS | Register `/ws` endpoint, `/topic` broker, `/app` prefix | Real-time transport configuration | SRP |
| `AsyncConfig` | Bounded thread pool | Define `eventTaskExecutor` bean | Concurrency backbone (our "consumer pool") | SRP |
| `EventBusException` / `GlobalExceptionHandler` | Predictable errors | Wrap bus-level failures; format REST errors | Cross-cutting reliability | SRP |

---

## 5. How to Run

1. Create a PostgreSQL database matching `application.yml` (`eventbus_db`,
   user/password `postgres`/`postgres`, or edit the file to match your
   instance). `ddl-auto: update` will create the `audit_log` table for you.
2. `mvn spring-boot:run`
3. Create a tournament:
   ```bash
   curl -X POST localhost:8080/api/tournaments \
     -H "Content-Type: application/json" \
     -d '{"id":"t1","name":"Summer Cup","teamIds":["teamA","teamB","teamC","teamD"]}'
   ```
4. Connect a STOMP/SockJS client to `ws://localhost:8080/ws` and subscribe to
   `/topic/tournament/t1`, `/topic/match/t1`, `/topic/notification/teamA`.
5. Close registration and watch all four subscribers fire independently:
   ```bash
   curl -X POST localhost:8080/api/tournaments/t1/close-registration
   ```

---

## 6. Custom Event Bus vs. Apache Kafka

**Similarities**
- Both implement publish-subscribe: one producer, many independent consumers.
- Both decouple producers from consumers via a topic/event-type abstraction.
- Both support fan-out to multiple consumer groups/subscribers per message.
- Both process consumers concurrently, off the producer's calling thread.

**Differences**

| Aspect | Custom Event Bus | Apache Kafka |
|---|---|---|
| Transport | In-process method calls | Network protocol, brokers, TCP |
| Durability | None — events live only in RAM during dispatch | Disk-backed log, configurable retention |
| Scale | Single JVM only | Distributed across many brokers/partitions |
| Replay | Not possible (event is gone once dispatched) | Consumers can re-read from any offset |
| Ordering guarantees | Best-effort, thread-pool dependent | Strict per-partition ordering |
| Delivery guarantees | At-most-once (if a subscriber throws, dispatch is only logged, not retried) | At-least-once / exactly-once (with config) |
| Cross-service use | Only works within one running application | Works across many independent services/languages |
| Operational cost | Zero — no extra infrastructure | Requires running/maintaining a Kafka cluster (or managed service) |

**Advantages of the custom Event Bus**
- Zero infrastructure, zero external dependencies, trivial to run locally.
- Extremely low latency (nanoseconds of dispatch overhead vs. network round trips).
- Simple mental model for small-to-medium monoliths or modular monoliths.

**Limitations**
- Events are lost if the JVM crashes mid-dispatch — no durability.
- Cannot scale beyond one process; no multi-instance consumer coordination.
- No replay/audit-from-log capability (we compensate partially here via the
  `AuditSubscriber` writing to PostgreSQL, but that's application-level, not
  bus-level).
- No back-pressure/partitioning strategy for very high throughput.

**When to use the custom Event Bus**
- A modular monolith where all "services" are just packages in one deployable.
- Low-to-moderate event volume where in-memory delivery is fully acceptable.
- Prototypes, teaching tools, or systems where infra simplicity outweighs
  durability guarantees.

**When Kafka is the better choice**
- Multiple independently deployed microservices/processes must communicate.
- You need durability, replay, or exactly-once semantics.
- Event volume is high enough to need partitioning and horizontal scaling.
- You need consumer groups, schema registries, or long-term event retention
  for analytics/event-sourcing.
