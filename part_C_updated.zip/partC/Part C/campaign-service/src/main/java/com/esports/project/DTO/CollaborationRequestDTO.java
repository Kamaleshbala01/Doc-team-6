package com.esports.project.DTO;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CollaborationRequestDTO {

    private String campaignId;

    private String userId;
    private String title;

    private String description;

    private BigDecimal proposedAmount;

	public CollaborationRequestDTO() {
		super();
	}

	public CollaborationRequestDTO(String campaignId, String userId, String title, String description,
			BigDecimal proposedAmount) {
		super();
		this.campaignId = campaignId;
		this.userId = userId;
		this.title = title;
		this.description = description;
		this.proposedAmount = proposedAmount;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getProposedAmount() {
		return proposedAmount;
	}

	public void setProposedAmount(BigDecimal proposedAmount) {
		this.proposedAmount = proposedAmount;
	}
    
}