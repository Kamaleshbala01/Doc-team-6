package com.esports.project.DTO;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.CampaignType;
import com.esports.project.enums.StatusMaster;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CampaignResponseDTO {

    private String id;

    private String campaignName;

    private CampaignType campaignType;

    private LocalDateTime startDate;

    private LocalDateTime endDate;

    private BigDecimal totalBudget;

    private StatusMaster status;

	public CampaignResponseDTO() {
		super();
	}

	public CampaignResponseDTO(String id, String campaignName, CampaignType campaignType, LocalDateTime startDate,
			LocalDateTime endDate, BigDecimal totalBudget, StatusMaster status) {
		super();
		this.id = id;
		this.campaignName = campaignName;
		this.campaignType = campaignType;
		this.startDate = startDate;
		this.endDate = endDate;
		this.totalBudget = totalBudget;
		this.status = status;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public CampaignType getCampaignType() {
		return campaignType;
	}

	public void setCampaignType(CampaignType campaignType) {
		this.campaignType = campaignType;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	public BigDecimal getTotalBudget() {
		return totalBudget;
	}

	public void setTotalBudget(BigDecimal totalBudget) {
		this.totalBudget = totalBudget;
	}

	public StatusMaster getStatus() {
		return status;
	}

	public void setStatus(StatusMaster status) {
		this.status = status;
	}
    
    
}