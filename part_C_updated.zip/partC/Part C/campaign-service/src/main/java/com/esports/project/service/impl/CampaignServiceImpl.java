package com.esports.project.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.esports.project.DTO.CampaignRequestDTO;
import com.esports.project.DTO.CampaignStatisticsDTO;
import com.esports.project.DTO.UpdateCampaignRequestDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.entity.Campaign;
import com.esports.project.enums.CampaignType;
import com.esports.project.enums.StatusMaster;
import com.esports.project.exception.BadRequestException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.exception.UnauthorizedException;
import com.esports.project.repository.CampaignRepository;
import com.esports.project.service.interfaces.CampaignService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class CampaignServiceImpl implements CampaignService {

	private final CampaignRepository campaignRepository;

	public CampaignServiceImpl(CampaignRepository campaignRepository) {
	    this.campaignRepository = campaignRepository;
	}

    private String getCurrentUserId() {

        UserDetailsDTO user =
                (UserDetailsDTO) SecurityContextHolder
                        .getContext()
                        .getAuthentication()
                        .getPrincipal();

        return user.getUserId();
    }

    private void validateCampaign(CampaignRequestDTO request) {

        if (request.getCampaignType() == null) {
            throw new BadRequestException(
                    "Campaign type is required");
        }

        if (request.getCampaignName() == null
                || request.getCampaignName().trim().isEmpty()) {
            throw new BadRequestException(
                    "Campaign name is required");
        }

        if (request.getStartDate() == null) {
            throw new BadRequestException(
                    "Start date is required");
        }

        if (request.getEndDate() == null) {
            throw new BadRequestException(
                    "End date is required");
        }

        if (request.getStartDate()
                .isAfter(request.getEndDate())) {

            throw new BadRequestException(
                    "Start date cannot be greater than end date");
        }

        if (request.getTotalBudget() == null
                || request.getTotalBudget().doubleValue() <= 0) {

            throw new BadRequestException(
                    "Total budget must be greater than 0");
        }

        if (request.getInfluencerCost() == null
                || request.getInfluencerCost().doubleValue() < 0) {

            throw new BadRequestException(
                    "Influencer cost cannot be negative");
        }

        if (request.getAdditionalExpenses() == null
                || request.getAdditionalExpenses().doubleValue() < 0) {

            throw new BadRequestException(
                    "Additional expenses cannot be negative");
        }
    }

    @Override
    public Campaign createCampaign(
            CampaignRequestDTO request) {

        validateCampaign(request);

        Campaign campaign = new Campaign();

        campaign.setCampaignType(
                request.getCampaignType());

        campaign.setCampaignName(
                request.getCampaignName());

        campaign.setStartDate(
                request.getStartDate());

        campaign.setEndDate(
                request.getEndDate());

        campaign.setDescription(
                request.getDescription());

        campaign.setTotalBudget(
                request.getTotalBudget());

        campaign.setInfluencerCost(
                request.getInfluencerCost());

        campaign.setAdditionalExpenses(
                request.getAdditionalExpenses());

        campaign.setBrandId(
                getCurrentUserId());

        campaign.setStatus(
                StatusMaster.ACTIVE);

        campaign.setCreatedAt(
                LocalDateTime.now());

        campaign.setUpdatedAt(
                LocalDateTime.now());

        return campaignRepository.save(campaign);
    }

    @Override
    public List<Campaign> getAllCampaigns() {

        return campaignRepository.findAll();
    }

    @Override
    public Campaign getCampaignById(
            String campaignId) {

        if (campaignId == null || campaignId.isBlank()) {
            throw new BadRequestException(
                    "Campaign id is required");
        }

        return campaignRepository
                .findById(campaignId)
                .orElseThrow(() ->
                        new NotFoundException(
                                "Campaign not found"));
    }

    @Override
    public List<Campaign> getMyCampaigns() {

        return campaignRepository
                .findByBrandId(getCurrentUserId());
    }

    @Override
    public List<Campaign> getCampaignByType(
            CampaignType campaignType) {

        if (campaignType == null) {
            throw new BadRequestException(
                    "Campaign type is required");
        }

        return campaignRepository
                .findByCampaignType(campaignType);
    }

    @Override
    public List<Campaign> getMyCampaignsByType(
            CampaignType campaignType) {

        if (campaignType == null) {
            throw new BadRequestException(
                    "Campaign type is required");
        }

        return campaignRepository
                .findByBrandIdAndCampaignType(
                        getCurrentUserId(),
                        campaignType);
    }

    @Override
    public Campaign updateCampaign(
            String campaignId,
            UpdateCampaignRequestDTO request) {

        Campaign campaign =
                campaignRepository
                        .findById(campaignId)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Campaign not found"));

        if (!campaign.getBrandId()
                .equals(getCurrentUserId())) {

            throw new UnauthorizedException(
                    "You are not authorized to update this campaign");
        }

        if (request.getStartDate() != null
                && request.getEndDate() != null
                && request.getStartDate()
                .isAfter(request.getEndDate())) {

            throw new BadRequestException(
                    "Start date cannot be greater than end date");
        }

        if (request.getCampaignType() != null) {
            campaign.setCampaignType(
                    request.getCampaignType());
        }

        if (request.getCampaignName() != null
                && !request.getCampaignName().isBlank()) {

            campaign.setCampaignName(
                    request.getCampaignName());
        }

        if (request.getStartDate() != null) {
            campaign.setStartDate(
                    request.getStartDate());
        }

        if (request.getEndDate() != null) {
            campaign.setEndDate(
                    request.getEndDate());
        }

        if (request.getDescription() != null) {
            campaign.setDescription(
                    request.getDescription());
        }

        if (request.getTotalBudget() != null) {

            if (request.getTotalBudget().doubleValue() <= 0) {
                throw new BadRequestException(
                        "Total budget must be greater than 0");
            }

            campaign.setTotalBudget(
                    request.getTotalBudget());
        }

        if (request.getInfluencerCost() != null) {

            if (request.getInfluencerCost().doubleValue() < 0) {
                throw new BadRequestException(
                        "Influencer cost cannot be negative");
            }

            campaign.setInfluencerCost(
                    request.getInfluencerCost());
        }

        if (request.getAdditionalExpenses() != null) {

            if (request.getAdditionalExpenses().doubleValue() < 0) {
                throw new BadRequestException(
                        "Additional expenses cannot be negative");
            }

            campaign.setAdditionalExpenses(
                    request.getAdditionalExpenses());
        }

        if (request.getStatus() != null) {
            campaign.setStatus(
                    request.getStatus());
        }

        campaign.setUpdatedAt(
                LocalDateTime.now());

        return campaignRepository.save(campaign);
    }

    @Override
    public void deleteCampaign(
            String campaignId) {

        Campaign campaign =
                campaignRepository
                        .findById(campaignId)
                        .orElseThrow(() ->
                                new NotFoundException(
                                        "Campaign not found"));

        if (!campaign.getBrandId()
                .equals(getCurrentUserId())) {

            throw new UnauthorizedException(
                    "You are not authorized to delete this campaign");
        }

        campaign.setStatus(
                StatusMaster.INACTIVE);

        campaign.setUpdatedAt(
                LocalDateTime.now());

        campaignRepository.save(campaign);
    }

    @Override
    public List<Campaign> getActiveCampaigns() {

        return campaignRepository
                .findByStatus(StatusMaster.ACTIVE);
    }

    @Override
    public CampaignStatisticsDTO getMyStatistics() {

        List<Campaign> campaigns =
                campaignRepository.findByBrandId(
                        getCurrentUserId());

        long activeCount =
                campaigns.stream()
                        .filter(c ->
                                c.getStatus() ==
                                        StatusMaster.ACTIVE)
                        .count();

        long pendingCount =
                campaigns.stream()
                        .filter(c ->
                                c.getStatus() ==
                                        StatusMaster.PENDING)
                        .count();

        long completedCount =
                campaigns.stream()
                        .filter(c ->
                                c.getStatus() ==
                                        StatusMaster.COMPLETED)
                        .count();

        long inactiveCount =
                campaigns.stream()
                        .filter(c ->
                                c.getStatus() ==
                                        StatusMaster.INACTIVE)
                        .count();

        CampaignStatisticsDTO dto =
                new CampaignStatisticsDTO();

        dto.setTotalCampaigns(
                campaigns.size());

        dto.setActiveCampaigns(
                activeCount);

        dto.setPendingCampaigns(
                pendingCount);

        dto.setCompletedCampaigns(
                completedCount);

        dto.setInactiveCampaigns(
                inactiveCount);

        return dto;
    }
}