package com.esports.project.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.project.DTO.CollaborationRequestDTO;
import com.esports.project.DTO.CollaborationRequestInfluencerDTO;
import com.esports.project.enums.StatusMaster;
import com.esports.project.service.interfaces.CollaborationService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/campaigns/collaborations")
@RequiredArgsConstructor
public class CollaborationController {

	private final CollaborationService collaborationService;

	public CollaborationController(CollaborationService collaborationService) {
	    this.collaborationService = collaborationService;
	}

	@PreAuthorize("hasAuthority('COLLABORATION_CREATEBY_BRAND')")
    @PostMapping("/brand")
    public ResponseEntity<?> createByBrand(
            @RequestBody CollaborationRequestDTO request) {

        return ResponseEntity.ok(
                collaborationService.createByBrand(
                        request));
    }

	@PreAuthorize("hasAuthority('COLLABORATION_CREATEBY_INFLUENCER')")
    @PostMapping("/influencer")
    public ResponseEntity<?> createByInfluencer(
            @RequestBody CollaborationRequestInfluencerDTO request) {

        return ResponseEntity.ok(
                collaborationService.createByInfluencer(
                        request));
    }

	@PreAuthorize("hasAuthority('COLLABORATION_READBY_COLLABORATION_ID')")
    @GetMapping("/{id}")
    public ResponseEntity<?> getById(
            @PathVariable String id) {

        return ResponseEntity.ok(
                collaborationService.getById(id));
    }

	@PreAuthorize("hasAuthority('COLLABORATION_SENTBY_SELF')")
    @GetMapping("/sent")
    public ResponseEntity<?> sent() {

        return ResponseEntity.ok(
                collaborationService.getSent());
    }
	
	@PreAuthorize("hasAuthority('COLLABORATION_RECEIVEDBY_SELF')")
    @GetMapping("/received")
    public ResponseEntity<?> received() {

        return ResponseEntity.ok(
                collaborationService.getReceived());
    }

	@PreAuthorize("hasAuthority('COLLABORATION_STATUS')")
    @GetMapping("/status/{status}")
    public ResponseEntity<?> status(
            @PathVariable StatusMaster status) {

        return ResponseEntity.ok(
                collaborationService.getByStatus(
                        status));
    }

	@PreAuthorize("hasAuthority('COLLABORATION_READBY_CAMPAIGN_ID')")
    @GetMapping("/campaign/{campaignId}")
    public ResponseEntity<?> campaign(
            @PathVariable String campaignId) {

        return ResponseEntity.ok(
                collaborationService
                        .getByCampaign(campaignId));
    }

	@PreAuthorize("hasAuthority('COLLABORATION_UPDATETO_ACCEPTED')")
    @PatchMapping("/{id}/accept")
    public ResponseEntity<?> accept(
            @PathVariable String id) {

        return ResponseEntity.ok(
                collaborationService.accept(id));
    }

	@PreAuthorize("hasAuthority('COLLABORATION_UPDATETO_REJECTED')")
    @PatchMapping("/{id}/reject")
    public ResponseEntity<?> reject(
            @PathVariable String id) {

        return ResponseEntity.ok(
                collaborationService.reject(id));
    }

	@PreAuthorize("hasAuthority('COLLABORATION_UPDATETO_COMPLETED')")
    @PatchMapping("/{id}/complete")
    public ResponseEntity<?> complete(
            @PathVariable String id) {

        return ResponseEntity.ok(
                collaborationService.complete(id));
    }

	@PreAuthorize("hasAuthority('COLLABORATION_DELETE')")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(
            @PathVariable String id) {

        collaborationService.delete(id);

        return ResponseEntity.ok(
                "Collaboration deleted successfully");
    }
}
