package com.esports.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.esports.project.entity.Campaign;
import com.esports.project.enums.CampaignType;
import com.esports.project.enums.StatusMaster;

@Repository
public interface CampaignRepository
        extends JpaRepository<Campaign, String> {

    List<Campaign> findByBrandId(
            String brandId);

    List<Campaign> findByCampaignType(
            CampaignType campaignType);

    List<Campaign> findByBrandIdAndCampaignType(
            String brandId,
            CampaignType campaignType);

    List<Campaign> findByStatus(
            StatusMaster status);
}