package com.esports.project.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.esports.project.DTO.CampaignRequestDTO;
import com.esports.project.DTO.CampaignStatisticsDTO;
import com.esports.project.DTO.UpdateCampaignRequestDTO;
import com.esports.project.entity.Campaign;
import com.esports.project.enums.CampaignType;
import com.esports.project.enums.StatusMaster;
import com.esports.project.exception.GlobalExceptionHandler;
import com.esports.project.exception.NotFoundException;
import com.esports.project.service.interfaces.CampaignService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class CampaignControllerTest {

    private MockMvc mockMvc;

    private ObjectMapper objectMapper;

    @Mock
    private CampaignService campaignService;

    @InjectMocks
    private CampaignController campaignController;

    @BeforeEach
    void setUp() {

        objectMapper = new ObjectMapper();
        objectMapper.findAndRegisterModules();

        mockMvc = MockMvcBuilders
                .standaloneSetup(campaignController)
                .setControllerAdvice(new GlobalExceptionHandler(null))
                .build();
    }

    private Campaign getCampaign() {

        Campaign campaign = new Campaign();
        campaign.setId("1");
        campaign.setCampaignName("Gaming Campaign");
        campaign.setCampaignType(CampaignType.BRAND_AWARENESS);
        campaign.setStatus(StatusMaster.ACTIVE);
        campaign.setTotalBudget(new BigDecimal("10000"));

        return campaign;
    }

    private CampaignRequestDTO getRequest() {

        CampaignRequestDTO dto = new CampaignRequestDTO();
        dto.setCampaignName("Gaming Campaign");
        dto.setCampaignType(CampaignType.BRAND_AWARENESS);
        dto.setDescription("Test Campaign");
        dto.setStartDate(LocalDateTime.now());
        dto.setEndDate(LocalDateTime.now().plusDays(10));
        dto.setTotalBudget(new BigDecimal("10000"));
        dto.setInfluencerCost(new BigDecimal("2000"));
        dto.setAdditionalExpenses(new BigDecimal("1000"));

        return dto;
    }

    @Test
    void createCampaign_Success() throws Exception {

        when(campaignService.createCampaign(any(CampaignRequestDTO.class)))
                .thenReturn(getCampaign());

        mockMvc.perform(post("/api/campaigns")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(getRequest())))
                .andExpect(status().isOk());
    }

    @Test
    void getAllCampaigns_Success() throws Exception {

        when(campaignService.getAllCampaigns())
                .thenReturn(List.of(getCampaign()));

        mockMvc.perform(get("/api/campaigns"))
                .andExpect(status().isOk());
    }

    @Test
    void getAllCampaigns_Empty() throws Exception {

        when(campaignService.getAllCampaigns())
                .thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/campaigns"))
                .andExpect(status().isOk());
    }

    @Test
    void getCampaignById_Success() throws Exception {

        when(campaignService.getCampaignById("1"))
                .thenReturn(getCampaign());

        mockMvc.perform(get("/api/campaigns/1"))
                .andExpect(status().isOk());
    }

    @Test
    void getCampaignById_NotFound() throws Exception {

        when(campaignService.getCampaignById("1"))
                .thenThrow(new NotFoundException("Campaign not found"));

        mockMvc.perform(get("/api/campaigns/1"))
                .andExpect(status().isNotFound());
    }

    @Test
    void getMyCampaigns_Success() throws Exception {

        when(campaignService.getMyCampaigns())
                .thenReturn(List.of(getCampaign()));

        mockMvc.perform(get("/api/campaigns/my"))
                .andExpect(status().isOk());
    }

    @Test
    void getCampaignByType_Success() throws Exception {

        when(campaignService.getCampaignByType(
                CampaignType.BRAND_AWARENESS))
                .thenReturn(List.of(getCampaign()));

        mockMvc.perform(
                        get("/api/campaigns/type/BRAND_AWARENESS"))
                .andExpect(status().isOk());
    }

    @Test
    void getMyCampaignsByType_Success() throws Exception {

        when(campaignService.getMyCampaignsByType(
                CampaignType.BRAND_AWARENESS))
                .thenReturn(List.of(getCampaign()));

        mockMvc.perform(
                        get("/api/campaigns/my/type/BRAND_AWARENESS"))
                .andExpect(status().isOk());
    }

    @Test
    void updateCampaign_Success() throws Exception {

        UpdateCampaignRequestDTO dto =
                new UpdateCampaignRequestDTO();

        dto.setCampaignName("Updated Campaign");

        when(campaignService.updateCampaign(
                eq("1"),
                any(UpdateCampaignRequestDTO.class)))
                .thenReturn(getCampaign());

        mockMvc.perform(
                        put("/api/campaigns/1")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk());
    }

    @Test
    void updateCampaign_NotFound() throws Exception {

        UpdateCampaignRequestDTO dto =
                new UpdateCampaignRequestDTO();

        when(campaignService.updateCampaign(
                eq("1"),
                any(UpdateCampaignRequestDTO.class)))
                .thenThrow(new NotFoundException("Campaign not found"));

        mockMvc.perform(
                        put("/api/campaigns/1")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isNotFound());
    }

    @Test
    void deleteCampaign_Success() throws Exception {

        doNothing().when(campaignService)
                .deleteCampaign("1");

        mockMvc.perform(delete("/api/campaigns/1"))
                .andExpect(status().isOk());
    }

    @Test
    void getActiveCampaigns_Success() throws Exception {

        when(campaignService.getActiveCampaigns())
                .thenReturn(List.of(getCampaign()));

        mockMvc.perform(get("/api/campaigns/active"))
                .andExpect(status().isOk());
    }

    @Test
    void getActiveCampaigns_Empty() throws Exception {

        when(campaignService.getActiveCampaigns())
                .thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/campaigns/active"))
                .andExpect(status().isOk());
    }

    @Test
    void getMyStatistics_Success() throws Exception {

        CampaignStatisticsDTO dto =
                new CampaignStatisticsDTO(
                        10,
                        5,
                        2,
                        2,
                        1);

        when(campaignService.getMyStatistics())
                .thenReturn(dto);

        mockMvc.perform(
                        get("/api/campaigns/my/statistics"))
                .andExpect(status().isOk());
    }

    @Test
    void getMyStatistics_EmptyStatistics() throws Exception {

        CampaignStatisticsDTO dto =
                new CampaignStatisticsDTO(
                        0,
                        0,
                        0,
                        0,
                        0);

        when(campaignService.getMyStatistics())
                .thenReturn(dto);

        mockMvc.perform(
                        get("/api/campaigns/my/statistics"))
                .andExpect(status().isOk());
    }
}