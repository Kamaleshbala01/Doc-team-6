package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import com.esports.project.DTO.CampaignRequestDTO;
import com.esports.project.DTO.CampaignStatisticsDTO;
import com.esports.project.DTO.UpdateCampaignRequestDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.entity.Campaign;
import com.esports.project.enums.CampaignType;
import com.esports.project.enums.StatusMaster;
import com.esports.project.exception.BadRequestException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.repository.CampaignRepository;
import com.esports.project.service.impl.CampaignServiceImpl;

@ExtendWith(MockitoExtension.class)
class CampaignServiceTest {

    @Mock
    private CampaignRepository campaignRepository;

    @InjectMocks
    private CampaignServiceImpl campaignService;

    @BeforeEach
    void setup() {

        UserDetailsDTO user = new UserDetailsDTO();
        user.setUserId("brand1");

        UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken(
                        user,
                        null,
                        Collections.emptyList());

        SecurityContextHolder.getContext()
                .setAuthentication(auth);
    }

    private CampaignRequestDTO getRequest() {

        CampaignRequestDTO dto = new CampaignRequestDTO();

        dto.setCampaignType(
                CampaignType.BRAND_AWARENESS);

        dto.setCampaignName("Gaming Campaign");

        dto.setDescription("Test");

        dto.setStartDate(
                LocalDateTime.now());

        dto.setEndDate(
                LocalDateTime.now().plusDays(10));

        dto.setTotalBudget(
                new BigDecimal("10000"));

        dto.setInfluencerCost(
                new BigDecimal("5000"));

        dto.setAdditionalExpenses(
                new BigDecimal("1000"));

        return dto;
    }

    private Campaign getCampaign() {

        Campaign campaign = new Campaign();

        campaign.setId("1");
        campaign.setBrandId("brand1");
        campaign.setCampaignName("Gaming");
        campaign.setCampaignType(
                CampaignType.BRAND_AWARENESS);
        campaign.setStatus(StatusMaster.ACTIVE);

        return campaign;
    }

    @Test
    void createCampaign_Success() {

        Campaign campaign = getCampaign();

        when(campaignRepository.save(any()))
                .thenReturn(campaign);

        Campaign result =
                campaignService.createCampaign(
                        getRequest());

        assertNotNull(result);
        assertEquals("1", result.getId());
    }

    @Test
    void createCampaign_NullType() {

        CampaignRequestDTO dto = getRequest();
        dto.setCampaignType(null);

        assertThrows(
                BadRequestException.class,
                () -> campaignService.createCampaign(dto));
    }

    @Test
    void createCampaign_EmptyName() {

        CampaignRequestDTO dto = getRequest();
        dto.setCampaignName("");

        assertThrows(
                BadRequestException.class,
                () -> campaignService.createCampaign(dto));
    }

    @Test
    void createCampaign_NullStartDate() {

        CampaignRequestDTO dto = getRequest();
        dto.setStartDate(null);

        assertThrows(
                BadRequestException.class,
                () -> campaignService.createCampaign(dto));
    }

    @Test
    void createCampaign_NullEndDate() {

        CampaignRequestDTO dto = getRequest();
        dto.setEndDate(null);

        assertThrows(
                BadRequestException.class,
                () -> campaignService.createCampaign(dto));
    }

    @Test
    void createCampaign_StartDateAfterEndDate() {

        CampaignRequestDTO dto = getRequest();

        dto.setStartDate(
                LocalDateTime.now().plusDays(5));

        dto.setEndDate(
                LocalDateTime.now());

        assertThrows(
                BadRequestException.class,
                () -> campaignService.createCampaign(dto));
    }

    @Test
    void createCampaign_InvalidBudget() {

        CampaignRequestDTO dto = getRequest();

        dto.setTotalBudget(
                BigDecimal.ZERO);

        assertThrows(
                BadRequestException.class,
                () -> campaignService.createCampaign(dto));
    }

    @Test
    void getCampaignById_Success() {

        when(campaignRepository.findById("1"))
                .thenReturn(Optional.of(getCampaign()));

        Campaign campaign =
                campaignService.getCampaignById("1");

        assertNotNull(campaign);
    }

    @Test
    void getCampaignById_NotFound() {

        when(campaignRepository.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> campaignService.getCampaignById("1"));
    }

    @Test
    void getCampaignById_BlankId() {

        assertThrows(
                BadRequestException.class,
                () -> campaignService.getCampaignById(""));
    }

    @Test
    void getAllCampaigns_Success() {

        when(campaignRepository.findAll())
                .thenReturn(Arrays.asList(getCampaign()));

        assertEquals(
                1,
                campaignService.getAllCampaigns().size());
    }

    @Test
    void getCampaignByType_Success() {

        when(campaignRepository.findByCampaignType(
                CampaignType.BRAND_AWARENESS))
                .thenReturn(Arrays.asList(getCampaign()));

        assertEquals(
                1,
                campaignService.getCampaignByType(
                        CampaignType.BRAND_AWARENESS)
                        .size());
    }

    @Test
    void getCampaignByType_NullType() {

        assertThrows(
                BadRequestException.class,
                () -> campaignService.getCampaignByType(null));
    }

    @Test
    void updateCampaign_Success() {

        Campaign campaign = getCampaign();

        UpdateCampaignRequestDTO dto =
                new UpdateCampaignRequestDTO();

        dto.setCampaignName("Updated");

        when(campaignRepository.findById("1"))
                .thenReturn(Optional.of(campaign));

        when(campaignRepository.save(any()))
                .thenReturn(campaign);

        Campaign result =
                campaignService.updateCampaign(
                        "1",
                        dto);

        assertNotNull(result);
    }

    @Test
    void updateCampaign_NotFound() {

        when(campaignRepository.findById("1"))
                .thenReturn(Optional.empty());

        UpdateCampaignRequestDTO dto =
                new UpdateCampaignRequestDTO();

        assertThrows(
                NotFoundException.class,
                () -> campaignService.updateCampaign(
                        "1",
                        dto));
    }

    @Test
    void updateCampaign_InvalidBudget() {

        Campaign campaign = getCampaign();

        when(campaignRepository.findById("1"))
                .thenReturn(Optional.of(campaign));

        UpdateCampaignRequestDTO dto =
                new UpdateCampaignRequestDTO();

        dto.setTotalBudget(
                BigDecimal.ZERO);

        assertThrows(
                BadRequestException.class,
                () -> campaignService.updateCampaign(
                        "1",
                        dto));
    }

    @Test
    void deleteCampaign_Success() {

        Campaign campaign = getCampaign();

        when(campaignRepository.findById("1"))
                .thenReturn(Optional.of(campaign));

        when(campaignRepository.save(any()))
                .thenReturn(campaign);

        assertDoesNotThrow(
                () -> campaignService.deleteCampaign("1"));
    }

    @Test
    void deleteCampaign_NotFound() {

        when(campaignRepository.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> campaignService.deleteCampaign("1"));
    }

    @Test
    void getMyStatistics_Success() {

        Campaign active = getCampaign();

        Campaign pending = getCampaign();
        pending.setStatus(StatusMaster.PENDING);

        Campaign completed = getCampaign();
        completed.setStatus(StatusMaster.COMPLETED);

        when(campaignRepository.findByBrandId("brand1"))
                .thenReturn(Arrays.asList(
                        active,
                        pending,
                        completed));

        CampaignStatisticsDTO dto =
                campaignService.getMyStatistics();

        assertEquals(3,
                dto.getTotalCampaigns());
    }

    @Test
    void getMyStatistics_Empty() {

        when(campaignRepository.findByBrandId("brand1"))
                .thenReturn(Collections.emptyList());

        CampaignStatisticsDTO dto =
                campaignService.getMyStatistics();

        assertEquals(0,
                dto.getTotalCampaigns());
    }
}