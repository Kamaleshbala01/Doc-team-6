package com.esports.project.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import com.esports.project.DTO.CollaborationRequestDTO;
import com.esports.project.DTO.CollaborationRequestInfluencerDTO;
import com.esports.project.DTO.UserDetailsDTO;
import com.esports.project.entity.Campaign;
import com.esports.project.entity.CollaborationRequest;
import com.esports.project.enums.CampaignType;
import com.esports.project.enums.StatusMaster;
import com.esports.project.exception.BadRequestException;
import com.esports.project.exception.NotFoundException;
import com.esports.project.repository.CampaignRepository;
import com.esports.project.repository.CollaborationRepository;
import com.esports.project.service.impl.CollaborationServiceImpl;

@ExtendWith(MockitoExtension.class)
class CollaborationServiceTest {

    @Mock
    private CollaborationRepository collaborationRepository;

    @Mock
    private CampaignRepository campaignRepository;

    @InjectMocks
    private CollaborationServiceImpl collaborationService;

    @BeforeEach
    void setup() {

        UserDetailsDTO user = new UserDetailsDTO();
        user.setUserId("user1");

        UsernamePasswordAuthenticationToken auth =
                new UsernamePasswordAuthenticationToken(
                        user,
                        null,
                        Collections.emptyList());

        SecurityContextHolder.getContext()
                .setAuthentication(auth);
    }

    private Campaign getCampaign() {

        Campaign campaign = new Campaign();
        campaign.setId("campaign1");
        campaign.setBrandId("user1");
        campaign.setCampaignName("Gaming Campaign");
        campaign.setCampaignType(
                CampaignType.BRAND_AWARENESS);

        return campaign;
    }

    private CollaborationRequest getCollaboration() {

        CollaborationRequest request =
                new CollaborationRequest();

        request.setId("1");
        request.setTitle("Test Collaboration");
        request.setDescription("Description");
        request.setSenderId("user1");
        request.setUserId("user2");
        request.setProposedAmount(
                new BigDecimal("1000"));
        request.setStatus(StatusMaster.PENDING);

        return request;
    }

    private CollaborationRequestDTO getBrandRequest() {

        CollaborationRequestDTO dto =
                new CollaborationRequestDTO();

        dto.setCampaignId("campaign1");
        dto.setUserId("user2");
        dto.setTitle("Title");
        dto.setDescription("Description");
        dto.setProposedAmount(
                new BigDecimal("1000"));

        return dto;
    }

    private CollaborationRequestInfluencerDTO getInfluencerRequest() {

        CollaborationRequestInfluencerDTO dto =
                new CollaborationRequestInfluencerDTO();

        dto.setCampaignId("campaign1");
        dto.setTitle("Title");
        dto.setDescription("Description");
        dto.setProposedAmount(
                new BigDecimal("1000"));

        return dto;
    }

    @Test
    void createByBrand_Success() {

        when(campaignRepository.findById("campaign1"))
                .thenReturn(Optional.of(getCampaign()));

        when(collaborationRepository.save(any()))
                .thenReturn(getCollaboration());

        CollaborationRequest response =
                collaborationService.createByBrand(
                        getBrandRequest());

        assertNotNull(response);
    }

    @Test
    void createByBrand_NullRequest() {

        assertThrows(
                BadRequestException.class,
                () -> collaborationService.createByBrand(null));
    }

    @Test
    void createByBrand_CampaignNotFound() {

        when(campaignRepository.findById("campaign1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> collaborationService.createByBrand(
                        getBrandRequest()));
    }

    @Test
    void createByInfluencer_Success() {

        when(campaignRepository.findById("campaign1"))
                .thenReturn(Optional.of(getCampaign()));

        when(collaborationRepository.save(any()))
                .thenReturn(getCollaboration());

        CollaborationRequest response =
                collaborationService.createByInfluencer(
                        getInfluencerRequest());

        assertNotNull(response);
    }

    @Test
    void createByInfluencer_CampaignNotFound() {

        when(campaignRepository.findById("campaign1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> collaborationService.createByInfluencer(
                        getInfluencerRequest()));
    }

    @Test
    void getSent_Success() {

        when(collaborationRepository.findBySenderId("user1"))
                .thenReturn(
                        Arrays.asList(getCollaboration()));

        assertEquals(
                1,
                collaborationService.getSent().size());
    }

    @Test
    void getReceived_Success() {

        when(collaborationRepository.findByUserId("user1"))
                .thenReturn(
                        Arrays.asList(getCollaboration()));

        assertNotNull(
                collaborationService.getReceived());
    }

    @Test
    void getByStatus_Success() {

        when(collaborationRepository
                .findBySenderIdAndStatus(
                        "user1",
                        StatusMaster.PENDING))
                .thenReturn(
                        Arrays.asList(getCollaboration()));

        when(collaborationRepository
                .findByUserIdAndStatus(
                        "user1",
                        StatusMaster.PENDING))
                .thenReturn(Collections.emptyList());

        assertNotNull(
                collaborationService.getByStatus(
                        StatusMaster.PENDING));
    }

    @Test
    void getByStatus_NullStatus() {

        assertThrows(
                BadRequestException.class,
                () -> collaborationService.getByStatus(null));
    }

    @Test
    void accept_Success() {

        CollaborationRequest request =
                getCollaboration();

        request.setUserId("user1");

        when(collaborationRepository.findById("1"))
                .thenReturn(Optional.of(request));

        when(collaborationRepository.save(any()))
                .thenReturn(request);

        CollaborationRequest response =
                collaborationService.accept("1");

        assertEquals(
                StatusMaster.ACCEPTED,
                response.getStatus());
    }

    @Test
    void accept_NotFound() {

        when(collaborationRepository.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> collaborationService.accept("1"));
    }

    @Test
    void reject_Success() {

        CollaborationRequest request =
                getCollaboration();

        request.setUserId("user1");

        when(collaborationRepository.findById("1"))
                .thenReturn(Optional.of(request));

        when(collaborationRepository.save(any()))
                .thenReturn(request);

        CollaborationRequest response =
                collaborationService.reject("1");

        assertEquals(
                StatusMaster.REJECTED,
                response.getStatus());
    }

    @Test
    void reject_NotFound() {

        when(collaborationRepository.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> collaborationService.reject("1"));
    }

    @Test
    void complete_Success() {

        CollaborationRequest request =
                getCollaboration();

        request.setStatus(StatusMaster.ACCEPTED);

        when(collaborationRepository.findById("1"))
                .thenReturn(Optional.of(request));

        when(collaborationRepository.save(any()))
                .thenReturn(request);

        CollaborationRequest response =
                collaborationService.complete("1");

        assertEquals(
                StatusMaster.COMPLETED,
                response.getStatus());
    }

    @Test
    void complete_NotFound() {

        when(collaborationRepository.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> collaborationService.complete("1"));
    }

    @Test
    void complete_StatusNotAccepted() {

        CollaborationRequest request =
                getCollaboration();

        request.setStatus(StatusMaster.REJECTED);

        when(collaborationRepository.findById("1"))
                .thenReturn(Optional.of(request));

        assertThrows(
                BadRequestException.class,
                () -> collaborationService.complete("1"));
    }

    @Test
    void delete_Success() {

        CollaborationRequest request =
                getCollaboration();

        when(collaborationRepository.findById("1"))
                .thenReturn(Optional.of(request));

        doNothing().when(collaborationRepository)
                .delete(any());

        assertDoesNotThrow(
                () -> collaborationService.delete("1"));
    }

    @Test
    void delete_NotFound() {

        when(collaborationRepository.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> collaborationService.delete("1"));
    }

    @Test
    void getById_Success() {

        when(collaborationRepository.findById("1"))
                .thenReturn(Optional.of(getCollaboration()));

        CollaborationRequest response =
                collaborationService.getById("1");

        assertNotNull(response);
    }

    @Test
    void getById_NotFound() {

        when(collaborationRepository.findById("1"))
                .thenReturn(Optional.empty());

        assertThrows(
                NotFoundException.class,
                () -> collaborationService.getById("1"));
    }

    @Test
    void getByCampaign_Success() {

        when(campaignRepository.findById("campaign1"))
                .thenReturn(Optional.of(getCampaign()));

        when(collaborationRepository.findByCampaignId("campaign1"))
                .thenReturn(
                        Arrays.asList(getCollaboration()));

        assertEquals(
                1,
                collaborationService.getByCampaign("campaign1")
                        .size());
    }
}