package com.esports.BrokerApplication.controller;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.BrokerApplication.auth.ServicePrincipal;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/")
public class TestController {

    @GetMapping("health")
    public String health() {
        return "OK";
    }

    @GetMapping("test/me")
    public Map<String, String> me(
            HttpServletRequest request) {

        ServicePrincipal principal =
                (ServicePrincipal)
                        request.getAttribute(
                                "servicePrincipal");

        return Map.of(
                "service",
                principal.getServiceName()
        );
    }

}
