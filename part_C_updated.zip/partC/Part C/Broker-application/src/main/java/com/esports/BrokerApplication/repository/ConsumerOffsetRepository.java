package com.esports.BrokerApplication.repository;

import com.esports.BrokerApplication.entity.ConsumerOffsetEntity;
import com.esports.BrokerApplication.entity.ConsumerOffsetId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsumerOffsetRepository
        extends JpaRepository<
                ConsumerOffsetEntity,
                ConsumerOffsetId> {
}