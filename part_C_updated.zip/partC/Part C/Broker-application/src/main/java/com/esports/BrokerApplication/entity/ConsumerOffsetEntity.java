package com.esports.BrokerApplication.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "consumer_offsets")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConsumerOffsetEntity {

    @EmbeddedId
    private ConsumerOffsetId id;

    private Long lastOffset;
}