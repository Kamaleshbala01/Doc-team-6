package com.esports.BrokerApplication.controller;

import com.esports.BrokerApplication.repository.ConsumerOffsetRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/offsets")
@RequiredArgsConstructor
public class OffsetController {

    private final ConsumerOffsetRepository repository;

    @GetMapping
    public Object getOffsets() {
        return repository.findAll();
    }
}