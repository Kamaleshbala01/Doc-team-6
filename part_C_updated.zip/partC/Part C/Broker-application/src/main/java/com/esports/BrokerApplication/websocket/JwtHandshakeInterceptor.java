package com.esports.BrokerApplication.websocket;

import com.esports.BrokerApplication.auth.JwtService;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;

import java.util.Map;

@Component
@RequiredArgsConstructor
public class JwtHandshakeInterceptor
        implements HandshakeInterceptor {

    private final JwtService jwtService;

    @Override
    public boolean beforeHandshake(
            ServerHttpRequest request,
            org.springframework.http.server.ServerHttpResponse response,
            WebSocketHandler wsHandler,
            Map<String, Object> attributes)
            throws Exception {

        if (!(request instanceof ServletServerHttpRequest servletRequest)) {
            return false;
        }

        String token =
                servletRequest.getServletRequest()
                        .getParameter("token");

        if (token == null || token.isBlank()) {
        return false;
        }


        if (!jwtService.validate(token)) {
            return false;
        }

        Claims claims =
                jwtService.extractClaims(token);

        String tokenType =
                claims.get("token_type", String.class);

        if (!"SERVICE".equals(tokenType)) {
            return false;
        }

        String serviceName =
                claims.getSubject();

        attributes.put(
                "serviceName",
                serviceName);

        return true;
    }

    @Override
    public void afterHandshake(
            ServerHttpRequest request,
            org.springframework.http.server.ServerHttpResponse response,
            WebSocketHandler wsHandler,
            Exception exception) {
    }
}