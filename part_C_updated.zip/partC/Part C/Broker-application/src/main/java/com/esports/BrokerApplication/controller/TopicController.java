package com.esports.BrokerApplication.controller;


import com.esports.BrokerApplication.service.TopicService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Set;

@RestController
@RequiredArgsConstructor
@RequestMapping("/topics")
public class TopicController {

    private final TopicService topicService;

    @GetMapping
    public Map<String, Set<String>> getTopics() {

        return topicService.getAllTopics();
    }
}
