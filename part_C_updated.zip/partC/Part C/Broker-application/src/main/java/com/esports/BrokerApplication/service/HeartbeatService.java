package com.esports.BrokerApplication.service;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import com.esports.BrokerApplication.entity.RegisteredServiceEntity;
import com.esports.BrokerApplication.repository.RegisteredServiceRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HeartbeatService {

    private final RegisteredServiceRepository repository;

    public void updateHeartbeat(
            String serviceName) {

        RegisteredServiceEntity service =
                repository.findById(serviceName)
                        .orElse(
                                RegisteredServiceEntity
                                        .builder()
                                        .serviceName(serviceName)
                                        .build());

        service.setOnline(true);
        service.setLastHeartbeat(
                LocalDateTime.now());

        repository.save(service);
    }

    public void markOffline(
            String serviceName) {

        repository.findById(serviceName)
                .ifPresent(service -> {

                    service.setOnline(false);

                    repository.save(service);
                });
    }
}
