package com.esports.BrokerApplication.controller;

import com.esports.BrokerApplication.entity.EventEntity;
import com.esports.BrokerApplication.repository.EventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/events")
@RequiredArgsConstructor
public class EventController {

    private final EventRepository eventRepository;

    @GetMapping
    public List<EventEntity> getAll() {

        return eventRepository.findAll();
    }
}