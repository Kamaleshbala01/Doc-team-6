package com.esports.BrokerApplication.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.esports.BrokerApplication.entity.EventEntity;
import com.esports.BrokerApplication.repository.EventRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ReplayService {

    private final EventRepository eventRepository;
    private final OffsetService offsetService;

    public List<EventEntity> replayEvents(
            String serviceName,
            String topic) {

        Long offset =
                offsetService.getOffset(
                        serviceName,
                        topic);

        return eventRepository
                .findByTopicAndIdGreaterThanOrderByIdAsc(
                        topic,
                        offset);
    }
}