package com.esports.BrokerApplication.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.esports.BrokerApplication.entity.RegisteredServiceEntity;
import com.esports.BrokerApplication.repository.RegisteredServiceRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/services")
@RequiredArgsConstructor
public class ServiceController {

    private final RegisteredServiceRepository repository;

    @GetMapping
    public List<RegisteredServiceEntity> getAll() {

        return repository.findAll();
    }
}
