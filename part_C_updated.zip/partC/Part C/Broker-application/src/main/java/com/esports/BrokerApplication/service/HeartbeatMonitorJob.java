package com.esports.BrokerApplication.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.esports.BrokerApplication.entity.RegisteredServiceEntity;
import com.esports.BrokerApplication.repository.RegisteredServiceRepository;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class HeartbeatMonitorJob {

    private final RegisteredServiceRepository repository;

    @Scheduled(fixedRate = 30000)
    public void checkServices() {

        LocalDateTime threshold =
                LocalDateTime.now()
                        .minusSeconds(60);

        List<RegisteredServiceEntity> services =
                repository.findAll();

        for (RegisteredServiceEntity s : services) {

            if (Boolean.TRUE.equals(s.getOnline())
                    && s.getLastHeartbeat() != null
                    && s.getLastHeartbeat()
                            .isBefore(threshold)) {

                s.setOnline(false);

                repository.save(s);

                System.out.println(
                        s.getServiceName()
                                + " marked OFFLINE");
            }
        }
    }
}
