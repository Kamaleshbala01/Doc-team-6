# Esports Platform — Console CRUD Application

A plain-Java (no Spring) console app covering full CRUD for all 55 tables
in `eSportsSchema.sql`, organised by functional module rather than one
class per table.

## Layout

```
src/main/java/com/esports/platform/
├── Main.java                       entry point — switch/case module menu
├── entity/                         your existing generated entity classes (unchanged)
├── service/
│   ├── interfaces/                 one interface per module (CRUD method contracts)
│   │   ├── UserService.java
│   │   ├── TournamentService.java
│   │   ├── TeamService.java
│   │   ├── CampaignService.java
│   │   ├── SocialMediaService.java
│   │   ├── FinanceService.java
│   │   ├── FileNotificationService.java
│   │   ├── ChatService.java
│   │   └── AffiliateService.java
│   └── impl/                       one implementation per interface (in-memory store)
│       └── ...ServiceImpl.java
├── controller/                     one controller per module + shared CrudBinding
│   ├── CrudBinding.java
│   ├── UserController.java
│   ├── TournamentController.java
│   └── ...
└── util/
    └── ConsoleUtil.java            shared reflection-based prompt/print/filter helpers
```

## Module → entity mapping

| Module | Entities |
|---|---|
| User | Users, Roles, UserRoles, UserProfile, TournamentOrganizerDetails, BrandDetails, InfluencerDetails |
| Tournament | TournamentCategory, TournamentType, SeedingType, Tournament, RulesCategory, TournamentRule, PrizeCategory, TournamentPrize, TournamentPackage, TournamentPayment, TournamentRegistration, TournamentRegistrationPayment, TournamentAnnouncement, TournamentFAQ |
| Team | Team, TeamPosition, TeamMember |
| Campaign | CampaignType, Campaign, CampaignPlatform, CampaignAsset, CampaignDeliverable, CollaborationRequest |
| SocialMedia | SocialMediaPlatform, SocialMediaAccount, Game, InfluencerGame, StatusMaster |
| Finance | PaymentMethod, TransactionType, RevenueTransaction, SubscriptionPlan, UserSubscription |
| FileNotification | Files, Notification, AuditLog |
| Chat | Conversation, ConversationParticipant, Message, MessageAttachment, MessageReadStatus, MessageReaction, UserPresence, ConversationPinnedMessage, ConversationSettings |
| Affiliate | AffiliateCampaign, AffiliateLink, AffiliateClick |

## How each layer works

**Interface** — for every entity in its module, declares six methods:
`createX`, `getXById`, `getAllXs`, `updateX`, `deleteX`, `filterXs(Predicate<X>)`.

**Service impl** — one `LinkedHashMap<PK, Entity>` + `AtomicInteger`/`AtomicLong`
id generator per entity. `getAllXs()`/`filterXs()` are implemented with streams
(`.stream().collect(...)`, `.stream().filter(predicate).collect(...)`).

**Controller** — rather than writing the same add/list/get/update/delete/filter
command-handling code once per entity, each entity is registered as a
`CrudBinding<T>` (a small bundle of method references / lambdas pointing at
the service). The command loop is written once per controller and works
against whichever entity key the user types. Field prompts for `add`/`update`
and the `filter field=value` command are driven by reflection over the
entity's declared fields via `ConsoleUtil` — no per-field code was hand-written
for any of the 55 entities.

**Main** — a `switch` on a menu number, each case constructs the module's
controller with the shared `Scanner` and calls `.start()`. Typing `back` inside
a module returns to this menu.

## Commands (same set inside every module)

```
list <entity>                 list all records
get <entity> <id>             fetch one record by id
add <entity>                  create a record — prompts for each field
update <entity> <id>          update a record — prompts for each field
delete <entity> <id>          delete a record
filter <entity> field=value   filter by exact match on one field
entities                      list the entity keys available in this module
help                          show the command list again
back                          return to the main menu
```

Entity keys are the lowercase class name, e.g. `tournament`,
`tournamentcategory`, `teammember`, `affiliateclick`.

### Example session

```
Select module: 2
=== Tournament Management ===
...
tournament> add tournament
Enter values for a new Tournament:
  organizerId (Integer): 1
  name (String): Summer Clash
  description (String): Regional 5v5 knockout
  ...
Created:
--- Tournament ---
  id = 1
  organizerId = 1
  name = Summer Clash
  ...

tournament> list tournament
--- Tournament ---
  id = 1
  ...
Total: 1

tournament> filter tournament status=Draft
(no records)

tournament> back

--- Main Menu ---
...
```

## Building & running

Requires JDK 17+ and Maven (network access to Maven Central for the one
dependency, `jakarta.persistence-api`, which supplies the `@Entity`/`@Id`/
`@Column`/`@Table` annotations already used on your entity classes — nothing
here touches an actual database, storage is in-memory for the life of the
process).

```bash
mvn compile exec:java
```

or build a runnable jar:

```bash
mvn package
java -jar target/esports-console-app.jar
```

**No JDK/Maven on hand right now?** If you're on plain `javac`, drop
`jakarta.persistence-api-3.1.0.jar` on the classpath (or swap the entity
imports to `javax.persistence.*` and use the older `javax.persistence-api`
jar) and compile with:

```bash
javac -cp jakarta.persistence-api-3.1.0.jar -d out $(find src -name "*.java")
java -cp "out:jakarta.persistence-api-3.1.0.jar" com.esports.platform.Main
```

## Notes / things worth knowing

- All data is **in-memory** — it resets every time you restart the app.
  Swap the `Map` storage in each `*ServiceImpl` for a JPA repository or JDBC
  DAO later without touching the interfaces or controllers.
- `update` replaces the stored object with the newly-prompted one (the id
  is preserved); it isn't a partial/field-level patch.
- The `filter` command matches one field with an exact, case-insensitive
  string comparison (`value.toString().equalsIgnoreCase(...)`) — good enough
  for console testing; swap in a richer `Predicate` composition if you need
  ranges or multi-field queries.
