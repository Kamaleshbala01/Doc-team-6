package com.esports.platform.util;

import jakarta.persistence.Id;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

/**
 * Small reflection-driven helper shared by every controller so that
 * "add"/"update"/"list"/"get"/"filter" only need to be written once and
 * work for any entity in the entity package, instead of once per class.
 * Fields are discovered from the JPA @Id / declared fields already present
 * on the generated entity classes.
 */
public final class ConsoleUtil {

    private ConsoleUtil() {
    }

    public static Field getIdField(Class<?> clazz) {
        return Arrays.stream(clazz.getDeclaredFields())
                .filter(f -> f.isAnnotationPresent(Id.class))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("No @Id field on " + clazz.getSimpleName()));
    }

    public static Object parseId(Class<?> clazz, String arg, Scanner sc) {
        Field idField = getIdField(clazz);
        String raw = (arg == null || arg.isBlank()) ? null : arg.trim();
        while (raw == null || raw.isBlank()) {
            System.out.print("Enter " + idField.getName() + ": ");
            raw = sc.nextLine().trim();
        }
        return convert(raw, idField.getType());
    }

    public static <T> T promptEntity(Class<T> clazz, Scanner sc) {
        try {
            T instance = clazz.getDeclaredConstructor().newInstance();
            for (Field f : clazz.getDeclaredFields()) {
                if (f.isAnnotationPresent(Id.class)) continue; // id is system-managed
                f.setAccessible(true);
                System.out.print("  " + f.getName() + " (" + f.getType().getSimpleName() + "): ");
                String raw = sc.nextLine().trim();
                if (raw.isEmpty()) continue;
                f.set(instance, convert(raw, f.getType()));
            }
            return instance;
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException("Could not build " + clazz.getSimpleName() + ": " + e.getMessage(), e);
        }
    }

    private static Object convert(String raw, Class<?> type) {
        try {
            if (type == Integer.class) return Integer.valueOf(raw);
            if (type == Long.class) return Long.valueOf(raw);
            if (type == Boolean.class) return Boolean.valueOf(raw);
            if (type == BigDecimal.class) return new BigDecimal(raw);
            if (type == LocalDateTime.class) return LocalDateTime.parse(raw);
            return raw;
        } catch (RuntimeException e) {
            System.out.println("    (could not parse '" + raw + "' as " + type.getSimpleName() + ", leaving null)");
            return null;
        }
    }

    public static void printEntity(Object entity) {
        if (entity == null) {
            System.out.println("Not found.");
            return;
        }
        System.out.println("--- " + entity.getClass().getSimpleName() + " ---");
        Arrays.stream(entity.getClass().getDeclaredFields()).forEach(f -> {
            f.setAccessible(true);
            try {
                System.out.println("  " + f.getName() + " = " + f.get(entity));
            } catch (IllegalAccessException ignored) {
                // unreachable: setAccessible(true) above
            }
        });
    }

    public static <T> void printList(List<T> list) {
        if (list == null || list.isEmpty()) {
            System.out.println("(no records)");
            return;
        }
        list.forEach(ConsoleUtil::printEntity);
        System.out.println("Total: " + list.size());
    }

    /** Builds a Predicate&lt;T&gt; from a "field=value" argument via reflection. */
    public static <T> Predicate<T> buildFilter(Class<T> clazz, String arg) {
        if (arg == null || !arg.contains("=")) return null;
        String[] kv = arg.split("=", 2);
        String fieldName = kv[0].trim();
        String value = kv[1].trim();
        Field field;
        try {
            field = clazz.getDeclaredField(fieldName);
            field.setAccessible(true);
        } catch (NoSuchFieldException e) {
            System.out.println("No such field '" + fieldName + "' on " + clazz.getSimpleName());
            return null;
        }
        Field finalField = field;
        return entity -> {
            try {
                Object v = finalField.get(entity);
                return v != null && v.toString().equalsIgnoreCase(value);
            } catch (IllegalAccessException e) {
                return false;
            }
        };
    }
}
