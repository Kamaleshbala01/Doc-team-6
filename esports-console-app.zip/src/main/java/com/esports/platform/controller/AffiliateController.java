package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.AffiliateServiceImpl;
import com.esports.platform.service.interfaces.AffiliateService;
import com.esports.platform.util.ConsoleUtil;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Predicate;

/**
 * Console controller for the Affiliate Marketing module.
 * Every entity in this module is registered once as a CrudBinding;
 * the command loop below is entity-agnostic and works for all of them.
 */
public class AffiliateController {

    private final AffiliateService affiliateService = new AffiliateServiceImpl();
    private final Scanner sc;
    private final Map<String, CrudBinding<?>> bindings = new LinkedHashMap<>();

    public AffiliateController(Scanner sc) {
        this.sc = sc;
        register();
    }

    private void register() {
        bindings.put("affiliatecampaign", new CrudBinding<>(AffiliateCampaign.class,
                affiliateService::createAffiliateCampaign,
                id -> affiliateService.getAffiliateCampaignById((Integer) id),
                affiliateService::getAllAffiliateCampaigns,
                (id, e) -> affiliateService.updateAffiliateCampaign((Integer) id, e),
                id -> affiliateService.deleteAffiliateCampaign((Integer) id),
                affiliateService::filterAffiliateCampaigns));
        bindings.put("affiliatelink", new CrudBinding<>(AffiliateLink.class,
                affiliateService::createAffiliateLink,
                id -> affiliateService.getAffiliateLinkById((Integer) id),
                affiliateService::getAllAffiliateLinks,
                (id, e) -> affiliateService.updateAffiliateLink((Integer) id, e),
                id -> affiliateService.deleteAffiliateLink((Integer) id),
                affiliateService::filterAffiliateLinks));
        bindings.put("affiliateclick", new CrudBinding<>(AffiliateClick.class,
                affiliateService::createAffiliateClick,
                id -> affiliateService.getAffiliateClickById((Long) id),
                affiliateService::getAllAffiliateClicks,
                (id, e) -> affiliateService.updateAffiliateClick((Long) id, e),
                id -> affiliateService.deleteAffiliateClick((Long) id),
                affiliateService::filterAffiliateClicks));
    }

    public void start() {
        System.out.println();
        System.out.println("=== Affiliate Marketing ===");
        printHelp();
        while (true) {
            System.out.print("affiliate> ");
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+", 3);
            String cmd = parts[0].toLowerCase();
            if (cmd.equals("back") || cmd.equals("exit")) {
                System.out.println("Returning to main menu...");
                return;
            }
            if (cmd.equals("help")) { printHelp(); continue; }
            if (cmd.equals("entities")) { bindings.keySet().forEach(System.out::println); continue; }
            if (parts.length < 2) {
                System.out.println("Usage: <command> <entity> [id | field=value]. Type 'entities' to list entities.");
                continue;
            }
            String entityKey = parts[1].toLowerCase();
            CrudBinding<?> binding = bindings.get(entityKey);
            if (binding == null) {
                System.out.println("Unknown entity '" + entityKey + "'. Type 'entities' to list.");
                continue;
            }
            String arg = parts.length > 2 ? parts[2] : null;
            handle(cmd, binding, arg);
        }
    }

    private <T> void handle(String cmd, CrudBinding<T> binding, String arg) {
        switch (cmd) {
            case "list":
                ConsoleUtil.printList(binding.getAll.get());
                break;
            case "get": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                ConsoleUtil.printEntity(binding.getById.apply(id));
                break;
            }
            case "add": {
                System.out.println("Enter values for a new " + binding.type.getSimpleName() + ":");
                T entity = ConsoleUtil.promptEntity(binding.type, sc);
                T created = binding.create.apply(entity);
                System.out.println("Created:");
                ConsoleUtil.printEntity(created);
                break;
            }
            case "update": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                T existing = binding.getById.apply(id);
                if (existing == null) { System.out.println("Not found."); break; }
                System.out.println("Enter new values for " + binding.type.getSimpleName() + " " + id + ":");
                T updatedData = ConsoleUtil.promptEntity(binding.type, sc);
                T updated = binding.update.apply(id, updatedData);
                System.out.println("Updated:");
                ConsoleUtil.printEntity(updated);
                break;
            }
            case "delete": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                boolean ok = binding.delete.apply(id);
                System.out.println(ok ? "Deleted." : "Not found.");
                break;
            }
            case "filter": {
                Predicate<T> predicate = ConsoleUtil.buildFilter(binding.type, arg);
                if (predicate == null) {
                    System.out.println("Usage: filter <entity> field=value");
                    break;
                }
                ConsoleUtil.printList(binding.filter.apply(predicate));
                break;
            }
            default:
                System.out.println("Unknown command '" + cmd + "'. Type 'help' for the command list.");
        }
    }

    private void printHelp() {
        System.out.println("Entities: " + String.join(", ", bindings.keySet()));
        System.out.println("Commands:");
        System.out.println("  list <entity>                 - list all records");
        System.out.println("  get <entity> <id>             - fetch one record");
        System.out.println("  add <entity>                  - create a record (prompts for fields)");
        System.out.println("  update <entity> <id>          - update a record (prompts for fields)");
        System.out.println("  delete <entity> <id>          - delete a record");
        System.out.println("  filter <entity> field=value   - filter records by exact field match");
        System.out.println("  entities                      - list entity keys for this module");
        System.out.println("  help                          - show this message");
        System.out.println("  back                          - return to the main menu");
    }
}