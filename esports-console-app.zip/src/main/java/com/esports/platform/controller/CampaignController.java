package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.CampaignServiceImpl;
import com.esports.platform.service.interfaces.CampaignService;
import com.esports.platform.util.ConsoleUtil;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Predicate;

/**
 * Console controller for the Campaign & Influencer Marketing module.
 * Every entity in this module is registered once as a CrudBinding;
 * the command loop below is entity-agnostic and works for all of them.
 */
public class CampaignController {

    private final CampaignService campaignService = new CampaignServiceImpl();
    private final Scanner sc;
    private final Map<String, CrudBinding<?>> bindings = new LinkedHashMap<>();

    public CampaignController(Scanner sc) {
        this.sc = sc;
        register();
    }

    private void register() {
        bindings.put("campaigntype", new CrudBinding<>(CampaignType.class,
                campaignService::createCampaignType,
                id -> campaignService.getCampaignTypeById((Integer) id),
                campaignService::getAllCampaignTypes,
                (id, e) -> campaignService.updateCampaignType((Integer) id, e),
                id -> campaignService.deleteCampaignType((Integer) id),
                campaignService::filterCampaignTypes));
        bindings.put("campaign", new CrudBinding<>(Campaign.class,
                campaignService::createCampaign,
                id -> campaignService.getCampaignById((Integer) id),
                campaignService::getAllCampaigns,
                (id, e) -> campaignService.updateCampaign((Integer) id, e),
                id -> campaignService.deleteCampaign((Integer) id),
                campaignService::filterCampaigns));
        bindings.put("campaignplatform", new CrudBinding<>(CampaignPlatform.class,
                campaignService::createCampaignPlatform,
                id -> campaignService.getCampaignPlatformById((Integer) id),
                campaignService::getAllCampaignPlatforms,
                (id, e) -> campaignService.updateCampaignPlatform((Integer) id, e),
                id -> campaignService.deleteCampaignPlatform((Integer) id),
                campaignService::filterCampaignPlatforms));
        bindings.put("campaignasset", new CrudBinding<>(CampaignAsset.class,
                campaignService::createCampaignAsset,
                id -> campaignService.getCampaignAssetById((Integer) id),
                campaignService::getAllCampaignAssets,
                (id, e) -> campaignService.updateCampaignAsset((Integer) id, e),
                id -> campaignService.deleteCampaignAsset((Integer) id),
                campaignService::filterCampaignAssets));
        bindings.put("campaigndeliverable", new CrudBinding<>(CampaignDeliverable.class,
                campaignService::createCampaignDeliverable,
                id -> campaignService.getCampaignDeliverableById((Integer) id),
                campaignService::getAllCampaignDeliverables,
                (id, e) -> campaignService.updateCampaignDeliverable((Integer) id, e),
                id -> campaignService.deleteCampaignDeliverable((Integer) id),
                campaignService::filterCampaignDeliverables));
        bindings.put("collaborationrequest", new CrudBinding<>(CollaborationRequest.class,
                campaignService::createCollaborationRequest,
                id -> campaignService.getCollaborationRequestById((Integer) id),
                campaignService::getAllCollaborationRequests,
                (id, e) -> campaignService.updateCollaborationRequest((Integer) id, e),
                id -> campaignService.deleteCollaborationRequest((Integer) id),
                campaignService::filterCollaborationRequests));
    }

    public void start() {
        System.out.println();
        System.out.println("=== Campaign & Influencer Marketing ===");
        printHelp();
        while (true) {
            System.out.print("campaign> ");
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+", 3);
            String cmd = parts[0].toLowerCase();
            if (cmd.equals("back") || cmd.equals("exit")) {
                System.out.println("Returning to main menu...");
                return;
            }
            if (cmd.equals("help")) { printHelp(); continue; }
            if (cmd.equals("entities")) { bindings.keySet().forEach(System.out::println); continue; }
            if (parts.length < 2) {
                System.out.println("Usage: <command> <entity> [id | field=value]. Type 'entities' to list entities.");
                continue;
            }
            String entityKey = parts[1].toLowerCase();
            CrudBinding<?> binding = bindings.get(entityKey);
            if (binding == null) {
                System.out.println("Unknown entity '" + entityKey + "'. Type 'entities' to list.");
                continue;
            }
            String arg = parts.length > 2 ? parts[2] : null;
            handle(cmd, binding, arg);
        }
    }

    private <T> void handle(String cmd, CrudBinding<T> binding, String arg) {
        switch (cmd) {
            case "list":
                ConsoleUtil.printList(binding.getAll.get());
                break;
            case "get": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                ConsoleUtil.printEntity(binding.getById.apply(id));
                break;
            }
            case "add": {
                System.out.println("Enter values for a new " + binding.type.getSimpleName() + ":");
                T entity = ConsoleUtil.promptEntity(binding.type, sc);
                T created = binding.create.apply(entity);
                System.out.println("Created:");
                ConsoleUtil.printEntity(created);
                break;
            }
            case "update": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                T existing = binding.getById.apply(id);
                if (existing == null) { System.out.println("Not found."); break; }
                System.out.println("Enter new values for " + binding.type.getSimpleName() + " " + id + ":");
                T updatedData = ConsoleUtil.promptEntity(binding.type, sc);
                T updated = binding.update.apply(id, updatedData);
                System.out.println("Updated:");
                ConsoleUtil.printEntity(updated);
                break;
            }
            case "delete": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                boolean ok = binding.delete.apply(id);
                System.out.println(ok ? "Deleted." : "Not found.");
                break;
            }
            case "filter": {
                Predicate<T> predicate = ConsoleUtil.buildFilter(binding.type, arg);
                if (predicate == null) {
                    System.out.println("Usage: filter <entity> field=value");
                    break;
                }
                ConsoleUtil.printList(binding.filter.apply(predicate));
                break;
            }
            default:
                System.out.println("Unknown command '" + cmd + "'. Type 'help' for the command list.");
        }
    }

    private void printHelp() {
        System.out.println("Entities: " + String.join(", ", bindings.keySet()));
        System.out.println("Commands:");
        System.out.println("  list <entity>                 - list all records");
        System.out.println("  get <entity> <id>             - fetch one record");
        System.out.println("  add <entity>                  - create a record (prompts for fields)");
        System.out.println("  update <entity> <id>          - update a record (prompts for fields)");
        System.out.println("  delete <entity> <id>          - delete a record");
        System.out.println("  filter <entity> field=value   - filter records by exact field match");
        System.out.println("  entities                      - list entity keys for this module");
        System.out.println("  help                          - show this message");
        System.out.println("  back                          - return to the main menu");
    }
}