package com.esports.platform.controller;

import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * Groups the five CRUD operations (+ a functional filter) for a single
 * entity type so a controller can register every entity in its module
 * behind one small, uniform registry instead of writing repetitive
 * command-handling code per entity.
 */
public class CrudBinding<T> {

    public final Class<T> type;
    public final Function<T, T> create;
    public final Function<Object, T> getById;
    public final Supplier<List<T>> getAll;
    public final BiFunction<Object, T, T> update;
    public final Function<Object, Boolean> delete;
    public final Function<Predicate<T>, List<T>> filter;

    public CrudBinding(Class<T> type,
                        Function<T, T> create,
                        Function<Object, T> getById,
                        Supplier<List<T>> getAll,
                        BiFunction<Object, T, T> update,
                        Function<Object, Boolean> delete,
                        Function<Predicate<T>, List<T>> filter) {
        this.type = type;
        this.create = create;
        this.getById = getById;
        this.getAll = getAll;
        this.update = update;
        this.delete = delete;
        this.filter = filter;
    }
}
