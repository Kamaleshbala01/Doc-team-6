package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.TournamentServiceImpl;
import com.esports.platform.service.interfaces.TournamentService;
import com.esports.platform.util.ConsoleUtil;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Predicate;

/**
 * Console controller for the Tournament Management module.
 * Every entity in this module is registered once as a CrudBinding;
 * the command loop below is entity-agnostic and works for all of them.
 */
public class TournamentController {

    private final TournamentService tournamentService = new TournamentServiceImpl();
    private final Scanner sc;
    private final Map<String, CrudBinding<?>> bindings = new LinkedHashMap<>();

    public TournamentController(Scanner sc) {
        this.sc = sc;
        register();
    }

    private void register() {
        bindings.put("tournamentcategory", new CrudBinding<>(TournamentCategory.class,
                tournamentService::createTournamentCategory,
                id -> tournamentService.getTournamentCategoryById((Integer) id),
                tournamentService::getAllTournamentCategorys,
                (id, e) -> tournamentService.updateTournamentCategory((Integer) id, e),
                id -> tournamentService.deleteTournamentCategory((Integer) id),
                tournamentService::filterTournamentCategorys));
        bindings.put("tournamenttype", new CrudBinding<>(TournamentType.class,
                tournamentService::createTournamentType,
                id -> tournamentService.getTournamentTypeById((Integer) id),
                tournamentService::getAllTournamentTypes,
                (id, e) -> tournamentService.updateTournamentType((Integer) id, e),
                id -> tournamentService.deleteTournamentType((Integer) id),
                tournamentService::filterTournamentTypes));
        bindings.put("seedingtype", new CrudBinding<>(SeedingType.class,
                tournamentService::createSeedingType,
                id -> tournamentService.getSeedingTypeById((Integer) id),
                tournamentService::getAllSeedingTypes,
                (id, e) -> tournamentService.updateSeedingType((Integer) id, e),
                id -> tournamentService.deleteSeedingType((Integer) id),
                tournamentService::filterSeedingTypes));
        bindings.put("tournament", new CrudBinding<>(Tournament.class,
                tournamentService::createTournament,
                id -> tournamentService.getTournamentById((Integer) id),
                tournamentService::getAllTournaments,
                (id, e) -> tournamentService.updateTournament((Integer) id, e),
                id -> tournamentService.deleteTournament((Integer) id),
                tournamentService::filterTournaments));
        bindings.put("rulescategory", new CrudBinding<>(RulesCategory.class,
                tournamentService::createRulesCategory,
                id -> tournamentService.getRulesCategoryById((Integer) id),
                tournamentService::getAllRulesCategorys,
                (id, e) -> tournamentService.updateRulesCategory((Integer) id, e),
                id -> tournamentService.deleteRulesCategory((Integer) id),
                tournamentService::filterRulesCategorys));
        bindings.put("tournamentrule", new CrudBinding<>(TournamentRule.class,
                tournamentService::createTournamentRule,
                id -> tournamentService.getTournamentRuleById((Integer) id),
                tournamentService::getAllTournamentRules,
                (id, e) -> tournamentService.updateTournamentRule((Integer) id, e),
                id -> tournamentService.deleteTournamentRule((Integer) id),
                tournamentService::filterTournamentRules));
        bindings.put("prizecategory", new CrudBinding<>(PrizeCategory.class,
                tournamentService::createPrizeCategory,
                id -> tournamentService.getPrizeCategoryById((Integer) id),
                tournamentService::getAllPrizeCategorys,
                (id, e) -> tournamentService.updatePrizeCategory((Integer) id, e),
                id -> tournamentService.deletePrizeCategory((Integer) id),
                tournamentService::filterPrizeCategorys));
        bindings.put("tournamentprize", new CrudBinding<>(TournamentPrize.class,
                tournamentService::createTournamentPrize,
                id -> tournamentService.getTournamentPrizeById((Integer) id),
                tournamentService::getAllTournamentPrizes,
                (id, e) -> tournamentService.updateTournamentPrize((Integer) id, e),
                id -> tournamentService.deleteTournamentPrize((Integer) id),
                tournamentService::filterTournamentPrizes));
        bindings.put("tournamentpackage", new CrudBinding<>(TournamentPackage.class,
                tournamentService::createTournamentPackage,
                id -> tournamentService.getTournamentPackageById((Integer) id),
                tournamentService::getAllTournamentPackages,
                (id, e) -> tournamentService.updateTournamentPackage((Integer) id, e),
                id -> tournamentService.deleteTournamentPackage((Integer) id),
                tournamentService::filterTournamentPackages));
        bindings.put("tournamentpayment", new CrudBinding<>(TournamentPayment.class,
                tournamentService::createTournamentPayment,
                id -> tournamentService.getTournamentPaymentById((Integer) id),
                tournamentService::getAllTournamentPayments,
                (id, e) -> tournamentService.updateTournamentPayment((Integer) id, e),
                id -> tournamentService.deleteTournamentPayment((Integer) id),
                tournamentService::filterTournamentPayments));
        bindings.put("tournamentregistration", new CrudBinding<>(TournamentRegistration.class,
                tournamentService::createTournamentRegistration,
                id -> tournamentService.getTournamentRegistrationById((Integer) id),
                tournamentService::getAllTournamentRegistrations,
                (id, e) -> tournamentService.updateTournamentRegistration((Integer) id, e),
                id -> tournamentService.deleteTournamentRegistration((Integer) id),
                tournamentService::filterTournamentRegistrations));
        bindings.put("tournamentregistrationpayment", new CrudBinding<>(TournamentRegistrationPayment.class,
                tournamentService::createTournamentRegistrationPayment,
                id -> tournamentService.getTournamentRegistrationPaymentById((Integer) id),
                tournamentService::getAllTournamentRegistrationPayments,
                (id, e) -> tournamentService.updateTournamentRegistrationPayment((Integer) id, e),
                id -> tournamentService.deleteTournamentRegistrationPayment((Integer) id),
                tournamentService::filterTournamentRegistrationPayments));
        bindings.put("tournamentannouncement", new CrudBinding<>(TournamentAnnouncement.class,
                tournamentService::createTournamentAnnouncement,
                id -> tournamentService.getTournamentAnnouncementById((Integer) id),
                tournamentService::getAllTournamentAnnouncements,
                (id, e) -> tournamentService.updateTournamentAnnouncement((Integer) id, e),
                id -> tournamentService.deleteTournamentAnnouncement((Integer) id),
                tournamentService::filterTournamentAnnouncements));
        bindings.put("tournamentfaq", new CrudBinding<>(TournamentFAQ.class,
                tournamentService::createTournamentFAQ,
                id -> tournamentService.getTournamentFAQById((Integer) id),
                tournamentService::getAllTournamentFAQs,
                (id, e) -> tournamentService.updateTournamentFAQ((Integer) id, e),
                id -> tournamentService.deleteTournamentFAQ((Integer) id),
                tournamentService::filterTournamentFAQs));
    }

    public void start() {
        System.out.println();
        System.out.println("=== Tournament Management ===");
        printHelp();
        while (true) {
            System.out.print("tournament> ");
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+", 3);
            String cmd = parts[0].toLowerCase();
            if (cmd.equals("back") || cmd.equals("exit")) {
                System.out.println("Returning to main menu...");
                return;
            }
            if (cmd.equals("help")) { printHelp(); continue; }
            if (cmd.equals("entities")) { bindings.keySet().forEach(System.out::println); continue; }
            if (parts.length < 2) {
                System.out.println("Usage: <command> <entity> [id | field=value]. Type 'entities' to list entities.");
                continue;
            }
            String entityKey = parts[1].toLowerCase();
            CrudBinding<?> binding = bindings.get(entityKey);
            if (binding == null) {
                System.out.println("Unknown entity '" + entityKey + "'. Type 'entities' to list.");
                continue;
            }
            String arg = parts.length > 2 ? parts[2] : null;
            handle(cmd, binding, arg);
        }
    }

    private <T> void handle(String cmd, CrudBinding<T> binding, String arg) {
        switch (cmd) {
            case "list":
                ConsoleUtil.printList(binding.getAll.get());
                break;
            case "get": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                ConsoleUtil.printEntity(binding.getById.apply(id));
                break;
            }
            case "add": {
                System.out.println("Enter values for a new " + binding.type.getSimpleName() + ":");
                T entity = ConsoleUtil.promptEntity(binding.type, sc);
                T created = binding.create.apply(entity);
                System.out.println("Created:");
                ConsoleUtil.printEntity(created);
                break;
            }
            case "update": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                T existing = binding.getById.apply(id);
                if (existing == null) { System.out.println("Not found."); break; }
                System.out.println("Enter new values for " + binding.type.getSimpleName() + " " + id + ":");
                T updatedData = ConsoleUtil.promptEntity(binding.type, sc);
                T updated = binding.update.apply(id, updatedData);
                System.out.println("Updated:");
                ConsoleUtil.printEntity(updated);
                break;
            }
            case "delete": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                boolean ok = binding.delete.apply(id);
                System.out.println(ok ? "Deleted." : "Not found.");
                break;
            }
            case "filter": {
                Predicate<T> predicate = ConsoleUtil.buildFilter(binding.type, arg);
                if (predicate == null) {
                    System.out.println("Usage: filter <entity> field=value");
                    break;
                }
                ConsoleUtil.printList(binding.filter.apply(predicate));
                break;
            }
            default:
                System.out.println("Unknown command '" + cmd + "'. Type 'help' for the command list.");
        }
    }

    private void printHelp() {
        System.out.println("Entities: " + String.join(", ", bindings.keySet()));
        System.out.println("Commands:");
        System.out.println("  list <entity>                 - list all records");
        System.out.println("  get <entity> <id>             - fetch one record");
        System.out.println("  add <entity>                  - create a record (prompts for fields)");
        System.out.println("  update <entity> <id>          - update a record (prompts for fields)");
        System.out.println("  delete <entity> <id>          - delete a record");
        System.out.println("  filter <entity> field=value   - filter records by exact field match");
        System.out.println("  entities                      - list entity keys for this module");
        System.out.println("  help                          - show this message");
        System.out.println("  back                          - return to the main menu");
    }
}