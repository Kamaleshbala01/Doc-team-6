package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.FileNotificationServiceImpl;
import com.esports.platform.service.interfaces.FileNotificationService;
import com.esports.platform.util.ConsoleUtil;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Predicate;

/**
 * Console controller for the Files, Notifications & Audit module.
 * Every entity in this module is registered once as a CrudBinding;
 * the command loop below is entity-agnostic and works for all of them.
 */
public class FileNotificationController {

    private final FileNotificationService fileNotificationService = new FileNotificationServiceImpl();
    private final Scanner sc;
    private final Map<String, CrudBinding<?>> bindings = new LinkedHashMap<>();

    public FileNotificationController(Scanner sc) {
        this.sc = sc;
        register();
    }

    private void register() {
        bindings.put("files", new CrudBinding<>(Files.class,
                fileNotificationService::createFiles,
                id -> fileNotificationService.getFilesById((Integer) id),
                fileNotificationService::getAllFiles,
                (id, e) -> fileNotificationService.updateFiles((Integer) id, e),
                id -> fileNotificationService.deleteFiles((Integer) id),
                fileNotificationService::filterFiles));
        bindings.put("notification", new CrudBinding<>(Notification.class,
                fileNotificationService::createNotification,
                id -> fileNotificationService.getNotificationById((Integer) id),
                fileNotificationService::getAllNotifications,
                (id, e) -> fileNotificationService.updateNotification((Integer) id, e),
                id -> fileNotificationService.deleteNotification((Integer) id),
                fileNotificationService::filterNotifications));
        bindings.put("auditlog", new CrudBinding<>(AuditLog.class,
                fileNotificationService::createAuditLog,
                id -> fileNotificationService.getAuditLogById((Integer) id),
                fileNotificationService::getAllAuditLogs,
                (id, e) -> fileNotificationService.updateAuditLog((Integer) id, e),
                id -> fileNotificationService.deleteAuditLog((Integer) id),
                fileNotificationService::filterAuditLogs));
    }

    public void start() {
        System.out.println();
        System.out.println("=== Files, Notifications & Audit ===");
        printHelp();
        while (true) {
            System.out.print("filenotification> ");
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+", 3);
            String cmd = parts[0].toLowerCase();
            if (cmd.equals("back") || cmd.equals("exit")) {
                System.out.println("Returning to main menu...");
                return;
            }
            if (cmd.equals("help")) { printHelp(); continue; }
            if (cmd.equals("entities")) { bindings.keySet().forEach(System.out::println); continue; }
            if (parts.length < 2) {
                System.out.println("Usage: <command> <entity> [id | field=value]. Type 'entities' to list entities.");
                continue;
            }
            String entityKey = parts[1].toLowerCase();
            CrudBinding<?> binding = bindings.get(entityKey);
            if (binding == null) {
                System.out.println("Unknown entity '" + entityKey + "'. Type 'entities' to list.");
                continue;
            }
            String arg = parts.length > 2 ? parts[2] : null;
            handle(cmd, binding, arg);
        }
    }

    private <T> void handle(String cmd, CrudBinding<T> binding, String arg) {
        switch (cmd) {
            case "list":
                ConsoleUtil.printList(binding.getAll.get());
                break;
            case "get": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                ConsoleUtil.printEntity(binding.getById.apply(id));
                break;
            }
            case "add": {
                System.out.println("Enter values for a new " + binding.type.getSimpleName() + ":");
                T entity = ConsoleUtil.promptEntity(binding.type, sc);
                T created = binding.create.apply(entity);
                System.out.println("Created:");
                ConsoleUtil.printEntity(created);
                break;
            }
            case "update": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                T existing = binding.getById.apply(id);
                if (existing == null) { System.out.println("Not found."); break; }
                System.out.println("Enter new values for " + binding.type.getSimpleName() + " " + id + ":");
                T updatedData = ConsoleUtil.promptEntity(binding.type, sc);
                T updated = binding.update.apply(id, updatedData);
                System.out.println("Updated:");
                ConsoleUtil.printEntity(updated);
                break;
            }
            case "delete": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                boolean ok = binding.delete.apply(id);
                System.out.println(ok ? "Deleted." : "Not found.");
                break;
            }
            case "filter": {
                Predicate<T> predicate = ConsoleUtil.buildFilter(binding.type, arg);
                if (predicate == null) {
                    System.out.println("Usage: filter <entity> field=value");
                    break;
                }
                ConsoleUtil.printList(binding.filter.apply(predicate));
                break;
            }
            default:
                System.out.println("Unknown command '" + cmd + "'. Type 'help' for the command list.");
        }
    }

    private void printHelp() {
        System.out.println("Entities: " + String.join(", ", bindings.keySet()));
        System.out.println("Commands:");
        System.out.println("  list <entity>                 - list all records");
        System.out.println("  get <entity> <id>             - fetch one record");
        System.out.println("  add <entity>                  - create a record (prompts for fields)");
        System.out.println("  update <entity> <id>          - update a record (prompts for fields)");
        System.out.println("  delete <entity> <id>          - delete a record");
        System.out.println("  filter <entity> field=value   - filter records by exact field match");
        System.out.println("  entities                      - list entity keys for this module");
        System.out.println("  help                          - show this message");
        System.out.println("  back                          - return to the main menu");
    }
}