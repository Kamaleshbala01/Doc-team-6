package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.ChatServiceImpl;
import com.esports.platform.service.interfaces.ChatService;
import com.esports.platform.util.ConsoleUtil;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Predicate;

/**
 * Console controller for the Chat / Messaging module.
 * Every entity in this module is registered once as a CrudBinding;
 * the command loop below is entity-agnostic and works for all of them.
 */
public class ChatController {

    private final ChatService chatService = new ChatServiceImpl();
    private final Scanner sc;
    private final Map<String, CrudBinding<?>> bindings = new LinkedHashMap<>();

    public ChatController(Scanner sc) {
        this.sc = sc;
        register();
    }

    private void register() {
        bindings.put("conversation", new CrudBinding<>(Conversation.class,
                chatService::createConversation,
                id -> chatService.getConversationById((Integer) id),
                chatService::getAllConversations,
                (id, e) -> chatService.updateConversation((Integer) id, e),
                id -> chatService.deleteConversation((Integer) id),
                chatService::filterConversations));
        bindings.put("conversationparticipant", new CrudBinding<>(ConversationParticipant.class,
                chatService::createConversationParticipant,
                id -> chatService.getConversationParticipantById((Long) id),
                chatService::getAllConversationParticipants,
                (id, e) -> chatService.updateConversationParticipant((Long) id, e),
                id -> chatService.deleteConversationParticipant((Long) id),
                chatService::filterConversationParticipants));
        bindings.put("message", new CrudBinding<>(Message.class,
                chatService::createMessage,
                id -> chatService.getMessageById((Long) id),
                chatService::getAllMessages,
                (id, e) -> chatService.updateMessage((Long) id, e),
                id -> chatService.deleteMessage((Long) id),
                chatService::filterMessages));
        bindings.put("messageattachment", new CrudBinding<>(MessageAttachment.class,
                chatService::createMessageAttachment,
                id -> chatService.getMessageAttachmentById((Long) id),
                chatService::getAllMessageAttachments,
                (id, e) -> chatService.updateMessageAttachment((Long) id, e),
                id -> chatService.deleteMessageAttachment((Long) id),
                chatService::filterMessageAttachments));
        bindings.put("messagereadstatus", new CrudBinding<>(MessageReadStatus.class,
                chatService::createMessageReadStatus,
                id -> chatService.getMessageReadStatusById((Long) id),
                chatService::getAllMessageReadStatus,
                (id, e) -> chatService.updateMessageReadStatus((Long) id, e),
                id -> chatService.deleteMessageReadStatus((Long) id),
                chatService::filterMessageReadStatus));
        bindings.put("messagereaction", new CrudBinding<>(MessageReaction.class,
                chatService::createMessageReaction,
                id -> chatService.getMessageReactionById((Long) id),
                chatService::getAllMessageReactions,
                (id, e) -> chatService.updateMessageReaction((Long) id, e),
                id -> chatService.deleteMessageReaction((Long) id),
                chatService::filterMessageReactions));
        bindings.put("userpresence", new CrudBinding<>(UserPresence.class,
                chatService::createUserPresence,
                id -> chatService.getUserPresenceById((Integer) id),
                chatService::getAllUserPresences,
                (id, e) -> chatService.updateUserPresence((Integer) id, e),
                id -> chatService.deleteUserPresence((Integer) id),
                chatService::filterUserPresences));
        bindings.put("conversationpinnedmessage", new CrudBinding<>(ConversationPinnedMessage.class,
                chatService::createConversationPinnedMessage,
                id -> chatService.getConversationPinnedMessageById((Long) id),
                chatService::getAllConversationPinnedMessages,
                (id, e) -> chatService.updateConversationPinnedMessage((Long) id, e),
                id -> chatService.deleteConversationPinnedMessage((Long) id),
                chatService::filterConversationPinnedMessages));
        bindings.put("conversationsettings", new CrudBinding<>(ConversationSettings.class,
                chatService::createConversationSettings,
                id -> chatService.getConversationSettingsById((Integer) id),
                chatService::getAllConversationSettings,
                (id, e) -> chatService.updateConversationSettings((Integer) id, e),
                id -> chatService.deleteConversationSettings((Integer) id),
                chatService::filterConversationSettings));
    }

    public void start() {
        System.out.println();
        System.out.println("=== Chat / Messaging ===");
        printHelp();
        while (true) {
            System.out.print("chat> ");
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+", 3);
            String cmd = parts[0].toLowerCase();
            if (cmd.equals("back") || cmd.equals("exit")) {
                System.out.println("Returning to main menu...");
                return;
            }
            if (cmd.equals("help")) { printHelp(); continue; }
            if (cmd.equals("entities")) { bindings.keySet().forEach(System.out::println); continue; }
            if (parts.length < 2) {
                System.out.println("Usage: <command> <entity> [id | field=value]. Type 'entities' to list entities.");
                continue;
            }
            String entityKey = parts[1].toLowerCase();
            CrudBinding<?> binding = bindings.get(entityKey);
            if (binding == null) {
                System.out.println("Unknown entity '" + entityKey + "'. Type 'entities' to list.");
                continue;
            }
            String arg = parts.length > 2 ? parts[2] : null;
            handle(cmd, binding, arg);
        }
    }

    private <T> void handle(String cmd, CrudBinding<T> binding, String arg) {
        switch (cmd) {
            case "list":
                ConsoleUtil.printList(binding.getAll.get());
                break;
            case "get": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                ConsoleUtil.printEntity(binding.getById.apply(id));
                break;
            }
            case "add": {
                System.out.println("Enter values for a new " + binding.type.getSimpleName() + ":");
                T entity = ConsoleUtil.promptEntity(binding.type, sc);
                T created = binding.create.apply(entity);
                System.out.println("Created:");
                ConsoleUtil.printEntity(created);
                break;
            }
            case "update": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                T existing = binding.getById.apply(id);
                if (existing == null) { System.out.println("Not found."); break; }
                System.out.println("Enter new values for " + binding.type.getSimpleName() + " " + id + ":");
                T updatedData = ConsoleUtil.promptEntity(binding.type, sc);
                T updated = binding.update.apply(id, updatedData);
                System.out.println("Updated:");
                ConsoleUtil.printEntity(updated);
                break;
            }
            case "delete": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                boolean ok = binding.delete.apply(id);
                System.out.println(ok ? "Deleted." : "Not found.");
                break;
            }
            case "filter": {
                Predicate<T> predicate = ConsoleUtil.buildFilter(binding.type, arg);
                if (predicate == null) {
                    System.out.println("Usage: filter <entity> field=value");
                    break;
                }
                ConsoleUtil.printList(binding.filter.apply(predicate));
                break;
            }
            default:
                System.out.println("Unknown command '" + cmd + "'. Type 'help' for the command list.");
        }
    }

    private void printHelp() {
        System.out.println("Entities: " + String.join(", ", bindings.keySet()));
        System.out.println("Commands:");
        System.out.println("  list <entity>                 - list all records");
        System.out.println("  get <entity> <id>             - fetch one record");
        System.out.println("  add <entity>                  - create a record (prompts for fields)");
        System.out.println("  update <entity> <id>          - update a record (prompts for fields)");
        System.out.println("  delete <entity> <id>          - delete a record");
        System.out.println("  filter <entity> field=value   - filter records by exact field match");
        System.out.println("  entities                      - list entity keys for this module");
        System.out.println("  help                          - show this message");
        System.out.println("  back                          - return to the main menu");
    }
}