package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.UserServiceImpl;
import com.esports.platform.service.interfaces.UserService;
import com.esports.platform.util.ConsoleUtil;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Predicate;

/**
 * Console controller for the User Management (Users, Roles, Profiles, Organiser/Brand/Influencer Details) module.
 * Every entity in this module is registered once as a CrudBinding;
 * the command loop below is entity-agnostic and works for all of them.
 */
public class UserController {

    private final UserService userService = new UserServiceImpl();
    private final Scanner sc;
    private final Map<String, CrudBinding<?>> bindings = new LinkedHashMap<>();

    public UserController(Scanner sc) {
        this.sc = sc;
        register();
    }

    private void register() {
        bindings.put("users", new CrudBinding<>(Users.class,
                userService::createUsers,
                id -> userService.getUsersById((Integer) id),
                userService::getAllUsers,
                (id, e) -> userService.updateUsers((Integer) id, e),
                id -> userService.deleteUsers((Integer) id),
                userService::filterUsers));
        bindings.put("roles", new CrudBinding<>(Roles.class,
                userService::createRoles,
                id -> userService.getRolesById((Integer) id),
                userService::getAllRoles,
                (id, e) -> userService.updateRoles((Integer) id, e),
                id -> userService.deleteRoles((Integer) id),
                userService::filterRoles));
        bindings.put("userroles", new CrudBinding<>(UserRoles.class,
                userService::createUserRoles,
                id -> userService.getUserRolesById((Integer) id),
                userService::getAllUserRoles,
                (id, e) -> userService.updateUserRoles((Integer) id, e),
                id -> userService.deleteUserRoles((Integer) id),
                userService::filterUserRoles));
        bindings.put("userprofile", new CrudBinding<>(UserProfile.class,
                userService::createUserProfile,
                id -> userService.getUserProfileById((Integer) id),
                userService::getAllUserProfiles,
                (id, e) -> userService.updateUserProfile((Integer) id, e),
                id -> userService.deleteUserProfile((Integer) id),
                userService::filterUserProfiles));
        bindings.put("tournamentorganizerdetails", new CrudBinding<>(TournamentOrganizerDetails.class,
                userService::createTournamentOrganizerDetails,
                id -> userService.getTournamentOrganizerDetailsById((Integer) id),
                userService::getAllTournamentOrganizerDetails,
                (id, e) -> userService.updateTournamentOrganizerDetails((Integer) id, e),
                id -> userService.deleteTournamentOrganizerDetails((Integer) id),
                userService::filterTournamentOrganizerDetails));
        bindings.put("branddetails", new CrudBinding<>(BrandDetails.class,
                userService::createBrandDetails,
                id -> userService.getBrandDetailsById((Integer) id),
                userService::getAllBrandDetails,
                (id, e) -> userService.updateBrandDetails((Integer) id, e),
                id -> userService.deleteBrandDetails((Integer) id),
                userService::filterBrandDetails));
        bindings.put("influencerdetails", new CrudBinding<>(InfluencerDetails.class,
                userService::createInfluencerDetails,
                id -> userService.getInfluencerDetailsById((Integer) id),
                userService::getAllInfluencerDetails,
                (id, e) -> userService.updateInfluencerDetails((Integer) id, e),
                id -> userService.deleteInfluencerDetails((Integer) id),
                userService::filterInfluencerDetails));
    }

    public void start() {
        System.out.println();
        System.out.println("=== User Management (Users, Roles, Profiles, Organiser/Brand/Influencer Details) ===");
        printHelp();
        while (true) {
            System.out.print("user> ");
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+", 3);
            String cmd = parts[0].toLowerCase();
            if (cmd.equals("back") || cmd.equals("exit")) {
                System.out.println("Returning to main menu...");
                return;
            }
            if (cmd.equals("help")) { printHelp(); continue; }
            if (cmd.equals("entities")) { bindings.keySet().forEach(System.out::println); continue; }
            if (parts.length < 2) {
                System.out.println("Usage: <command> <entity> [id | field=value]. Type 'entities' to list entities.");
                continue;
            }
            String entityKey = parts[1].toLowerCase();
            CrudBinding<?> binding = bindings.get(entityKey);
            if (binding == null) {
                System.out.println("Unknown entity '" + entityKey + "'. Type 'entities' to list.");
                continue;
            }
            String arg = parts.length > 2 ? parts[2] : null;
            handle(cmd, binding, arg);
        }
    }

    private <T> void handle(String cmd, CrudBinding<T> binding, String arg) {
        switch (cmd) {
            case "list":
                ConsoleUtil.printList(binding.getAll.get());
                break;
            case "get": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                ConsoleUtil.printEntity(binding.getById.apply(id));
                break;
            }
            case "add": {
                System.out.println("Enter values for a new " + binding.type.getSimpleName() + ":");
                T entity = ConsoleUtil.promptEntity(binding.type, sc);
                T created = binding.create.apply(entity);
                System.out.println("Created:");
                ConsoleUtil.printEntity(created);
                break;
            }
            case "update": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                T existing = binding.getById.apply(id);
                if (existing == null) { System.out.println("Not found."); break; }
                System.out.println("Enter new values for " + binding.type.getSimpleName() + " " + id + ":");
                T updatedData = ConsoleUtil.promptEntity(binding.type, sc);
                T updated = binding.update.apply(id, updatedData);
                System.out.println("Updated:");
                ConsoleUtil.printEntity(updated);
                break;
            }
            case "delete": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                boolean ok = binding.delete.apply(id);
                System.out.println(ok ? "Deleted." : "Not found.");
                break;
            }
            case "filter": {
                Predicate<T> predicate = ConsoleUtil.buildFilter(binding.type, arg);
                if (predicate == null) {
                    System.out.println("Usage: filter <entity> field=value");
                    break;
                }
                ConsoleUtil.printList(binding.filter.apply(predicate));
                break;
            }
            default:
                System.out.println("Unknown command '" + cmd + "'. Type 'help' for the command list.");
        }
    }

    private void printHelp() {
        System.out.println("Entities: " + String.join(", ", bindings.keySet()));
        System.out.println("Commands:");
        System.out.println("  list <entity>                 - list all records");
        System.out.println("  get <entity> <id>             - fetch one record");
        System.out.println("  add <entity>                  - create a record (prompts for fields)");
        System.out.println("  update <entity> <id>          - update a record (prompts for fields)");
        System.out.println("  delete <entity> <id>          - delete a record");
        System.out.println("  filter <entity> field=value   - filter records by exact field match");
        System.out.println("  entities                      - list entity keys for this module");
        System.out.println("  help                          - show this message");
        System.out.println("  back                          - return to the main menu");
    }
}