package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.FinanceServiceImpl;
import com.esports.platform.service.interfaces.FinanceService;
import com.esports.platform.util.ConsoleUtil;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Predicate;

/**
 * Console controller for the Finance (Payments, Subscriptions, Revenue) module.
 * Every entity in this module is registered once as a CrudBinding;
 * the command loop below is entity-agnostic and works for all of them.
 */
public class FinanceController {

    private final FinanceService financeService = new FinanceServiceImpl();
    private final Scanner sc;
    private final Map<String, CrudBinding<?>> bindings = new LinkedHashMap<>();

    public FinanceController(Scanner sc) {
        this.sc = sc;
        register();
    }

    private void register() {
        bindings.put("paymentmethod", new CrudBinding<>(PaymentMethod.class,
                financeService::createPaymentMethod,
                id -> financeService.getPaymentMethodById((Integer) id),
                financeService::getAllPaymentMethods,
                (id, e) -> financeService.updatePaymentMethod((Integer) id, e),
                id -> financeService.deletePaymentMethod((Integer) id),
                financeService::filterPaymentMethods));
        bindings.put("transactiontype", new CrudBinding<>(TransactionType.class,
                financeService::createTransactionType,
                id -> financeService.getTransactionTypeById((Integer) id),
                financeService::getAllTransactionTypes,
                (id, e) -> financeService.updateTransactionType((Integer) id, e),
                id -> financeService.deleteTransactionType((Integer) id),
                financeService::filterTransactionTypes));
        bindings.put("revenuetransaction", new CrudBinding<>(RevenueTransaction.class,
                financeService::createRevenueTransaction,
                id -> financeService.getRevenueTransactionById((Integer) id),
                financeService::getAllRevenueTransactions,
                (id, e) -> financeService.updateRevenueTransaction((Integer) id, e),
                id -> financeService.deleteRevenueTransaction((Integer) id),
                financeService::filterRevenueTransactions));
        bindings.put("subscriptionplan", new CrudBinding<>(SubscriptionPlan.class,
                financeService::createSubscriptionPlan,
                id -> financeService.getSubscriptionPlanById((Integer) id),
                financeService::getAllSubscriptionPlans,
                (id, e) -> financeService.updateSubscriptionPlan((Integer) id, e),
                id -> financeService.deleteSubscriptionPlan((Integer) id),
                financeService::filterSubscriptionPlans));
        bindings.put("usersubscription", new CrudBinding<>(UserSubscription.class,
                financeService::createUserSubscription,
                id -> financeService.getUserSubscriptionById((Integer) id),
                financeService::getAllUserSubscriptions,
                (id, e) -> financeService.updateUserSubscription((Integer) id, e),
                id -> financeService.deleteUserSubscription((Integer) id),
                financeService::filterUserSubscriptions));
    }

    public void start() {
        System.out.println();
        System.out.println("=== Finance (Payments, Subscriptions, Revenue) ===");
        printHelp();
        while (true) {
            System.out.print("finance> ");
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+", 3);
            String cmd = parts[0].toLowerCase();
            if (cmd.equals("back") || cmd.equals("exit")) {
                System.out.println("Returning to main menu...");
                return;
            }
            if (cmd.equals("help")) { printHelp(); continue; }
            if (cmd.equals("entities")) { bindings.keySet().forEach(System.out::println); continue; }
            if (parts.length < 2) {
                System.out.println("Usage: <command> <entity> [id | field=value]. Type 'entities' to list entities.");
                continue;
            }
            String entityKey = parts[1].toLowerCase();
            CrudBinding<?> binding = bindings.get(entityKey);
            if (binding == null) {
                System.out.println("Unknown entity '" + entityKey + "'. Type 'entities' to list.");
                continue;
            }
            String arg = parts.length > 2 ? parts[2] : null;
            handle(cmd, binding, arg);
        }
    }

    private <T> void handle(String cmd, CrudBinding<T> binding, String arg) {
        switch (cmd) {
            case "list":
                ConsoleUtil.printList(binding.getAll.get());
                break;
            case "get": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                ConsoleUtil.printEntity(binding.getById.apply(id));
                break;
            }
            case "add": {
                System.out.println("Enter values for a new " + binding.type.getSimpleName() + ":");
                T entity = ConsoleUtil.promptEntity(binding.type, sc);
                T created = binding.create.apply(entity);
                System.out.println("Created:");
                ConsoleUtil.printEntity(created);
                break;
            }
            case "update": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                T existing = binding.getById.apply(id);
                if (existing == null) { System.out.println("Not found."); break; }
                System.out.println("Enter new values for " + binding.type.getSimpleName() + " " + id + ":");
                T updatedData = ConsoleUtil.promptEntity(binding.type, sc);
                T updated = binding.update.apply(id, updatedData);
                System.out.println("Updated:");
                ConsoleUtil.printEntity(updated);
                break;
            }
            case "delete": {
                Object id = ConsoleUtil.parseId(binding.type, arg, sc);
                boolean ok = binding.delete.apply(id);
                System.out.println(ok ? "Deleted." : "Not found.");
                break;
            }
            case "filter": {
                Predicate<T> predicate = ConsoleUtil.buildFilter(binding.type, arg);
                if (predicate == null) {
                    System.out.println("Usage: filter <entity> field=value");
                    break;
                }
                ConsoleUtil.printList(binding.filter.apply(predicate));
                break;
            }
            default:
                System.out.println("Unknown command '" + cmd + "'. Type 'help' for the command list.");
        }
    }

    private void printHelp() {
        System.out.println("Entities: " + String.join(", ", bindings.keySet()));
        System.out.println("Commands:");
        System.out.println("  list <entity>                 - list all records");
        System.out.println("  get <entity> <id>             - fetch one record");
        System.out.println("  add <entity>                  - create a record (prompts for fields)");
        System.out.println("  update <entity> <id>          - update a record (prompts for fields)");
        System.out.println("  delete <entity> <id>          - delete a record");
        System.out.println("  filter <entity> field=value   - filter records by exact field match");
        System.out.println("  entities                      - list entity keys for this module");
        System.out.println("  help                          - show this message");
        System.out.println("  back                          - return to the main menu");
    }
}