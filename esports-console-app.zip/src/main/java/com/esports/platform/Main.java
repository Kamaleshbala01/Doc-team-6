package com.esports.platform;

import com.esports.platform.controller.*;

import java.util.Scanner;

/**
 * Entry point for the Gaming & Esports Influencer Marketing Platform
 * console application. Pick a module, then use its command set
 * (list / get / add / update / delete / filter) against any entity
 * that module owns.
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("==================================================================");
        System.out.println(" Gaming & Esports Influencer Marketing Platform - Console CRUD App ");
        System.out.println("==================================================================");

        boolean running = true;
        while (running) {
            printMenu();
            System.out.print("Select module: ");
            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1": new UserController(sc).start(); break;
                case "2": new TournamentController(sc).start(); break;
                case "3": new TeamController(sc).start(); break;
                case "4": new CampaignController(sc).start(); break;
                case "5": new SocialMediaController(sc).start(); break;
                case "6": new FinanceController(sc).start(); break;
                case "7": new FileNotificationController(sc).start(); break;
                case "8": new ChatController(sc).start(); break;
                case "9": new AffiliateController(sc).start(); break;
                case "0":
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
        sc.close();
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("--- Main Menu ---");
        System.out.println("1. User Management (Users, Roles, Profiles, Organiser/Brand/Influencer Details)");
        System.out.println("2. Tournament Management");
        System.out.println("3. Team Management");
        System.out.println("4. Campaign & Influencer Marketing");
        System.out.println("5. Social Media & Games");
        System.out.println("6. Finance (Payments, Subscriptions, Revenue)");
        System.out.println("7. Files, Notifications & Audit");
        System.out.println("8. Chat / Messaging");
        System.out.println("9. Affiliate Marketing");
        System.out.println("0. Exit");
    }
}