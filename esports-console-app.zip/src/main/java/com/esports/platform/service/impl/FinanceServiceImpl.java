package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.FinanceService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * In-memory implementation of FinanceService.
 * Storage is a LinkedHashMap per entity (keeps insertion order);
 * ids are generated with an Atomic counter per entity.
 */
public class FinanceServiceImpl implements FinanceService {

    private final Map<Integer, PaymentMethod> paymentMethodStore = new LinkedHashMap<>();
    private final AtomicInteger paymentMethodIdGen = new AtomicInteger(1);
    private final Map<Integer, TransactionType> transactionTypeStore = new LinkedHashMap<>();
    private final AtomicInteger transactionTypeIdGen = new AtomicInteger(1);
    private final Map<Integer, RevenueTransaction> revenueTransactionStore = new LinkedHashMap<>();
    private final AtomicInteger revenueTransactionIdGen = new AtomicInteger(1);
    private final Map<Integer, SubscriptionPlan> subscriptionPlanStore = new LinkedHashMap<>();
    private final AtomicInteger subscriptionPlanIdGen = new AtomicInteger(1);
    private final Map<Integer, UserSubscription> userSubscriptionStore = new LinkedHashMap<>();
    private final AtomicInteger userSubscriptionIdGen = new AtomicInteger(1);

    // ---- PaymentMethod ----
    @Override
    public PaymentMethod createPaymentMethod(PaymentMethod entity) {
        Integer newId = paymentMethodIdGen.getAndIncrement();
        entity.setId(newId);
        paymentMethodStore.put(newId, entity);
        return entity;
    }

    @Override
    public PaymentMethod getPaymentMethodById(Integer id) {
        return paymentMethodStore.get(id);
    }

    @Override
    public List<PaymentMethod> getAllPaymentMethods() {
        return paymentMethodStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public PaymentMethod updatePaymentMethod(Integer id, PaymentMethod entity) {
        if (!paymentMethodStore.containsKey(id)) return null;
        entity.setId(id);
        paymentMethodStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deletePaymentMethod(Integer id) {
        return paymentMethodStore.remove(id) != null;
    }

    @Override
    public List<PaymentMethod> filterPaymentMethods(Predicate<PaymentMethod> predicate) {
        return paymentMethodStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TransactionType ----
    @Override
    public TransactionType createTransactionType(TransactionType entity) {
        Integer newId = transactionTypeIdGen.getAndIncrement();
        entity.setId(newId);
        transactionTypeStore.put(newId, entity);
        return entity;
    }

    @Override
    public TransactionType getTransactionTypeById(Integer id) {
        return transactionTypeStore.get(id);
    }

    @Override
    public List<TransactionType> getAllTransactionTypes() {
        return transactionTypeStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TransactionType updateTransactionType(Integer id, TransactionType entity) {
        if (!transactionTypeStore.containsKey(id)) return null;
        entity.setId(id);
        transactionTypeStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTransactionType(Integer id) {
        return transactionTypeStore.remove(id) != null;
    }

    @Override
    public List<TransactionType> filterTransactionTypes(Predicate<TransactionType> predicate) {
        return transactionTypeStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- RevenueTransaction ----
    @Override
    public RevenueTransaction createRevenueTransaction(RevenueTransaction entity) {
        Integer newId = revenueTransactionIdGen.getAndIncrement();
        entity.setId(newId);
        revenueTransactionStore.put(newId, entity);
        return entity;
    }

    @Override
    public RevenueTransaction getRevenueTransactionById(Integer id) {
        return revenueTransactionStore.get(id);
    }

    @Override
    public List<RevenueTransaction> getAllRevenueTransactions() {
        return revenueTransactionStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public RevenueTransaction updateRevenueTransaction(Integer id, RevenueTransaction entity) {
        if (!revenueTransactionStore.containsKey(id)) return null;
        entity.setId(id);
        revenueTransactionStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteRevenueTransaction(Integer id) {
        return revenueTransactionStore.remove(id) != null;
    }

    @Override
    public List<RevenueTransaction> filterRevenueTransactions(Predicate<RevenueTransaction> predicate) {
        return revenueTransactionStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- SubscriptionPlan ----
    @Override
    public SubscriptionPlan createSubscriptionPlan(SubscriptionPlan entity) {
        Integer newId = subscriptionPlanIdGen.getAndIncrement();
        entity.setId(newId);
        subscriptionPlanStore.put(newId, entity);
        return entity;
    }

    @Override
    public SubscriptionPlan getSubscriptionPlanById(Integer id) {
        return subscriptionPlanStore.get(id);
    }

    @Override
    public List<SubscriptionPlan> getAllSubscriptionPlans() {
        return subscriptionPlanStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public SubscriptionPlan updateSubscriptionPlan(Integer id, SubscriptionPlan entity) {
        if (!subscriptionPlanStore.containsKey(id)) return null;
        entity.setId(id);
        subscriptionPlanStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteSubscriptionPlan(Integer id) {
        return subscriptionPlanStore.remove(id) != null;
    }

    @Override
    public List<SubscriptionPlan> filterSubscriptionPlans(Predicate<SubscriptionPlan> predicate) {
        return subscriptionPlanStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- UserSubscription ----
    @Override
    public UserSubscription createUserSubscription(UserSubscription entity) {
        Integer newId = userSubscriptionIdGen.getAndIncrement();
        entity.setId(newId);
        userSubscriptionStore.put(newId, entity);
        return entity;
    }

    @Override
    public UserSubscription getUserSubscriptionById(Integer id) {
        return userSubscriptionStore.get(id);
    }

    @Override
    public List<UserSubscription> getAllUserSubscriptions() {
        return userSubscriptionStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public UserSubscription updateUserSubscription(Integer id, UserSubscription entity) {
        if (!userSubscriptionStore.containsKey(id)) return null;
        entity.setId(id);
        userSubscriptionStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteUserSubscription(Integer id) {
        return userSubscriptionStore.remove(id) != null;
    }

    @Override
    public List<UserSubscription> filterUserSubscriptions(Predicate<UserSubscription> predicate) {
        return userSubscriptionStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

}