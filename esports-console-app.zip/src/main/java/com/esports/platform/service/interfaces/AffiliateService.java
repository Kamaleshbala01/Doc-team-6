package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;
import java.util.function.Predicate;

/**
 * CRUD contract for the Affiliate Marketing module.
 * Covers entities: AffiliateCampaign, AffiliateLink, AffiliateClick
 */
public interface AffiliateService {

    // ---- AffiliateCampaign ----
    AffiliateCampaign createAffiliateCampaign(AffiliateCampaign entity);
    AffiliateCampaign getAffiliateCampaignById(Integer id);
    List<AffiliateCampaign> getAllAffiliateCampaigns();
    AffiliateCampaign updateAffiliateCampaign(Integer id, AffiliateCampaign entity);
    boolean deleteAffiliateCampaign(Integer id);
    List<AffiliateCampaign> filterAffiliateCampaigns(Predicate<AffiliateCampaign> predicate);

    // ---- AffiliateLink ----
    AffiliateLink createAffiliateLink(AffiliateLink entity);
    AffiliateLink getAffiliateLinkById(Integer id);
    List<AffiliateLink> getAllAffiliateLinks();
    AffiliateLink updateAffiliateLink(Integer id, AffiliateLink entity);
    boolean deleteAffiliateLink(Integer id);
    List<AffiliateLink> filterAffiliateLinks(Predicate<AffiliateLink> predicate);

    // ---- AffiliateClick ----
    AffiliateClick createAffiliateClick(AffiliateClick entity);
    AffiliateClick getAffiliateClickById(Long id);
    List<AffiliateClick> getAllAffiliateClicks();
    AffiliateClick updateAffiliateClick(Long id, AffiliateClick entity);
    boolean deleteAffiliateClick(Long id);
    List<AffiliateClick> filterAffiliateClicks(Predicate<AffiliateClick> predicate);

}