package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;
import java.util.function.Predicate;

/**
 * CRUD contract for the Campaign & Influencer Marketing module.
 * Covers entities: CampaignType, Campaign, CampaignPlatform, CampaignAsset, CampaignDeliverable, CollaborationRequest
 */
public interface CampaignService {

    // ---- CampaignType ----
    CampaignType createCampaignType(CampaignType entity);
    CampaignType getCampaignTypeById(Integer id);
    List<CampaignType> getAllCampaignTypes();
    CampaignType updateCampaignType(Integer id, CampaignType entity);
    boolean deleteCampaignType(Integer id);
    List<CampaignType> filterCampaignTypes(Predicate<CampaignType> predicate);

    // ---- Campaign ----
    Campaign createCampaign(Campaign entity);
    Campaign getCampaignById(Integer id);
    List<Campaign> getAllCampaigns();
    Campaign updateCampaign(Integer id, Campaign entity);
    boolean deleteCampaign(Integer id);
    List<Campaign> filterCampaigns(Predicate<Campaign> predicate);

    // ---- CampaignPlatform ----
    CampaignPlatform createCampaignPlatform(CampaignPlatform entity);
    CampaignPlatform getCampaignPlatformById(Integer id);
    List<CampaignPlatform> getAllCampaignPlatforms();
    CampaignPlatform updateCampaignPlatform(Integer id, CampaignPlatform entity);
    boolean deleteCampaignPlatform(Integer id);
    List<CampaignPlatform> filterCampaignPlatforms(Predicate<CampaignPlatform> predicate);

    // ---- CampaignAsset ----
    CampaignAsset createCampaignAsset(CampaignAsset entity);
    CampaignAsset getCampaignAssetById(Integer id);
    List<CampaignAsset> getAllCampaignAssets();
    CampaignAsset updateCampaignAsset(Integer id, CampaignAsset entity);
    boolean deleteCampaignAsset(Integer id);
    List<CampaignAsset> filterCampaignAssets(Predicate<CampaignAsset> predicate);

    // ---- CampaignDeliverable ----
    CampaignDeliverable createCampaignDeliverable(CampaignDeliverable entity);
    CampaignDeliverable getCampaignDeliverableById(Integer id);
    List<CampaignDeliverable> getAllCampaignDeliverables();
    CampaignDeliverable updateCampaignDeliverable(Integer id, CampaignDeliverable entity);
    boolean deleteCampaignDeliverable(Integer id);
    List<CampaignDeliverable> filterCampaignDeliverables(Predicate<CampaignDeliverable> predicate);

    // ---- CollaborationRequest ----
    CollaborationRequest createCollaborationRequest(CollaborationRequest entity);
    CollaborationRequest getCollaborationRequestById(Integer id);
    List<CollaborationRequest> getAllCollaborationRequests();
    CollaborationRequest updateCollaborationRequest(Integer id, CollaborationRequest entity);
    boolean deleteCollaborationRequest(Integer id);
    List<CollaborationRequest> filterCollaborationRequests(Predicate<CollaborationRequest> predicate);

}