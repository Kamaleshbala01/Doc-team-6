package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;
import java.util.function.Predicate;

/**
 * CRUD contract for the Team Management module.
 * Covers entities: Team, TeamPosition, TeamMember
 */
public interface TeamService {

    // ---- Team ----
    Team createTeam(Team entity);
    Team getTeamById(Integer id);
    List<Team> getAllTeams();
    Team updateTeam(Integer id, Team entity);
    boolean deleteTeam(Integer id);
    List<Team> filterTeams(Predicate<Team> predicate);

    // ---- TeamPosition ----
    TeamPosition createTeamPosition(TeamPosition entity);
    TeamPosition getTeamPositionById(Integer id);
    List<TeamPosition> getAllTeamPositions();
    TeamPosition updateTeamPosition(Integer id, TeamPosition entity);
    boolean deleteTeamPosition(Integer id);
    List<TeamPosition> filterTeamPositions(Predicate<TeamPosition> predicate);

    // ---- TeamMember ----
    TeamMember createTeamMember(TeamMember entity);
    TeamMember getTeamMemberById(Integer id);
    List<TeamMember> getAllTeamMembers();
    TeamMember updateTeamMember(Integer id, TeamMember entity);
    boolean deleteTeamMember(Integer id);
    List<TeamMember> filterTeamMembers(Predicate<TeamMember> predicate);

}