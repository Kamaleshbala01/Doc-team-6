package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.TournamentService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * In-memory implementation of TournamentService.
 * Storage is a LinkedHashMap per entity (keeps insertion order);
 * ids are generated with an Atomic counter per entity.
 */
public class TournamentServiceImpl implements TournamentService {

    private final Map<Integer, TournamentCategory> tournamentCategoryStore = new LinkedHashMap<>();
    private final AtomicInteger tournamentCategoryIdGen = new AtomicInteger(1);
    private final Map<Integer, TournamentType> tournamentTypeStore = new LinkedHashMap<>();
    private final AtomicInteger tournamentTypeIdGen = new AtomicInteger(1);
    private final Map<Integer, SeedingType> seedingTypeStore = new LinkedHashMap<>();
    private final AtomicInteger seedingTypeIdGen = new AtomicInteger(1);
    private final Map<Integer, Tournament> tournamentStore = new LinkedHashMap<>();
    private final AtomicInteger tournamentIdGen = new AtomicInteger(1);
    private final Map<Integer, RulesCategory> rulesCategoryStore = new LinkedHashMap<>();
    private final AtomicInteger rulesCategoryIdGen = new AtomicInteger(1);
    private final Map<Integer, TournamentRule> tournamentRuleStore = new LinkedHashMap<>();
    private final AtomicInteger tournamentRuleIdGen = new AtomicInteger(1);
    private final Map<Integer, PrizeCategory> prizeCategoryStore = new LinkedHashMap<>();
    private final AtomicInteger prizeCategoryIdGen = new AtomicInteger(1);
    private final Map<Integer, TournamentPrize> tournamentPrizeStore = new LinkedHashMap<>();
    private final AtomicInteger tournamentPrizeIdGen = new AtomicInteger(1);
    private final Map<Integer, TournamentPackage> tournamentPackageStore = new LinkedHashMap<>();
    private final AtomicInteger tournamentPackageIdGen = new AtomicInteger(1);
    private final Map<Integer, TournamentPayment> tournamentPaymentStore = new LinkedHashMap<>();
    private final AtomicInteger tournamentPaymentIdGen = new AtomicInteger(1);
    private final Map<Integer, TournamentRegistration> tournamentRegistrationStore = new LinkedHashMap<>();
    private final AtomicInteger tournamentRegistrationIdGen = new AtomicInteger(1);
    private final Map<Integer, TournamentRegistrationPayment> tournamentRegistrationPaymentStore = new LinkedHashMap<>();
    private final AtomicInteger tournamentRegistrationPaymentIdGen = new AtomicInteger(1);
    private final Map<Integer, TournamentAnnouncement> tournamentAnnouncementStore = new LinkedHashMap<>();
    private final AtomicInteger tournamentAnnouncementIdGen = new AtomicInteger(1);
    private final Map<Integer, TournamentFAQ> tournamentFAQStore = new LinkedHashMap<>();
    private final AtomicInteger tournamentFAQIdGen = new AtomicInteger(1);

    // ---- TournamentCategory ----
    @Override
    public TournamentCategory createTournamentCategory(TournamentCategory entity) {
        Integer newId = tournamentCategoryIdGen.getAndIncrement();
        entity.setId(newId);
        tournamentCategoryStore.put(newId, entity);
        return entity;
    }

    @Override
    public TournamentCategory getTournamentCategoryById(Integer id) {
        return tournamentCategoryStore.get(id);
    }

    @Override
    public List<TournamentCategory> getAllTournamentCategorys() {
        return tournamentCategoryStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentCategory updateTournamentCategory(Integer id, TournamentCategory entity) {
        if (!tournamentCategoryStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentCategoryStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentCategory(Integer id) {
        return tournamentCategoryStore.remove(id) != null;
    }

    @Override
    public List<TournamentCategory> filterTournamentCategorys(Predicate<TournamentCategory> predicate) {
        return tournamentCategoryStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TournamentType ----
    @Override
    public TournamentType createTournamentType(TournamentType entity) {
        Integer newId = tournamentTypeIdGen.getAndIncrement();
        entity.setId(newId);
        tournamentTypeStore.put(newId, entity);
        return entity;
    }

    @Override
    public TournamentType getTournamentTypeById(Integer id) {
        return tournamentTypeStore.get(id);
    }

    @Override
    public List<TournamentType> getAllTournamentTypes() {
        return tournamentTypeStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentType updateTournamentType(Integer id, TournamentType entity) {
        if (!tournamentTypeStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentTypeStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentType(Integer id) {
        return tournamentTypeStore.remove(id) != null;
    }

    @Override
    public List<TournamentType> filterTournamentTypes(Predicate<TournamentType> predicate) {
        return tournamentTypeStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- SeedingType ----
    @Override
    public SeedingType createSeedingType(SeedingType entity) {
        Integer newId = seedingTypeIdGen.getAndIncrement();
        entity.setId(newId);
        seedingTypeStore.put(newId, entity);
        return entity;
    }

    @Override
    public SeedingType getSeedingTypeById(Integer id) {
        return seedingTypeStore.get(id);
    }

    @Override
    public List<SeedingType> getAllSeedingTypes() {
        return seedingTypeStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public SeedingType updateSeedingType(Integer id, SeedingType entity) {
        if (!seedingTypeStore.containsKey(id)) return null;
        entity.setId(id);
        seedingTypeStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteSeedingType(Integer id) {
        return seedingTypeStore.remove(id) != null;
    }

    @Override
    public List<SeedingType> filterSeedingTypes(Predicate<SeedingType> predicate) {
        return seedingTypeStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- Tournament ----
    @Override
    public Tournament createTournament(Tournament entity) {
        Integer newId = tournamentIdGen.getAndIncrement();
        entity.setId(newId);
        tournamentStore.put(newId, entity);
        return entity;
    }

    @Override
    public Tournament getTournamentById(Integer id) {
        return tournamentStore.get(id);
    }

    @Override
    public List<Tournament> getAllTournaments() {
        return tournamentStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Tournament updateTournament(Integer id, Tournament entity) {
        if (!tournamentStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournament(Integer id) {
        return tournamentStore.remove(id) != null;
    }

    @Override
    public List<Tournament> filterTournaments(Predicate<Tournament> predicate) {
        return tournamentStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- RulesCategory ----
    @Override
    public RulesCategory createRulesCategory(RulesCategory entity) {
        Integer newId = rulesCategoryIdGen.getAndIncrement();
        entity.setId(newId);
        rulesCategoryStore.put(newId, entity);
        return entity;
    }

    @Override
    public RulesCategory getRulesCategoryById(Integer id) {
        return rulesCategoryStore.get(id);
    }

    @Override
    public List<RulesCategory> getAllRulesCategorys() {
        return rulesCategoryStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public RulesCategory updateRulesCategory(Integer id, RulesCategory entity) {
        if (!rulesCategoryStore.containsKey(id)) return null;
        entity.setId(id);
        rulesCategoryStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteRulesCategory(Integer id) {
        return rulesCategoryStore.remove(id) != null;
    }

    @Override
    public List<RulesCategory> filterRulesCategorys(Predicate<RulesCategory> predicate) {
        return rulesCategoryStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TournamentRule ----
    @Override
    public TournamentRule createTournamentRule(TournamentRule entity) {
        Integer newId = tournamentRuleIdGen.getAndIncrement();
        entity.setId(newId);
        tournamentRuleStore.put(newId, entity);
        return entity;
    }

    @Override
    public TournamentRule getTournamentRuleById(Integer id) {
        return tournamentRuleStore.get(id);
    }

    @Override
    public List<TournamentRule> getAllTournamentRules() {
        return tournamentRuleStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentRule updateTournamentRule(Integer id, TournamentRule entity) {
        if (!tournamentRuleStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentRuleStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentRule(Integer id) {
        return tournamentRuleStore.remove(id) != null;
    }

    @Override
    public List<TournamentRule> filterTournamentRules(Predicate<TournamentRule> predicate) {
        return tournamentRuleStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- PrizeCategory ----
    @Override
    public PrizeCategory createPrizeCategory(PrizeCategory entity) {
        Integer newId = prizeCategoryIdGen.getAndIncrement();
        entity.setId(newId);
        prizeCategoryStore.put(newId, entity);
        return entity;
    }

    @Override
    public PrizeCategory getPrizeCategoryById(Integer id) {
        return prizeCategoryStore.get(id);
    }

    @Override
    public List<PrizeCategory> getAllPrizeCategorys() {
        return prizeCategoryStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public PrizeCategory updatePrizeCategory(Integer id, PrizeCategory entity) {
        if (!prizeCategoryStore.containsKey(id)) return null;
        entity.setId(id);
        prizeCategoryStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deletePrizeCategory(Integer id) {
        return prizeCategoryStore.remove(id) != null;
    }

    @Override
    public List<PrizeCategory> filterPrizeCategorys(Predicate<PrizeCategory> predicate) {
        return prizeCategoryStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TournamentPrize ----
    @Override
    public TournamentPrize createTournamentPrize(TournamentPrize entity) {
        Integer newId = tournamentPrizeIdGen.getAndIncrement();
        entity.setId(newId);
        tournamentPrizeStore.put(newId, entity);
        return entity;
    }

    @Override
    public TournamentPrize getTournamentPrizeById(Integer id) {
        return tournamentPrizeStore.get(id);
    }

    @Override
    public List<TournamentPrize> getAllTournamentPrizes() {
        return tournamentPrizeStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentPrize updateTournamentPrize(Integer id, TournamentPrize entity) {
        if (!tournamentPrizeStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentPrizeStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentPrize(Integer id) {
        return tournamentPrizeStore.remove(id) != null;
    }

    @Override
    public List<TournamentPrize> filterTournamentPrizes(Predicate<TournamentPrize> predicate) {
        return tournamentPrizeStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TournamentPackage ----
    @Override
    public TournamentPackage createTournamentPackage(TournamentPackage entity) {
        Integer newId = tournamentPackageIdGen.getAndIncrement();
        entity.setId(newId);
        tournamentPackageStore.put(newId, entity);
        return entity;
    }

    @Override
    public TournamentPackage getTournamentPackageById(Integer id) {
        return tournamentPackageStore.get(id);
    }

    @Override
    public List<TournamentPackage> getAllTournamentPackages() {
        return tournamentPackageStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentPackage updateTournamentPackage(Integer id, TournamentPackage entity) {
        if (!tournamentPackageStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentPackageStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentPackage(Integer id) {
        return tournamentPackageStore.remove(id) != null;
    }

    @Override
    public List<TournamentPackage> filterTournamentPackages(Predicate<TournamentPackage> predicate) {
        return tournamentPackageStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TournamentPayment ----
    @Override
    public TournamentPayment createTournamentPayment(TournamentPayment entity) {
        Integer newId = tournamentPaymentIdGen.getAndIncrement();
        entity.setId(newId);
        tournamentPaymentStore.put(newId, entity);
        return entity;
    }

    @Override
    public TournamentPayment getTournamentPaymentById(Integer id) {
        return tournamentPaymentStore.get(id);
    }

    @Override
    public List<TournamentPayment> getAllTournamentPayments() {
        return tournamentPaymentStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentPayment updateTournamentPayment(Integer id, TournamentPayment entity) {
        if (!tournamentPaymentStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentPaymentStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentPayment(Integer id) {
        return tournamentPaymentStore.remove(id) != null;
    }

    @Override
    public List<TournamentPayment> filterTournamentPayments(Predicate<TournamentPayment> predicate) {
        return tournamentPaymentStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TournamentRegistration ----
    @Override
    public TournamentRegistration createTournamentRegistration(TournamentRegistration entity) {
        Integer newId = tournamentRegistrationIdGen.getAndIncrement();
        entity.setId(newId);
        tournamentRegistrationStore.put(newId, entity);
        return entity;
    }

    @Override
    public TournamentRegistration getTournamentRegistrationById(Integer id) {
        return tournamentRegistrationStore.get(id);
    }

    @Override
    public List<TournamentRegistration> getAllTournamentRegistrations() {
        return tournamentRegistrationStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentRegistration updateTournamentRegistration(Integer id, TournamentRegistration entity) {
        if (!tournamentRegistrationStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentRegistrationStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentRegistration(Integer id) {
        return tournamentRegistrationStore.remove(id) != null;
    }

    @Override
    public List<TournamentRegistration> filterTournamentRegistrations(Predicate<TournamentRegistration> predicate) {
        return tournamentRegistrationStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TournamentRegistrationPayment ----
    @Override
    public TournamentRegistrationPayment createTournamentRegistrationPayment(TournamentRegistrationPayment entity) {
        Integer newId = tournamentRegistrationPaymentIdGen.getAndIncrement();
        entity.setId(newId);
        tournamentRegistrationPaymentStore.put(newId, entity);
        return entity;
    }

    @Override
    public TournamentRegistrationPayment getTournamentRegistrationPaymentById(Integer id) {
        return tournamentRegistrationPaymentStore.get(id);
    }

    @Override
    public List<TournamentRegistrationPayment> getAllTournamentRegistrationPayments() {
        return tournamentRegistrationPaymentStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentRegistrationPayment updateTournamentRegistrationPayment(Integer id, TournamentRegistrationPayment entity) {
        if (!tournamentRegistrationPaymentStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentRegistrationPaymentStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentRegistrationPayment(Integer id) {
        return tournamentRegistrationPaymentStore.remove(id) != null;
    }

    @Override
    public List<TournamentRegistrationPayment> filterTournamentRegistrationPayments(Predicate<TournamentRegistrationPayment> predicate) {
        return tournamentRegistrationPaymentStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TournamentAnnouncement ----
    @Override
    public TournamentAnnouncement createTournamentAnnouncement(TournamentAnnouncement entity) {
        Integer newId = tournamentAnnouncementIdGen.getAndIncrement();
        entity.setId(newId);
        tournamentAnnouncementStore.put(newId, entity);
        return entity;
    }

    @Override
    public TournamentAnnouncement getTournamentAnnouncementById(Integer id) {
        return tournamentAnnouncementStore.get(id);
    }

    @Override
    public List<TournamentAnnouncement> getAllTournamentAnnouncements() {
        return tournamentAnnouncementStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentAnnouncement updateTournamentAnnouncement(Integer id, TournamentAnnouncement entity) {
        if (!tournamentAnnouncementStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentAnnouncementStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentAnnouncement(Integer id) {
        return tournamentAnnouncementStore.remove(id) != null;
    }

    @Override
    public List<TournamentAnnouncement> filterTournamentAnnouncements(Predicate<TournamentAnnouncement> predicate) {
        return tournamentAnnouncementStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TournamentFAQ ----
    @Override
    public TournamentFAQ createTournamentFAQ(TournamentFAQ entity) {
        Integer newId = tournamentFAQIdGen.getAndIncrement();
        entity.setId(newId);
        tournamentFAQStore.put(newId, entity);
        return entity;
    }

    @Override
    public TournamentFAQ getTournamentFAQById(Integer id) {
        return tournamentFAQStore.get(id);
    }

    @Override
    public List<TournamentFAQ> getAllTournamentFAQs() {
        return tournamentFAQStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentFAQ updateTournamentFAQ(Integer id, TournamentFAQ entity) {
        if (!tournamentFAQStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentFAQStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentFAQ(Integer id) {
        return tournamentFAQStore.remove(id) != null;
    }

    @Override
    public List<TournamentFAQ> filterTournamentFAQs(Predicate<TournamentFAQ> predicate) {
        return tournamentFAQStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

}