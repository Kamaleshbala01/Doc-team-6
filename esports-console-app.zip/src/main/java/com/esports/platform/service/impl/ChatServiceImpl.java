package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.ChatService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * In-memory implementation of ChatService.
 * Storage is a LinkedHashMap per entity (keeps insertion order);
 * ids are generated with an Atomic counter per entity.
 */
public class ChatServiceImpl implements ChatService {

    private final Map<Integer, Conversation> conversationStore = new LinkedHashMap<>();
    private final AtomicInteger conversationIdGen = new AtomicInteger(1);
    private final Map<Long, ConversationParticipant> conversationParticipantStore = new LinkedHashMap<>();
    private final AtomicLong conversationParticipantIdGen = new AtomicLong(1);
    private final Map<Long, Message> messageStore = new LinkedHashMap<>();
    private final AtomicLong messageIdGen = new AtomicLong(1);
    private final Map<Long, MessageAttachment> messageAttachmentStore = new LinkedHashMap<>();
    private final AtomicLong messageAttachmentIdGen = new AtomicLong(1);
    private final Map<Long, MessageReadStatus> messageReadStatusStore = new LinkedHashMap<>();
    private final AtomicLong messageReadStatusIdGen = new AtomicLong(1);
    private final Map<Long, MessageReaction> messageReactionStore = new LinkedHashMap<>();
    private final AtomicLong messageReactionIdGen = new AtomicLong(1);
    private final Map<Integer, UserPresence> userPresenceStore = new LinkedHashMap<>();
    private final AtomicInteger userPresenceIdGen = new AtomicInteger(1);
    private final Map<Long, ConversationPinnedMessage> conversationPinnedMessageStore = new LinkedHashMap<>();
    private final AtomicLong conversationPinnedMessageIdGen = new AtomicLong(1);
    private final Map<Integer, ConversationSettings> conversationSettingsStore = new LinkedHashMap<>();
    private final AtomicInteger conversationSettingsIdGen = new AtomicInteger(1);

    // ---- Conversation ----
    @Override
    public Conversation createConversation(Conversation entity) {
        Integer newId = conversationIdGen.getAndIncrement();
        entity.setId(newId);
        conversationStore.put(newId, entity);
        return entity;
    }

    @Override
    public Conversation getConversationById(Integer id) {
        return conversationStore.get(id);
    }

    @Override
    public List<Conversation> getAllConversations() {
        return conversationStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Conversation updateConversation(Integer id, Conversation entity) {
        if (!conversationStore.containsKey(id)) return null;
        entity.setId(id);
        conversationStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteConversation(Integer id) {
        return conversationStore.remove(id) != null;
    }

    @Override
    public List<Conversation> filterConversations(Predicate<Conversation> predicate) {
        return conversationStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- ConversationParticipant ----
    @Override
    public ConversationParticipant createConversationParticipant(ConversationParticipant entity) {
        Long newId = conversationParticipantIdGen.getAndIncrement();
        entity.setId(newId);
        conversationParticipantStore.put(newId, entity);
        return entity;
    }

    @Override
    public ConversationParticipant getConversationParticipantById(Long id) {
        return conversationParticipantStore.get(id);
    }

    @Override
    public List<ConversationParticipant> getAllConversationParticipants() {
        return conversationParticipantStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public ConversationParticipant updateConversationParticipant(Long id, ConversationParticipant entity) {
        if (!conversationParticipantStore.containsKey(id)) return null;
        entity.setId(id);
        conversationParticipantStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteConversationParticipant(Long id) {
        return conversationParticipantStore.remove(id) != null;
    }

    @Override
    public List<ConversationParticipant> filterConversationParticipants(Predicate<ConversationParticipant> predicate) {
        return conversationParticipantStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- Message ----
    @Override
    public Message createMessage(Message entity) {
        Long newId = messageIdGen.getAndIncrement();
        entity.setId(newId);
        messageStore.put(newId, entity);
        return entity;
    }

    @Override
    public Message getMessageById(Long id) {
        return messageStore.get(id);
    }

    @Override
    public List<Message> getAllMessages() {
        return messageStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Message updateMessage(Long id, Message entity) {
        if (!messageStore.containsKey(id)) return null;
        entity.setId(id);
        messageStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteMessage(Long id) {
        return messageStore.remove(id) != null;
    }

    @Override
    public List<Message> filterMessages(Predicate<Message> predicate) {
        return messageStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- MessageAttachment ----
    @Override
    public MessageAttachment createMessageAttachment(MessageAttachment entity) {
        Long newId = messageAttachmentIdGen.getAndIncrement();
        entity.setId(newId);
        messageAttachmentStore.put(newId, entity);
        return entity;
    }

    @Override
    public MessageAttachment getMessageAttachmentById(Long id) {
        return messageAttachmentStore.get(id);
    }

    @Override
    public List<MessageAttachment> getAllMessageAttachments() {
        return messageAttachmentStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public MessageAttachment updateMessageAttachment(Long id, MessageAttachment entity) {
        if (!messageAttachmentStore.containsKey(id)) return null;
        entity.setId(id);
        messageAttachmentStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteMessageAttachment(Long id) {
        return messageAttachmentStore.remove(id) != null;
    }

    @Override
    public List<MessageAttachment> filterMessageAttachments(Predicate<MessageAttachment> predicate) {
        return messageAttachmentStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- MessageReadStatus ----
    @Override
    public MessageReadStatus createMessageReadStatus(MessageReadStatus entity) {
        Long newId = messageReadStatusIdGen.getAndIncrement();
        entity.setId(newId);
        messageReadStatusStore.put(newId, entity);
        return entity;
    }

    @Override
    public MessageReadStatus getMessageReadStatusById(Long id) {
        return messageReadStatusStore.get(id);
    }

    @Override
    public List<MessageReadStatus> getAllMessageReadStatus() {
        return messageReadStatusStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public MessageReadStatus updateMessageReadStatus(Long id, MessageReadStatus entity) {
        if (!messageReadStatusStore.containsKey(id)) return null;
        entity.setId(id);
        messageReadStatusStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteMessageReadStatus(Long id) {
        return messageReadStatusStore.remove(id) != null;
    }

    @Override
    public List<MessageReadStatus> filterMessageReadStatus(Predicate<MessageReadStatus> predicate) {
        return messageReadStatusStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- MessageReaction ----
    @Override
    public MessageReaction createMessageReaction(MessageReaction entity) {
        Long newId = messageReactionIdGen.getAndIncrement();
        entity.setId(newId);
        messageReactionStore.put(newId, entity);
        return entity;
    }

    @Override
    public MessageReaction getMessageReactionById(Long id) {
        return messageReactionStore.get(id);
    }

    @Override
    public List<MessageReaction> getAllMessageReactions() {
        return messageReactionStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public MessageReaction updateMessageReaction(Long id, MessageReaction entity) {
        if (!messageReactionStore.containsKey(id)) return null;
        entity.setId(id);
        messageReactionStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteMessageReaction(Long id) {
        return messageReactionStore.remove(id) != null;
    }

    @Override
    public List<MessageReaction> filterMessageReactions(Predicate<MessageReaction> predicate) {
        return messageReactionStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- UserPresence ----
    @Override
    public UserPresence createUserPresence(UserPresence entity) {
        Integer newId = userPresenceIdGen.getAndIncrement();
        entity.setUserId(newId);
        userPresenceStore.put(newId, entity);
        return entity;
    }

    @Override
    public UserPresence getUserPresenceById(Integer id) {
        return userPresenceStore.get(id);
    }

    @Override
    public List<UserPresence> getAllUserPresences() {
        return userPresenceStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public UserPresence updateUserPresence(Integer id, UserPresence entity) {
        if (!userPresenceStore.containsKey(id)) return null;
        entity.setUserId(id);
        userPresenceStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteUserPresence(Integer id) {
        return userPresenceStore.remove(id) != null;
    }

    @Override
    public List<UserPresence> filterUserPresences(Predicate<UserPresence> predicate) {
        return userPresenceStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- ConversationPinnedMessage ----
    @Override
    public ConversationPinnedMessage createConversationPinnedMessage(ConversationPinnedMessage entity) {
        Long newId = conversationPinnedMessageIdGen.getAndIncrement();
        entity.setId(newId);
        conversationPinnedMessageStore.put(newId, entity);
        return entity;
    }

    @Override
    public ConversationPinnedMessage getConversationPinnedMessageById(Long id) {
        return conversationPinnedMessageStore.get(id);
    }

    @Override
    public List<ConversationPinnedMessage> getAllConversationPinnedMessages() {
        return conversationPinnedMessageStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public ConversationPinnedMessage updateConversationPinnedMessage(Long id, ConversationPinnedMessage entity) {
        if (!conversationPinnedMessageStore.containsKey(id)) return null;
        entity.setId(id);
        conversationPinnedMessageStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteConversationPinnedMessage(Long id) {
        return conversationPinnedMessageStore.remove(id) != null;
    }

    @Override
    public List<ConversationPinnedMessage> filterConversationPinnedMessages(Predicate<ConversationPinnedMessage> predicate) {
        return conversationPinnedMessageStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- ConversationSettings ----
    @Override
    public ConversationSettings createConversationSettings(ConversationSettings entity) {
        Integer newId = conversationSettingsIdGen.getAndIncrement();
        entity.setId(newId);
        conversationSettingsStore.put(newId, entity);
        return entity;
    }

    @Override
    public ConversationSettings getConversationSettingsById(Integer id) {
        return conversationSettingsStore.get(id);
    }

    @Override
    public List<ConversationSettings> getAllConversationSettings() {
        return conversationSettingsStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public ConversationSettings updateConversationSettings(Integer id, ConversationSettings entity) {
        if (!conversationSettingsStore.containsKey(id)) return null;
        entity.setId(id);
        conversationSettingsStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteConversationSettings(Integer id) {
        return conversationSettingsStore.remove(id) != null;
    }

    @Override
    public List<ConversationSettings> filterConversationSettings(Predicate<ConversationSettings> predicate) {
        return conversationSettingsStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

}