package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.TeamService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * In-memory implementation of TeamService.
 * Storage is a LinkedHashMap per entity (keeps insertion order);
 * ids are generated with an Atomic counter per entity.
 */
public class TeamServiceImpl implements TeamService {

    private final Map<Integer, Team> teamStore = new LinkedHashMap<>();
    private final AtomicInteger teamIdGen = new AtomicInteger(1);
    private final Map<Integer, TeamPosition> teamPositionStore = new LinkedHashMap<>();
    private final AtomicInteger teamPositionIdGen = new AtomicInteger(1);
    private final Map<Integer, TeamMember> teamMemberStore = new LinkedHashMap<>();
    private final AtomicInteger teamMemberIdGen = new AtomicInteger(1);

    // ---- Team ----
    @Override
    public Team createTeam(Team entity) {
        Integer newId = teamIdGen.getAndIncrement();
        entity.setId(newId);
        teamStore.put(newId, entity);
        return entity;
    }

    @Override
    public Team getTeamById(Integer id) {
        return teamStore.get(id);
    }

    @Override
    public List<Team> getAllTeams() {
        return teamStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Team updateTeam(Integer id, Team entity) {
        if (!teamStore.containsKey(id)) return null;
        entity.setId(id);
        teamStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTeam(Integer id) {
        return teamStore.remove(id) != null;
    }

    @Override
    public List<Team> filterTeams(Predicate<Team> predicate) {
        return teamStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TeamPosition ----
    @Override
    public TeamPosition createTeamPosition(TeamPosition entity) {
        Integer newId = teamPositionIdGen.getAndIncrement();
        entity.setId(newId);
        teamPositionStore.put(newId, entity);
        return entity;
    }

    @Override
    public TeamPosition getTeamPositionById(Integer id) {
        return teamPositionStore.get(id);
    }

    @Override
    public List<TeamPosition> getAllTeamPositions() {
        return teamPositionStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TeamPosition updateTeamPosition(Integer id, TeamPosition entity) {
        if (!teamPositionStore.containsKey(id)) return null;
        entity.setId(id);
        teamPositionStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTeamPosition(Integer id) {
        return teamPositionStore.remove(id) != null;
    }

    @Override
    public List<TeamPosition> filterTeamPositions(Predicate<TeamPosition> predicate) {
        return teamPositionStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- TeamMember ----
    @Override
    public TeamMember createTeamMember(TeamMember entity) {
        Integer newId = teamMemberIdGen.getAndIncrement();
        entity.setId(newId);
        teamMemberStore.put(newId, entity);
        return entity;
    }

    @Override
    public TeamMember getTeamMemberById(Integer id) {
        return teamMemberStore.get(id);
    }

    @Override
    public List<TeamMember> getAllTeamMembers() {
        return teamMemberStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TeamMember updateTeamMember(Integer id, TeamMember entity) {
        if (!teamMemberStore.containsKey(id)) return null;
        entity.setId(id);
        teamMemberStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTeamMember(Integer id) {
        return teamMemberStore.remove(id) != null;
    }

    @Override
    public List<TeamMember> filterTeamMembers(Predicate<TeamMember> predicate) {
        return teamMemberStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

}