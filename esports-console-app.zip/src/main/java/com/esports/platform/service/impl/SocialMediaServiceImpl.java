package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.SocialMediaService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * In-memory implementation of SocialMediaService.
 * Storage is a LinkedHashMap per entity (keeps insertion order);
 * ids are generated with an Atomic counter per entity.
 */
public class SocialMediaServiceImpl implements SocialMediaService {

    private final Map<Integer, SocialMediaPlatform> socialMediaPlatformStore = new LinkedHashMap<>();
    private final AtomicInteger socialMediaPlatformIdGen = new AtomicInteger(1);
    private final Map<Integer, SocialMediaAccount> socialMediaAccountStore = new LinkedHashMap<>();
    private final AtomicInteger socialMediaAccountIdGen = new AtomicInteger(1);
    private final Map<Integer, Game> gameStore = new LinkedHashMap<>();
    private final AtomicInteger gameIdGen = new AtomicInteger(1);
    private final Map<Integer, InfluencerGame> influencerGameStore = new LinkedHashMap<>();
    private final AtomicInteger influencerGameIdGen = new AtomicInteger(1);
    private final Map<Integer, StatusMaster> statusMasterStore = new LinkedHashMap<>();
    private final AtomicInteger statusMasterIdGen = new AtomicInteger(1);

    // ---- SocialMediaPlatform ----
    @Override
    public SocialMediaPlatform createSocialMediaPlatform(SocialMediaPlatform entity) {
        Integer newId = socialMediaPlatformIdGen.getAndIncrement();
        entity.setId(newId);
        socialMediaPlatformStore.put(newId, entity);
        return entity;
    }

    @Override
    public SocialMediaPlatform getSocialMediaPlatformById(Integer id) {
        return socialMediaPlatformStore.get(id);
    }

    @Override
    public List<SocialMediaPlatform> getAllSocialMediaPlatforms() {
        return socialMediaPlatformStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public SocialMediaPlatform updateSocialMediaPlatform(Integer id, SocialMediaPlatform entity) {
        if (!socialMediaPlatformStore.containsKey(id)) return null;
        entity.setId(id);
        socialMediaPlatformStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteSocialMediaPlatform(Integer id) {
        return socialMediaPlatformStore.remove(id) != null;
    }

    @Override
    public List<SocialMediaPlatform> filterSocialMediaPlatforms(Predicate<SocialMediaPlatform> predicate) {
        return socialMediaPlatformStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- SocialMediaAccount ----
    @Override
    public SocialMediaAccount createSocialMediaAccount(SocialMediaAccount entity) {
        Integer newId = socialMediaAccountIdGen.getAndIncrement();
        entity.setId(newId);
        socialMediaAccountStore.put(newId, entity);
        return entity;
    }

    @Override
    public SocialMediaAccount getSocialMediaAccountById(Integer id) {
        return socialMediaAccountStore.get(id);
    }

    @Override
    public List<SocialMediaAccount> getAllSocialMediaAccounts() {
        return socialMediaAccountStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public SocialMediaAccount updateSocialMediaAccount(Integer id, SocialMediaAccount entity) {
        if (!socialMediaAccountStore.containsKey(id)) return null;
        entity.setId(id);
        socialMediaAccountStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteSocialMediaAccount(Integer id) {
        return socialMediaAccountStore.remove(id) != null;
    }

    @Override
    public List<SocialMediaAccount> filterSocialMediaAccounts(Predicate<SocialMediaAccount> predicate) {
        return socialMediaAccountStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- Game ----
    @Override
    public Game createGame(Game entity) {
        Integer newId = gameIdGen.getAndIncrement();
        entity.setId(newId);
        gameStore.put(newId, entity);
        return entity;
    }

    @Override
    public Game getGameById(Integer id) {
        return gameStore.get(id);
    }

    @Override
    public List<Game> getAllGames() {
        return gameStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Game updateGame(Integer id, Game entity) {
        if (!gameStore.containsKey(id)) return null;
        entity.setId(id);
        gameStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteGame(Integer id) {
        return gameStore.remove(id) != null;
    }

    @Override
    public List<Game> filterGames(Predicate<Game> predicate) {
        return gameStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- InfluencerGame ----
    @Override
    public InfluencerGame createInfluencerGame(InfluencerGame entity) {
        Integer newId = influencerGameIdGen.getAndIncrement();
        entity.setId(newId);
        influencerGameStore.put(newId, entity);
        return entity;
    }

    @Override
    public InfluencerGame getInfluencerGameById(Integer id) {
        return influencerGameStore.get(id);
    }

    @Override
    public List<InfluencerGame> getAllInfluencerGames() {
        return influencerGameStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public InfluencerGame updateInfluencerGame(Integer id, InfluencerGame entity) {
        if (!influencerGameStore.containsKey(id)) return null;
        entity.setId(id);
        influencerGameStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteInfluencerGame(Integer id) {
        return influencerGameStore.remove(id) != null;
    }

    @Override
    public List<InfluencerGame> filterInfluencerGames(Predicate<InfluencerGame> predicate) {
        return influencerGameStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- StatusMaster ----
    @Override
    public StatusMaster createStatusMaster(StatusMaster entity) {
        Integer newId = statusMasterIdGen.getAndIncrement();
        entity.setId(newId);
        statusMasterStore.put(newId, entity);
        return entity;
    }

    @Override
    public StatusMaster getStatusMasterById(Integer id) {
        return statusMasterStore.get(id);
    }

    @Override
    public List<StatusMaster> getAllStatusMasters() {
        return statusMasterStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public StatusMaster updateStatusMaster(Integer id, StatusMaster entity) {
        if (!statusMasterStore.containsKey(id)) return null;
        entity.setId(id);
        statusMasterStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteStatusMaster(Integer id) {
        return statusMasterStore.remove(id) != null;
    }

    @Override
    public List<StatusMaster> filterStatusMasters(Predicate<StatusMaster> predicate) {
        return statusMasterStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

}