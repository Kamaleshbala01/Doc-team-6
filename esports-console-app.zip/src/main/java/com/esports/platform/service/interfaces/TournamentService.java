package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;
import java.util.function.Predicate;

/**
 * CRUD contract for the Tournament Management module.
 * Covers entities: TournamentCategory, TournamentType, SeedingType, Tournament, RulesCategory, TournamentRule, PrizeCategory, TournamentPrize, TournamentPackage, TournamentPayment, TournamentRegistration, TournamentRegistrationPayment, TournamentAnnouncement, TournamentFAQ
 */
public interface TournamentService {

    // ---- TournamentCategory ----
    TournamentCategory createTournamentCategory(TournamentCategory entity);
    TournamentCategory getTournamentCategoryById(Integer id);
    List<TournamentCategory> getAllTournamentCategorys();
    TournamentCategory updateTournamentCategory(Integer id, TournamentCategory entity);
    boolean deleteTournamentCategory(Integer id);
    List<TournamentCategory> filterTournamentCategorys(Predicate<TournamentCategory> predicate);

    // ---- TournamentType ----
    TournamentType createTournamentType(TournamentType entity);
    TournamentType getTournamentTypeById(Integer id);
    List<TournamentType> getAllTournamentTypes();
    TournamentType updateTournamentType(Integer id, TournamentType entity);
    boolean deleteTournamentType(Integer id);
    List<TournamentType> filterTournamentTypes(Predicate<TournamentType> predicate);

    // ---- SeedingType ----
    SeedingType createSeedingType(SeedingType entity);
    SeedingType getSeedingTypeById(Integer id);
    List<SeedingType> getAllSeedingTypes();
    SeedingType updateSeedingType(Integer id, SeedingType entity);
    boolean deleteSeedingType(Integer id);
    List<SeedingType> filterSeedingTypes(Predicate<SeedingType> predicate);

    // ---- Tournament ----
    Tournament createTournament(Tournament entity);
    Tournament getTournamentById(Integer id);
    List<Tournament> getAllTournaments();
    Tournament updateTournament(Integer id, Tournament entity);
    boolean deleteTournament(Integer id);
    List<Tournament> filterTournaments(Predicate<Tournament> predicate);

    // ---- RulesCategory ----
    RulesCategory createRulesCategory(RulesCategory entity);
    RulesCategory getRulesCategoryById(Integer id);
    List<RulesCategory> getAllRulesCategorys();
    RulesCategory updateRulesCategory(Integer id, RulesCategory entity);
    boolean deleteRulesCategory(Integer id);
    List<RulesCategory> filterRulesCategorys(Predicate<RulesCategory> predicate);

    // ---- TournamentRule ----
    TournamentRule createTournamentRule(TournamentRule entity);
    TournamentRule getTournamentRuleById(Integer id);
    List<TournamentRule> getAllTournamentRules();
    TournamentRule updateTournamentRule(Integer id, TournamentRule entity);
    boolean deleteTournamentRule(Integer id);
    List<TournamentRule> filterTournamentRules(Predicate<TournamentRule> predicate);

    // ---- PrizeCategory ----
    PrizeCategory createPrizeCategory(PrizeCategory entity);
    PrizeCategory getPrizeCategoryById(Integer id);
    List<PrizeCategory> getAllPrizeCategorys();
    PrizeCategory updatePrizeCategory(Integer id, PrizeCategory entity);
    boolean deletePrizeCategory(Integer id);
    List<PrizeCategory> filterPrizeCategorys(Predicate<PrizeCategory> predicate);

    // ---- TournamentPrize ----
    TournamentPrize createTournamentPrize(TournamentPrize entity);
    TournamentPrize getTournamentPrizeById(Integer id);
    List<TournamentPrize> getAllTournamentPrizes();
    TournamentPrize updateTournamentPrize(Integer id, TournamentPrize entity);
    boolean deleteTournamentPrize(Integer id);
    List<TournamentPrize> filterTournamentPrizes(Predicate<TournamentPrize> predicate);

    // ---- TournamentPackage ----
    TournamentPackage createTournamentPackage(TournamentPackage entity);
    TournamentPackage getTournamentPackageById(Integer id);
    List<TournamentPackage> getAllTournamentPackages();
    TournamentPackage updateTournamentPackage(Integer id, TournamentPackage entity);
    boolean deleteTournamentPackage(Integer id);
    List<TournamentPackage> filterTournamentPackages(Predicate<TournamentPackage> predicate);

    // ---- TournamentPayment ----
    TournamentPayment createTournamentPayment(TournamentPayment entity);
    TournamentPayment getTournamentPaymentById(Integer id);
    List<TournamentPayment> getAllTournamentPayments();
    TournamentPayment updateTournamentPayment(Integer id, TournamentPayment entity);
    boolean deleteTournamentPayment(Integer id);
    List<TournamentPayment> filterTournamentPayments(Predicate<TournamentPayment> predicate);

    // ---- TournamentRegistration ----
    TournamentRegistration createTournamentRegistration(TournamentRegistration entity);
    TournamentRegistration getTournamentRegistrationById(Integer id);
    List<TournamentRegistration> getAllTournamentRegistrations();
    TournamentRegistration updateTournamentRegistration(Integer id, TournamentRegistration entity);
    boolean deleteTournamentRegistration(Integer id);
    List<TournamentRegistration> filterTournamentRegistrations(Predicate<TournamentRegistration> predicate);

    // ---- TournamentRegistrationPayment ----
    TournamentRegistrationPayment createTournamentRegistrationPayment(TournamentRegistrationPayment entity);
    TournamentRegistrationPayment getTournamentRegistrationPaymentById(Integer id);
    List<TournamentRegistrationPayment> getAllTournamentRegistrationPayments();
    TournamentRegistrationPayment updateTournamentRegistrationPayment(Integer id, TournamentRegistrationPayment entity);
    boolean deleteTournamentRegistrationPayment(Integer id);
    List<TournamentRegistrationPayment> filterTournamentRegistrationPayments(Predicate<TournamentRegistrationPayment> predicate);

    // ---- TournamentAnnouncement ----
    TournamentAnnouncement createTournamentAnnouncement(TournamentAnnouncement entity);
    TournamentAnnouncement getTournamentAnnouncementById(Integer id);
    List<TournamentAnnouncement> getAllTournamentAnnouncements();
    TournamentAnnouncement updateTournamentAnnouncement(Integer id, TournamentAnnouncement entity);
    boolean deleteTournamentAnnouncement(Integer id);
    List<TournamentAnnouncement> filterTournamentAnnouncements(Predicate<TournamentAnnouncement> predicate);

    // ---- TournamentFAQ ----
    TournamentFAQ createTournamentFAQ(TournamentFAQ entity);
    TournamentFAQ getTournamentFAQById(Integer id);
    List<TournamentFAQ> getAllTournamentFAQs();
    TournamentFAQ updateTournamentFAQ(Integer id, TournamentFAQ entity);
    boolean deleteTournamentFAQ(Integer id);
    List<TournamentFAQ> filterTournamentFAQs(Predicate<TournamentFAQ> predicate);

}