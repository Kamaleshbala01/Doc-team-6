package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.AffiliateService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * In-memory implementation of AffiliateService.
 * Storage is a LinkedHashMap per entity (keeps insertion order);
 * ids are generated with an Atomic counter per entity.
 */
public class AffiliateServiceImpl implements AffiliateService {

    private final Map<Integer, AffiliateCampaign> affiliateCampaignStore = new LinkedHashMap<>();
    private final AtomicInteger affiliateCampaignIdGen = new AtomicInteger(1);
    private final Map<Integer, AffiliateLink> affiliateLinkStore = new LinkedHashMap<>();
    private final AtomicInteger affiliateLinkIdGen = new AtomicInteger(1);
    private final Map<Long, AffiliateClick> affiliateClickStore = new LinkedHashMap<>();
    private final AtomicLong affiliateClickIdGen = new AtomicLong(1);

    // ---- AffiliateCampaign ----
    @Override
    public AffiliateCampaign createAffiliateCampaign(AffiliateCampaign entity) {
        Integer newId = affiliateCampaignIdGen.getAndIncrement();
        entity.setId(newId);
        affiliateCampaignStore.put(newId, entity);
        return entity;
    }

    @Override
    public AffiliateCampaign getAffiliateCampaignById(Integer id) {
        return affiliateCampaignStore.get(id);
    }

    @Override
    public List<AffiliateCampaign> getAllAffiliateCampaigns() {
        return affiliateCampaignStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public AffiliateCampaign updateAffiliateCampaign(Integer id, AffiliateCampaign entity) {
        if (!affiliateCampaignStore.containsKey(id)) return null;
        entity.setId(id);
        affiliateCampaignStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteAffiliateCampaign(Integer id) {
        return affiliateCampaignStore.remove(id) != null;
    }

    @Override
    public List<AffiliateCampaign> filterAffiliateCampaigns(Predicate<AffiliateCampaign> predicate) {
        return affiliateCampaignStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- AffiliateLink ----
    @Override
    public AffiliateLink createAffiliateLink(AffiliateLink entity) {
        Integer newId = affiliateLinkIdGen.getAndIncrement();
        entity.setId(newId);
        affiliateLinkStore.put(newId, entity);
        return entity;
    }

    @Override
    public AffiliateLink getAffiliateLinkById(Integer id) {
        return affiliateLinkStore.get(id);
    }

    @Override
    public List<AffiliateLink> getAllAffiliateLinks() {
        return affiliateLinkStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public AffiliateLink updateAffiliateLink(Integer id, AffiliateLink entity) {
        if (!affiliateLinkStore.containsKey(id)) return null;
        entity.setId(id);
        affiliateLinkStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteAffiliateLink(Integer id) {
        return affiliateLinkStore.remove(id) != null;
    }

    @Override
    public List<AffiliateLink> filterAffiliateLinks(Predicate<AffiliateLink> predicate) {
        return affiliateLinkStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- AffiliateClick ----
    @Override
    public AffiliateClick createAffiliateClick(AffiliateClick entity) {
        Long newId = affiliateClickIdGen.getAndIncrement();
        entity.setId(newId);
        affiliateClickStore.put(newId, entity);
        return entity;
    }

    @Override
    public AffiliateClick getAffiliateClickById(Long id) {
        return affiliateClickStore.get(id);
    }

    @Override
    public List<AffiliateClick> getAllAffiliateClicks() {
        return affiliateClickStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public AffiliateClick updateAffiliateClick(Long id, AffiliateClick entity) {
        if (!affiliateClickStore.containsKey(id)) return null;
        entity.setId(id);
        affiliateClickStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteAffiliateClick(Long id) {
        return affiliateClickStore.remove(id) != null;
    }

    @Override
    public List<AffiliateClick> filterAffiliateClicks(Predicate<AffiliateClick> predicate) {
        return affiliateClickStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

}