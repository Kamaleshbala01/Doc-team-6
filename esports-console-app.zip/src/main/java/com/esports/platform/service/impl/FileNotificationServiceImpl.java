package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.FileNotificationService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * In-memory implementation of FileNotificationService.
 * Storage is a LinkedHashMap per entity (keeps insertion order);
 * ids are generated with an Atomic counter per entity.
 */
public class FileNotificationServiceImpl implements FileNotificationService {

    private final Map<Integer, Files> filesStore = new LinkedHashMap<>();
    private final AtomicInteger filesIdGen = new AtomicInteger(1);
    private final Map<Integer, Notification> notificationStore = new LinkedHashMap<>();
    private final AtomicInteger notificationIdGen = new AtomicInteger(1);
    private final Map<Integer, AuditLog> auditLogStore = new LinkedHashMap<>();
    private final AtomicInteger auditLogIdGen = new AtomicInteger(1);

    // ---- Files ----
    @Override
    public Files createFiles(Files entity) {
        Integer newId = filesIdGen.getAndIncrement();
        entity.setId(newId);
        filesStore.put(newId, entity);
        return entity;
    }

    @Override
    public Files getFilesById(Integer id) {
        return filesStore.get(id);
    }

    @Override
    public List<Files> getAllFiles() {
        return filesStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Files updateFiles(Integer id, Files entity) {
        if (!filesStore.containsKey(id)) return null;
        entity.setId(id);
        filesStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteFiles(Integer id) {
        return filesStore.remove(id) != null;
    }

    @Override
    public List<Files> filterFiles(Predicate<Files> predicate) {
        return filesStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- Notification ----
    @Override
    public Notification createNotification(Notification entity) {
        Integer newId = notificationIdGen.getAndIncrement();
        entity.setId(newId);
        notificationStore.put(newId, entity);
        return entity;
    }

    @Override
    public Notification getNotificationById(Integer id) {
        return notificationStore.get(id);
    }

    @Override
    public List<Notification> getAllNotifications() {
        return notificationStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Notification updateNotification(Integer id, Notification entity) {
        if (!notificationStore.containsKey(id)) return null;
        entity.setId(id);
        notificationStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteNotification(Integer id) {
        return notificationStore.remove(id) != null;
    }

    @Override
    public List<Notification> filterNotifications(Predicate<Notification> predicate) {
        return notificationStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

    // ---- AuditLog ----
    @Override
    public AuditLog createAuditLog(AuditLog entity) {
        Integer newId = auditLogIdGen.getAndIncrement();
        entity.setId(newId);
        auditLogStore.put(newId, entity);
        return entity;
    }

    @Override
    public AuditLog getAuditLogById(Integer id) {
        return auditLogStore.get(id);
    }

    @Override
    public List<AuditLog> getAllAuditLogs() {
        return auditLogStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public AuditLog updateAuditLog(Integer id, AuditLog entity) {
        if (!auditLogStore.containsKey(id)) return null;
        entity.setId(id);
        auditLogStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteAuditLog(Integer id) {
        return auditLogStore.remove(id) != null;
    }

    @Override
    public List<AuditLog> filterAuditLogs(Predicate<AuditLog> predicate) {
        return auditLogStore.values().stream().filter(predicate).collect(Collectors.toList());
    }

}