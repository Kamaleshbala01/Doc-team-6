package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;
import java.util.function.Predicate;

/**
 * CRUD contract for the Social Media & Games module.
 * Covers entities: SocialMediaPlatform, SocialMediaAccount, Game, InfluencerGame, StatusMaster
 */
public interface SocialMediaService {

    // ---- SocialMediaPlatform ----
    SocialMediaPlatform createSocialMediaPlatform(SocialMediaPlatform entity);
    SocialMediaPlatform getSocialMediaPlatformById(Integer id);
    List<SocialMediaPlatform> getAllSocialMediaPlatforms();
    SocialMediaPlatform updateSocialMediaPlatform(Integer id, SocialMediaPlatform entity);
    boolean deleteSocialMediaPlatform(Integer id);
    List<SocialMediaPlatform> filterSocialMediaPlatforms(Predicate<SocialMediaPlatform> predicate);

    // ---- SocialMediaAccount ----
    SocialMediaAccount createSocialMediaAccount(SocialMediaAccount entity);
    SocialMediaAccount getSocialMediaAccountById(Integer id);
    List<SocialMediaAccount> getAllSocialMediaAccounts();
    SocialMediaAccount updateSocialMediaAccount(Integer id, SocialMediaAccount entity);
    boolean deleteSocialMediaAccount(Integer id);
    List<SocialMediaAccount> filterSocialMediaAccounts(Predicate<SocialMediaAccount> predicate);

    // ---- Game ----
    Game createGame(Game entity);
    Game getGameById(Integer id);
    List<Game> getAllGames();
    Game updateGame(Integer id, Game entity);
    boolean deleteGame(Integer id);
    List<Game> filterGames(Predicate<Game> predicate);

    // ---- InfluencerGame ----
    InfluencerGame createInfluencerGame(InfluencerGame entity);
    InfluencerGame getInfluencerGameById(Integer id);
    List<InfluencerGame> getAllInfluencerGames();
    InfluencerGame updateInfluencerGame(Integer id, InfluencerGame entity);
    boolean deleteInfluencerGame(Integer id);
    List<InfluencerGame> filterInfluencerGames(Predicate<InfluencerGame> predicate);

    // ---- StatusMaster ----
    StatusMaster createStatusMaster(StatusMaster entity);
    StatusMaster getStatusMasterById(Integer id);
    List<StatusMaster> getAllStatusMasters();
    StatusMaster updateStatusMaster(Integer id, StatusMaster entity);
    boolean deleteStatusMaster(Integer id);
    List<StatusMaster> filterStatusMasters(Predicate<StatusMaster> predicate);

}