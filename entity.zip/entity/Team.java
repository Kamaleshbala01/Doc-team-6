package com.esports.project.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "teams")
public class Team {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String teamName;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    /*
     * Relationship mapping
     */

     // team logo file id

     @OneToOne(fetch = FetchType.EAGER)
     @JoinColumn(name = "file_id")
     private Files teamLogoUrl;

     // owner like leader of the team

     @ManyToOne
     @JoinColumn(name = "leader_id")
     @JsonBackReference(value = "user-own-teams")
     private User user;

     // team members details

     @OneToMany(mappedBy = "team")
     @JsonManagedReference(value = "team-members")
     private List<TeamMembers> teamMembers;

     // tournament regestraion mapping

     @OneToMany(mappedBy = "team",fetch = FetchType.LAZY)
     @JsonManagedReference(value = "team-registration")
     private List<TournamentRegistration> tournamentRegistrations;

    
}
