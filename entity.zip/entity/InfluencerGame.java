package com.esports.project.entity;

import com.esports.project.enums.Game;
import com.esports.project.enums.GameMode;
import com.esports.project.enums.GamePlatform;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "influencer_games")
public class InfluencerGame {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private Game game;

    @Enumerated(EnumType.STRING)
    private GameMode mode;

    @Enumerated(EnumType.STRING)
    private GamePlatform platform;

    private Boolean isPrimary;

    /*
     * Relationship mapping
     */
    
    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference(value = "influencer-games")
    private User influencer;
    
}
