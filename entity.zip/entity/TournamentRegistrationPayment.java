package com.esports.project.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.PaymentMethod;
import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tournament_registration_payments")
public class TournamentRegistrationPayment {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    private PaymentMethod paymentMethod;

    @Enumerated(EnumType.STRING)
    private StatusMaster paymentStatus;
    private LocalDateTime paidDate;
    private LocalDateTime createdAt;

    /*
     * relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "team_id")
    @JsonBackReference(value = "tournament-registration-payment")
    private User user;

    // registraion mapping

    @ManyToOne
    @JoinColumn(name = "registration_id")
    @JsonBackReference(value = "tournament-registration-registration-payment")
    private TournamentRegistration tournamentRegistration;
    
}
