package com.esports.project.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "files")
public class Files {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String fileName;
    private String fileType;
    private String bucketName;
    private String storagePath;
    private Long fileSize;
    private LocalDateTime createdAt;

    /*
     * Relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference(value = "user-files")
    private User uploadedBy;

}
