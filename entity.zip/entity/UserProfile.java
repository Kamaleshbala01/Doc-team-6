package com.esports.project.entity;

import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "user_profiles")
@Getter
@Setter
public class UserProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String firstName;
    private String lastName;
    private String profileImageURI;
    private String bio;
    private Boolean isInfluencer;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;

    /*
     * relationship mapping
     */

     @OneToOne
     @JoinColumn(name = "user_id")
     @JsonBackReference(value = "user-profile")
     private User user;
}
