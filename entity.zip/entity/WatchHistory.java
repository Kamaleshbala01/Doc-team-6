package com.esports.project.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "watch_histories")
public class WatchHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private LocalDateTime createdAt;

    /*
     * Relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference(value = "user-watch-history")
    private User user; 

    // match mapping

    @ManyToOne
    @JoinColumn(name = "match_id")
    @JsonBackReference(value = "match-details-watch-history")
    private MatchDetails matchDetails;
}
