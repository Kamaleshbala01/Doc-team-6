package com.esports.project.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "organizer_details")
public class OrganizerDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String governmentIdUri;
    private String selfieVerificationUri;
    private String verificationStatus;
    private LocalDateTime verifiedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    /**
     * Relationship mapping
     */

     @OneToOne
     @JoinColumn(name = "user_id")
     @JsonManagedReference(value = "organizer-details")
     private User user;
}
