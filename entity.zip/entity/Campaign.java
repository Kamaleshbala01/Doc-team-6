package com.esports.project.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.esports.project.enums.CampaignType;
import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "campaigns")
public class Campaign {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private CampaignType campaignType;

    private String campaignName;

    private LocalDateTime startDate;
    private LocalDateTime endDate;

    private String description;

    private BigDecimal totalBudget;
    private BigDecimal influencerCost;
    private BigDecimal additionalExpenses;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    /*
     * relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference(value = "brand-campaign")
    private User brand;

    // file for thumnail link

    @OneToOne
    @JoinColumn(name = "file_id")
    private Files thumbNailUri;

    // affilate link mapping

    @OneToOne(mappedBy = "campaign",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "campaign-affiliate-link")
    private List<AffiliateLink> AffiliateLink;

    // colaburation request

    @OneToMany(mappedBy = "campaign",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "collaburation-request")
    private List<CollaburationRequest> collaburationRequests;
}
