package com.esports.project.entity;


import java.time.LocalDateTime;
import java.util.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String email;
    private String username;
    private String password;
    private Boolean emailVerified;
    private String mobileNumber;
    private Boolean mobileVerifed;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;


    /**
     * relationship mapping
     */

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "user-roles",
                joinColumns = @JoinColumn(name = "user_id"),
                inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    @JsonManagedReference(value = "user-role")
    private Set<Role> roles;

    // user Profile
    @OneToOne(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-profile")
    private UserProfile userProfile;

    // brand profile
    @OneToOne(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "brand-details")
    private BrandDetails brandDetails;

    // organizer profile
    @OneToOne(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "organizer-details")
    private OrganizerDetails organizerDetails;

    // tournament 

    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "tournaments")
    private List<Tournament> tournaments;

    // files

    @OneToMany(mappedBy = "uploadedBy")
    @JsonManagedReference(value = "user-files")
    private List<Files> files;


    // games for influencer mapping
    @OneToMany(mappedBy = "influencer")
    @JsonManagedReference(value = "influencer-games")
    private List<InfluencerGame> influencerGames;

    // campaign details

    @OneToMany(mappedBy = "brand")
    @JsonManagedReference(value = "brand-campaign")
    private List<Campaign> campaigns;

    // affiliate link mapping for the influencer

    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-affiliate-link")
    private List<AffiliateLink> affiliateLinks;

    // myown teams

    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-own-teams")
    private List<Team> ownedTeams;

    // my participant team

    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-team-participants")
    private List<TeamMembers> TeamParticipants;

    // Tournament FAQs 

    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-faqs")
    private List<TournamentFAQ> tournamentFAQs;

    // influencer social media mapping

    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "influencer-social-media")
    private List<SocialMediaAccount> socialMediaAccounts;

    // tournament registration payment

    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "tournament-registration-payment")
    private List<TournamentRegistrationPayment> tournamentRegistrationPayments;

    // watch history

    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-watch-history")
    private List<WatchHistory> watchHistories;

    // subscription plan

    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-subscription")
    private List<UserSubscription> userSubscriptions;

    // collaburation request sender

    @OneToMany(mappedBy = "sender",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "sender-collaburation-request")
    private List<CollaburationRequest> senderCollaburationRequests;

    // collaburation request reciver

    @OneToMany(mappedBy = "reciver",fetch = FetchType.LAZY)
    @JsonBackReference(value = "reciver-collaburation-request")
    private List<CollaburationRequest> reciverCollaburationRequests;

    // conversation creation 

    @OneToMany(mappedBy = "createdBy",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-conversation")
    private List<Conversation> conversations;

    // conversation participants 

    @OneToMany(mappedBy = "participant",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "conversation-participants")
    private List<ConversationParticipants> conversationParticipants;

    // message mapping 

    @OneToMany(mappedBy = "sender",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-message")
    private List<Message> messages;

    // message read mapping

    @OneToMany(mappedBy = "readBy", fetch = FetchType.LAZY)
    @JsonBackReference(value = "user-message-read-status")
    private List<MessageReadStatus> messageReadStatus;

    // notification mapping

    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-notification")
    private List<Notification> notifications;

    
}
