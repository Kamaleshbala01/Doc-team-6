package com.esports.project.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "round_details")
public class RoundDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String roundName;
    private Integer maximumParticipants;
    private Integer qualifyingCount;
    private LocalDateTime createdAt;

    /*
     * Relationship mapping
     */

    // Tournament 

    @ManyToOne
    @JoinColumn(name = "tournament_id")
    @JsonBackReference(value = "tournament-round-details")
    private Tournament tournament;

    // Match details 

    @OneToMany(mappedBy = "roundDetails")
    @JsonManagedReference(value = "round-match-details")
    private List<MatchDetails> matchDetails;
}
