package com.esports.project.entity;

import java.time.LocalDateTime;

import com.esports.project.enums.RulesCategory;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tournament_rules")
public class TournamentRules {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private RulesCategory category;
    private String ruleText;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    /*
     * Relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "tournament_id")
    @JsonBackReference(value = "tournament-rules")
    private Tournament tournament;
}
