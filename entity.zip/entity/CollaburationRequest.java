package com.esports.project.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "collaburation_requests")
public class CollaburationRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    private String title;
    private String description;
    private BigDecimal proposedAmount;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    /*
     * Relationship mapping
     */

    // campaign mapping
    @ManyToOne
    @JoinColumn(name = "campaign_id")
    @JsonBackReference(value = "collaburation-request")
    private Campaign campaign;

    // colaburation sender maping

    @ManyToOne
    @JoinColumn(name = "sender_id")
    @JsonBackReference(value = "sender-collaburation-request")
    private User sender;

    // colaburation reciver
    @ManyToOne
    @JoinColumn(name = "reciver_id")
    @JsonBackReference(value = "reciver-collaburation-request")
    private User reciver;

    
}
