package com.esports.project.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "user_subscriptions")
public class UserSubscription {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private BigDecimal amountPaid;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;
    
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    /*
     * Relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference(value = "user-subscription")
    private User user;

    // subscription plan mapping

    @ManyToOne
    @JoinColumn(name = "subscription_plan_id")
    @JsonBackReference(value = "user-subscription")
    private SubscriptionPlan subscriptionPlan;
    
}
