package com.esports.project.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.esports.project.enums.SubscriptionType;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "subscription_plans")
public class SubscriptionPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String name;

    @Enumerated(EnumType.STRING)
    private SubscriptionType userType;
    private BigDecimal price;
    private Integer durationDays;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    /*
     * Subscription  mapping
     */

    @OneToMany(mappedBy = "subscriptionPlan",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "user-subscription")
    private List<UserSubscription> userSubscriptions;
}
