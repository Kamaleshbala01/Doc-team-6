package com.esports.project.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.esports.project.enums.ConversationType;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "conversations")
public class Conversation {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private ConversationType conversationType;
    private String name;
    private String description;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    /*
     * Relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference(value = "user-conversation")
    private User createdBy;

    // conversationParticipants

    @OneToMany(mappedBy = "conversation",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JsonManagedReference(value = "conversation-participants")
    private List<ConversationParticipants> conversationParticipants;

    // converation message mapping

    @OneToMany(mappedBy = "conversation", fetch = FetchType.LAZY)
    @JsonManagedReference(value = "converation-message")
    private List<Message> messages;

}
