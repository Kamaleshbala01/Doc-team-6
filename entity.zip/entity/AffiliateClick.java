package com.esports.project.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "affiliate-clicks")
public class AffiliateClick {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String sessionId;
    private String visitorIp;
    private String deviceType;
    private String browser;
    private String refererUrl;
    private LocalDateTime clickedAt;

    /*
     * Relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "affiliate_link_id")
    @JsonBackReference(value = "affiliate-click")
    private AffiliateLink affiliateLink;
}
