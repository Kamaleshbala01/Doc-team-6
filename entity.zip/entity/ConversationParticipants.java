package com.esports.project.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "conversation_participants")
public class ConversationParticipants {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private Boolean isAdmin;
    private Boolean isMuted;
    private LocalDateTime joinedAt;
    private LocalDateTime leftAt;
    private LocalDateTime createdAt;

    /*
     * Relationship mapping
     */

    // conversation mapping

    @ManyToOne
    @JoinColumn(name = "conversation_id")
    @JsonBackReference(value = "conversation-participants")
    private Conversation conversation;

    // participant mapping

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference(value = "conversation-participants")
    private User participant;
}
