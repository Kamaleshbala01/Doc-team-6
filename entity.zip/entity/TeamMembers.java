package com.esports.project.entity;

import java.time.LocalDateTime;

import com.esports.project.enums.TeamPosition;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "team_menbers")
public class TeamMembers {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private TeamPosition position;

    private LocalDateTime joinedAt;
    private LocalDateTime updatedAt;

    /*
     * Relationship mapping
     */

    // Team mapping
    
    @ManyToOne
    @JoinColumn(name = "team_id")
    @JsonBackReference(value = "team-members")
    private Team team;

    // member like user mapping

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference(value = "user-team-participants")
    private User user;
    
}
