package com.esports.project.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tournament_registration")
public class TournamentRegistration {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private StatusMaster registrationStatus;

    private LocalDateTime registrationDate;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt; 

    /*
     * Relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "tournament_id")
    @JsonBackReference(value = "tournament-registration")
    private Tournament tournament;

    // team mapping

    @ManyToOne
    @JoinColumn(name = "team_id")
    @JsonBackReference(value = "team-registration")
    private Team team;

    // registration payment

    @OneToMany(mappedBy = "tournamentRegistration")
    @JsonManagedReference(value = "tournament-registration-registration-payment")
    private List<TournamentRegistrationPayment> tournamentRegistrationPayments;
    
}
