package com.esports.project.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.esports.project.enums.SocialMediaPlatform;
import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "social_media_account")
public class SocialMediaAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private SocialMediaPlatform platform;
    private String accountName;
    private String profileUrl;
    private Long followersCount;
    private Long subscriberCount;
    private BigDecimal viewSubscriptionRatio;
    private BigDecimal viewCommentRatio;

    private StatusMaster status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    /*
     * Relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonBackReference(value = "influencer-social-media")
    private User user;
}
