"use strict";

/* =====================================================
   ACTIVITY PAGE
===================================================== */

document.addEventListener("DOMContentLoaded", () => {

    initializeSidebar();
    renderActivity();
    initializeSearch();

    window.addEventListener(
        "gv:storage",
        renderActivity
    );

});

/* =====================================================
   GET ACTIVITY
===================================================== */

function getActivities() {

    return StorageManager
        .all(COLLECTIONS.ACTIVITY)
        .sort(
            (a, b) =>
                new Date(b.createdAt) -
                new Date(a.createdAt)
        );

}

/* =====================================================
   RENDER ACTIVITY
===================================================== */

function renderActivity() {

    const activities =
        getActivities();

    const view =
        document.getElementById(
            "activityView"
        );

    view.innerHTML = `

        <section class="panel">

            <div class="panel-header">

                <h2>
                    Activity Timeline
                </h2>

                <span class="badge">
                    ${activities.length} Logs
                </span>

            </div>

            <div class="timeline"
                 id="activityTimeline">

                ${
                    activities.length
                        ? activities
                            .map(activityCard)
                            .join("")
                        : emptyState()
                }

            </div>

        </section>

    `;
}

/* =====================================================
   ACTIVITY CARD
===================================================== */

function activityCard(log) {

    return `

        <div class="timeline-item">

            <span class="timeline-dot"></span>

            <div class="timeline-content">

                <strong>
                    ${escapeHtml(
                        log.action
                    )}
                </strong>

                <p>

                    Module :
                    ${escapeHtml(
                        log.module || "System"
                    )}

                </p>

                <small>

                    ${escapeHtml(
                        log.admin || "Admin"
                    )}

                    •

                    ${formatDate(
                        log.createdAt
                    )}

                </small>

            </div>

        </div>

    `;
}

/* =====================================================
   SEARCH
===================================================== */

function initializeSearch() {

    const search =
        document.getElementById(
            "activitySearch"
        );

    if (!search) return;

    search.addEventListener(
        "input",
        () => {

            const term =
                search.value
                    .toLowerCase()
                    .trim();

            const logs =
                getActivities()
                .filter(log =>
                    Object.values(log)
                        .join(" ")
                        .toLowerCase()
                        .includes(term)
                );

            renderSearchResults(logs);

        }
    );
}

function renderSearchResults(logs) {

    const timeline =
        document.getElementById(
            "activityTimeline"
        );

    if (!timeline) return;

    timeline.innerHTML =

        logs.length

            ? logs
                .map(activityCard)
                .join("")

            : emptyState();
}

/* =====================================================
   EMPTY STATE
===================================================== */

function emptyState() {

    return `

        <div class="empty">

            No activity logs found

        </div>

    `;
}

/* =====================================================
   FORMAT DATE
===================================================== */

function formatDate(date) {

    if (!date) return "-";

    return new Date(date)
        .toLocaleString(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit"
            }
        );
}

/* =====================================================
   ESCAPE
===================================================== */

function escapeHtml(value) {

    return String(value || "")
        .replace(
            /[&<>"']/g,
            char => ({
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                "\"": "&quot;",
                "'": "&#39;"
            }[char])
        );
}

/* =====================================================
   MOBILE SIDEBAR
===================================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu || !backdrop) return;

    menu.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .add("nav-open");

        }
    );

    backdrop.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .remove("nav-open");

        }
    );
}