"use strict";

/* =====================================================
   DASHBOARD
===================================================== */

document.addEventListener("DOMContentLoaded", () => {

    initializeSidebar();
    renderDashboard();
    bindActions();

});

/* =====================================================
   HELPERS
===================================================== */

const dashboardView =
    document.getElementById("dashboardView");

const money = value =>
    new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0
    }).format(Number(value) || 0);

const formatDate = value =>
    new Date(value).toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

function getRows(collection) {
    return StorageManager.all(collection);
}

function sum(items, key) {
    return items.reduce(
        (total, item) =>
            total + Number(item[key] || 0),
        0
    );
}

function pendingCount() {

    return [
        COLLECTIONS.USERS,
        COLLECTIONS.INFLUENCERS,
        COLLECTIONS.BRANDS
    ]
        .flatMap(col =>
            getRows(col)
        )
        .filter(r =>
            r.status === "Pending"
        )
        .length;

}

/* =====================================================
   DASHBOARD
===================================================== */

function renderDashboard() {

    const users =
        getRows(COLLECTIONS.USERS);

    const influencers =
        getRows(COLLECTIONS.INFLUENCERS);

    const brands =
        getRows(COLLECTIONS.BRANDS);

    const tournaments =
        getRows(COLLECTIONS.TOURNAMENTS);

    const subscriptions =
        getRows(COLLECTIONS.SUBSCRIPTIONS);

    const tickets =
        getRows(COLLECTIONS.SUPPORT);

    const activities =
        getRows(COLLECTIONS.ACTIVITY);

    const revenue =
        sum(subscriptions, "revenue");

    dashboardView.innerHTML = `

        <div class="stat-grid">

            ${statCard(
                "Total Users",
                users.length,
                "All registered users"
            )}

            ${statCard(
                "Verified Users",
                users.filter(
                    u => u.status === "Approved"
                ).length,
                "Approved accounts"
            )}

            ${statCard(
                "Pending Reviews",
                pendingCount(),
                "Needs verification"
            )}

            ${statCard(
                "Influencers",
                influencers.length,
                "Creator partners"
            )}

            ${statCard(
                "Brands",
                brands.length,
                "Business accounts"
            )}

            ${statCard(
                "Tournaments",
                tournaments.length,
                "Total events"
            )}

            ${statCard(
                "Revenue",
                money(revenue),
                "Monthly revenue"
            )}

            ${statCard(
                "Open Tickets",
                tickets.filter(
                    t => t.status !== "Resolved"
                ).length,
                "Support requests"
            )}

        </div>

        <div class="chart-grid">

            ${chartCard(
                "User Distribution",
                "userDistribution"
            )}

            ${chartCard(
                "Verification Status",
                "verificationChart"
            )}

            ${chartCard(
                "Revenue",
                "revenueChart"
            )}

            ${chartCard(
                "Tournaments",
                "tournamentChart"
            )}

            ${chartCard(
                "Growth",
                "growthChart"
            )}

        </div>

        <div class="dashboard-grid">

            ${miniTable(
                "Recent Users",
                users.slice(0, 5),
                [
                    "name",
                    "email",
                    "status"
                ]
            )}

            ${miniTable(
                "Recent Tournaments",
                tournaments.slice(0, 5),
                [
                    "title",
                    "game",
                    "status"
                ]
            )}

            <section class="panel">

                <h2>
                    Recent Activity
                </h2>

                <div class="timeline">

                    ${activities
                        .slice(0, 8)
                        .map(activityItem)
                        .join("")}

                </div>

            </section>

        </div>
    `;

    drawCharts();
}

/* =====================================================
   CARDS
===================================================== */

function statCard(title, value, hint) {

    return `
        <article class="stat-card">

            <span>${title}</span>

            <strong>${value}</strong>

            <small>${hint}</small>

        </article>
    `;
}

function chartCard(title, id) {

    return `
        <section class="panel chart-card">

            <h2>${title}</h2>

            <canvas id="${id}"></canvas>

        </section>
    `;
}

/* =====================================================
   TABLES
===================================================== */

function miniTable(title, data, columns) {

    return `
        <section class="panel">

            <h2>${title}</h2>

            <table>

                <thead>
                    <tr>
                        ${columns
                            .map(col =>
                                `<th>${col}</th>`
                            )
                            .join("")}
                    </tr>
                </thead>

                <tbody>

                    ${data.map(row => `
                        <tr>

                            ${columns.map(col => `
                                <td>
                                    ${formatRow(
                                        row[col],
                                        col
                                    )}
                                </td>
                            `).join("")}

                        </tr>
                    `).join("")}

                </tbody>

            </table>

        </section>
    `;
}

/* =====================================================
   ACTIVITY
===================================================== */

function activityItem(item) {

    return `
        <div class="timeline-item">

            <span></span>

            <div>

                <strong>
                    ${item.action}
                </strong>

                <small>
                    ${item.admin}
                    •
                    ${formatDate(
                        item.createdAt
                    )}
                </small>

            </div>

        </div>
    `;
}

/* =====================================================
   FORMAT
===================================================== */

function formatRow(value, key) {

    if (
        ["revenue", "price", "prizePool"]
            .includes(key)
    ) {
        return money(value);
    }

    if (key === "status") {

        return `
            <span class="badge ${String(value)
                .toLowerCase()
                .replaceAll(" ", "-")}">

                ${value}

            </span>
        `;
    }

    return value || "-";
}

/* =====================================================
   CHARTS
===================================================== */

function drawCharts() {

    if (!window.Chart) return;

    const users =
        getRows(COLLECTIONS.USERS);

    const influencers =
        getRows(COLLECTIONS.INFLUENCERS);

    const brands =
        getRows(COLLECTIONS.BRANDS);

    const tournaments =
        getRows(COLLECTIONS.TOURNAMENTS);

    const subscriptions =
        getRows(COLLECTIONS.SUBSCRIPTIONS);

    createChart(
        "userDistribution",
        "doughnut",
        ["Users", "Influencers", "Brands"],
        [
            users.length,
            influencers.length,
            brands.length
        ]
    );

    const statusTotals = {
        Approved: 0,
        Pending: 0,
        Rejected: 0
    };

    [...users, ...influencers, ...brands]
        .forEach(item => {

            if (
                statusTotals[item.status] !==
                undefined
            ) {
                statusTotals[item.status]++;
            }

        });

    createChart(
        "verificationChart",
        "pie",
        [
            "Approved",
            "Pending",
            "Rejected"
        ],
        [
            statusTotals.Approved,
            statusTotals.Pending,
            statusTotals.Rejected
        ]
    );

    createChart(
        "revenueChart",
        "line",
        subscriptions.map(
            s => s.plan
        ),
        subscriptions.map(
            s => s.revenue
        )
    );

    createChart(
        "tournamentChart",
        "bar",
        tournaments.map(
            t => t.game
        ),
        tournaments.map(
            t => t.teams
        )
    );

    createChart(
        "growthChart",
        "line",
        [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun"
        ],
        [
            200,
            380,
            550,
            760,
            920,
            users.length +
            influencers.length +
            brands.length
        ]
    );
}

/* =====================================================
   CREATE CHART
===================================================== */

function createChart(
    id,
    type,
    labels,
    data
) {

    const canvas =
        document.getElementById(id);

    if (!canvas) return;

    new Chart(canvas, {

        type,

        data: {

            labels,

            datasets: [{
                label: "Invictus",
                data,

                borderColor:
                    "#06b6d4",

                backgroundColor: [
                    "#7c3aed",
                    "#06b6d4",
                    "#22c55e",
                    "#f59e0b",
                    "#ef4444",
                    "#8b5cf6"
                ],

                tension: 0.4,

                fill: true
            }]
        },

        options: {

            responsive: true,

            maintainAspectRatio: false,

            plugins: {
                legend: {
                    labels: {
                        color: "#f8fafc"
                    }
                }
            }
        }
    });
}

/* =====================================================
   ACTIONS
===================================================== */

function bindActions() {

    const notificationBtn =
        document.getElementById(
            "notificationBtn"
        );

    if (notificationBtn) {

        notificationBtn.addEventListener(
            "click",
            () => {

                alert(
                    `${pendingCount()} pending verification requests`
                );

            }
        );
    }

    const mailBtn =
        document.getElementById(
            "mailBtn"
        );

    if (mailBtn) {

        mailBtn.addEventListener(
            "click",
            () => {

                alert(
                    "Inbox feature coming soon"
                );

            }
        );
    }
}

/* =====================================================
   MOBILE
===================================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu || !backdrop) return;

    menu.addEventListener(
        "click",
        () => {

            document.body.classList.add(
                "nav-open"
            );

        }
    );

    backdrop.addEventListener(
        "click",
        () => {

            document.body.classList.remove(
                "nav-open"
            );

        }
    );
}