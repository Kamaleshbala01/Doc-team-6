"use strict";

/* =====================================================
   SETTINGS PAGE
===================================================== */

document.addEventListener("DOMContentLoaded", () => {

    initializeSidebar();
    renderSettings();

});

/* =====================================================
   SETTINGS
===================================================== */

function getSettings() {

    return StorageManager.load(
        COLLECTIONS.SETTINGS,
        {}
    );

}

/* =====================================================
   ACTIVITY LOG
===================================================== */

function logActivity(action) {

    const settings = getSettings();

    StorageManager.insert(
        COLLECTIONS.ACTIVITY,
        {
            action,
            admin:
                settings.adminName ||
                "Admin Xeno",

            module: "Settings",

            createdAt:
                new Date().toISOString()
        }
    );

}

/* =====================================================
   TOAST
===================================================== */

function showToast(
    message,
    type = "success"
) {

    const container =
        document.getElementById(
            "toastStack"
        );

    if (!container) {
        alert(message);
        return;
    }

    const toast =
        document.createElement("div");

    toast.className =
        `toast ${type}`;

    toast.textContent =
        message;

    container.appendChild(
        toast
    );

    setTimeout(() => {
        toast.remove();
    }, 3000);

}

/* =====================================================
   RENDER SETTINGS
===================================================== */

function renderSettings() {

    const settings =
        getSettings();

    const view =
        document.getElementById(
            "settingsView"
        );

    view.innerHTML = `

        <section class="panel">

            <form
                id="settingsForm"
                class="settings-form">

                <label>

                    Platform Name

                    <input
                        type="text"
                        name="platformName"
                        required
                        value="${settings.platformName || "Invictus"}">

                </label>

                <label>

                    Admin Name

                    <input
                        type="text"
                        name="adminName"
                        required
                        value="${settings.adminName || "Admin Xeno"}">

                </label>

                <label>

                    Theme

                    <select name="theme">

                        <option
                            value="Dark"
                            ${settings.theme === "Dark" ? "selected" : ""}>
                            Dark
                        </option>

                        <option
                            value="Light"
                            ${settings.theme === "Light" ? "selected" : ""}>
                            Light
                        </option>

                    </select>

                </label>

                <label class="check">

                    <input
                        type="checkbox"
                        name="notifications"
                        ${settings.notifications ? "checked" : ""}>

                    Enable Notifications

                </label>

                <label class="check">

                    <input
                        type="checkbox"
                        name="autoBackup"
                        ${settings.autoBackup ? "checked" : ""}>

                    Enable Auto Backup

                </label>

                <button
                    type="submit"
                    class="btn primary">

                    Save Settings

                </button>

            </form>

        </section>

    `;

    bindSettingsForm();
}

/* =====================================================
   SAVE SETTINGS
===================================================== */

function bindSettingsForm() {

    const form =
        document.getElementById(
            "settingsForm"
        );

    if (!form) return;

    form.addEventListener(
        "submit",
        event => {

            event.preventDefault();

            const data =
                Object.fromEntries(
                    new FormData(form)
                );

            data.notifications =
                form.notifications.checked;

            data.autoBackup =
                form.autoBackup.checked;

            StorageManager.save(
                COLLECTIONS.SETTINGS,
                data
            );

            document.getElementById(
                "adminNameDisplay"
            ).textContent =
                data.adminName;

            logActivity(
                "Updated platform settings"
            );

            showToast(
                "Settings saved successfully"
            );

        }
    );
}

/* =====================================================
   MOBILE SIDEBAR
===================================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu || !backdrop) return;

    menu.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .add("nav-open");

        }
    );

    backdrop.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .remove("nav-open");

        }
    );
}