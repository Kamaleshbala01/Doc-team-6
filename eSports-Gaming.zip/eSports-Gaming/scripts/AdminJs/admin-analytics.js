"use strict";

/* =====================================================
   ANALYTICS PAGE
===================================================== */

document.addEventListener("DOMContentLoaded", () => {

    initializeSidebar();
    renderAnalytics();

});

/* =====================================================
   HELPERS
===================================================== */

function rows(collection) {
    return StorageManager.all(collection);
}

/* =====================================================
   RENDER ANALYTICS
===================================================== */

function renderAnalytics() {

    const view =
        document.getElementById("analyticsView");

    view.innerHTML = `

        <div class="chart-grid wide">

            <section class="panel chart-card">
                <h2>User Growth</h2>
                <canvas id="growthChart"></canvas>
            </section>

            <section class="panel chart-card">
                <h2>Revenue Analysis</h2>
                <canvas id="revenueChart"></canvas>
            </section>

            <section class="panel chart-card">
                <h2>Verification Status</h2>
                <canvas id="verificationChart"></canvas>
            </section>

            <section class="panel chart-card">
                <h2>Country Distribution</h2>
                <canvas id="countryChart"></canvas>
            </section>

            <section class="panel chart-card">
                <h2>Top Gaming Categories</h2>
                <canvas id="gamesChart"></canvas>
            </section>

        </div>

    `;

    drawCharts();
}

/* =====================================================
   CHARTS
===================================================== */

function drawCharts() {

    if (!window.Chart) return;

    const users =
        rows(COLLECTIONS.USERS);

    const influencers =
        rows(COLLECTIONS.INFLUENCERS);

    const brands =
        rows(COLLECTIONS.BRANDS);

    const subscriptions =
        rows(COLLECTIONS.SUBSCRIPTIONS);

    /* =============================================
       GROWTH
    ============================================= */

    createChart(
        "growthChart",
        "line",
        ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
        [
            200,
            400,
            620,
            850,
            1100,
            users.length +
            influencers.length +
            brands.length
        ],
        "Users"
    );

    /* =============================================
       REVENUE
    ============================================= */

    createChart(
        "revenueChart",
        "line",
        subscriptions.map(
            item => item.plan
        ),
        subscriptions.map(
            item => item.revenue
        ),
        "Revenue"
    );

    /* =============================================
       VERIFICATION
    ============================================= */

    const approved =
        [...users, ...influencers, ...brands]
        .filter(
            item => item.status === "Approved"
        ).length;

    const pending =
        [...users, ...influencers, ...brands]
        .filter(
            item => item.status === "Pending"
        ).length;

    const rejected =
        [...users, ...influencers, ...brands]
        .filter(
            item => item.status === "Rejected"
        ).length;

    createChart(
        "verificationChart",
        "pie",
        [
            "Approved",
            "Pending",
            "Rejected"
        ],
        [
            approved,
            pending,
            rejected
        ],
        "Verification"
    );

    /* =============================================
       COUNTRY DISTRIBUTION
    ============================================= */

    const countries =
        [...new Set(
            users.map(
                user => user.country
            )
        )];

    const countryCounts =
        countries.map(country =>
            users.filter(
                user =>
                    user.country === country
            ).length
        );

    createChart(
        "countryChart",
        "bar",
        countries,
        countryCounts,
        "Users"
    );

    /* =============================================
       TOP GAMES
    ============================================= */

    const games =
        [...new Set(
            users.map(
                user => user.game
            )
        )];

    const gameCounts =
        games.map(game =>
            users.filter(
                user =>
                    user.game === game
            ).length
        );

    createChart(
        "gamesChart",
        "bar",
        games,
        gameCounts,
        "Players"
    );
}

/* =====================================================
   CREATE CHART
===================================================== */

function createChart(
    id,
    type,
    labels,
    data,
    datasetLabel
) {

    const canvas =
        document.getElementById(id);

    if (!canvas) return;

    new Chart(canvas, {

        type,

        data: {

            labels,

            datasets: [{
                label: datasetLabel,
                data,

                borderColor:
                    "#06b6d4",

                backgroundColor: [
                    "#7c3aed",
                    "#06b6d4",
                    "#22c55e",
                    "#f59e0b",
                    "#ef4444",
                    "#8b5cf6",
                    "#14b8a6",
                    "#a855f7"
                ],

                fill: true,

                tension: 0.4
            }]
        },

        options: {

            responsive: true,

            maintainAspectRatio: false,

            plugins: {

                legend: {

                    labels: {
                        color: "#f8fafc"
                    }

                }

            },

            scales:

                type === "pie" ||
                type === "doughnut"

                    ? {}

                    : {

                        x: {

                            ticks: {
                                color: "#94a3b8"
                            },

                            grid: {
                                color: "#243244"
                            }

                        },

                        y: {

                            ticks: {
                                color: "#94a3b8"
                            },

                            grid: {
                                color: "#243244"
                            }

                        }

                    }

        }

    });
}

/* =====================================================
   MOBILE SIDEBAR
===================================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu || !backdrop) return;

    menu.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .add("nav-open");

        }
    );

    backdrop.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .remove("nav-open");

        }
    );
}