// ===============================
// Analytics Chart
// ===============================

const analyticsBtn = document.getElementById("viewAnalytics");

const ctx = document.getElementById("analyticsChart");

let chart = null;

analyticsBtn.addEventListener("click", function () {

    if (chart != null) {

        chart.destroy();

    }

    chart = new Chart(ctx, {

        type: "line",

        data: {

            labels: [

                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul"

            ],

            datasets: [

                {

                    label: "Ranking Points",

                    data: [

                        7200,
                        7600,
                        8050,
                        8500,
                        9000,
                        9450,
                        9850

                    ],

                    borderColor: "#7C3AED",

                    backgroundColor: "rgba(124,58,237,0.2)",

                    tension: 0.4,

                    fill: true

                }

            ]

        }

    });

});




// ===============================
// Fake Ranking Data
// ===============================

const rankingData = {

    bgmi: [

        ["#1","ShadowX","12000"],

        ["#2","Nandha Kumar","9850"],

        ["#3","Nova","9600"]

    ],

    valorant: [

        ["#1","Alpha","11200"],

        ["#2","Ghost","10800"],

        ["#3","Nandha Kumar","9200"]

    ],

    freefire: [

        ["#1","Phoenix","10500"],

        ["#2","Dragon","9800"],

        ["#3","Storm","9600"]

    ],

    cod: [

        ["#1","Blaze","11000"],

        ["#2","Hunter","10100"],

        ["#3","Nandha Kumar","9500"]

    ]

};


const buttons = document.querySelectorAll(".gameBtn");

const rankingBox = document.getElementById("gameRankingList");

function loadRanking(game){

    rankingBox.innerHTML="";

    rankingData[game].forEach(player=>{

        rankingBox.innerHTML += `

        <div class="player-card">

            <h3>${player[0]}</h3>

            <p>${player[1]}</p>

            <span>${player[2]} Points</span>

        </div>

        `;

    });

}

buttons.forEach(button=>{

    button.addEventListener("click",function(){

        buttons.forEach(btn=>btn.classList.remove("active"));

        this.classList.add("active");

        loadRanking(this.dataset.game);

    });

});

loadRanking("bgmi");


const rankingProgress = document.getElementById("rankingProgress");

analyticsBtn.addEventListener("click", function (){
    rankingProgress.scrollIntoView({
        behavior:"smooth",
        block:"start"
    })
})
