document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("influencerForm");

    const platform = document.getElementById("platform");
    const game = document.getElementById("game");

    const otherPlatform = document.getElementById("otherPlatform");
    const otherGame = document.getElementById("otherGame");

    const channelName = document.getElementById("channelName");
    const channelError = document.getElementById("channelError");

    /* ============================
       OTHER PLATFORM
    ============================ */

    platform.addEventListener("change", () => {

        if (platform.value === "Other") {
            otherPlatform.style.display = "block";
            otherPlatform.required = true;
        } else {
            otherPlatform.style.display = "none";
            otherPlatform.required = false;
            otherPlatform.value = "";
        }

    });

    /* ============================
       OTHER GAME
    ============================ */

    game.addEventListener("change", () => {

        if (game.value === "Other") {
            otherGame.style.display = "block";
            otherGame.required = true;
        } else {
            otherGame.style.display = "none";
            otherGame.required = false;
            otherGame.value = "";
        }

    });

    /* ============================
       CHANNEL NAME VALIDATION
    ============================ */

    channelName.addEventListener("input", () => {

        const value = channelName.value.trim();

        if (value.length < 3) {

            channelError.style.color = "#ef4444";
            channelError.textContent =
                "Channel name must contain at least 3 characters";

        } else {

            channelError.style.color = "#22c55e";
            channelError.textContent =
                "Valid Channel Name";

        }

    });

    /* ============================
       FORM SUBMIT
    ============================ */

    form.addEventListener("submit", (e) => {

        e.preventDefault();

        const name = channelName.value.trim();

        if (name.length < 3) {

            alert(
                "Gaming Channel Name must contain at least 3 characters."
            );

            channelName.focus();
            return;
        }

        const followers =
            document.getElementById("followers").value;

        if (followers < 1000) {

            alert(
                "Minimum 1000 Followers/Subscribers required to apply."
            );

            return;
        }

        showSuccessPopup();

        form.reset();

        otherPlatform.style.display = "none";
        otherGame.style.display = "none";

        channelError.textContent = "";

    });

    /* ============================
       SUCCESS POPUP
    ============================ */

    function showSuccessPopup() {

        const popup = document.createElement("div");

        popup.className = "success-popup";

        popup.innerHTML = `

            <div class="popup-content">

                <i class="fa-solid fa-circle-check"></i>

                <h2>Application Submitted</h2>

                <p>
                    Influencer details submitted successfully.
                    Our team will review your application shortly.
                </p>

                <button id="closePopup">
                    OK
                </button>

            </div>
        `;

        document.body.appendChild(popup);

        document.getElementById("closePopup")
            .addEventListener("click", () => {

                popup.remove();

            });
    }

});

const becomeInfluencer = document.getElementById("becomeInfluencer");

becomeInfluencerBtn.addEventListener("click", function (){
    becomeInfluencer.scrollIntoView({
        behavior:"smooth",
        block:"start"
    })
})
