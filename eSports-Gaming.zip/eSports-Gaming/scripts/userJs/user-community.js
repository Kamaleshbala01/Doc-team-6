// ==========================
// Fake Players
// ==========================

const players = [
    "ShadowX",
    "Nova",
    "Blaze"
];

// ==========================
// Search Community Groups
// ==========================

const groupSearch = document.querySelector(".search-box input");
const groupCards = document.querySelectorAll(".group-card");

groupSearch.addEventListener("keyup", function () {

    const value = this.value.toLowerCase();

    groupCards.forEach(card => {

        const name = card.querySelector("h3").textContent.toLowerCase();

        if (name.includes(value)) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }

    });

});


// ==========================
// Find Players
// ==========================

const searchBoxes = document.querySelectorAll(".search-box input");

const playerSearch = searchBoxes[1];

const findPlayerBtn = document.querySelectorAll(".btn-secondary")[0];



// ==========================
// Create Group
// ==========================

const createBtn = document.querySelector(".topbar .btn-primary");

const myGroups = document.querySelector(".dashboard-section .card-grid");

createBtn.addEventListener("click", function () {

    const groupName = prompt("Enter Group Name");

    if (!groupName || groupName.trim() === "")
        return;

    const card = document.createElement("div");

    card.className = "group-card";

    card.innerHTML = `
        <h3>${groupName}</h3>
        <p>1 Member</p>
        <p>New Community</p>
        <button class="btn-primary">Open Group</button>
    `;

    myGroups.appendChild(card);

});


// ==========================
// Join Group
// ==========================

document.querySelectorAll(".btn-secondary").forEach(btn => {

    if (btn.textContent.trim() === "Join Group") {

        btn.addEventListener("click", function () {

            this.innerHTML = "Joined";
            this.disabled = true;

        });

    }

});


// ==========================
// Invite Players
// ==========================

const inviteInput = searchBoxes[2];

const inviteBtn = document.querySelector(".invite-card .btn-primary");

inviteBtn.addEventListener("click", function () {

    const player = inviteInput.value.trim();

    if (player === "") {
        alert("Enter player name");
        return;
    }

    const found = players.find(p =>
        p.toLowerCase() === player.toLowerCase()
    );

    if (found) {
        alert("Invitation sent to " + found);
    } else {
        alert("Player not found");
    }

});


const resultBox = document.getElementById("playerResults");

document.getElementById("findPlayerBtn").addEventListener("click",function(){

    const keyword = playerSearch.value.trim().toLowerCase();

    resultBox.innerHTML = "";

    const foundPlayers = players.filter(player =>
        player.name.toLowerCase().includes(keyword)
    );

    if(foundPlayers.length===0){

        resultBox.innerHTML = `
            <div class="not-found">
                No player found.
            </div>
        `;

        return;
    }

    foundPlayers.forEach(player=>{

        resultBox.innerHTML += `
            <div class="player-card">

                <div class="player-info">

                    <img src="${player.image}" class="player-avatar">

                    <div>

                        <h4>${player.name}</h4>

                        <p class="player-status">${player.status}</p>

                    </div>

                </div>

                <button class="btn-primary">
                    Invite
                </button>

            </div>
        `;

    });

});

const groupInput = document.getElementById("groupSearch");
const groupResult = document.getElementById("groupResults");
const searchGroupBtn = document.getElementById("searchGroupBtn");

searchGroupBtn.addEventListener("click", function(){

    const keyword = groupInput.value.trim().toLowerCase();

    groupResult.innerHTML = "";

    const foundGroups = groups.filter(group =>
        group.name.toLowerCase().includes(keyword)
    );

    if(foundGroups.length === 0){

        groupResult.innerHTML = `
            <div class="no-group">
                No group found.
            </div>
        `;

        return;
    }

    foundGroups.forEach(group=>{

        groupResult.innerHTML += `

            <div class="group-search-card">

                <div class="group-info">

                    <h3>${group.name}</h3>

                    <p>${group.members}</p>

                    <p>${group.type}</p>

                </div>

                <button class="btn-primary">
                    Open Group
                </button>

            </div>

        `;

    });

});

function openGroup(groupName){
    window.location.href=`group_chat.html?group=${encodeURIComponent(groupName)}`
}