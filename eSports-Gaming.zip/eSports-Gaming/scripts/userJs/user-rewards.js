const withdrawBtn = document.getElementById("withdrawBtn");
const withdrawModal = document.getElementById("withdrawModal");
const closeWithdraw = document.getElementById("closeWithdraw");
const withdrawForm = document.getElementById("withdrawForm");
const error = document.getElementById("withdrawError");

withdrawBtn.addEventListener("click", () => {
    withdrawModal.style.display = "flex";
});

closeWithdraw.addEventListener("click", () => {
    withdrawModal.style.display = "none";
});

withdrawForm.addEventListener("submit", function(e){

    e.preventDefault();

    error.textContent = "";

    const name = document.getElementById("accountName").value.trim();
    const account = document.getElementById("accountNumber").value.trim();
    const ifsc = document.getElementById("ifsc").value.trim();
    const amount = document.getElementById("withdrawAmount").value.trim();

    if(name.length < 3){
        error.textContent = "Enter account holder name.";
        return;
    }

    if(!/^\d{9,18}$/.test(account)){
        error.textContent = "Enter a valid account number.";
        return;
    }

    if(!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc)){
        error.textContent = "Enter a valid IFSC code.";
        return;
    }

    if(amount === "" || Number(amount) <= 0){
        error.textContent = "Enter a valid amount.";
        return;
    }

    withdrawModal.style.display = "none";

    alert("Withdrawal request submitted successfully.\nAmount: ₹" + amount + "\nStatus: Processing");
});



function claimReward() {
    const btn = document.getElementById("claimBtn");

    btn.textContent = "Claimed";
    btn.disabled = true;          // Optional: prevent further clicks
  
    btn.style.color = "white";
    
    btn.style.background="linear-gradient(90deg, #7c3aed, #9333ea)";

}

function redeemReward(){
    const rewardBtn = document.getElementById("rewardBtn");
    rewardBtn.textContent = "Redeemed";
    rewardBtn.disabled = true;
    rewardBtn.style.color="white";
    rewardBtn.style.background="linear-gradient()"
}

function redeemReward1(){
    const rewardBtn1 = document.getElementById("rewardBtn1");
    rewardBtn1.textContent = "Redeemed";
    rewardBtn1.disabled = true;
    rewardBtn1.style.color="white";
    rewardBtn1.style.background="linear-gradient()"
}

function redeemReward2(){
    const rewardBtn2 = document.getElementById("rewardBtn2");
    rewardBtn2.textContent = "Redeemed";
    rewardBtn2.disabled = true;
    rewardBtn2.style.color="white";
    rewardBtn2.style.background="linear-gradient()"
}
