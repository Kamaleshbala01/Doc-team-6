document.addEventListener("DOMContentLoaded", () => {

    const modalHTML = `
    <div id="editProfileModal" class="profile-modal">

        <div class="modal-content">

            <span class="close-modal">&times;</span>

            <h2>Edit Profile</h2>

            <form id="editProfileForm">

                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" id="editName">
                </div>

                <div class="form-group">
                    <label>Professional Title</label>
                    <input type="text" id="editTitle">
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="email" id="editEmail">
                </div>

                <div class="form-group">
                    <label>Mobile Number</label>
                    <input type="text" id="editMobile">
                </div>

                <div class="form-group">
                    <label>Location</label>
                    <input type="text" id="editLocation">
                </div>

                <div class="form-group">
                    <label>Favorite Games</label>
                    <textarea id="editGames"></textarea>
                </div>

                <div class="form-group">
                    <label>Preferred Role</label>
                    <input type="text" id="editRole">
                </div>

                <div class="form-group">
                    <label>Experience</label>
                    <input type="text" id="editExperience">
                </div>

                <div class="form-group">
                    <label>Platform</label>
                    <input type="text" id="editPlatform">
                </div>

                <div class="modal-buttons">
                    <button type="submit" class="save-btn">
                        Save Changes
                    </button>

                    <button type="button" class="cancel-btn">
                        Cancel
                    </button>
                </div>

            </form>

        </div>

    </div>
    `;

    document.body.insertAdjacentHTML("beforeend", modalHTML);

    const editBtn = document.getElementById("editProfileBtn");
    const modal = document.getElementById("editProfileModal");
    const closeBtn = document.querySelector(".close-modal");
    const cancelBtn = document.querySelector(".cancel-btn");
    const form = document.getElementById("editProfileForm");

    // Open Modal
    editBtn.addEventListener("click", () => {

        document.body.style.overflow = "hidden";

        document.getElementById("editName").value =
            document.querySelector(".profile-right h2").childNodes[0].textContent.trim();

        document.getElementById("editTitle").value =
            document.querySelector(".profile-right p").textContent.trim();

        document.getElementById("editEmail").value =
            document.querySelector(".profile-info div:nth-child(1) span").textContent.trim();

        document.getElementById("editMobile").value =
            document.querySelector(".profile-info div:nth-child(2) span").textContent.trim();

        document.getElementById("editLocation").value =
            document.querySelector(".profile-info div:nth-child(3) span").textContent.trim();

        document.getElementById("editGames").value =
            Array.from(
                document.querySelectorAll(".info-card:nth-child(1) p")
            )
            .map(game => game.textContent)
            .join(", ");

        document.getElementById("editRole").value =
            document.querySelector(".info-card:nth-child(2) p").textContent.trim();

        document.getElementById("editExperience").value =
            document.querySelector(".info-card:nth-child(3) p").textContent.trim();

        document.getElementById("editPlatform").value =
            document.querySelector(".info-card:nth-child(4) p").textContent.trim();

        modal.style.display = "flex";
    });

    function closeModal() {
        modal.style.display = "none";
        document.body.style.overflow = "auto";
    }

    closeBtn.addEventListener("click", closeModal);

    cancelBtn.addEventListener("click", closeModal);

    window.addEventListener("click", (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });

    // Save Profile
    form.addEventListener("submit", (e) => {

        e.preventDefault();

        const name =
            document.getElementById("editName").value;

        document.querySelector(".profile-right h2").childNodes[0].textContent =
            name + " ";

        document.querySelector(".profile-right p").textContent =
            document.getElementById("editTitle").value;

        document.querySelector(".profile-info div:nth-child(1) span").textContent =
            document.getElementById("editEmail").value;

        document.querySelector(".profile-info div:nth-child(2) span").textContent =
            document.getElementById("editMobile").value;

        document.querySelector(".profile-info div:nth-child(3) span").textContent =
            document.getElementById("editLocation").value;

        const games =
            document.getElementById("editGames").value
            .split(",");

        const gameCard =
            document.querySelector(".info-card:nth-child(1)");

        gameCard.innerHTML = "<h3>Favorite Games</h3>";

        games.forEach(game => {
            gameCard.innerHTML += `<p>${game.trim()}</p>`;
        });

        document.querySelector(".info-card:nth-child(2) p").textContent =
            document.getElementById("editRole").value;

        document.querySelector(".info-card:nth-child(3) p").textContent =
            document.getElementById("editExperience").value;

        document.querySelector(".info-card:nth-child(4) p").textContent =
            document.getElementById("editPlatform").value;

        closeModal();

        alert("✅ Profile Updated Successfully");
    });

});