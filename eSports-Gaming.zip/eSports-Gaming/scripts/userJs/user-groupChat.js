const params = new URLSearchParams(window.location.search);

const group = params.get("group");

document.getElementById("groupName").textContent = group;

const chatBox = document.getElementById("chatBox");

const chats = {

"BGMI Warriors":[

{
user:"ShadowX",
msg:"Welcome everyone!"
},

{
user:"Nandha",
msg:"Ready for tonight's match?"
},

{
user:"Blaze",
msg:"Let's win this tournament 🔥"
}

],

"Valorant Elite":[

{
user:"Nova",
msg:"Scrims at 8 PM."
},

{
user:"Alpha",
msg:"Everyone join voice chat."
},

{
user:"Nandha",
msg:"Coming in 10 mins."
}

]

};

function loadChat(){

chatBox.innerHTML="";

(chats[group]||[]).forEach(chat=>{

chatBox.innerHTML+=`

<div class="message">

<strong>${chat.user}</strong>

<p>${chat.msg}</p>

</div>

`;

});

chatBox.scrollTop=chatBox.scrollHeight;

}

loadChat();

document.getElementById("sendBtn").onclick=function(){

const input=document.getElementById("message");

if(input.value.trim()=="") return;

chatBox.innerHTML+=`

<div class="message own">

<strong>You</strong>

<p>${input.value}</p>

</div>

`;

input.value="";

chatBox.scrollTop=chatBox.scrollHeight;

};
