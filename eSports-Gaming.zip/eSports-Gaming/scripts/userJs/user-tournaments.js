
// ======================================
// Fake Tournament Database
// ======================================

const tournaments=[

{
name:"BGMI Squad Clash",
game:"BGMI",
prize:"₹75,000",
date:"1 August"
},

{
name:"Free Fire Championship",
game:"Free Fire MAX",
prize:"₹1,00,000",
date:"25 July"
},

{
name:"COD Mobile Cup",
game:"COD Mobile",
prize:"₹50,000",
date:"28 July"
},

{
name:"Valorant Masters",
game:"Valorant",
prize:"₹80,000",
date:"18 July"
}

];

// ======================================
// Tournament Search
// ======================================
const searchInput = document.getElementById("tournamentSearch");
const cards = document.querySelectorAll(".game-card");
const suggestionsBox = document.getElementById("searchSuggestions");

searchInput.addEventListener("keyup", function () {

    const keyword = this.value.toLowerCase();
    suggestionsBox.innerHTML = "";

    cards.forEach(card => {

        const title = card.querySelector("h3").textContent;

        if (title.toLowerCase().includes(keyword)) {

            card.style.display = "block";

            // Create suggestion
            const suggestion = document.createElement("div");
            suggestion.classList.add("suggestion-item");
            suggestion.textContent = title;

            suggestion.addEventListener("click", () => {
                searchInput.value = title;
                suggestionsBox.style.display = "none";
            });

            suggestionsBox.appendChild(suggestion);

        } else {
            card.style.display = "none";
        }
    });

    suggestionsBox.style.display =
        suggestionsBox.children.length > 0 &&
        keyword !== ""
            ? "block"
            : "none";
});


// ======================================
// Game Filter
// ======================================

const filter=document.getElementById("gameFilter");

filter.addEventListener("change",function(){

const selected=this.value;

cards.forEach(card=>{

const game=card.querySelector("h3").textContent;

if(selected==="All Games"){

card.style.display="block";

return;

}

if(game.includes(selected.replace(" MAX","")))

card.style.display="block";

else

card.style.display="none";

});

});


// ======================================
// Browse Games
// ======================================

document.getElementById("browseGames").addEventListener("click",function(){

const games=tournaments.map(t=>t.game);

const unique=[...new Set(games)];

showToast("Games Available : "+unique.join(", "));

});


// ======================================
// Register Tournament
// ======================================

// const registerButtons=document.querySelectorAll(".registerBtn");

// const currentGrid=document.getElementById("currentTournamentGrid");

// registerButtons.forEach(button=>{

// button.addEventListener("click",function(){

// const card=this.closest(".game-card");

// const title=card.querySelector("h3").textContent;

// const info=card.querySelectorAll("p");

// const clone=card.cloneNode(true);

// clone.querySelector("button").innerHTML="View Match";

// clone.querySelector("button").className="btn-secondary";

// currentGrid.appendChild(clone);

// this.innerHTML="Registered ✓";

// this.disabled=true;

// showToast(title+" Registered Successfully");

// });

// });


// ======================================
// Toast
// ======================================

function showToast(message){

const toast=document.getElementById("toast");

toast.innerHTML=message;

toast.style.display="block";

setTimeout(()=>{

toast.style.display="none";

},2500);

}

// =======================================
// Tournament Modal
// =======================================

const modal=document.getElementById("tournamentModal");

const modalBody=document.getElementById("modalBody");

const close=document.querySelector(".close-modal");

close.onclick=()=>{

modal.style.display="none";

}

window.onclick=function(e){

if(e.target===modal)

modal.style.display="none";

}

// =======================================
// View Match
// =======================================

document.addEventListener("click",function(e){

if(e.target.innerText==="View Match"){

const tournament=e.target.parentElement.querySelector("h3").innerText;

modal.style.display="block";

modalBody.innerHTML=`

<h2>${tournament}</h2>

<table>

<tr>

<td>Round</td>

<td>Quarter Finals</td>

</tr>

<tr>

<td>Map</td>

<td>Erangel</td>

</tr>

<tr>

<td>Your Team</td>

<td>Alpha Squad</td>

</tr>

<tr>

<td>Kills</td>

<td>11</td>

</tr>

<tr>

<td>Current Rank</td>

<td>#3</td>

</tr>

<tr>

<td>Status</td>

<td style="color:#22C55E;">LIVE</td>

</tr>

</table>

<div class="leaderboard">

<h3>Current Leaderboard</h3>

<ol>

<li>Shadow Clan - 98 pts</li>

<li>Nova Esports - 91 pts</li>

<li>Alpha Squad - 88 pts</li>

<li>Team Blaze - 82 pts</li>

</ol>

</div>

`;

}

});


// =======================================
// Tournament Details
// =======================================

document.addEventListener("click",function(e){

if(e.target.innerText==="Tournament Details"){

const tournament=e.target.parentElement.querySelector("h3").innerText;

modal.style.display="block";

modalBody.innerHTML=`

<h2>${tournament}</h2>

<table>

<tr><td>Game</td><td>Valorant</td></tr>

<tr><td>Prize Pool</td><td>₹80,000</td></tr>

<tr><td>Entry Fee</td><td>Free</td></tr>

<tr><td>Team Size</td><td>5 Players</td></tr>

<tr><td>Registration Ends</td><td>20 July</td></tr>

<tr><td>Tournament Starts</td><td>22 July</td></tr>

<tr><td>Rules</td><td>Single Elimination</td></tr>

</table>

`;

}

});
// =======================================
// Watch Live
// =======================================

let viewers=25000;

document.addEventListener("click",function(e){

if(e.target.innerText==="Watch Live"){

const tournament=e.target.parentElement.querySelector("h3").innerText;

modal.style.display="block";

modalBody.innerHTML=`

<h2>

<span class="live-dot">🔴</span>

${tournament}

</h2>

<div class="live-counter">

Watching :

<span id="viewerCount">

${viewers}

</span>

</div>

<h3>Live Commentary</h3>

<p>

Alpha Squad has taken control of the zone.

Shadow Clan secures another elimination.

Only 5 teams remaining.

</p>

<div class="leaderboard">

<h3>Live Leaderboard</h3>

<ol>

<li>Shadow Clan</li>

<li>Alpha Squad</li>

<li>Nova Esports</li>

<li>Warriors Gaming</li>

</ol>

</div>

`;

const counter=document.getElementById("viewerCount");

const interval=setInterval(()=>{

if(modal.style.display==="none"){

clearInterval(interval);

return;

}

viewers+=Math.floor(Math.random()*15);

counter.innerHTML=viewers.toLocaleString();

},2000);

}

});

// ===========================
// Register Tournament
// ===========================

const registerButtons = document.querySelectorAll(".registerBtn");

registerButtons.forEach(button => {

    button.addEventListener("click", function () {

        const card = this.closest(".game-card");

        const tournament = {
            title: card.querySelector("h3").innerText,
            image: card.querySelector("img").src,
            info1: card.querySelectorAll("p")[0].innerText,
            info2: card.querySelectorAll("p")[1].innerText
        };

        let registered = JSON.parse(localStorage.getItem("registeredTournaments")) || [];

        const exists = registered.some(t => t.title === tournament.title);

        if (!exists) {

            registered.push(tournament);

            localStorage.setItem(
                "registeredTournaments",
                JSON.stringify(registered)
            );

            loadRegisteredTournaments();

            this.innerHTML = "Registered ✓";
            this.disabled = true;

            showToast("Tournament Registered Successfully");

        }

    });

});



// ===========================
// Load Registered
// ===========================

function loadRegisteredTournaments(){

const currentGrid=document.getElementById("currentTournamentGrid");

const registered=JSON.parse(localStorage.getItem("registeredTournaments"))||[];

registered.forEach(t=>{

if(currentGrid.innerHTML.includes(t.title))
return;

currentGrid.innerHTML+=`

<div class="game-card">

<img src="${t.image}">

<h3>${t.title}</h3>

<p>${t.info1}</p>

<p>${t.info2}</p>

<button class="btn-secondary">

View Match

</button>

</div>

`;

});

}

loadRegisteredTournaments();



// ===========================
// Countdown
// ===========================

const countdowns=document.querySelectorAll(".countdown");

setInterval(()=>{

countdowns.forEach(box=>{

const end=new Date(box.dataset.date);

const now=new Date();

const diff=end-now;

if(diff<=0){

box.innerHTML="Registration Closed";

return;

}

const days=Math.floor(diff/(1000*60*60*24));

const hours=Math.floor(diff/(1000*60*60)%24);

const mins=Math.floor(diff/(1000*60)%60);

box.innerHTML=`Ends in ${days}d ${hours}h ${mins}m`;

});

},1000);



// ===========================
// Suggestions
// ===========================

// const suggestionBox=document.getElementById("searchSuggestions");

// searchInput.addEventListener("keyup",function(){

// const keyword=this.value.toLowerCase();

// suggestionBox.innerHTML="";

// if(keyword==="") return;

// const results=tournaments.filter(t=>

// t.name.toLowerCase().includes(keyword)

// );

// results.forEach(t=>{

// suggestionBox.innerHTML+=`

// <div class="suggestion">

// ${t.name}

// </div>

// `;

// });

// });

// suggestionBox.addEventListener("click",function(e){

// if(e.target.classList.contains("suggestion")){

// searchInput.value=e.target.innerText;

// suggestionBox.innerHTML="";

// searchInput.dispatchEvent(new Event("keyup"));

// }

// });


// ===========================
// Suggestions
// ===========================

const suggestionBox=document.getElementById("searchSuggestions");

searchInput.addEventListener("keyup",function(){

const keyword=this.value.toLowerCase();

suggestionBox.innerHTML="";

if(keyword==="") return;

const results=tournaments.filter(t=>

t.name.toLowerCase().includes(keyword)

);

results.forEach(t=>{

suggestionBox.innerHTML+=`

<div class="suggestion">

${t.name}

</div>

`;

});

});

suggestionBox.addEventListener("click",function(e){

if(e.target.classList.contains("suggestion")){

searchInput.value=e.target.innerText;

suggestionBox.innerHTML="";

searchInput.dispatchEvent(new Event("keyup"));

}

});

// ===========================
// Notifications
// ===========================

const notifications=[

"🔥 ShadowX joined BGMI Squad Clash",

"🏆 Alpha Squad won BGMI Finals",

"🎮 Registration opened for Valorant Masters",

"💰 Prize Pool increased to ₹2,00,000",

"⭐ Nova became Tournament MVP"

];

const notify=document.getElementById("notification");

setInterval(()=>{

const random=

notifications[Math.floor(Math.random()*notifications.length)];

notify.innerHTML=random;

notify.style.display="block";

setTimeout(()=>{

notify.style.display="none";

},4000);

},15000);




// ===================================
// Statistics Counter
// ===================================

function updateStatistics(){

const registered=JSON.parse(localStorage.getItem("registeredTournaments"))||[];

document.getElementById("registeredCount").innerHTML=registered.length;

}

updateStatistics();


const sort=document.getElementById("sortHistory");

const table=document.querySelector(".history-table tbody");

sort.addEventListener("change",()=>{

const rows=[...table.querySelectorAll("tr")];

rows.sort((a,b)=>{

const type=sort.value;

if(type==="game"){

return a.cells[1].innerText.localeCompare(b.cells[1].innerText);

}

if(type==="rank"){

return parseInt(a.cells[2].innerText.replace("#",""))-

parseInt(b.cells[2].innerText.replace("#",""));

}

if(type==="prize"){

const prizeA=parseInt(a.cells[3].innerText.replace(/[₹,]/g,""));

const prizeB=parseInt(b.cells[3].innerText.replace(/[₹,]/g,""));

return prizeB-prizeA;

}

return 0;

});

table.innerHTML="";

rows.forEach(r=>table.appendChild(r));

});

const feed=document.getElementById("activityFeed");

const activities=[

"🏆 You registered for BGMI Squad Clash",

"🔥 Shadow Clan won BGMI Finals",

"🎮 Valorant Masters starts tomorrow",

"⭐ You moved to Rank #14",

"💰 Prize Pool increased to ₹5,00,000"

];

activities.forEach(item=>{

feed.innerHTML+=`

<div class="activity-card">

${item}

</div>

`;

});

function showToast(message){

const toast=document.getElementById("toast");

toast.innerHTML=message;

toast.style.display="block";

toast.style.opacity="1";

toast.style.transform="translateY(0)";

setTimeout(()=>{

toast.style.opacity="0";

toast.style.transform="translateY(-20px)";

setTimeout(()=>{

toast.style.display="none";

},300);

},2500);

}

const updates=[

"🔥 Shadow Clan knocked Team Alpha",

"🎯 Nova Esports secured Chicken Dinner",

"⚡ Zone 6 has started",

"🏆 Warriors reached Finals",

"💥 5 squads remaining"

];

const live=document.getElementById("liveUpdates");

setInterval(()=>{

const random=

updates[Math.floor(Math.random()*updates.length)];

live.innerHTML=`

<div class="activity">

${random}

</div>

`;

},6000);


setInterval(()=>{

viewers+=Math.floor(Math.random()*20);

const viewer=document.getElementById("viewerCount");

if(viewer)

viewer.innerHTML=viewers.toLocaleString();

},2000);
