
function exportMain(){

const sections = [
document.getElementById("section1"),
document.getElementById("section2"),
document.getElementById("section3"),
document.getElementById("section4"),
document.getElementById("section5")];

const printContainer = document.createElement("div");
printContainer.style.width = "100%";
printContainer.style.display="block";

sections.forEach(sec=>{
const clone = sec.cloneNode(true);

clone.style.display="block";
clone.style.width="100%";
//clone.style.marginBottom="20px";
clone.style.float="none";
clone.style.position="static";

printContainer.appendChild(clone);
});

const opt = {
margin: 10,
filename: "report_analytics.pdf",
html2canvas:{scale:2},
jsPDF:{unit:"mm",format:"a4",orientation:"portrait"}
};
html2pdf().from(printContainer).set(opt).save();
}