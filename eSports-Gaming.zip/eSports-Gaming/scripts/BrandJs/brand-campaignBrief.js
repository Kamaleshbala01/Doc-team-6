/*=========================================
    CAMPAIGN BRIEF PAGE
=========================================*/

document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("briefForm");

    const objective = document.getElementById("objective");
    const description = document.getElementById("description");
    const guidelines = document.getElementById("guidelines");
    const dos = document.getElementById("dos");
    const donts = document.getElementById("donts");
    const deadline = document.getElementById("deadline");
    const assets = document.getElementById("assets");

    const checkboxes =
        document.querySelectorAll(".checkbox-item input");

    /*=========================
        FILE PREVIEW
    =========================*/

    assets.addEventListener("change", () => {

        if (assets.files.length > 0) {

            let names = [];

            for (let file of assets.files) {

                names.push(file.name);

            }

            alert("Selected Files:\n\n" + names.join("\n"));

        }

    });

    /*=========================
        FORM SUBMIT
    =========================*/

    form.addEventListener("submit", function(e){

        e.preventDefault();
        window.location.href = "budgetPayment.html" ;

        if(objective.value===""){

            alert("Please select Campaign Objective.");

            objective.focus();

            return;

        }

        if(description.value.trim()===""){

            alert("Please enter Campaign Description.");

            description.focus();

            return;

        }

        /*=====================
        DELIVERABLE VALIDATION
        =====================*/

        let selected=false;

        checkboxes.forEach(box=>{

            if(box.checked){

                selected=true;

            }

        });

        if(!selected){

            alert("Please select at least one Deliverable.");

            return;

        }

        /*=====================
        BRAND GUIDELINES
        =====================*/

        if(guidelines.value.trim()===""){

            alert("Please enter Brand Guidelines.");

            guidelines.focus();

            return;

        }

        if(dos.value.trim()===""){

            alert("Please enter Do's.");

            dos.focus();

            return;

        }

        if(donts.value.trim()===""){

            alert("Please enter Don'ts.");

            donts.focus();

            return;

        }

        /*=====================
        DEADLINE
        =====================*/

        if(deadline.value===""){

            alert("Please choose Submission Deadline.");

            deadline.focus();

            return;

        }

        const today=new Date();

        const selectedDate=new Date(deadline.value);

        today.setHours(0,0,0,0);

        if(selectedDate<today){

            alert("Deadline cannot be in the past.");

            return;

        }

        /*=====================
        SUCCESS
        =====================*/

        alert("Campaign Brief Saved Successfully!");

        window.location.href="budgetPayment.html";

    });

});