const pages = [
{name : "Home - Dashboard", url: "brand_dashboard.html"},
{name : "Find Influencers", url:"#"},
{name : "Campaigns", url:"#"},
{name : "Tournaments", url:"#"},
{name : "Payments", url:"#"},
{name : "ROI Analytics", url:"brand_analytics_ROI.html"},
{name : "Messages", url:"brand_messages.html"},
{name : "Help and Support", url:"#"},
{name : "Settings", url:"#"}];

const search = document.getElementById("search");
const results = document.getElementById("results");

search.addEventListener("input",()=>{
const value = search.value.toLowerCase().trim();
results.innerHTML="";
if (!value) return;
const filtered = pages.filter(p=>p.name.toLowerCase().includes(value));

filtered.forEach(p=>{
const li = document.createElement("li");
li.textContent = p.name;

li.addEventListener("click",()=>{
window.location.href = p.url;
});
results.appendChild(li);
});
});


function dataNotFound(){
window.alert("Data not found");
}

const notifyBtn = document.getElementById("notifBtn");
const popup = document.getElementById("popup");
const btnClose = document.getElementById("closeBtn");

notifyBtn.addEventListener("click",()=>{
popup.classList.remove("hidden");
console.log("Popup shown");
});

closeBtn.addEventListener("click",()=>{
popup.classList.add("hidden");
});


