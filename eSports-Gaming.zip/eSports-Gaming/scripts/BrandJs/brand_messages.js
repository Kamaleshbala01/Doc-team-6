const chats = {
influencer:[],
PR_Rep:[],
Brand_PR_Group:[],
Marketing:[],
Project_X:[],
Admin:[],
Consumer_1839:[]}

let currentChat = "influencer";
const chatMessages = document.getElementById("chatMessages");
const messageInput = document.getElementById("messageInput");
const sendButton = document.getElementById("sendBtn");
const emojiBtn = document.getElementById("emojiBtn");
const modal = document.getElementById("emojiModal");

emojiBtn.addEventListener("click",()=>{
modal.classList.toggle("hidden");
});

document.querySelectorAll(".emoji").forEach(e=>{
e.addEventListener("click",()=>
{
messageInput.value+=e.textContent;
});
});

document.addEventListener("click",(e)=>{
if (!modal.contains(e.target) && e.target!=emojiBtn)
{
modal.classList.add("hidden");
}
});

function renderMessages(){
chatMessages.innerHTML = "";
const chat = chats[currentChat];
for (const message of chat){
const bubble = document.createElement("div");
bubble.classList.add("message");
bubble.classList.add(message.author);

bubble.textContent = message.text;
if (message.author==="me"){
bubble.className = "msg right";
}
else{
bubble.className = "msg left";
}
chatMessages.appendChild(bubble);
}
chatMessages.scrollTop = chatMessages.scrollHeight;
}


function sendMessages(text){

chats[currentChat].push({
id:Date.now(),
author:"me",
text:text,
timestamp: new Date()
});

renderMessages();

chats[currentChat].push({
id:Date.now()+1,
author:"Other",
text:"Live Chat is under construction"});
renderMessages();

}

function receiveMessage(text){
chats[currentChat].push({
id:Date.now(),
author:"Other",
text:text,
timestamp: new Date()
});
renderMessages();

}

sendButton.addEventListener("click",()=>{
const text = messageInput.value.trim();
if (text=="") return;
sendMessages(text);
messageInput.value="";
messageInput.focus();
});

messageInput.addEventListener("keydown",(event)=>{
if (event.key=="Enter"){
event.preventDefault();
sendButton.click();
}
});

receiveMessage("Hello");

document.querySelectorAll(".chat-item").forEach(item=>{
item.addEventListener("click",(e)=>{

const item = e.target.closest(".chat-item");
if(!item) return;
const chatId = item.dataset.chat;
console.log("Chatid:",chatId);
currentChat = chatId;

document.getElementById("chatHeader").textContent = item.textContent.trim();

if (!chats[currentChat])
{
chats[currentChat] = [];
}
updateSideBarActive(chatId);
renderMessages();

});
});

function updateSideBarActive(chatId){
console.log("UPDATING ACTIVE SIDEBAR TO:",chatId);
document.querySelectorAll(".chat-item").forEach(item=>{
item.classList.remove("active");
if (item.dataset.chat===chatId)
{
item.classList.add("active");
}
});
}

modalElement = document.getElementById("chatModal");
searchedUser = document.getElementById("searchUser");

document.getElementById("closeModal").addEventListener("click",()=>
{
modalElement.classList.add("chatModal-hidden");
searchedUser.value = "";
});

function openChatterWindow()
{
//console.log("Btn Pressed");
modalElement.classList.remove("chatModal-hidden");
}

function addChatter(){
console.log("Chat Added");
const container = document.getElementById("chat-items");
const textValue = searchedUser.value.trim();
if (textValue!==""){
const newDiv = document.createElement("div");
newDiv.className = "chat-item";
newDiv.setAttribute('data-chat',textValue);
newDiv.textContent = textValue;
addingChat(newDiv);
container.appendChild(newDiv);
searchedUser.value = "";
}
else{
window.alert("Chat ID is empty");
}
}


function addingChat(item){
item.addEventListener("click",(e)=>{
const item = e.target.closest(".chat-item");
if(!item) return;
const chatId = item.dataset.chat;
console.log("Chatid:",chatId);
currentChat = chatId;
document.getElementById("chatHeader").textContent = item.textContent.trim();
if (!chats[currentChat])
{
chats[currentChat] = [];
}
updateSideBarActive(chatId);
renderMessages();
});
}


document.addEventListener("DOMContentLoaded",()=>
{
modalElement.classList.add("chatModal-hidden");
});

