// ===============================
// TOURNAMENT SEARCH & FILTER
// ===============================

let selectedTournament = "";

let selectedButton = null;

let selectedCard = null;

const paymentModal =
document.getElementById("paymentModal");

document.querySelector(".close-payment").onclick=()=>{

paymentModal.style.display="none";

}

document.getElementById("payNow").addEventListener("click", () => {

    // 1. Get selected payment method
    const method = document.querySelector(
        'input[name="payment"]:checked'
    ).value;

    // 2. Close popup
    paymentModal.style.display = "none";

    // 3. Update Sponsor Button
    selectedButton.innerText = "Sponsored";
    selectedButton.classList.add("sponsored");
    selectedButton.style.background = "#22C55E";

    // 4. Update Budget
    budget -= sponsorCost;
    updateBudget();
    localStorage.setItem("budget", budget);

    // 5. SAVE PAYMENT ← Add Part 1 here
    let payments = JSON.parse(localStorage.getItem("payments")) || [];

    const payment = {

        id: "PAY-" + Date.now(),

        tournament: selectedTournament,

        amount: sponsorCost,

        method: method,

        status: "Success",

        invoice: "INV-" + Math.floor(Math.random() * 100000),

        date: new Date().toLocaleDateString()

    };

    payments.push(payment);

    localStorage.setItem("payments", JSON.stringify(payments));

    // 6. SAVE INVOICE ← Add Part 2 here
    let invoices = JSON.parse(localStorage.getItem("invoices")) || [];

    invoices.push({

        invoiceNo: payment.invoice,

        tournament: selectedTournament,

        amount: sponsorCost,

        status: "Paid",

        dueDate: new Date().toLocaleDateString()

    });

    localStorage.setItem("invoices", JSON.stringify(invoices));

    // 7. UPDATE WALLET ← Add Part 3 here
    let wallet =
        Number(localStorage.getItem("wallet")) || 325000;

    wallet -= sponsorCost;

    localStorage.setItem("wallet", wallet);

    // 8. UPDATE TOTAL SPENT ← Add Part 4 here
    let totalSpent =
        Number(localStorage.getItem("totalSpent")) || 2450000;

    totalSpent += sponsorCost;

    localStorage.setItem("totalSpent", totalSpent);

    // 9. Show Notification
    showNotification("Payment Successful via " + method);

});

document.addEventListener("DOMContentLoaded", () => {

    const searchInput = document.querySelector(".filter-bar input");
    const gameFilter = document.querySelectorAll(".filter-bar select")[0];
    const statusFilter = document.querySelectorAll(".filter-bar select")[1];

    const cards = document.querySelectorAll(".tournament-card");

    function filterTournament() {

        const searchValue = searchInput.value.toLowerCase();
        const selectedGame = gameFilter.value.toLowerCase();
        const selectedStatus = statusFilter.value.toLowerCase();

        cards.forEach(card => {

            const title = card.querySelector("h3").textContent.toLowerCase();

            const game = card.querySelector(".game-tag")
                             .textContent
                             .toLowerCase();

            const status = card.querySelector(".badge")
                               .textContent
                               .toLowerCase();

            const matchSearch =
                title.includes(searchValue);

            const matchGame =
                selectedGame === "game" ||
                game.includes(selectedGame);

            const matchStatus =
                selectedStatus === "status" ||
                status.includes(selectedStatus);

            if (matchSearch && matchGame && matchStatus) {

                card.style.display = "block";

            } else {

                card.style.display = "none";

            }

        });

    }

    searchInput.addEventListener("keyup", filterTournament);

    gameFilter.addEventListener("change", filterTournament);

    statusFilter.addEventListener("change", filterTournament);

});

// ===============================
// VIEW DETAILS MODAL
// ===============================

const modal = document.getElementById("detailsModal");

const closeBtn = document.querySelector(".close-modal");

const viewButtons = document.querySelectorAll(".secondary-btn");

viewButtons.forEach(button=>{

    if(button.textContent.trim()=="View Details"){

        button.addEventListener("click",function(){

            const card=this.closest(".tournament-card");

            document.getElementById("modalTitle").textContent=
            card.querySelector("h3").textContent;

            document.getElementById("modalOrganizer").textContent=
            card.querySelector("p").textContent.replace("Organizer : ","");

            document.getElementById("modalPrize").textContent=
            card.querySelectorAll(".card-stats h4")[0].textContent;

            document.getElementById("modalAudience").textContent=
            card.querySelectorAll(".card-stats h4")[1].textContent;

            document.getElementById("modalTeams").textContent=
            card.querySelectorAll(".card-stats h4")[2].textContent;

            document.getElementById("modalSlots").textContent=
            card.querySelectorAll(".card-stats h4")[3].textContent;

            document.getElementById("modalStatus").textContent=
            card.querySelector(".badge").textContent;

            modal.style.display="flex";

        });

    }

});

closeBtn.onclick=function(){

modal.style.display="none";

}

window.onclick=function(event){

if(event.target==modal){

modal.style.display="none";

}

}
// ===============================
// SPONSOR TOURNAMENT
// ===============================

// Load sponsored tournaments from localStorage
let sponsoredTournaments =
    JSON.parse(localStorage.getItem("sponsoredTournaments")) || [];

// Get all sponsor buttons
const sponsorButtons = document.querySelectorAll(".primary-btn");

// Loop through buttons
sponsorButtons.forEach(button => {

    if (button.textContent.trim() === "Sponsor") {

        const card = button.closest(".tournament-card");
        const tournamentName = card.querySelector("h3").textContent;

        // Restore sponsored state after refresh
        if (sponsoredTournaments.includes(tournamentName)) {

            button.classList.add("sponsored")
            button.textContent = "Sponsored";
            button.style.background = "#22C55E";

        }

        button.addEventListener("click", () => {

    const tournamentName = card.querySelector("h3").textContent;
    const slot = card.querySelectorAll(".card-stats h4")[3];

    let slotValue = parseInt(slot.textContent);

    // Already Sponsored → Unsponsor
    if (button.classList.contains("sponsored")) {

        button.textContent = "Sponsor";
        button.classList.remove("sponsored");

        button.style.background = "";

        slot.textContent = slotValue + 1;

        budget += sponsorCost;

        updateBudget();

        localStorage.setItem("budget", budget);

        sponsoredTournaments = sponsoredTournaments.filter(
            item => item !== tournamentName
        );

        localStorage.setItem(
            "sponsoredTournaments",
            JSON.stringify(sponsoredTournaments)
        );

        showNotification("Sponsorship Cancelled");

        return;
    }

    // Sponsor
    if (confirm("Sponsor this tournament?")) {

        selectedTournament = tournamentName;

selectedButton = button;

selectedCard = card;

document.getElementById("payTournament").innerText =
tournamentName;

document.getElementById("payAmount").innerText =
sponsorCost.toLocaleString();

document.getElementById("paymentModal").style.display =
"flex";

        showNotification("Tournament Sponsored");

        // ===============================
// CREATE PAYMENT ENTRY
// ===============================

let payments =
JSON.parse(localStorage.getItem("payments")) || [];

// Random Payment ID
const paymentId =
"PAY" + Date.now();

// Invoice Number
const invoice =
"INV" + Math.floor(Math.random()*100000);

// Amount
const amount = sponsorCost;

// Current Date
const paymentDate =
new Date().toLocaleDateString();

// Payment Object
const payment = {

    paymentId: paymentId,

    invoice: invoice,

    tournament: tournamentName,

    amount: amount,

    method: "Sponsor",

    status: "Pending",

    date: paymentDate

};

payments.push(payment);

localStorage.setItem(
    "payments",
    JSON.stringify(payments)
);

    }

});

    }

});
// ===============================
// NOTIFICATION
// ===============================

function showNotification(message) {

    const notification = document.createElement("div");

    notification.className = "notification";

    notification.innerText = message;

    document.body.appendChild(notification);

    setTimeout(() => {

        notification.classList.add("show");

    }, 100);

    setTimeout(() => {

        notification.classList.remove("show");

        setTimeout(() => {

            notification.remove();

        }, 300);

    }, 3000);

}
// ===============================
// BUDGET MANAGEMENT
// ===============================

// Initial budget (₹8,00,000)
let budget = Number(localStorage.getItem("budget")) || 800000;

// Show budget on page
updateBudget();

// Update budget card
function updateBudget() {

    document.getElementById("budgetAmount").textContent =
        "₹" + budget.toLocaleString("en-IN");

}

// Sponsorship amount
const sponsorCost = 200000;

// Sponsor History
let sponsorHistory =
    JSON.parse(localStorage.getItem("sponsorHistory")) || [];

    console.log(

JSON.parse(

localStorage.getItem("sponsorHistory")

)

);

// ===============================
// SAVE TOURNAMENT
// ===============================

let savedTournaments =
JSON.parse(localStorage.getItem("savedTournaments")) || [];

const saveButtons =
document.querySelectorAll(".save-btn");

saveButtons.forEach(button=>{

const card=
button.closest(".tournament-card");

const tournament=
card.querySelector("h3").textContent;

// Restore saved state

if(savedTournaments.includes(tournament)){

button.textContent="♥ Saved";

button.classList.add("saved");

}

button.addEventListener("click",()=>{

if(savedTournaments.includes(tournament)){

savedTournaments=
savedTournaments.filter(item=>item!==tournament);

button.textContent="♡ Save";

button.classList.remove("saved");

showNotification("Removed from Saved");

}

else{

savedTournaments.push(tournament);

button.textContent="♥ Saved";

button.classList.add("saved");

showNotification("Tournament Saved");

}

localStorage.setItem(

"savedTournaments",

JSON.stringify(savedTournaments)

);

updateSavedPanel();

});

});


// ===============================
// UPDATE SAVED PANEL
// ===============================

function updateSavedPanel(){

const panel=document.getElementById("savedList");

panel.innerHTML="";

if(savedTournaments.length===0){

panel.innerHTML="<p>No Saved Tournaments</p>";

return;

}

savedTournaments.forEach(item=>{

const div=document.createElement("div");

div.className="saved-item";

div.innerHTML=`
<h4>${item}</h4>
`;

panel.appendChild(div);

});

}

updateSavedPanel();