// ======================================
// PAYMENT DASHBOARD
// ======================================

document.addEventListener("DOMContentLoaded", () => {

    loadPaymentHistory();

    loadInvoices();

    updateStatistics();

});

// ======================================
// LOAD PAYMENT HISTORY
// ======================================

function loadPaymentHistory() {

    const payments =
        JSON.parse(localStorage.getItem("payments")) || [];

    const tbody =
        document.querySelector("#paymentTableBody");

    if (!tbody) return;

    tbody.innerHTML = "";

    payments.forEach(payment => {

        const row = document.createElement("tr");

        row.innerHTML = `

        <td>${payment.id}</td>

        <td>${payment.tournament}</td>

        <td>₹${payment.amount.toLocaleString()}</td>

        <td>${payment.method}</td>

        <td>${payment.invoice}</td>

        <td>${payment.status}</td>

        <td>${payment.date}</td>

        `;

        tbody.appendChild(row);

    });

}

// ======================================
// LOAD INVOICE HISTORY
// ======================================

function loadInvoices() {

    const invoices =
        JSON.parse(localStorage.getItem("invoices")) || [];

    const tbody =
        document.querySelector("#invoiceTableBody");

    if (!tbody) return;

    tbody.innerHTML = "";

    invoices.forEach(invoice => {

        const row = document.createElement("tr");

        row.innerHTML = `

        <td>${invoice.invoiceNo}</td>

        <td>${invoice.tournament}</td>

        <td>₹${invoice.amount.toLocaleString()}</td>

        <td>${invoice.status}</td>

        <td>${invoice.dueDate}</td>

        `;

        tbody.appendChild(row);

    });

}

// ======================================
// UPDATE PAYMENT STATISTICS
// ======================================

function updateStatistics() {

    const payments =
        JSON.parse(localStorage.getItem("payments")) || [];

    const wallet =
        Number(localStorage.getItem("wallet")) || 325000;

    const totalSpent =
        Number(localStorage.getItem("totalSpent")) || 2450000;

    let pending = 0;
    let success = 0;

    payments.forEach(payment => {

        if (payment.status === "Pending") {

            pending++;

        }

        if (payment.status === "Success") {

            success++;

        }

    });

    // Wallet Balance
    const walletElement =
        document.getElementById("walletBalance");

    if (walletElement) {

        walletElement.textContent =
            "₹" + wallet.toLocaleString("en-IN");

    }

    // Total Spent
    const spentElement =
        document.getElementById("totalSpent");

    if (spentElement) {

        spentElement.textContent =
            "₹" + totalSpent.toLocaleString("en-IN");

    }

    // Pending Payments
    const pendingElement =
        document.getElementById("pendingPayments");

    if (pendingElement) {

        pendingElement.textContent = pending;

    }

    // Successful Payments
    const successElement =
        document.getElementById("successPayments");

    if (successElement) {

        successElement.textContent = success;

    }

}







const addMoneyBtn =
    document.getElementById("addMoneyBtn");

const moneyModal =
    document.getElementById("moneyModal");

const closeMoneyModal =
    document.getElementById("closeMoneyModal");

addMoneyBtn.addEventListener("click", () => {
    moneyModal.classList.add("active");
});

closeMoneyModal.addEventListener("click", () => {
    moneyModal.classList.remove("active");
});

moneyModal.addEventListener("click", (e) => {
    if (e.target === moneyModal) {
        moneyModal.classList.remove("active");
    }
});

document.getElementById("addMoneyForm").addEventListener("submit", function(e) {

    e.preventDefault();

    const totalAdded =
        document.getElementById("totalAddedInput").value;

    const totalSpent =
        document.getElementById("totalSpentInput").value;

    const pending =
        document.getElementById("pendingInput").value;

    document.getElementById("totalAddedValue").textContent =
        "₹" + Number(totalAdded).toLocaleString("en-IN");

    document.getElementById("totalSpentValue").textContent =
        "₹" + Number(totalSpent).toLocaleString("en-IN");

    document.getElementById("pendingValue").textContent =
        "₹" + Number(pending).toLocaleString("en-IN");

    document.getElementById("totalSpent").textContent =
        "₹" + Number(totalSpent).toLocaleString("en-IN");

    document.getElementById("pendingStat").textContent =
        "₹" + Number(pending).toLocaleString("en-IN");

    alert("Saved Successfully!");

    moneyModal.classList.remove("active");

    this.reset();
});
