
External Email: Be cautious while opening any links or attachments.
 
/*=========================================
        REVIEW & LAUNCH PAGE
=========================================*/

document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("reviewForm");

    const confirmLaunch =
        document.getElementById("confirmLaunch");

    const saveDraft =
        document.getElementById("saveDraft");

    const launchNotes =
        document.getElementById("launchNotes");

    /*=================================
            SAVE AS DRAFT
    =================================*/

    saveDraft.addEventListener("click", () => {

        localStorage.setItem(
            "campaignDraft",
            launchNotes.value
        );

        alert("Campaign saved as Draft successfully!");

    });

    /*=================================
            LOAD DRAFT
    =================================*/

    const savedDraft =
        localStorage.getItem("campaignDraft");

    if(savedDraft){

        launchNotes.value = savedDraft;

    }

    /*=================================
            LAUNCH CAMPAIGN
    =================================*/

    form.addEventListener("submit", function(e){

        e.preventDefault();

        if(!confirmLaunch.checked){

            alert(
                "Please confirm that you have reviewed all campaign details."
            );

            return;

        }

        /* Clear Draft */

        localStorage.removeItem("campaignDraft");

        alert(
            "🎉 Congratulations!\n\nYour Campaign has been launched successfully."
        );

        /* Redirect */

        window.location.href = "allCampaigns.html";

    });

});
