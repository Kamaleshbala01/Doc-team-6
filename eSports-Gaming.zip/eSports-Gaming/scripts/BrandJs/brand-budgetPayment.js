/*=========================================
      BUDGET & PAYMENT PAGE
=========================================*/

document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("budgetForm");

    const totalBudget = document.getElementById("totalBudget");
    const influencerCost = document.getElementById("influencerCost");
    const platformFee = document.getElementById("platformFee");
    const additionalExpense = document.getElementById("additionalExpense");
    const promoCode = document.getElementById("promoCode");
    const paymentMethod = document.getElementById("paymentMethod");
    const agreeTerms = document.getElementById("agreeTerms");

    const summaryBudget = document.getElementById("summaryBudget");
    const summaryInfluencer = document.getElementById("summaryInfluencer");
    const summaryFee = document.getElementById("summaryFee");
    const summaryExpense = document.getElementById("summaryExpense");
    const grandTotal = document.getElementById("grandTotal");

    /*=================================
        CALCULATE GRAND TOTAL
    =================================*/

    function updateSummary(){

        let budget = Number(totalBudget.value) || 0;
        let influencer = Number(influencerCost.value) || 0;
        let fee = Number(platformFee.value) || 0;
        let expense = Number(additionalExpense.value) || 0;

        let total = influencer + fee + expense;

        /* Promo Code */

        if(promoCode.value.trim().toUpperCase()==="ESPORT10"){

            total = total - (total * 0.10);

        }

        summaryBudget.textContent = "₹" + budget.toLocaleString();

        summaryInfluencer.textContent =
            "₹" + influencer.toLocaleString();

        summaryFee.textContent =
            "₹" + fee.toLocaleString();

        summaryExpense.textContent =
            "₹" + expense.toLocaleString();

        grandTotal.textContent =
            "₹" + Math.round(total).toLocaleString();

    }

    totalBudget.addEventListener("input",updateSummary);

    influencerCost.addEventListener("input",updateSummary);

    platformFee.addEventListener("input",updateSummary);

    additionalExpense.addEventListener("input",updateSummary);

    promoCode.addEventListener("input",updateSummary);

    updateSummary();

    /*=================================
            FORM VALIDATION
    =================================*/

    form.addEventListener("submit",function(e){

        e.preventDefault();

        if(totalBudget.value===""){

            alert("Please enter Total Campaign Budget.");

            totalBudget.focus();

            return;

        }

        if(influencerCost.value===""){

            alert("Please enter Influencer Cost.");

            influencerCost.focus();

            return;

        }

        if(paymentMethod.value===""){

            alert("Please select a Payment Method.");

            paymentMethod.focus();

            return;

        }

        if(!agreeTerms.checked){

            alert("Please accept Terms & Conditions.");

            return;

        }

        if(Number(influencerCost.value) >
           Number(totalBudget.value)){

            alert("Influencer cost cannot exceed Total Budget.");

            return;

        }

        alert("Budget & Payment Saved Successfully!");

        window.location.href="reviewLaunch.html";

    });

});
