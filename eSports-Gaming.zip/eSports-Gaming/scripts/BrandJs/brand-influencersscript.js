const influencers = [
  {
    name: "MortalGaming",
    username: "@mortalgaming",
    game: "BGMI",
    followers: "6.1M",
    engagement: "7.8%",
    views: "1.2M",
    price: "₹1,20,000",
    image: "https://via.placeholder.com/80"
  },
  {
    name: "Scout",
    username: "@scout",
    game: "BGMI",
    followers: "4.8M",
    engagement: "8.2%",
    views: "950K",
    price: "₹90,000",
    image: "https://via.placeholder.com/80"
  },
  {
    name: "Jonathan",
    username: "@jonathan",
    game: "BGMI",
    followers: "5.3M",
    engagement: "9.1%",
    views: "1.1M",
    price: "₹1,00,000",
    image: "https://via.placeholder.com/80"
  },
  {
    name: "Payal Gaming",
    username: "@payalgaming",
    game: "Free Fire",
    followers: "3.2M",
    engagement: "6.5%",
    views: "700K",
    price: "₹70,000",
    image: "https://via.placeholder.com/80"
  }
];

// =========================
// Select Cards Container
// =========================

const cardsContainer = document.querySelector(".cards");

// =========================
// Display Cards
// =========================

function displayCards(data){

    cardsContainer.innerHTML="";

    data.forEach((item)=>{

        cardsContainer.innerHTML += `
        <div class="card">

            <div class="left">

                <img src="${item.image}">

                <div>

                    <h2>${item.name}</h2>

                    <p>${item.username}</p>

                    <span>${item.game}</span>

                </div>

            </div>

            <div class="middle">

                <p>Followers</p>

                <h3>${item.followers}</h3>

            </div>

            <div class="middle">

                <p>Engagement</p>

                <h3>${item.engagement}</h3>

            </div>

            <div class="middle">

                <p>Views</p>

                <h3>${item.views}</h3>

            </div>

            <div class="right">

                <h2>${item.price}</h2>

                <button class="profileBtn">View Profile</button>

                <button class="shortBtn">Add Shortlist</button>

            </div>

        </div>
        `;

    });

    addEvents();

}

// =========================
// Load Cards
// =========================

displayCards(influencers);

// =========================
// Search Function
// =========================

const searchBox=document.querySelector(".search input");

searchBox.addEventListener("keyup",()=>{

let value=searchBox.value.toLowerCase();

let result=influencers.filter((item)=>{

return item.name.toLowerCase().includes(value)
||
item.game.toLowerCase().includes(value);

});

displayCards(result);

});

// =========================
// Button Events
// =========================

function addEvents(){

const profileBtns=document.querySelectorAll(".profileBtn");

const shortBtns=document.querySelectorAll(".shortBtn");

// View Profile

profileBtns.forEach((btn,index)=>{

btn.onclick=()=>{

alert(
"Opening Profile of "+influencers[index].name
);

};

});

// Shortlist

shortBtns.forEach((btn,index)=>{

btn.onclick=()=>{

let list=JSON.parse(
localStorage.getItem("shortlist")
)||[];

list.push(influencers[index]);

localStorage.setItem(
"shortlist",
JSON.stringify(list)
);

alert(
influencers[index].name+
" Added to Shortlist"
);

};

});

}

console.log("Dashboard Loaded Successfully");