/* ==========================================
   SELECT INFLUENCERS PAGE
   Premium Esports Dashboard
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const searchInput = document.getElementById("searchInput");
    const cards = document.querySelectorAll(".influencer-card");
    const buttons = document.querySelectorAll(".select-btn");
    const selectedCount = document.getElementById("selectedCount");
    const selectedList = document.getElementById("selectedList");

    let selectedInfluencers = [];

    /* -----------------------------
       SEARCH FUNCTION
    ----------------------------- */

    searchInput.addEventListener("keyup", function () {

        const value = this.value.toLowerCase();

        cards.forEach(card => {

            const name = card.querySelector("h3").textContent.toLowerCase();
            const role = card.querySelector(".creator-role").textContent.toLowerCase();

            if (name.includes(value) || role.includes(value)) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }

        });

    });

    /* -----------------------------
       SELECT INFLUENCER
    ----------------------------- */

    buttons.forEach(button => {

        button.addEventListener("click", function () {

            const card = this.closest(".influencer-card");
            const name = card.querySelector("h3").textContent;

            if (selectedInfluencers.includes(name)) {

                selectedInfluencers =
                    selectedInfluencers.filter(item => item !== name);

                this.textContent = "Select Influencer";
                this.style.background =
                    "linear-gradient(135deg,#7C3AED,#9333EA)";

            } else {

                selectedInfluencers.push(name);

                this.textContent = "Selected ✓";
                this.style.background = "#22C55E";

            }

            updateSelected();

        });

    });

    /* -----------------------------
       UPDATE SELECTED LIST
    ----------------------------- */

    function updateSelected() {

        selectedCount.textContent = selectedInfluencers.length;

        selectedList.innerHTML = "";

        if (selectedInfluencers.length === 0) {

            selectedList.innerHTML =
                "<p class='empty-text'>No influencers selected.</p>";

            return;

        }

        selectedInfluencers.forEach(name => {

            const item = document.createElement("div");

            item.style.padding = "12px";
            item.style.marginTop = "10px";
            item.style.border = "1px solid #334155";
            item.style.borderRadius = "10px";
            item.style.background = "#161B22";

            item.innerHTML = `
                <strong>${name}</strong>
            `;

            selectedList.appendChild(item);

        });

    }

    /* -----------------------------
       NEXT BUTTON
    ----------------------------- */

    const nextBtn = document.querySelector(".primary-btn");

    nextBtn.addEventListener("click", function () {

        if (selectedInfluencers.length === 0) {

            alert("Please select at least one influencer.");

            return;

        }

        window.location.href = "campaignBrief.html";

    });

    /* -----------------------------
       PREVIOUS BUTTON
    ----------------------------- */

    const previousBtn = document.querySelector(".secondary-btn");

    previousBtn.addEventListener("click", function () {

        window.location.href = "createCampaign.html";

    });

});