// ==============================
// Get Elements
// ==============================

const campaignName = document.getElementById("campaignName");
const campaignType = document.getElementById("campaignType");
const game = document.getElementById("game");
const objective = document.getElementById("objective");
const startDate = document.getElementById("startDate");
const endDate = document.getElementById("endDate");
const description = document.getElementById("description");
const thumbnail = document.getElementById("thumbnail");

const summaryName = document.getElementById("summaryName");
const summaryType = document.getElementById("summaryType");
const summaryGame = document.getElementById("summaryGame");
const summaryObjective = document.getElementById("summaryObjective");
const summaryDuration = document.getElementById("summaryDuration");

const nextBtn = document.querySelector(".next-btn");
const draftBtn = document.querySelector(".draft-btn");

// ==============================
// Update Campaign Summary
// ==============================

function updateSummary(){

    summaryName.textContent =
        campaignName.value || "-";

    summaryType.textContent =
        campaignType.value || "-";

    summaryGame.textContent =
        game.value || "-";

    summaryObjective.textContent =
        objective.value || "-";

    if(startDate.value && endDate.value){

        summaryDuration.textContent =
        startDate.value + "  →  " + endDate.value;

    }else{

        summaryDuration.textContent="-";

    }

}

// ==============================
// Event Listeners
// ==============================

campaignName.addEventListener("input",updateSummary);
campaignType.addEventListener("change",updateSummary);
game.addEventListener("change",updateSummary);
objective.addEventListener("change",updateSummary);
startDate.addEventListener("change",updateSummary);
endDate.addEventListener("change",updateSummary);

// ==============================
// Image Upload Preview
// ==============================

thumbnail.addEventListener("change",function(){

    const file=this.files[0];

    if(!file) return;

    const reader=new FileReader();

    reader.onload=function(e){

        let old=document.querySelector(".preview");

        if(old){
            old.remove();
        }

        const img=document.createElement("img");

        img.src=e.target.result;

        img.className="preview";

        img.style.width="100%";
        img.style.marginTop="15px";
        img.style.borderRadius="12px";
        img.style.objectFit="cover";

        document.querySelector(".upload-box")
        .appendChild(img);

    }

    reader.readAsDataURL(file);

});

// ==============================
// Save Draft
// ==============================

draftBtn.addEventListener("click",function(){

    localStorage.setItem("campaignName",campaignName.value);
    localStorage.setItem("campaignType",campaignType.value);
    localStorage.setItem("game",game.value);
    localStorage.setItem("objective",objective.value);
    localStorage.setItem("startDate",startDate.value);
    localStorage.setItem("endDate",endDate.value);
    localStorage.setItem("description",description.value);

    alert("Campaign saved as Draft!");

});

// ==============================
// Load Draft
// ==============================

window.onload=function(){

    if(localStorage.getItem("campaignName")){

        campaignName.value=localStorage.getItem("campaignName");
        campaignType.value=localStorage.getItem("campaignType");
        game.value=localStorage.getItem("game");
        objective.value=localStorage.getItem("objective");
        startDate.value=localStorage.getItem("startDate");
        endDate.value=localStorage.getItem("endDate");
        description.value=localStorage.getItem("description");

        updateSummary();

    }

}

// ==============================
// Next Button Validation
// ==============================

nextBtn.addEventListener("click",function(){

    if(campaignName.value.trim()===""){

        alert("Please enter Campaign Name");
        campaignName.focus();
        return;

    }

    if(campaignType.selectedIndex===0){

        alert("Please select Campaign Type");
        return;

    }

    if(game.selectedIndex===0){

        alert("Please select Game");
        return;

    }

    if(objective.selectedIndex===0){

        alert("Please select Campaign Objective");
        return;

    }

    if(startDate.value===""){

        alert("Please choose Start Date");
        return;

    }

    if(endDate.value===""){

        alert("Please choose End Date");
        return;

    }

    if(description.value.trim()===""){

        alert("Please enter Campaign Description");
        description.focus();
        return;

    }

    alert("Campaign Details Saved!\n\nProceeding to Select Influencers...");

    // Change this later to your actual next page
    // window.location.href="findInfluencers.html";

});

// ==============================
// Character Counter
// ==============================

const counter=document.createElement("small");

counter.style.display="block";
counter.style.textAlign="right";
counter.style.marginTop="5px";
counter.style.color="#777";

description.parentNode.appendChild(counter);

description.addEventListener("input",function(){

    counter.innerHTML=
    description.value.length+" characters";

});

// ==============================
// Auto Set Minimum End Date
// ==============================

startDate.addEventListener("change",function(){

    endDate.min=startDate.value;

});

// ==============================
// Finish
// ==============================

console.log("Create Campaign Page Loaded Successfully!");