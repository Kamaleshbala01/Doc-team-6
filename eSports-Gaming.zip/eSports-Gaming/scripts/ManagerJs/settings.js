"use strict";

/* ==========================================
   SETTINGS PAGE
========================================== */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeSidebar();

        loadSettings();

        bindSettingsForm();

    }
);

/* ==========================================
   STORAGE KEY
========================================== */

const SETTINGS_KEY =
    "managerSettings";

/* ==========================================
   LOAD SETTINGS
========================================== */

function loadSettings() {

    const settings =
        JSON.parse(
            localStorage.getItem(
                SETTINGS_KEY
            )
        ) || {};

    document.getElementById(
        "platformName"
    ).value =
        settings.platformName ||
        "Invictus";

    document.getElementById(
        "supportEmail"
    ).value =
        settings.supportEmail ||
        "support@invictus.com";

    document.getElementById(
        "currency"
    ).value =
        settings.currency ||
        "INR";

    document.getElementById(
        "timezone"
    ).value =
        settings.timezone ||
        "Asia/Kolkata";

    document.getElementById(
        "emailNotifications"
    ).checked =
        settings.emailNotifications ??
        true;

    document.getElementById(
        "maintenanceMode"
    ).checked =
        settings.maintenanceMode ??
        false;
}

/* ==========================================
   SAVE SETTINGS
========================================== */

function bindSettingsForm() {

    const form =
        document.getElementById(
            "settingsForm"
        );

    if (!form) return;

    form.addEventListener(
        "submit",
        event => {

            event.preventDefault();

            const settings = {

                platformName:
                document.getElementById(
                    "platformName"
                ).value,

                supportEmail:
                document.getElementById(
                    "supportEmail"
                ).value,

                currency:
                document.getElementById(
                    "currency"
                ).value,

                timezone:
                document.getElementById(
                    "timezone"
                ).value,

                emailNotifications:
                document.getElementById(
                    "emailNotifications"
                ).checked,

                maintenanceMode:
                document.getElementById(
                    "maintenanceMode"
                ).checked

            };

            localStorage.setItem(
                SETTINGS_KEY,
                JSON.stringify(
                    settings
                )
            );

            toast(
                "Settings saved successfully",
                "success"
            );

        }
    );
}

/* ==========================================
   TOAST
========================================== */

function toast(
    message,
    type = "success"
) {

    const stack =
        document.getElementById(
            "toastStack"
        );

    const toast =
        document.createElement(
            "div"
        );

    toast.className =
        `toast ${type}`;

    toast.textContent =
        message;

    stack.appendChild(
        toast
    );

    setTimeout(
        () => {

            toast.remove();

        },
        3000
    );
}

/* ==========================================
   MOBILE SIDEBAR
========================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu || !backdrop) return;

    menu.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .add(
                    "nav-open"
                );

        }
    );

    backdrop.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .remove(
                    "nav-open"
                );

        }
    );
}