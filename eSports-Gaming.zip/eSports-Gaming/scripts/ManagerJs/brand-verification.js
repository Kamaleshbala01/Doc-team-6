"use strict";

/* ==========================================
   BRAND VERIFICATION
========================================== */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeSidebar();

        state.page = 1;

        renderBrands();

    }
);

const state = {
    page: 1
};

/* ==========================================
   DATA
========================================== */

function brands() {

    return StorageManager.all(
        COLLECTIONS.BRANDS
    );

}

/* ==========================================
   RENDER BRANDS
========================================== */

function renderBrands() {

    const view =
        document.getElementById(
            "brandsView"
        );

    const search =
        document
            .getElementById(
                "brandSearch"
            )
            ?.value
            .toLowerCase() || "";

    const filtered =
        brands()
        .filter(item =>
            Object.values(item)
            .join(" ")
            .toLowerCase()
            .includes(search)
        );

    const pageSize = 10;

    const totalPages =
        Math.max(
            1,
            Math.ceil(
                filtered.length / pageSize
            )
        );

    const start =
        (state.page - 1) *
        pageSize;

    const pageData =
        filtered.slice(
            start,
            start + pageSize
        );

    view.innerHTML = `

        <section class="panel">

            <div class="bulk-actions">

                <button
                    class="btn success"
                    id="bulkApprove">

                    Bulk Approve

                </button>

                <button
                    class="btn danger"
                    id="bulkReject">

                    Bulk Reject

                </button>

            </div>

            <div class="table-scroll">

                <table>

                    <thead>

                        <tr>

                            <th>

                                <input
                                    type="checkbox"
                                    id="selectAll">

                            </th>

                            <th>Company</th>
                            <th>Website</th>
                            <th>Industry</th>
                            <th>Revenue</th>
                            <th>Campaigns</th>
                            <th>Country</th>
                            <th>Status</th>
                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                        ${
                            pageData.length
                            ?
                            pageData
                                .map(renderRow)
                                .join("")
                            :
                            `
                            <tr>

                                <td
                                    colspan="9"
                                    class="empty">

                                    No brands found

                                </td>

                            </tr>
                            `
                        }

                    </tbody>

                </table>

            </div>

            <div class="pagination">

                <button
                    class="btn secondary"
                    id="prevBtn"
                    ${state.page === 1 ? "disabled" : ""}>

                    Previous

                </button>

                <span>

                    Page
                    ${state.page}
                    of
                    ${totalPages}

                </span>

                <button
                    class="btn secondary"
                    id="nextBtn"
                    ${state.page === totalPages ? "disabled" : ""}>

                    Next

                </button>

            </div>

        </section>

    `;

    bindEvents(totalPages);
}

/* ==========================================
   ROW
========================================== */

function renderRow(item) {

    return `

        <tr>

            <td>

                <input
                    type="checkbox"
                    class="recordCheck"
                    value="${item.id}">

            </td>

            <td>${item.company}</td>

            <td>

                ${item.website}

            </td>

            <td>${item.industry}</td>

            <td>

                ₹${Number(
                    item.revenue
                ).toLocaleString("en-IN")}

            </td>

            <td>${item.campaigns}</td>

            <td>${item.country}</td>

            <td>

                <span class="badge ${item.status
                    .toLowerCase()
                    .replaceAll(" ","-")}">

                    ${item.status}

                </span>

            </td>

            <td class="row-actions">

                <button
                    data-view="${item.id}">

                    View

                </button>

                <button
                    data-approve="${item.id}">

                    Approve

                </button>

                <button
                    data-reject="${item.id}">

                    Reject

                </button>

            </td>

        </tr>

    `;
}

/* ==========================================
   EVENTS
========================================== */

function bindEvents(totalPages) {

    document
        .getElementById("brandSearch")
        ?.addEventListener(
            "input",
            () => {

                state.page = 1;

                renderBrands();

            }
        );

    document
        .querySelectorAll(
            "[data-view]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                openDetails(
                    button.dataset.view
                );

        });

    document
        .querySelectorAll(
            "[data-approve]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                updateStatus(
                    button.dataset.approve,
                    "Approved"
                );

        });

    document
        .querySelectorAll(
            "[data-reject]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                updateStatus(
                    button.dataset.reject,
                    "Rejected"
                );

        });

    document
        .getElementById(
            "bulkApprove"
        )
        ?.addEventListener(
            "click",
            () =>
            bulkUpdate(
                "Approved"
            )
        );

    document
        .getElementById(
            "bulkReject"
        )
        ?.addEventListener(
            "click",
            () =>
            bulkUpdate(
                "Rejected"
            )
        );

    document
        .getElementById(
            "prevBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page--;

                renderBrands();

            }
        );

    document
        .getElementById(
            "nextBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page++;

                renderBrands();

            }
        );

}

/* ==========================================
   UPDATE STATUS
========================================== */

function updateStatus(
    id,
    status
) {

    StorageManager.update(
        COLLECTIONS.BRANDS,
        id,
        { status }
    );

    toast(
        `Brand ${status}`,
        "success"
    );

    renderBrands();
}

/* ==========================================
   BULK UPDATE
========================================== */

function bulkUpdate(status) {

    const ids =
        [
            ...document.querySelectorAll(
                ".recordCheck:checked"
            )
        ].map(
            checkbox => checkbox.value
        );

    if (!ids.length) {

        toast(
            "Select brands first",
            "warning"
        );

        return;
    }

    StorageManager.bulkUpdate(
        COLLECTIONS.BRANDS,
        ids,
        { status }
    );

    toast(
        `${ids.length} records updated`,
        "success"
    );

    renderBrands();
}

/* ==========================================
   DETAILS MODAL
========================================== */

function openDetails(id) {

    const item =
        StorageManager.find(
            COLLECTIONS.BRANDS,
            id
        );

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = false;

    modal.innerHTML = `

        <div
            class="modal-backdrop"
            onclick="closeModal()">
        </div>

        <section class="modal">

            <header>

                <h2>
                    ${item.company}
                </h2>

                <button
                    onclick="closeModal()">

                    Close

                </button>

            </header>

            <div class="details">

                ${
                    Object.entries(item)
                    .map(
                        ([key,val]) => `
                        <div>

                            <dt>${key}</dt>

                            <dd>${val}</dd>

                        </div>
                        `
                    )
                    .join("")
                }

            </div>

        </section>

    `;
}

/* ==========================================
   CLOSE MODAL
========================================== */

function closeModal() {

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = true;

    modal.innerHTML = "";

}

/* ==========================================
   TOAST
========================================== */

function toast(
    message,
    type = "success"
) {

    const stack =
        document.getElementById(
            "toastStack"
        );

    const node =
        document.createElement(
            "div"
        );

    node.className =
        `toast ${type}`;

    node.textContent =
        message;

    stack.appendChild(node);

    setTimeout(
        () => node.remove(),
        3000
    );
}

/* ==========================================
   MOBILE SIDEBAR
========================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu) return;

    menu.addEventListener(
        "click",
        () =>
        document.body
        .classList
        .add("nav-open")
    );

    backdrop.addEventListener(
        "click",
        () =>
        document.body
        .classList
        .remove("nav-open")
    );
}