"use strict";

/* ==========================================
   SUPPORT TICKETS
========================================== */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeSidebar();

        state.page = 1;

        renderTickets();

    }
);

const state = {
    page: 1
};

/* ==========================================
   DATA
========================================== */

function tickets() {

    return StorageManager.all(
        COLLECTIONS.SUPPORT
    );

}

/* ==========================================
   RENDER
========================================== */

function renderTickets() {

    const view =
        document.getElementById(
            "supportView"
        );

    const search =
        document
            .getElementById(
                "ticketSearch"
            )
            ?.value
            .toLowerCase() || "";

    const filtered =
        tickets()
        .filter(ticket =>
            Object.values(ticket)
            .join(" ")
            .toLowerCase()
            .includes(search)
        );

    const pageSize = 10;

    const totalPages =
        Math.max(
            1,
            Math.ceil(
                filtered.length /
                pageSize
            )
        );

    const start =
        (state.page - 1) *
        pageSize;

    const rows =
        filtered.slice(
            start,
            start + pageSize
        );

    view.innerHTML = `

        <section class="panel">

            <div class="table-scroll">

                <table>

                    <thead>

                        <tr>

                            <th>Subject</th>
                            <th>Requester</th>
                            <th>Priority</th>
                            <th>Assignee</th>
                            <th>Country</th>
                            <th>Status</th>
                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                        ${
                            rows.length
                            ?
                            rows
                                .map(renderRow)
                                .join("")
                            :
                            `
                            <tr>
                                <td colspan="7"
                                    class="empty">
                                    No tickets found
                                </td>
                            </tr>
                            `
                        }

                    </tbody>

                </table>

            </div>

            <div class="pagination">

                <button
                    class="btn secondary"
                    id="prevBtn"
                    ${state.page === 1 ? "disabled" : ""}>

                    Previous

                </button>

                <span>

                    Page ${state.page}
                    of
                    ${totalPages}

                </span>

                <button
                    class="btn secondary"
                    id="nextBtn"
                    ${state.page === totalPages ? "disabled" : ""}>

                    Next

                </button>

            </div>

        </section>

    `;

    bindEvents();
}

/* ==========================================
   ROW
========================================== */

function renderRow(ticket) {

    return `

        <tr>

            <td>${ticket.subject}</td>

            <td>${ticket.requester}</td>

            <td>

                <span class="badge ${ticket.priority.toLowerCase()}">

                    ${ticket.priority}

                </span>

            </td>

            <td>${ticket.assignee}</td>

            <td>${ticket.country}</td>

            <td>

                <span class="badge ${ticket.status.toLowerCase()}">

                    ${ticket.status}

                </span>

            </td>

            <td class="row-actions">

                <button
                    data-view="${ticket.id}">

                    View

                </button>

                <button
                    data-resolve="${ticket.id}">

                    Resolve

                </button>

            </td>

        </tr>

    `;
}

/* ==========================================
   EVENTS
========================================== */

function bindEvents() {

    document
        .getElementById(
            "ticketSearch"
        )
        ?.addEventListener(
            "input",
            () => {

                state.page = 1;

                renderTickets();

            }
        );

    document
        .querySelectorAll(
            "[data-view]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                openDetails(
                    button.dataset.view
                );

        });

    document
        .querySelectorAll(
            "[data-resolve]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                resolveTicket(
                    button.dataset.resolve
                );

        });

    document
        .getElementById(
            "prevBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page--;

                renderTickets();

            }
        );

    document
        .getElementById(
            "nextBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page++;

                renderTickets();

            }
        );
}

/* ==========================================
   RESOLVE TICKET
========================================== */

function resolveTicket(id) {

    StorageManager.update(
        COLLECTIONS.SUPPORT,
        id,
        {
            status: "Resolved"
        }
    );

    toast(
        "Ticket resolved",
        "success"
    );

    renderTickets();
}

/* ==========================================
   DETAILS MODAL
========================================== */

function openDetails(id) {

    const ticket =
        StorageManager.find(
            COLLECTIONS.SUPPORT,
            id
        );

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = false;

    modal.innerHTML = `

        <div
            class="modal-backdrop"
            onclick="closeModal()">
        </div>

        <section class="modal">

            <header>

                <h2>
                    Ticket Details
                </h2>

                <button
                    onclick="closeModal()">

                    Close

                </button>

            </header>

            <div class="details">

                ${
                    Object.entries(ticket)
                    .map(
                        ([key,val]) => `
                        <div>

                            <dt>${key}</dt>

                            <dd>${val}</dd>

                        </div>
                        `
                    )
                    .join("")
                }

            </div>

        </section>

    `;
}

/* ==========================================
   CLOSE MODAL
========================================== */

function closeModal() {

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = true;

    modal.innerHTML = "";
}

/* ==========================================
   TOAST
========================================== */

function toast(
    message,
    type = "success"
) {

    const stack =
        document.getElementById(
            "toastStack"
        );

    const node =
        document.createElement(
            "div"
        );

    node.className =
        `toast ${type}`;

    node.textContent =
        message;

    stack.appendChild(node);

    setTimeout(
        () => node.remove(),
        3000
    );
}

/* ==========================================
   MOBILE SIDEBAR
========================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu) return;

    menu.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .add("nav-open");

        }
    );

    backdrop.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .remove("nav-open");

        }
    );
}