"use strict";

/* ==========================================
   USER VERIFICATION
========================================== */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeSidebar();

        state.page = 1;

        renderUsers();

    }
);

const state = {
    page: 1
};

/* ==========================================
   HELPERS
========================================== */

function users() {
    return StorageManager.all(
        COLLECTIONS.USERS
    );
}

function money(value) {

    return new Intl.NumberFormat(
        "en-IN",
        {
            style: "currency",
            currency: "INR",
            maximumFractionDigits: 0
        }
    ).format(Number(value) || 0);

}

function formatDate(value) {

    if (!value) return "-";

    return new Date(value)
        .toLocaleDateString(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        );

}

/* ==========================================
   RENDER
========================================== */

function renderUsers() {

    const view =
        document.getElementById(
            "usersView"
        );

    const search =
        document
            .getElementById(
                "userSearch"
            )?.value
            ?.toLowerCase() || "";

    const filtered =
        users()
            .filter(user =>
                Object.values(user)
                    .join(" ")
                    .toLowerCase()
                    .includes(search)
            );

    const pageSize = 10;

    const totalPages =
        Math.max(
            1,
            Math.ceil(
                filtered.length /
                pageSize
            )
        );

    const start =
        (state.page - 1) *
        pageSize;

    const rows =
        filtered.slice(
            start,
            start + pageSize
        );

    view.innerHTML = `

        <section class="panel">

            <div class="bulk-actions">

                <button
                    class="btn success"
                    id="bulkApprove">

                    Bulk Approve

                </button>

                <button
                    class="btn danger"
                    id="bulkReject">

                    Bulk Reject

                </button>

            </div>

            <div class="table-scroll">

                <table>

                    <thead>

                        <tr>

                            <th>
                                <input
                                    type="checkbox"
                                    id="selectAll">
                            </th>

                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Country</th>
                            <th>Game</th>
                            <th>Status</th>
                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                        ${
                            rows.map(
                                user =>
                                renderRow(
                                    user
                                )
                            )
                            .join("")
                        }

                    </tbody>

                </table>

            </div>

            <div class="pagination">

                <button
                    class="btn secondary"
                    id="prevBtn"
                    ${state.page === 1
                        ? "disabled"
                        : ""}>

                    Previous

                </button>

                <span>

                    Page
                    ${state.page}
                    of
                    ${totalPages}

                </span>

                <button
                    class="btn secondary"
                    id="nextBtn"
                    ${state.page === totalPages
                        ? "disabled"
                        : ""}>

                    Next

                </button>

            </div>

        </section>

    `;

    bindUserEvents(
        totalPages
    );
}

/* ==========================================
   ROW
========================================== */

function renderRow(user) {

    return `

        <tr>

            <td>

                <input
                    type="checkbox"
                    class="userCheck"
                    value="${user.id}">

            </td>

            <td>${user.name}</td>

            <td>${user.email}</td>

            <td>${user.role}</td>

            <td>${user.country}</td>

            <td>${user.game}</td>

            <td>

                <span
                class="badge ${user.status
                    .toLowerCase()
                    .replaceAll(" ","-")}">

                    ${user.status}

                </span>

            </td>

            <td class="row-actions">

                <button
                    data-view="${user.id}">

                    View

                </button>

                <button
                    data-approve="${user.id}">

                    Approve

                </button>

                <button
                    data-reject="${user.id}">

                    Reject

                </button>

            </td>

        </tr>

    `;
}

/* ==========================================
   EVENTS
========================================== */

function bindUserEvents(
    totalPages
) {

    document
        .getElementById(
            "userSearch"
        )
        ?.addEventListener(
            "input",
            () => {
                state.page = 1;
                renderUsers();
            }
        );

    document
        .querySelectorAll(
            "[data-view]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                openDetails(
                    button.dataset.view
                );

        });

    document
        .querySelectorAll(
            "[data-approve]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                updateUser(
                    button.dataset.approve,
                    "Approved"
                );

        });

    document
        .querySelectorAll(
            "[data-reject]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                updateUser(
                    button.dataset.reject,
                    "Rejected"
                );

        });

    document
        .getElementById(
            "bulkApprove"
        )
        ?.addEventListener(
            "click",
            () =>
            bulkUpdate(
                "Approved"
            )
        );

    document
        .getElementById(
            "bulkReject"
        )
        ?.addEventListener(
            "click",
            () =>
            bulkUpdate(
                "Rejected"
            )
        );

    document
        .getElementById(
            "prevBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page--;

                renderUsers();

            }
        );

    document
        .getElementById(
            "nextBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page++;

                renderUsers();

            }
        );

}

/* ==========================================
   UPDATE
========================================== */

function updateUser(
    id,
    status
) {

    StorageManager.update(
        COLLECTIONS.USERS,
        id,
        { status }
    );

    toast(
        `User ${status}`,
        "success"
    );

    renderUsers();
}

/* ==========================================
   BULK UPDATE
========================================== */

function bulkUpdate(
    status
) {

    const ids =
        [
            ...document.querySelectorAll(
                ".userCheck:checked"
            )
        ].map(
            box => box.value
        );

    if (!ids.length) {

        toast(
            "Select users first",
            "warning"
        );

        return;
    }

    StorageManager.bulkUpdate(
        COLLECTIONS.USERS,
        ids,
        { status }
    );

    toast(
        `${ids.length} users updated`,
        "success"
    );

    renderUsers();
}

/* ==========================================
   DETAILS MODAL
========================================== */

function openDetails(id) {

    const user =
        StorageManager.find(
            COLLECTIONS.USERS,
            id
        );

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden =
        false;

    modal.innerHTML = `

        <div
            class="modal-backdrop">

        </div>

        <section class="modal">

            <header>

                <h2>
                    ${user.name}
                </h2>

                <button
                    onclick="closeModal()">

                    Close

                </button>

            </header>

            <div class="details">

                ${
                    Object.entries(user)
                    .map(
                        ([key,value]) => `
                        <div>

                            <dt>
                                ${key}
                            </dt>

                            <dd>
                                ${value}
                            </dd>

                        </div>
                    `
                    ).join("")
                }

            </div>

        </section>

    `;
}

/* ==========================================
   CLOSE MODAL
========================================== */

function closeModal() {

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = true;

    modal.innerHTML = "";

}

/* ==========================================
   TOAST
========================================== */

function toast(
    message,
    type = "success"
) {

    const stack =
        document.getElementById(
            "toastStack"
        );

    const item =
        document.createElement(
            "div"
        );

    item.className =
        `toast ${type}`;

    item.textContent =
        message;

    stack.appendChild(item);

    setTimeout(
        () => item.remove(),
        3000
    );
}

/* ==========================================
   SIDEBAR
========================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu) return;

    menu.addEventListener(
        "click",
        () =>
        document.body
            .classList
            .add("nav-open")
    );

    backdrop.addEventListener(
        "click",
        () =>
        document.body
            .classList
            .remove("nav-open")
    );
}