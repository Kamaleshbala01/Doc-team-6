"use strict";

/* ==========================================
   TOURNAMENT MANAGEMENT
========================================== */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeSidebar();

        state.page = 1;

        renderTournaments();
    }
);

const state = {
    page: 1
};

/* ==========================================
   DATA
========================================== */

function tournaments() {
    return StorageManager.all(
        COLLECTIONS.TOURNAMENTS
    );
}

/* ==========================================
   RENDER
========================================== */

function renderTournaments() {

    const view =
        document.getElementById(
            "tournamentsView"
        );

    const search =
        document
            .getElementById(
                "tournamentSearch"
            )
            ?.value
            .toLowerCase() || "";

    const filtered =
        tournaments()
        .filter(item =>
            Object.values(item)
                .join(" ")
                .toLowerCase()
                .includes(search)
        );

    const pageSize = 10;

    const totalPages =
        Math.max(
            1,
            Math.ceil(
                filtered.length /
                pageSize
            )
        );

    const start =
        (state.page - 1) *
        pageSize;

    const records =
        filtered.slice(
            start,
            start + pageSize
        );

    view.innerHTML = `

        <section class="panel">

            <div class="bulk-actions">

                <button
                    class="btn primary"
                    id="newTournament">

                    Create Tournament

                </button>

            </div>

            <div class="table-scroll">

                <table>

                    <thead>

                        <tr>

                            <th>Title</th>
                            <th>Game</th>
                            <th>Prize Pool</th>
                            <th>Teams</th>
                            <th>Winner</th>
                            <th>Country</th>
                            <th>Status</th>
                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                        ${
                            records.length
                            ?
                            records
                                .map(renderRow)
                                .join("")
                            :
                            `
                            <tr>
                                <td colspan="8"
                                    class="empty">
                                    No tournaments found
                                </td>
                            </tr>
                            `
                        }

                    </tbody>

                </table>

            </div>

            <div class="pagination">

                <button
                    class="btn secondary"
                    id="prevBtn"
                    ${state.page === 1 ? "disabled" : ""}>

                    Previous

                </button>

                <span>

                    Page ${state.page}
                    of
                    ${totalPages}

                </span>

                <button
                    class="btn secondary"
                    id="nextBtn"
                    ${state.page === totalPages ? "disabled" : ""}>

                    Next

                </button>

            </div>

        </section>

    `;

    bindEvents(totalPages);
}

/* ==========================================
   ROW
========================================== */

function renderRow(item) {

    return `

        <tr>

            <td>${item.title}</td>

            <td>${item.game}</td>

            <td>
                ₹${Number(item.prizePool)
                    .toLocaleString("en-IN")}
            </td>

            <td>${item.teams}</td>

            <td>${item.winner}</td>

            <td>${item.country}</td>

            <td>

                <span
                    class="badge ${item.status
                        .toLowerCase()}">

                    ${item.status}

                </span>

            </td>

            <td class="row-actions">

                <button
                    data-view="${item.id}">

                    View

                </button>

                <button
                    data-edit="${item.id}">

                    Edit

                </button>

                <button
                    data-delete="${item.id}">

                    Delete

                </button>

            </td>

        </tr>

    `;
}

/* ==========================================
   EVENTS
========================================== */

function bindEvents(totalPages) {

    document
        .getElementById(
            "tournamentSearch"
        )
        ?.addEventListener(
            "input",
            () => {

                state.page = 1;
                renderTournaments();

            }
        );

    document
        .getElementById(
            "newTournament"
        )
        ?.addEventListener(
            "click",
            openCreateModal
        );

    document
        .querySelectorAll(
            "[data-view]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                openDetails(
                    button.dataset.view
                );

        });

    document
        .querySelectorAll(
            "[data-edit]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                openEditModal(
                    button.dataset.edit
                );

        });

    document
        .querySelectorAll(
            "[data-delete]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                deleteTournament(
                    button.dataset.delete
                );

        });

    document
        .getElementById(
            "prevBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page--;

                renderTournaments();

            }
        );

    document
        .getElementById(
            "nextBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page++;

                renderTournaments();

            }
        );
}

/* ==========================================
   CREATE TOURNAMENT
========================================== */

function openCreateModal() {

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = false;

    modal.innerHTML = `

        <div class="modal-backdrop"></div>

        <section class="modal">

            <h2>Create Tournament</h2>

            <form id="createForm"
                  class="form-grid">

                <input
                    name="title"
                    placeholder="Tournament Title"
                    required>

                <input
                    name="game"
                    placeholder="Game"
                    required>

                <input
                    name="prizePool"
                    type="number"
                    placeholder="Prize Pool"
                    required>

                <input
                    name="teams"
                    type="number"
                    placeholder="Teams"
                    required>

                <input
                    name="country"
                    placeholder="Country"
                    required>

                <select name="status">

                    <option>Upcoming</option>

                    <option>Live</option>

                    <option>Completed</option>

                </select>

                <div class="modal-actions">

                    <button
                        type="button"
                        class="btn secondary"
                        onclick="closeModal()">

                        Cancel

                    </button>

                    <button
                        class="btn primary">

                        Create

                    </button>

                </div>

            </form>

        </section>

    `;

    document
        .getElementById(
            "createForm"
        )
        .addEventListener(
            "submit",
            saveTournament
        );
}

function saveTournament(event) {

    event.preventDefault();

    const data =
        Object.fromEntries(
            new FormData(
                event.target
            )
        );

    StorageManager.insert(
        COLLECTIONS.TOURNAMENTS,
        {
            ...data,
            winner: "TBD"
        }
    );

    toast(
        "Tournament created",
        "success"
    );

    closeModal();

    renderTournaments();
}

/* ==========================================
   EDIT TOURNAMENT
========================================== */

function openEditModal(id) {

    const item =
        StorageManager.find(
            COLLECTIONS.TOURNAMENTS,
            id
        );

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = false;

    modal.innerHTML = `

        <div class="modal-backdrop"></div>

        <section class="modal">

            <h2>Edit Tournament</h2>

            <form id="editForm"
                  class="form-grid">

                <input
                    name="title"
                    value="${item.title}">

                <input
                    name="game"
                    value="${item.game}">

                <input
                    name="winner"
                    value="${item.winner}">

                <select name="status">

                    <option ${item.status==="Upcoming"?"selected":""}>
                        Upcoming
                    </option>

                    <option ${item.status==="Live"?"selected":""}>
                        Live
                    </option>

                    <option ${item.status==="Completed"?"selected":""}>
                        Completed
                    </option>

                    <option ${item.status==="Cancelled"?"selected":""}>
                        Cancelled
                    </option>

                </select>

                <div class="modal-actions">

                    <button
                        type="button"
                        class="btn secondary"
                        onclick="closeModal()">

                        Cancel

                    </button>

                    <button
                        class="btn primary">

                        Save

                    </button>

                </div>

            </form>

        </section>

    `;

    document
        .getElementById(
            "editForm"
        )
        .addEventListener(
            "submit",
            event => {

                event.preventDefault();

                const formData =
                    Object.fromEntries(
                        new FormData(
                            event.target
                        )
                    );

                StorageManager.update(
                    COLLECTIONS.TOURNAMENTS,
                    id,
                    formData
                );

                toast(
                    "Tournament updated",
                    "success"
                );

                closeModal();

                renderTournaments();
            }
        );
}

/* ==========================================
   VIEW DETAILS
========================================== */

function openDetails(id) {

    const item =
        StorageManager.find(
            COLLECTIONS.TOURNAMENTS,
            id
        );

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = false;

    modal.innerHTML = `

        <div
            class="modal-backdrop"
            onclick="closeModal()">
        </div>

        <section class="modal">

            <h2>
                ${item.title}
            </h2>

            <div class="details">

                ${
                    Object.entries(item)
                    .map(
                        ([key,val]) => `
                        <div>
                            <dt>${key}</dt>
                            <dd>${val}</dd>
                        </div>
                    `
                    )
                    .join("")
                }

            </div>

        </section>

    `;
}

/* ==========================================
   DELETE
========================================== */

function deleteTournament(id) {

    if (
        !confirm(
            "Delete tournament?"
        )
    ) return;

    StorageManager.remove(
        COLLECTIONS.TOURNAMENTS,
        id
    );

    toast(
        "Tournament deleted",
        "success"
    );

    renderTournaments();
}

/* ==========================================
   MODAL
========================================== */

function closeModal() {

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = true;

    modal.innerHTML = "";
}

/* ==========================================
   TOAST
========================================== */

function toast(
    message,
    type="success"
) {

    const stack =
        document.getElementById(
            "toastStack"
        );

    const node =
        document.createElement(
            "div"
        );

    node.className =
        `toast ${type}`;

    node.textContent =
        message;

    stack.appendChild(node);

    setTimeout(
        () => node.remove(),
        3000
    );
}

/* ==========================================
   SIDEBAR
========================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu) return;

    menu.addEventListener(
        "click",
        () =>
        document.body
            .classList
            .add("nav-open")
    );

    backdrop.addEventListener(
        "click",
        () =>
        document.body
            .classList
            .remove("nav-open")
    );
}