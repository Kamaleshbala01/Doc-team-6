"use strict";

/* ==========================================
   SUBSCRIPTION MANAGEMENT
========================================== */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeSidebar();

        state.page = 1;

        renderSubscriptions();

    }
);

const state = {
    page: 1
};

/* ==========================================
   DATA
========================================== */

function subscriptions() {

    return StorageManager.all(
        COLLECTIONS.SUBSCRIPTIONS
    );

}

/* ==========================================
   RENDER
========================================== */

function renderSubscriptions() {

    const view =
        document.getElementById(
            "subscriptionsView"
        );

    const search =
        document
            .getElementById(
                "subscriptionSearch"
            )
            ?.value
            .toLowerCase() || "";

    const filtered =
        subscriptions()
        .filter(item =>
            Object.values(item)
            .join(" ")
            .toLowerCase()
            .includes(search)
        );

    const pageSize = 10;

    const totalPages =
        Math.max(
            1,
            Math.ceil(
                filtered.length /
                pageSize
            )
        );

    const start =
        (state.page - 1) *
        pageSize;

    const pageData =
        filtered.slice(
            start,
            start + pageSize
        );

    view.innerHTML = `

        <section class="panel">

            <div class="table-scroll">

                <table>

                    <thead>

                        <tr>

                            <th>Plan</th>
                            <th>Price</th>
                            <th>Subscribers</th>
                            <th>Revenue</th>
                            <th>Status</th>
                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                        ${
                            pageData.length
                            ?
                            pageData
                            .map(renderRow)
                            .join("")
                            :
                            `
                            <tr>

                                <td
                                    colspan="6"
                                    class="empty">

                                    No subscriptions found

                                </td>

                            </tr>
                            `
                        }

                    </tbody>

                </table>

            </div>

            <div class="pagination">

                <button
                    class="btn secondary"
                    id="prevBtn"
                    ${state.page === 1 ? "disabled" : ""}>

                    Previous

                </button>

                <span>

                    Page
                    ${state.page}
                    of
                    ${totalPages}

                </span>

                <button
                    class="btn secondary"
                    id="nextBtn"
                    ${state.page === totalPages ? "disabled" : ""}>

                    Next

                </button>

            </div>

        </section>

    `;

    bindEvents(totalPages);
}

/* ==========================================
   TABLE ROW
========================================== */

function renderRow(item) {

    return `

        <tr>

            <td>
                ${item.plan}
            </td>

            <td>
                ₹${Number(item.price)
                    .toLocaleString("en-IN")}
            </td>

            <td>
                ${Number(item.subscribers)
                    .toLocaleString("en-IN")}
            </td>

            <td>
                ₹${Number(item.revenue)
                    .toLocaleString("en-IN")}
            </td>

            <td>

                <span
                    class="badge ${item.status
                        .toLowerCase()}">

                    ${item.status}

                </span>

            </td>

            <td class="row-actions">

                <button
                    data-view="${item.id}">

                    View

                </button>

            </td>

        </tr>

    `;

}

/* ==========================================
   EVENTS
========================================== */

function bindEvents(totalPages) {

    document
        .getElementById(
            "subscriptionSearch"
        )
        ?.addEventListener(
            "input",
            () => {

                state.page = 1;

                renderSubscriptions();

            }
        );

    document
        .querySelectorAll(
            "[data-view]"
        )
        .forEach(button => {

            button.onclick =
                () =>
                openDetails(
                    button.dataset.view
                );

        });

    document
        .getElementById(
            "prevBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page--;

                renderSubscriptions();

            }
        );

    document
        .getElementById(
            "nextBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page++;

                renderSubscriptions();

            }
        );
}

/* ==========================================
   DETAILS MODAL
========================================== */

function openDetails(id) {

    const item =
        StorageManager.find(
            COLLECTIONS.SUBSCRIPTIONS,
            id
        );

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = false;

    modal.innerHTML = `

        <div
            class="modal-backdrop"
            onclick="closeModal()">
        </div>

        <section class="modal">

            <header>

                <h2>
                    ${item.plan}
                </h2>

                <button
                    onclick="closeModal()">

                    Close

                </button>

            </header>

            <div class="details">

                ${
                    Object.entries(item)
                    .map(
                        ([key,val]) => `
                        <div>

                            <dt>${key}</dt>

                            <dd>${val}</dd>

                        </div>
                        `
                    )
                    .join("")
                }

            </div>

        </section>

    `;
}

/* ==========================================
   MODAL
========================================== */

function closeModal() {

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = true;

    modal.innerHTML = "";
}

/* ==========================================
   TOAST
========================================== */

function toast(
    message,
    type = "success"
) {

    const stack =
        document.getElementById(
            "toastStack"
        );

    const node =
        document.createElement(
            "div"
        );

    node.className =
        `toast ${type}`;

    node.textContent =
        message;

    stack.appendChild(node);

    setTimeout(
        () => node.remove(),
        3000
    );
}

/* ==========================================
   MOBILE SIDEBAR
========================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu) return;

    menu.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .add("nav-open");

        }
    );

    backdrop.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .remove("nav-open");

        }
    );
}