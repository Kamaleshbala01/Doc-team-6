"use strict";

/* ==========================================
   INFLUENCER VERIFICATION
========================================== */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeSidebar();

        state.page = 1;

        renderInfluencers();

    }
);

const state = {
    page: 1
};

/* ==========================================
   GET DATA
========================================== */

function influencers() {

    return StorageManager.all(
        COLLECTIONS.INFLUENCERS
    );

}

/* ==========================================
   RENDER
========================================== */

function renderInfluencers() {

    const view =
        document.getElementById(
            "influencersView"
        );

    const search =
        document
            .getElementById(
                "influencerSearch"
            )
            ?.value
            .toLowerCase() || "";

    const filtered =
        influencers()
        .filter(item =>
            Object.values(item)
                .join(" ")
                .toLowerCase()
                .includes(search)
        );

    const pageSize = 10;

    const totalPages =
        Math.max(
            1,
            Math.ceil(
                filtered.length /
                pageSize
            )
        );

    const start =
        (state.page - 1) *
        pageSize;

    const records =
        filtered.slice(
            start,
            start + pageSize
        );

    view.innerHTML = `

        <section class="panel">

            <div class="bulk-actions">

                <button
                    class="btn success"
                    id="bulkApprove">
                    Bulk Approve
                </button>

                <button
                    class="btn danger"
                    id="bulkReject">
                    Bulk Reject
                </button>

            </div>

            <div class="table-scroll">

                <table>

                    <thead>

                        <tr>

                            <th>
                                <input
                                    type="checkbox"
                                    id="selectAll">
                            </th>

                            <th>Name</th>
                            <th>Platform</th>
                            <th>Subscribers</th>
                            <th>Views</th>
                            <th>Engagement</th>
                            <th>Country</th>
                            <th>Status</th>
                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                        ${
                            records.length
                            ?
                            records
                            .map(renderRow)
                            .join("")
                            :
                            `
                            <tr>
                                <td colspan="9"
                                    class="empty">
                                    No influencers found
                                </td>
                            </tr>
                            `
                        }

                    </tbody>

                </table>

            </div>

            <div class="pagination">

                <button
                    class="btn secondary"
                    id="prevBtn"
                    ${state.page === 1 ? "disabled" : ""}>
                    Previous
                </button>

                <span>
                    Page ${state.page}
                    of
                    ${totalPages}
                </span>

                <button
                    class="btn secondary"
                    id="nextBtn"
                    ${state.page === totalPages ? "disabled" : ""}>
                    Next
                </button>

            </div>

        </section>

    `;

    bindEvents(totalPages);
}

/* ==========================================
   TABLE ROW
========================================== */

function renderRow(item) {

    return `

        <tr>

            <td>

                <input
                    type="checkbox"
                    class="recordCheck"
                    value="${item.id}">

            </td>

            <td>${item.name}</td>

            <td>${item.platform}</td>

            <td>${Number(item.subscribers).toLocaleString()}</td>

            <td>${Number(item.views).toLocaleString()}</td>

            <td>${item.engagement}</td>

            <td>${item.country}</td>

            <td>

                <span class="badge ${item.status
                    .toLowerCase()
                    .replaceAll(" ","-")}">

                    ${item.status}

                </span>

            </td>

            <td class="row-actions">

                <button
                    data-view="${item.id}">
                    View
                </button>

                <button
                    data-approve="${item.id}">
                    Approve
                </button>

                <button
                    data-reject="${item.id}">
                    Reject
                </button>

            </td>

        </tr>

    `;
}

/* ==========================================
   EVENTS
========================================== */

function bindEvents(totalPages) {

    document
        .getElementById(
            "influencerSearch"
        )
        ?.addEventListener(
            "input",
            () => {

                state.page = 1;

                renderInfluencers();

            }
        );

    document
        .querySelectorAll(
            "[data-view]"
        )
        .forEach(button =>
            button.onclick =
                () =>
                openDetails(
                    button.dataset.view
                )
        );

    document
        .querySelectorAll(
            "[data-approve]"
        )
        .forEach(button =>
            button.onclick =
                () =>
                updateStatus(
                    button.dataset.approve,
                    "Approved"
                )
        );

    document
        .querySelectorAll(
            "[data-reject]"
        )
        .forEach(button =>
            button.onclick =
                () =>
                updateStatus(
                    button.dataset.reject,
                    "Rejected"
                )
        );

    document
        .getElementById(
            "bulkApprove"
        )
        ?.addEventListener(
            "click",
            () =>
            bulkUpdate(
                "Approved"
            )
        );

    document
        .getElementById(
            "bulkReject"
        )
        ?.addEventListener(
            "click",
            () =>
            bulkUpdate(
                "Rejected"
            )
        );

    document
        .getElementById(
            "prevBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page--;

                renderInfluencers();

            }
        );

    document
        .getElementById(
            "nextBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                state.page++;

                renderInfluencers();

            }
        );
}

/* ==========================================
   STATUS UPDATE
========================================== */

function updateStatus(
    id,
    status
) {

    StorageManager.update(
        COLLECTIONS.INFLUENCERS,
        id,
        { status }
    );

    toast(
        `Influencer ${status}`,
        "success"
    );

    renderInfluencers();
}

/* ==========================================
   BULK UPDATE
========================================== */

function bulkUpdate(status) {

    const ids =
        [
            ...document.querySelectorAll(
                ".recordCheck:checked"
            )
        ].map(
            checkbox =>
            checkbox.value
        );

    if (!ids.length) {

        toast(
            "Select influencers first",
            "warning"
        );

        return;
    }

    StorageManager.bulkUpdate(
        COLLECTIONS.INFLUENCERS,
        ids,
        { status }
    );

    toast(
        `${ids.length} records updated`,
        "success"
    );

    renderInfluencers();
}

/* ==========================================
   DETAILS MODAL
========================================== */

function openDetails(id) {

    const item =
        StorageManager.find(
            COLLECTIONS.INFLUENCERS,
            id
        );

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = false;

    modal.innerHTML = `

        <div
            class="modal-backdrop"
            onclick="closeModal()">
        </div>

        <section class="modal">

            <header>

                <h2>${item.name}</h2>

                <button
                    onclick="closeModal()">

                    Close

                </button>

            </header>

            <div class="details">

                ${
                    Object.entries(item)
                    .map(
                        ([key,val]) => `
                        <div>
                            <dt>${key}</dt>
                            <dd>${val}</dd>
                        </div>
                    `
                    ).join("")
                }

            </div>

        </section>

    `;
}

function closeModal() {

    const modal =
        document.getElementById(
            "modalRoot"
        );

    modal.hidden = true;

    modal.innerHTML = "";
}

/* ==========================================
   TOAST
========================================== */

function toast(
    message,
    type = "success"
) {

    const stack =
        document.getElementById(
            "toastStack"
        );

    const toast =
        document.createElement(
            "div"
        );

    toast.className =
        `toast ${type}`;

    toast.textContent =
        message;

    stack.appendChild(
        toast
    );

    setTimeout(
        () => toast.remove(),
        3000
    );
}

/* ==========================================
   MOBILE SIDEBAR
========================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu) return;

    menu.addEventListener(
        "click",
        () =>
        document.body
            .classList
            .add("nav-open")
    );

    backdrop.addEventListener(
        "click",
        () =>
        document.body
            .classList
            .remove("nav-open")
    );
}