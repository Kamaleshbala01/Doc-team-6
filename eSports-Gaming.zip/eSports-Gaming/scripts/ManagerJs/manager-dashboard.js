"use strict";

/* ==========================================
   MANAGER DASHBOARD
========================================== */

document.addEventListener("DOMContentLoaded", () => {

    initializeSidebar();
    renderDashboard();
    bindTopbarActions();

});

/* ==========================================
   HELPERS
========================================== */

const dashboardView =
    document.getElementById("dashboardView");

const money = value =>
    new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0
    }).format(Number(value) || 0);

const formatDate = value =>
    value
        ? new Date(value).toLocaleDateString(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
          )
        : "-";

const rows = collection =>
    StorageManager.all(collection);

const sum = (items, key) =>
    items.reduce(
        (total, item) =>
            total + Number(item[key] || 0),
        0
    );

/* ==========================================
   COUNTS
========================================== */

function pendingCount() {

    return [
        COLLECTIONS.USERS,
        COLLECTIONS.INFLUENCERS,
        COLLECTIONS.BRANDS
    ]
        .flatMap(collection =>
            rows(collection)
        )
        .filter(item =>
            item.status === "Pending"
        )
        .length;
}

/* ==========================================
   DASHBOARD
========================================== */

function renderDashboard() {

    const users =
        rows(COLLECTIONS.USERS);

    const influencers =
        rows(COLLECTIONS.INFLUENCERS);

    const brands =
        rows(COLLECTIONS.BRANDS);

    const tournaments =
        rows(COLLECTIONS.TOURNAMENTS);

    const subscriptions =
        rows(COLLECTIONS.SUBSCRIPTIONS);

    const tickets =
        rows(COLLECTIONS.SUPPORT);

    const activities =
        rows(COLLECTIONS.ACTIVITY);

    const revenue =
        sum(subscriptions, "revenue");

    dashboardView.innerHTML = `

        <div class="stat-grid">

            ${statCard(
                "Total Users",
                users.length,
                "Platform Accounts"
            )}

            ${statCard(
                "Verified Users",
                users.filter(
                    x => x.status === "Approved"
                ).length,
                "Approved Profiles"
            )}

            ${statCard(
                "Pending Users",
                pendingCount(),
                "Needs Review"
            )}

            ${statCard(
                "Rejected Users",
                users.filter(
                    x => x.status === "Rejected"
                ).length,
                "Verification Denied"
            )}

            ${statCard(
                "Influencers",
                influencers.length,
                "Creator Partners"
            )}

            ${statCard(
                "Brands",
                brands.length,
                "Sponsor Accounts"
            )}

            ${statCard(
                "Tournaments",
                tournaments.length,
                "Events Tracked"
            )}

            ${statCard(
                "Revenue",
                money(revenue),
                "Monthly Revenue"
            )}

            ${statCard(
                "Support Tickets",
                tickets.filter(
                    x => x.status !== "Resolved"
                ).length,
                "Open Requests"
            )}

            ${statCard(
                "Subscriptions",
                subscriptions.reduce(
                    (t, x) =>
                        t + x.subscribers,
                    0
                ),
                "Active Seats"
            )}

        </div>

        <div class="chart-grid">

            ${chartCard(
                "User Distribution",
                "userDistribution"
            )}

            ${chartCard(
                "Verification Status",
                "verificationChart"
            )}

            ${chartCard(
                "Revenue",
                "revenueChart"
            )}

            ${chartCard(
                "Tournament Teams",
                "tournamentChart"
            )}

            ${chartCard(
                "Growth",
                "growthChart"
            )}

        </div>

        <div class="dashboard-grid">

            ${miniTable(
                "Recent Users",
                users.slice(0,6),
                [
                    "name",
                    "email",
                    "status"
                ]
            )}

            ${miniTable(
                "Recent Tournaments",
                tournaments.slice(0,6),
                [
                    "title",
                    "game",
                    "status"
                ]
            )}

            ${miniTable(
                "Support Tickets",
                tickets.slice(0,6),
                [
                    "subject",
                    "priority",
                    "status"
                ]
            )}

            <section class="panel">

                <h2>
                    Recent Activity
                </h2>

                <div class="timeline">

                    ${activities
                        .slice(0,7)
                        .map(timelineItem)
                        .join("")}

                </div>

            </section>

        </div>

    `;

    drawCharts();
}

/* ==========================================
   CARDS
========================================== */

function statCard(
    title,
    value,
    hint
) {

    return `

        <article class="stat-card">

            <span>${title}</span>

            <strong>${value}</strong>

            <small>${hint}</small>

        </article>

    `;
}

function chartCard(
    title,
    id
) {

    return `

        <section class="panel chart-card">

            <h2>${title}</h2>

            <canvas id="${id}"></canvas>

        </section>

    `;
}

/* ==========================================
   TIMELINE
========================================== */

function timelineItem(item) {

    return `

        <div class="timeline-item">

            <span></span>

            <div>

                <strong>
                    ${item.action}
                </strong>

                <small>
                    ${item.admin}
                    •
                    ${formatDate(
                        item.createdAt
                    )}
                </small>

            </div>

        </div>

    `;
}

/* ==========================================
   MINI TABLE
========================================== */

function miniTable(
    title,
    data,
    columns
) {

    return `

        <section class="panel">

            <h2>${title}</h2>

            <table>

                <thead>

                    <tr>

                        ${columns
                            .map(
                                col =>
                                `<th>${col}</th>`
                            )
                            .join("")}

                    </tr>

                </thead>

                <tbody>

                    ${
                        data.map(
                            row => `
                            <tr>

                                ${columns.map(
                                    col => `
                                    <td>
                                        ${formatCell(
                                            row[col],
                                            col
                                        )}
                                    </td>
                                `
                                ).join("")}

                            </tr>
                        `
                        ).join("")
                    }

                </tbody>

            </table>

        </section>

    `;
}

/* ==========================================
   FORMAT CELL
========================================== */

function formatCell(
    value,
    key
) {

    if (
        [
            "price",
            "revenue",
            "prizePool"
        ].includes(key)
    ) {
        return money(value);
    }

    if (key === "status") {

        return `
            <span
                class="badge ${String(value)
                    .toLowerCase()
                    .replaceAll(" ","-")}">
                ${value}
            </span>
        `;
    }

    return value ?? "-";
}

/* ==========================================
   CHARTS
========================================== */

function drawCharts() {

    if (!window.Chart) return;

    const users =
        rows(COLLECTIONS.USERS);

    const influencers =
        rows(COLLECTIONS.INFLUENCERS);

    const brands =
        rows(COLLECTIONS.BRANDS);

    const tournaments =
        rows(COLLECTIONS.TOURNAMENTS);

    const subscriptions =
        rows(COLLECTIONS.SUBSCRIPTIONS);

    createChart(
        "userDistribution",
        "doughnut",
        [
            "Users",
            "Influencers",
            "Brands"
        ],
        [
            users.length,
            influencers.length,
            brands.length
        ]
    );

    const approved =
        [...users, ...influencers, ...brands]
        .filter(
            item =>
                item.status === "Approved"
        )
        .length;

    const pending =
        [...users, ...influencers, ...brands]
        .filter(
            item =>
                item.status === "Pending"
        )
        .length;

    const rejected =
        [...users, ...influencers, ...brands]
        .filter(
            item =>
                item.status === "Rejected"
        )
        .length;

    createChart(
        "verificationChart",
        "pie",
        [
            "Approved",
            "Pending",
            "Rejected"
        ],
        [
            approved,
            pending,
            rejected
        ]
    );

    createChart(
        "revenueChart",
        "line",
        subscriptions.map(
            x => x.plan
        ),
        subscriptions.map(
            x => x.revenue
        )
    );

    createChart(
        "tournamentChart",
        "bar",
        tournaments.slice(0,8).map(
            x => x.game
        ),
        tournaments.slice(0,8).map(
            x => x.teams
        )
    );

    createChart(
        "growthChart",
        "line",
        [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun"
        ],
        [
            260,
            410,
            620,
            820,
            980,
            users.length +
            influencers.length +
            brands.length
        ]
    );
}

/* ==========================================
   CREATE CHART
========================================== */

function createChart(
    id,
    type,
    labels,
    data
) {

    const canvas =
        document.getElementById(id);

    if (!canvas) return;

    new Chart(canvas, {

        type,

        data: {

            labels,

            datasets: [{
                label: "Invictus",
                data,

                borderColor:"#06b6d4",

                backgroundColor:[
                    "#7c3aed",
                    "#06b6d4",
                    "#22c55e",
                    "#f59e0b",
                    "#ef4444",
                    "#8b5cf6",
                    "#14b8a6"
                ],

                tension:0.35,

                fill:type === "line"
            }]
        },

        options:{

            responsive:true,

            maintainAspectRatio:false,

            plugins:{
                legend:{
                    labels:{
                        color:"#f8fafc"
                    }
                }
            }
        }
    });
}

/* ==========================================
   TOPBAR BUTTONS
========================================== */

function bindTopbarActions() {

    const notification =
        document.getElementById(
            "notificationBtn"
        );

    const message =
        document.getElementById(
            "messageBtn"
        );

    if (notification) {

        notification.addEventListener(
            "click",
            () => {

                alert(
                    `${pendingCount()} pending verification requests`
                );

            }
        );
    }

    if (message) {

        message.addEventListener(
            "click",
            () => {

                alert(
                    "Inbox is clear"
                );

            }
        );
    }
}

/* ==========================================
   MOBILE SIDEBAR
========================================== */

function initializeSidebar() {

    const menu =
        document.getElementById(
            "mobileMenu"
        );

    const backdrop =
        document.getElementById(
            "mobileBackdrop"
        );

    if (!menu || !backdrop) return;

    menu.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .add("nav-open");

        }
    );

    backdrop.addEventListener(
        "click",
        () => {

            document.body
                .classList
                .remove("nav-open");

        }
    );
}