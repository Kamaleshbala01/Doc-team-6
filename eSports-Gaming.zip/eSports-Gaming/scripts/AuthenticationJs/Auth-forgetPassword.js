// ================= FORGOT PASSWORD =================

const forgotPasswordForm = document.getElementById("forgotPasswordForm");

if (forgotPasswordForm) {

    forgotPasswordForm.addEventListener("submit", function (e) {

        e.preventDefault();

        clearErrors();

        let valid = true;

        const email = document.getElementById("email");

        // Email Validation
        if (email.value.trim() === "") {

            showError(email, "Email address is required");
            valid = false;

        }
        else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {

            showError(email, "Enter a valid email address");
            valid = false;

        }

        // Redirect to OTP Page
        if (valid) {

            window.location.href = "otp-verification.html";

        }

    });

}

function showError(input, message) {

    const inputGroup = input.closest(".input-group");

    let error = inputGroup.querySelector(".error-message");

    if (!error) {

        error = document.createElement("small");
        error.className = "error-message";
        inputGroup.appendChild(error);

    }

    error.textContent = message;
    input.style.borderColor = "#ff4d4f";

}

function clearErrors() {

    document.querySelectorAll(".error-message").forEach(error => error.remove());

    document.querySelectorAll(".input-box input").forEach(input => {
        input.style.borderColor = "";
    });

}