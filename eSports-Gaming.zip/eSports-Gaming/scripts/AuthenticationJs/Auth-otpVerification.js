// ===========================
// Generate Random OTP
// ===========================

const generatedOTP = Math.floor(100000 + Math.random() * 900000).toString();

console.log("Generated OTP:", generatedOTP);

// ===========================
// OTP Verification
// ===========================

const otpForm = document.getElementById("otpForm");

if (otpForm) {

    otpForm.addEventListener("submit", function (e) {

        e.preventDefault();

        clearOTPError();

        const inputs = document.querySelectorAll(".otp-input");

        let enteredOTP = "";

        inputs.forEach(input => {
            enteredOTP += input.value;
        });

        if (enteredOTP.length !== 6) {

            showOTPError("Please enter the complete 6-digit OTP.");
            return;

        }

        if (enteredOTP !== generatedOTP) {

            showOTPError("Invalid OTP. Please try again.");
            return;

        }

        // Success
        window.location.href = "reset-password.html";

    });

}

// ===========================
// OTP Input Auto Move
// ===========================

const otpInputs = document.querySelectorAll(".otp-input");

otpInputs.forEach((input, index) => {

    input.addEventListener("input", function () {

        this.value = this.value.replace(/[^0-9]/g, "");

        if (this.value.length === 1 && index < otpInputs.length - 1) {

            otpInputs[index + 1].focus();

        }

    });

    input.addEventListener("keydown", function (e) {

        if (e.key === "Backspace" &&
            this.value === "" &&
            index > 0) {

            otpInputs[index - 1].focus();

        }

    });

});

// ===========================
// Resend OTP
// ===========================

document.getElementById("resendOTP").addEventListener("click", function () {

    alert("A new OTP has been generated.");

    location.reload();

});

// ===========================
// Countdown Timer
// ===========================

let time = 120;

const timer = document.getElementById("timer");

const countdown = setInterval(function () {

    const minutes = Math.floor(time / 60);

    const seconds = time % 60;

    timer.innerHTML =
        `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    if (time <= 0) {

        clearInterval(countdown);

        timer.innerHTML = "Expired";

    }

    time--;

}, 1000);

// ===========================
// Error Functions
// ===========================

function showOTPError(message) {

    let error = document.getElementById("otpError");

    if (!error) {

        error = document.createElement("small");

        error.id = "otpError";

        error.className = "error-message";

        document.querySelector(".otp-container")
            .insertAdjacentElement("afterend", error);

    }

    error.textContent = message;

}

function clearOTPError() {

    const error = document.getElementById("otpError");

    if (error) {

        error.remove();

    }

}