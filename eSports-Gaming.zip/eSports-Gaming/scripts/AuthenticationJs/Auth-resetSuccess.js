// ================================
// Password Reset Success Countdown
// ================================

let timeLeft = 5;

// <span id="countdown">5</span>
const countdown = document.getElementById("countdown");

const timer = setInterval(function () {

    countdown.textContent = timeLeft;

    timeLeft--;

    if (timeLeft < 0) {

        clearInterval(timer);

        window.location.href = "login.html";

    }

}, 1000);

// ================================
// Redirect Now Button (Optional)
// ================================

const loginBtn = document.getElementById("loginNow");

if (loginBtn) {

    loginBtn.addEventListener("click", function () {

        window.location.href = "login.html";

    });

}
