// ================================
// Reset Password Validation
// ================================

const resetForm = document.getElementById("resetPasswordForm");

if (resetForm) {

    resetForm.addEventListener("submit", function (e) {

        e.preventDefault();

        clearErrors();

        let valid = true;

        const newPassword = document.getElementById("newPassword");
        const confirmPassword = document.getElementById("confirmPassword");

        const password = newPassword.value.trim();

        // Minimum 8 characters
        if (password.length < 8) {
            showError(newPassword, "Password must contain at least 8 characters.");
            valid = false;
        }

        // Uppercase
        else if (!/[A-Z]/.test(password)) {
            showError(newPassword, "Password must contain at least one uppercase letter.");
            valid = false;
        }

        // Lowercase
        else if (!/[a-z]/.test(password)) {
            showError(newPassword, "Password must contain at least one lowercase letter.");
            valid = false;
        }

        // Number
        else if (!/[0-9]/.test(password)) {
            showError(newPassword, "Password must contain at least one number.");
            valid = false;
        }

        // Special Character
        else if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
            showError(newPassword, "Password must contain at least one special character.");
            valid = false;
        }

        // Confirm Password
        if (confirmPassword.value.trim() === "") {

            showError(confirmPassword, "Please confirm your password.");
            valid = false;

        }

        else if (password !== confirmPassword.value.trim()) {

            showError(confirmPassword, "Passwords do not match.");
            valid = false;

        }

        // Success
        if (valid) {

            window.location.href = "password-reset-success.html";

        }

    });

}

// ================================
// Show Error
// ================================

function showError(input, message) {

    const inputGroup = input.closest(".input-group");

    let error = inputGroup.querySelector(".error-message");

    if (!error) {

        error = document.createElement("small");

        error.className = "error-message";

        inputGroup.appendChild(error);

    }

    error.textContent = message;

    input.parentElement.style.borderColor = "#EF4444";

}

// ================================
// Clear Errors
// ================================

function clearErrors() {

    document.querySelectorAll(".error-message").forEach(error => {

        error.remove();

    });

    document.querySelectorAll(".input-box").forEach(box => {

        box.style.borderColor = "#334155";

    });

}

const passwordInput = document.getElementById("newPassword");
const toggleButton = document.querySelector(".password-toggle");
const icon = toggleButton.querySelector("i");

toggleButton.addEventListener("click", () => {
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
    } else {
        passwordInput.type = "password";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
    }
});