const form = document.getElementById("brandRegisterForm");
console.log("Brand Register loaded");
if (form) {

    form.addEventListener("submit", function (e) {

        e.preventDefault();

        clearErrors();

        let valid = true;

        const brandName = document.getElementById("brandName");
        const website = document.getElementById("website");
        const lei = document.getElementById("lei");
        const email = document.getElementById("email");
        const phone = document.getElementById("phone");
        const address = document.getElementById("address");
        const terms = document.getElementById("terms");

        // Brand Name
        if (brandName.value.trim().length < 3) {

            showError(brandName, "Brand name must be at least 3 characters.");
            valid = false;

        }

        // Website
        const websitePattern = /^https?:\/\/.+/;

        if (!websitePattern.test(website.value.trim())) {

            showError(website, "Enter a valid website URL.");
            valid = false;

        }

        // LEI
        if (lei.value.trim().length < 8) {

            showError(lei, "Enter a valid LEI number.");
            valid = false;

        }

        // Email
        const emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

        if (email.value.trim() === "") {

            showError(email, "Email address is required.");
            valid = false;

        }

        else if (!emailPattern.test(email.value.trim())) {

            showError(email, "Enter a valid email address.");
            valid = false;

        }

        // Phone
        if (!/^[6-9]\d{9}$/.test(phone.value.trim())) {

            showError(phone, "Enter a valid 10-digit phone number.");
            valid = false;

        }

        // Address
        if (address.value.trim().length < 10) {

            showError(address, "Please enter your business address.");
            valid = false;

        }

        // Terms
        if (!terms.checked) {

            showCheckboxError(terms, "Please accept the Terms & Conditions.");
            valid = false;

        }

        // Success
        if (valid) {

            window.location.href = "login.html";

        }

    });

}


// ==========================
// Show Input Error
// ==========================

function showError(input, message) {

    const group = input.closest(".input-group");

    let error = group.querySelector(".error-message");

    if (!error) {

        error = document.createElement("small");

        error.className = "error-message";

        group.appendChild(error);

    }

    error.textContent = message;

}


// ==========================
// Checkbox Error
// ==========================

function showCheckboxError(input, message) {

    const group = input.closest(".checkbox-group");

    let error = group.querySelector(".error-message");

    if (!error) {

        error = document.createElement("small");

        error.className = "error-message";

        group.appendChild(error);

    }

    error.textContent = message;

}


// ==========================
// Clear Errors
// ==========================

function clearErrors() {

    document.querySelectorAll(".error-message").forEach(error => {

        error.remove();

    });

}
