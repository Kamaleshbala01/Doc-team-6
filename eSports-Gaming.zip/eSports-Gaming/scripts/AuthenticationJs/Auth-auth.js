const form = document.getElementById("registerForm");

if(form){
form.addEventListener("submit", function(e){

    e.preventDefault();

    clearErrors();

    let valid = true;

    const fullName = document.getElementById("fullName");
    const username = document.getElementById("username");
    const email = document.getElementById("email");
    const mobile = document.getElementById("mobile");
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirmPassword");
    const terms = document.getElementById("terms");

    if(fullName.value.trim().length < 3){
        showError(fullName,"fullNameError","Full name must contain at least 3 characters");
        valid = false;
    }

    if(username.value.trim().length < 4){
        showError(username,"usernameError","Username must be at least 4 characters");
        valid = false;
    }

    const emailRegex=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if(!emailRegex.test(email.value.trim())){
        showError(email,"emailError","Enter a valid email address");
        valid=false;
    }

    const mobileRegex=/^[6-9]\d{9}$/;

    if(!mobileRegex.test(mobile.value.trim())){
        showError(mobile,"mobileError","Enter a valid mobile number");
        valid=false;
    }

    if(password.value.length<8){
        showError(password,"passwordError","Password must contain at least 8 characters");
        valid=false;
    }

    if(password.value!==confirmPassword.value){
        showError(confirmPassword,"confirmPasswordError","Passwords do not match");
        valid=false;
    }

    if(!terms.checked){
        document.getElementById("termsError").textContent="Please accept Terms & Conditions";
        valid=false;
    }

    if(valid){
        if(email.value === "organizer@gmail.com")
            window.location.href="../../components/authentication-authorization/login.html";
        else if(email.value === "admin@gmail.com") window.location.href="../../components/admin-module/admin-index.html";
        else if(email.value === "brand@gmail.com") window.location.href="../../components/brand-module/brand-dashboard.html";
        else  window.location.href="login.html";
    }

});

function showError(input,errorId,message){

    document.getElementById(errorId).textContent=message;
    input.parentElement.classList.add("error-border");

}

function clearErrors(){

    document.querySelectorAll(".error").forEach(e=>e.textContent="");

    document.querySelectorAll(".input-box").forEach(box=>{
        box.classList.remove("error-border");
    });

}
}

const loginForm = document.getElementById("loginForm");

if(loginForm){

    loginForm.addEventListener("submit", function(e){

        e.preventDefault();

        clearLoginErrors();

        let valid = true;

        const email = document.getElementById("email");
        const password = document.getElementById("password");

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if(!emailRegex.test(email.value.trim())){
            showLoginError(email,"emailError","Enter a valid email address");
            valid = false;
        }

        if(password.value.length < 8){
            showLoginError(password,"passwordError","Password must be at least 8 characters");
            valid = false;
        }

        if(valid){
            if(valid && email.value ==="admin@gmail.com" && password.value==="Admin@123"){
                window.location.href="../../components/admin-module/admin-index.html";
            }else if(valid && email.value === "organizer@gmail.com"  && password.value==="Organizer@123")
                window.location.href="../../components/tournament-management/tournament-index.html";
            else if(email.value === "brand@gmail.com"  && password.value==="Brand@123")
                 window.location.href="../../components/brand-module/brand-dashboard.html";
            else if(email.value  === "user@gmail.com"  && password.value==="User@123") 
                 window.location.href="../../components/user-module/user-dashboard.html";
            else if(email.value  === "manager@gmail.com"  && password.value==="Manager@123") 
                 window.location.href="../../components/manager-module/manager-index.html";
            else
            showLoginError(password,"passwordError","Incorrect Password");
        }

    });

}

function showLoginError(input,errorId,message){

    document.getElementById(errorId).textContent = message;
    input.parentElement.classList.add("error-border");

}

function clearLoginErrors(){

    document.querySelectorAll(".error").forEach(error=>{
        error.textContent = "";
    });

    document.querySelectorAll(".input-box").forEach(box=>{
        box.classList.remove("error-border");
    });

}
document.addEventListener("DOMContentLoaded", () => {

    const passwordInput = document.getElementById("password");
    const toggleBtn = document.querySelector(".password-toggle");
    const icon = toggleBtn.querySelector("i");

    toggleBtn.addEventListener("click", () => {

        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            icon.classList.remove("fa-eye");
            icon.classList.add("fa-eye-slash");
        } else {
            passwordInput.type = "password";
            icon.classList.remove("fa-eye-slash");
            icon.classList.add("fa-eye");
        }

    });

});

