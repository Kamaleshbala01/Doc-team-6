# Invictus – Gaming & Esports Platform (Angular)

This is an Angular 18 (standalone components) conversion of the original static
HTML/CSS/JS "eSports-Gaming" prototype. The visual design, color theme,
typography, and layout are preserved from the original CSS; the app logic
has been rebuilt using idiomatic Angular (Router, services, guards,
reactive-style forms) instead of direct DOM manipulation.

## Getting started

```bash
npm install
ng serve
```

Then open http://localhost:4200.

> This project was hand-authored in a sandboxed environment without network
> access, so `npm install` / a real Angular CLI build have not been run
> against it here. Double‑check `npm install && ng build` locally — the
> structure follows the standard Angular CLI v18 application layout, but if
> your installed CLI version differs you may need to tweak `angular.json`
> slightly (e.g. builder names changed between Angular 17 and 18).

## Demo accounts

The login page simulates a backend. Use these credentials to reach each
role's dashboard:

| Role                 | Email                     | Password         |
|----------------------|----------------------------|------------------|
| Player (User)         | user@gmail.com             | User@123         |
| Influencer             | influencer@gmail.com       | Influencer@123   |
| Brand                  | brand@gmail.com            | Brand@123        |
| Tournament Organizer    | organizer@gmail.com        | Organizer@123    |
| Admin                   | admin@gmail.com            | Admin@123        |

## Project structure

```
src/app/
 ├── core/              # constants (roles, nav config)
 ├── shared/             # sidebar, header, footer, breadcrumb, loader, placeholder page
 ├── layouts/            # dashboard-layout, public-layout, auth-layout
 ├── authentication/     # login, register, brand-register, forgot/reset/otp, policy, 404
 ├── user/               # Player dashboard + profile/become-influencer routes
 ├── influencer/         # Influencer routes (placeholder pages)
 ├── brand/              # Brand dashboard + campaign/payment routes
 ├── tournament-organizer/ # Tournament dashboard + tournament/match/team routes
 ├── admin/              # Admin dashboard + users/brands/influencers/tournaments/reports
 ├── services/           # UserService, BrandService, InfluencerService, TournamentService,
 │                        #   AdminService, AuthService – all return mock Observables today
 ├── guards/             # authGuard, roleGuard
 ├── models/             # User, Auth, Tournament, Campaign, DashboardStat
 ├── interceptors/       # authInterceptor (attaches mock bearer token)
 ├── app.routes.ts
 └── app.component.ts
```

## What's fully built vs. placeholder

Per the brief, the primary flagship screens are fully converted with the
original UI preserved:

- Landing page, 404, Privacy Policy
- Full authentication flow (login, register, brand register, forgot
  password, OTP verification, reset password, success screen)
- One full dashboard per role: `/user/dashboard`, `/brand/dashboard`,
  `/tournament-organizer/dashboard`, `/admin/dashboard`

Every other route in the spec (profile pages, campaign management, find
influencer, create tournament, matches, teams, users/brands/influencers
admin lists, reports, etc.) is wired up in the router and reachable from
each role's sidebar, rendering a placeholder component (`<h1>{{ title }}
</h1>`) ready for you to flesh out — exactly as requested in the brief's
"pages without implementation" instruction.

## Wiring up a real backend

Swap the `of(...)` mock calls in `src/app/services/*.service.ts` for real
`HttpClient` calls against `environment.apiBaseUrl`. `AuthService` already
persists a token to `localStorage` and `authInterceptor` attaches it to
every outgoing request, so very little else needs to change.
