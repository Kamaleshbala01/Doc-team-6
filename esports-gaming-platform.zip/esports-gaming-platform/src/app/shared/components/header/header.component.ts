import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

/** Dashboard topbar shown at the top of every `.main-content` area. */
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html'
})
export class HeaderComponent {
  @Input() title = 'Welcome Back 👋';
  @Input() subtitle = '';
  @Input() userName = 'Demo User';
  @Input() avatarUrl = 'assets/images/profile.jpeg';
}
