import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { BreadcrumbComponent } from '../breadcrumb/breadcrumb.component';

/**
 * Generic placeholder used for every feature page that doesn't have a
 * full implementation yet (per the project brief). Reads its heading
 * from the matched route's `data.title` so one component can serve
 * every not-yet-built page instead of duplicating near-identical files.
 */
@Component({
  selector: 'app-placeholder-page',
  standalone: true,
  imports: [CommonModule, HeaderComponent, BreadcrumbComponent],
  templateUrl: './placeholder-page.component.html'
})
export class PlaceholderPageComponent {
  title: string;

  constructor(private route: ActivatedRoute) {
    this.title = (this.route.snapshot.data['title'] as string) ?? 'Coming Soon';
  }
}
