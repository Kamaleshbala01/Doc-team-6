import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, NavigationEnd, Router, RouterLink } from '@angular/router';
import { filter, map, startWith } from 'rxjs';
import { AsyncPipe } from '@angular/common';

interface Crumb {
  label: string;
  url: string;
}

/** Simple route-driven breadcrumb trail, shown under the topbar on inner pages. */
@Component({
  selector: 'app-breadcrumb',
  standalone: true,
  imports: [CommonModule, RouterLink, AsyncPipe],
  templateUrl: './breadcrumb.component.html'
})
export class BreadcrumbComponent implements OnInit {
  crumbs$ = this.router.events.pipe(
    filter((event) => event instanceof NavigationEnd),
    startWith(null),
    map(() => this.buildCrumbs())
  );

  constructor(private router: Router, private route: ActivatedRoute) {}

  ngOnInit(): void {}

  private buildCrumbs(): Crumb[] {
    const segments = this.router.url.split('?')[0].split('/').filter(Boolean);
    let path = '';
    return segments.map((segment) => {
      path += `/${segment}`;
      const label = segment
        .replace(/-/g, ' ')
        .replace(/\b\w/g, (c) => c.toUpperCase());
      return { label, url: path };
    });
  }
}
