import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

/** Reusable loading spinner overlay. Toggle with the `visible` input. */
@Component({
  selector: 'app-loader',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './loader.component.html'
})
export class LoaderComponent {
  @Input() visible = false;
  @Input() message = 'Loading...';
}
