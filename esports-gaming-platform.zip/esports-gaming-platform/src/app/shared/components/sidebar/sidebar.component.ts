import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { UserRole } from '../../../core/constants/roles';
import { NAV_ITEMS, NavItem } from '../../../core/constants/nav-items';

/**
 * Role-aware sidebar, reused across every dashboard layout.
 * Pass the active role and it renders that role's nav items,
 * highlighting the current route the same way the original
 * static `.active` class did.
 */
@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './sidebar.component.html'
})
export class SidebarComponent {
  @Input({ required: true }) role!: UserRole;

  get navItems(): NavItem[] {
    return NAV_ITEMS[this.role] ?? [];
  }
}
