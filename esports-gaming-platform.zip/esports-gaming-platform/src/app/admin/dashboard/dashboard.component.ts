import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../../shared/components/header/header.component';
import { AdminService } from '../../services/admin.service';
import { DashboardStat } from '../../models/dashboard-stat.model';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, HeaderComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class AdminDashboardComponent implements OnInit {
  stats: DashboardStat[] = [];

  recentActivity = [
    { label: 'New brand "NovaTech" pending approval', time: '12 min ago' },
    { label: 'Tournament "Winter Championship" published', time: '1 hr ago' },
    { label: 'Influencer verification approved for Scout', time: '3 hrs ago' },
    { label: 'Payout batch processed for 24 users', time: 'Yesterday' }
  ];

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.adminService.getDashboardStats().subscribe((stats) => (this.stats = stats));
  }
}
