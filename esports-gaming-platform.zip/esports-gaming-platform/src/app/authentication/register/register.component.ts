import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  fullName = '';
  username = '';
  email = '';
  mobile = '';
  password = '';
  confirmPassword = '';
  terms = false;

  showPassword = false;
  showConfirmPassword = false;
  submitting = false;

  errors: Record<string, string> = {};

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit(): void {
    this.errors = {};
    let valid = true;

    if (this.fullName.trim().length < 3) {
      this.errors['fullName'] = 'Full name must contain at least 3 characters';
      valid = false;
    }

    if (this.username.trim().length < 4) {
      this.errors['username'] = 'Username must be at least 4 characters';
      valid = false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(this.email.trim())) {
      this.errors['email'] = 'Enter a valid email address';
      valid = false;
    }

    const mobileRegex = /^[6-9]\d{9}$/;
    if (!mobileRegex.test(this.mobile.trim())) {
      this.errors['mobile'] = 'Enter a valid mobile number';
      valid = false;
    }

    if (this.password.length < 8) {
      this.errors['password'] = 'Password must contain at least 8 characters';
      valid = false;
    }

    if (this.password !== this.confirmPassword) {
      this.errors['confirmPassword'] = 'Passwords do not match';
      valid = false;
    }

    if (!this.terms) {
      this.errors['terms'] = 'Please accept Terms & Conditions';
      valid = false;
    }

    if (!valid) return;

    this.submitting = true;
    this.auth
      .register({
        fullName: this.fullName,
        username: this.username,
        email: this.email,
        mobile: this.mobile,
        password: this.password,
        confirmPassword: this.confirmPassword
      })
      .subscribe(() => {
        this.submitting = false;
        this.router.navigateByUrl('/user/dashboard');
      });
  }
}
