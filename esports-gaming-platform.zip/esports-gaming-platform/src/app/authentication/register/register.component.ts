import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  fullName = '';
  username = '';
  email = '';
  mobile = '';
  password = '';
  confirmPassword = '';
  terms = false;

  showPassword = false;
  showConfirmPassword = false;
  submitting = false;
  apiError = '';

  errors: Record<string, string> = {};

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit(): void {
    this.errors = {};
    this.apiError = '';
    let valid = true;

    if (this.fullName.trim().length < 3) {
      this.errors['fullName'] = 'Full name must contain at least 3 characters';
      valid = false;
    }

    if (this.username.trim().length < 4) {
      this.errors['username'] = 'Username must be at least 4 characters';
      valid = false;
    } else if (!/^[a-zA-Z0-9_]+$/.test(this.username.trim())) {
      this.errors['username'] = 'Username can only contain letters, numbers and underscores';
      valid = false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(this.email.trim())) {
      this.errors['email'] = 'Enter a valid email address';
      valid = false;
    }

    const mobileRegex = /^[6-9]\d{9}$/;
    if (!mobileRegex.test(this.mobile.trim())) {
      this.errors['mobile'] = 'Enter a valid 10-digit mobile number';
      valid = false;
    }

    if (this.password.length < 8) {
      this.errors['password'] = 'Password must contain at least 8 characters';
      valid = false;
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(this.password)) {
      this.errors['password'] = 'Include at least one uppercase letter, one lowercase letter and one number';
      valid = false;
    }

    if (this.confirmPassword.length === 0) {
      this.errors['confirmPassword'] = 'Please confirm your password';
      valid = false;
    } else if (this.password !== this.confirmPassword) {
      this.errors['confirmPassword'] = 'Passwords do not match';
      valid = false;
    }

    if (!this.terms) {
      this.errors['terms'] = 'Please accept Terms & Conditions';
      valid = false;
    }

    if (!valid) return;

    this.submitting = true;
    this.auth
      .register({
        fullName: this.fullName.trim(),
        username: this.username.trim(),
        email: this.email.trim(),
        mobile: this.mobile.trim(),
        password: this.password,
        confirmPassword: this.confirmPassword
      })
      .subscribe({
        next: () => {
          this.submitting = false;
          this.router.navigateByUrl('/user/dashboard');
        },
        error: (err) => {
          this.submitting = false;
          this.apiError = this.resolveApiErrorMessage(err);
        }
      });
  }

  private resolveApiErrorMessage(err: any): string {
    if (err?.status === 409) {
      return err.message ?? 'An account with these details already exists.';
    }
    if (err?.status === 0) {
      return 'Unable to reach the server. Check your connection and try again.';
    }
    if (typeof err?.status === 'number' && err.status >= 500) {
      return 'Something went wrong on our end. Please try again shortly.';
    }
    return err?.message ?? 'Registration failed. Please try again.';
  }
}
