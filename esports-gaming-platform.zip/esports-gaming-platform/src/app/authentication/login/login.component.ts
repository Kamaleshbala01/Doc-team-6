import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { UserRole } from '../../core/constants/roles';

/**
 * Demo credentials preserved from the original static prototype so the
 * five role-based dashboards can still be reached without a real backend.
 */
const DEMO_ACCOUNTS: Record<string, { password: string; role: UserRole; home: string }> = {
  'admin@gmail.com': { password: 'Admin@123', role: UserRole.ADMIN, home: '/admin/dashboard' },
  'organizer@gmail.com': { password: 'Organizer@123', role: UserRole.TOURNAMENT_ORGANIZER, home: '/tournament-organizer/dashboard' },
  'brand@gmail.com': { password: 'Brand@123', role: UserRole.BRAND, home: '/brand/dashboard' },
  'user@gmail.com': { password: 'User@123', role: UserRole.USER, home: '/user/dashboard' },
  'influencer@gmail.com': { password: 'Influencer@123', role: UserRole.INFLUENCER, home: '/influencer/dashboard' }
};

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  email = '';
  password = '';
  remember = false;
  showPassword = false;

  emailError = '';
  passwordError = '';
  apiError = '';
  submitting = false;

  constructor(private auth: AuthService, private router: Router) {}

  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  onSubmit(): void {
    this.clearErrors();
    let valid = true;

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(this.email.trim())) {
      this.emailError = 'Enter a valid email address';
      valid = false;
    }

    if (this.password.length < 8) {
      this.passwordError = 'Password must be at least 8 characters';
      valid = false;
    }

    if (!valid) return;

    const account = DEMO_ACCOUNTS[this.email.trim().toLowerCase()];
    if (!account || account.password !== this.password) {
      this.passwordError = 'Incorrect email or password. Try user@gmail.com / User@123';
      return;
    }

    this.submitting = true;
    this.auth.login({ email: this.email.trim(), password: this.password }).subscribe({
      next: () => {
        this.submitting = false;
        this.router.navigateByUrl(account.home);
      },
      error: (err) => {
        this.submitting = false;
        this.apiError = this.resolveApiErrorMessage(err);
      }
    });
  }

  private resolveApiErrorMessage(err: any): string {
    if (err?.status === 401) {
      return 'Incorrect email or password.';
    }
    if (err?.status === 0) {
      return 'Unable to reach the server. Check your connection and try again.';
    }
    if (typeof err?.status === 'number' && err.status >= 500) {
      return 'Something went wrong on our end. Please try again shortly.';
    }
    return err?.message ?? 'Login failed. Please try again.';
  }

  private clearErrors(): void {
    this.emailError = '';
    this.passwordError = '';
    this.apiError = '';
  }
}
