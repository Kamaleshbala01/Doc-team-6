import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-otp-verification',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './otp-verification.component.html',
  styleUrl: './otp-verification.component.css'
})
export class OtpVerificationComponent implements OnInit, OnDestroy {
  digits = ['', '', '', '', '', ''];
  secondsLeft = 120;
  error = '';
  private timerHandle?: ReturnType<typeof setInterval>;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.startTimer();
  }

  ngOnDestroy(): void {
    if (this.timerHandle) clearInterval(this.timerHandle);
  }

  get timerLabel(): string {
    const m = Math.floor(this.secondsLeft / 60).toString().padStart(2, '0');
    const s = (this.secondsLeft % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  }

  onDigitInput(index: number, event: Event): void {
    const input = event.target as HTMLInputElement;
    this.digits[index] = input.value.slice(-1);
    if (input.value && index < this.digits.length - 1) {
      const next = input.parentElement?.querySelectorAll('input')[index + 1] as HTMLInputElement | undefined;
      next?.focus();
    }
  }

  resendOtp(): void {
    this.secondsLeft = 120;
    this.startTimer();
  }

  onSubmit(): void {
    if (this.digits.some((d) => !d)) {
      this.error = 'Enter the complete 6-digit code';
      return;
    }
    this.error = '';
    this.router.navigateByUrl('/reset-password');
  }

  private startTimer(): void {
    if (this.timerHandle) clearInterval(this.timerHandle);
    this.timerHandle = setInterval(() => {
      if (this.secondsLeft > 0) {
        this.secondsLeft--;
      } else if (this.timerHandle) {
        clearInterval(this.timerHandle);
      }
    }, 1000);
  }
}
