import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-password-reset-success',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './password-reset-success.component.html',
  styleUrl: './password-reset-success.component.css'
})
export class PasswordResetSuccessComponent implements OnInit, OnDestroy {
  countdown = 5;
  private handle?: ReturnType<typeof setInterval>;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.handle = setInterval(() => {
      this.countdown--;
      if (this.countdown <= 0) {
        clearInterval(this.handle);
        this.router.navigateByUrl('/login');
      }
    }, 1000);
  }

  ngOnDestroy(): void {
    if (this.handle) clearInterval(this.handle);
  }
}
