import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-brand-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './brand-register.component.html',
  styleUrl: './brand-register.component.css'
})
export class BrandRegisterComponent {
  brandType = 'tournament-organiser';
  brandName = '';
  website = '';
  lei = '';
  email = '';
  phone = '';
  password = '';
  confirmPassword = '';
  address = '';
  terms = false;

  submitting = false;
  errors: Record<string, string> = {};

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit(): void {
    this.errors = {};
    let valid = true;

    if (!this.brandName.trim()) { this.errors['brandName'] = 'Brand name is required'; valid = false; }
    if (!this.website.trim()) { this.errors['website'] = 'Website URL is required'; valid = false; }
    if (!this.lei.trim()) { this.errors['lei'] = 'LEI number is required'; valid = false; }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(this.email.trim())) { this.errors['email'] = 'Enter a valid email address'; valid = false; }

    if (this.password.length < 8) { this.errors['password'] = 'Password must contain at least 8 characters'; valid = false; }
    if (this.password !== this.confirmPassword) { this.errors['confirmPassword'] = 'Passwords do not match'; valid = false; }
    if (!this.address.trim()) { this.errors['address'] = 'Business address is required'; valid = false; }
    if (!this.terms) { this.errors['terms'] = 'Please accept Terms & Conditions'; valid = false; }

    if (!valid) return;

    this.submitting = true;
    this.auth
      .register({
        fullName: this.brandName,
        username: this.brandName,
        email: this.email,
        mobile: this.phone,
        password: this.password,
        confirmPassword: this.confirmPassword
      })
      .subscribe(() => {
        this.submitting = false;
        this.router.navigateByUrl('/brand/dashboard');
      });
  }
}
