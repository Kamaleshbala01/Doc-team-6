import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { HeaderComponent } from '../../shared/components/header/header.component';
import { UserService } from '../../services/user.service';
import { DashboardStat } from '../../models/dashboard-stat.model';

@Component({
  selector: 'app-user-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, HeaderComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class UserDashboardComponent implements OnInit {
  stats: DashboardStat[] = [];

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.userService.getDashboardStats().subscribe((stats) => (this.stats = stats));
  }
}
