import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { UserRole } from '../core/constants/roles';

/**
 * Restricts a route to a set of allowed roles, passed in route data as `roles`.
 * Placeholder logic based on the mock role stored by AuthService.
 *
 * Example route config:
 *   { path: 'dashboard', canActivate: [roleGuard], data: { roles: [UserRole.ADMIN] } }
 */
export const roleGuard: CanActivateFn = (route) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const allowedRoles = (route.data?.['roles'] as UserRole[] | undefined) ?? [];
  const currentRole = auth.getRole();

  if (allowedRoles.length === 0 || (currentRole && allowedRoles.includes(currentRole))) {
    return true;
  }

  router.navigate(['/login']);
  return false;
};
