import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { HeaderComponent } from '../../shared/components/header/header.component';
import { BrandService } from '../../services/brand.service';
import { DashboardStat } from '../../models/dashboard-stat.model';

@Component({
  selector: 'app-brand-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, HeaderComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class BrandDashboardComponent implements OnInit {
  stats: DashboardStat[] = [];

  constructor(private brandService: BrandService) {}

  ngOnInit(): void {
    this.brandService.getDashboardStats().subscribe((stats) => (this.stats = stats));
  }
}
