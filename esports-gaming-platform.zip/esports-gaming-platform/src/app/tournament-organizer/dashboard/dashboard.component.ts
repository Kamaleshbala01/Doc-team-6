import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { HeaderComponent } from '../../shared/components/header/header.component';
import { TournamentService } from '../../services/tournament.service';
import { DashboardStat } from '../../models/dashboard-stat.model';

@Component({
  selector: 'app-tournament-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, HeaderComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class TournamentDashboardComponent implements OnInit {
  stats: DashboardStat[] = [];

  recentTournaments = [
    { name: 'Summer Clash 2026', game: 'Valorant', teams: 32, status: 'live', prize: '₹12,00,000' },
    { name: 'BGMI Pro League', game: 'BGMI', teams: 64, status: 'upcoming', prize: '₹15,00,000' },
    { name: 'Rocket Masters', game: 'Rocket League', teams: 16, status: 'completed', prize: '₹75,000' },
    { name: 'COD Open', game: 'Call of Duty', teams: 48, status: 'upcoming', prize: '₹1,20,000' }
  ];

  latestRegistrations = [
    { team: 'Team Alpha', game: 'Valorant', status: 'Verified' },
    { team: 'Night Hawks', game: 'BGMI', status: 'Pending' },
    { team: 'Team Nexus', game: 'CS2', status: 'Verified' }
  ];

  recentActivity = ['Tournament Published', 'Sponsor Joined', '25 Teams Registered', 'Brackets Generated', 'Prize Pool Updated'];

  constructor(private tournamentService: TournamentService) {}

  ngOnInit(): void {
    this.tournamentService.getDashboardStats().subscribe((stats) => (this.stats = stats));
  }
}
