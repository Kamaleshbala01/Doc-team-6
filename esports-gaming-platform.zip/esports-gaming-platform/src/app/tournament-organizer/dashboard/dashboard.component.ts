import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { HeaderComponent } from '../../shared/components/header/header.component';
import { TournamentService } from '../../services/tournament.service';
import { DashboardStat } from '../../models/dashboard-stat.model';
import { TournamentResponse } from '../../models/tournament.model';
import { TOURNAMENT_TYPE_LABELS } from '../../models/tournament-enums.model';

@Component({
  selector: 'app-tournament-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, HeaderComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class TournamentDashboardComponent implements OnInit {
  stats: DashboardStat[] = [];
  recentTournaments: TournamentResponse[] = [];
  loadingTournaments = true;
  loadError = '';

  readonly typeLabels = TOURNAMENT_TYPE_LABELS;

  // No backend endpoint exists yet for team registrations or an activity
  // feed (that would span team-service / notification-service), so these
  // two widgets stay illustrative until those integrations are wired up.
  latestRegistrations = [
    { team: 'Team Alpha', game: 'Valorant', status: 'Verified' },
    { team: 'Night Hawks', game: 'BGMI', status: 'Pending' },
    { team: 'Team Nexus', game: 'CS2', status: 'Verified' }
  ];

  recentActivity = ['Tournament Published', 'Sponsor Joined', '25 Teams Registered', 'Brackets Generated', 'Prize Pool Updated'];

  constructor(private tournamentService: TournamentService) {}

  ngOnInit(): void {
    this.tournamentService.getDashboardStats().subscribe({
      next: (stats) => (this.stats = stats),
      error: () => (this.stats = [])
    });

    this.tournamentService.getMyTournaments().subscribe({
      next: (tournaments) => {
        this.recentTournaments = tournaments
          .slice()
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          .slice(0, 5);
        this.loadingTournaments = false;
      },
      error: () => {
        this.loadError = 'Could not load your tournaments right now.';
        this.loadingTournaments = false;
      }
    });
  }

  statusClass(status: string): string {
    return status.toLowerCase();
  }
}
