import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HeaderComponent } from '../../shared/components/header/header.component';
import { BreadcrumbComponent } from '../../shared/components/breadcrumb/breadcrumb.component';
import { TournamentService } from '../../services/tournament.service';
import { TournamentRequest } from '../../models/tournament.model';
import {
  SEED_TYPE_LABELS,
  SeedType,
  TOURNAMENT_CATEGORY_LABELS,
  TOURNAMENT_TYPES_BY_CATEGORY,
  TOURNAMENT_TYPE_LABELS,
  TournamentCategory,
  TournamentType,
  TournamentVerification
} from '../../models/tournament-enums.model';

@Component({
  selector: 'app-create-tournament',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, HeaderComponent, BreadcrumbComponent],
  templateUrl: './create-tournament.component.html',
  styleUrl: './create-tournament.component.css'
})
export class CreateTournamentComponent {
  // Enums exposed to the template
  readonly TournamentCategory = TournamentCategory;
  readonly categoryOptions = Object.values(TournamentCategory);
  readonly categoryLabels = TOURNAMENT_CATEGORY_LABELS;
  readonly typeLabels = TOURNAMENT_TYPE_LABELS;
  readonly seedTypeOptions = Object.values(SeedType);
  readonly seedTypeLabels = SEED_TYPE_LABELS;
  readonly TournamentVerification = TournamentVerification;

  // Form model
  name = '';
  description = '';
  tournamentCategory: TournamentCategory | '' = '';
  tournamentType: TournamentType | '' = '';
  registrationStartDate = '';
  registrationEndDate = '';
  tournamentStartDate = '';
  tournamentEndDate = '';
  maximumTeams: number | null = null;
  maximumPlayersPerTeam: number | null = null;
  seedingTypeId: SeedType | '' = '';
  entryFee: number | null = null;
  verificationRequired: TournamentVerification | '' = '';

  submitting = false;
  apiError = '';
  errors: Record<string, string> = {};

  constructor(private tournamentService: TournamentService, private router: Router) {}

  /** Tournament type options narrow to whatever belongs to the chosen category. */
  get typeOptionsForCategory(): TournamentType[] {
    if (!this.tournamentCategory) return [];
    return TOURNAMENT_TYPES_BY_CATEGORY[this.tournamentCategory];
  }

  onCategoryChange(): void {
    // Reset type whenever category changes so a stale, mismatched
    // selection can never be submitted.
    this.tournamentType = '';
    delete this.errors['tournamentType'];
  }

  onSubmit(): void {
    this.errors = {};
    this.apiError = '';

    if (!this.validate()) return;

    const payload: TournamentRequest = {
      name: this.name.trim(),
      description: this.description.trim(),
      registrationStartDate: this.toLocalDateTimeString(this.registrationStartDate),
      registrationEndDate: this.toLocalDateTimeString(this.registrationEndDate),
      tournamentStartDate: this.toLocalDateTimeString(this.tournamentStartDate),
      tournamentEndDate: this.toLocalDateTimeString(this.tournamentEndDate),
      tournamentCategory: this.tournamentCategory as TournamentCategory,
      tournamentType: this.tournamentType as TournamentType,
      maximumTeams: this.maximumTeams as number,
      maximumPlayersPerTeam: this.maximumPlayersPerTeam as number,
      seedingTypeId: this.seedingTypeId as SeedType,
      entryFee: this.entryFee as number,
      verificationRequired: this.verificationRequired as TournamentVerification
    };

    this.submitting = true;
    this.tournamentService.createTournament(payload).subscribe({
      next: () => {
        this.submitting = false;
        this.router.navigateByUrl('/tournament-organizer/tournaments');
      },
      error: (err) => {
        this.submitting = false;
        this.apiError = this.resolveApiErrorMessage(err);
      }
    });
  }

  /**
   * Mirrors TournamentRequestDTO's bean-validation annotations plus
   * TournamentService.validateTournamentDates() / validateTournamentDetails()
   * on the backend, so obviously-invalid submissions are caught before a
   * round trip instead of only surfacing as a 400 response.
   */
  private validate(): boolean {
    const e: Record<string, string> = {};

    if (this.name.trim().length === 0) {
      e['name'] = 'Tournament name is required';
    }

    if (this.description.trim().length === 0) {
      e['description'] = 'Description is required';
    }

    if (!this.tournamentCategory) {
      e['tournamentCategory'] = 'Tournament category is required';
    }

    if (!this.tournamentType) {
      e['tournamentType'] = 'Tournament type is required';
    } else if (
      this.tournamentCategory &&
      !TOURNAMENT_TYPES_BY_CATEGORY[this.tournamentCategory].includes(this.tournamentType)
    ) {
      // Defensive check - the dropdown is already filtered by category, but
      // this guards against a stale value if the category was changed
      // programmatically.
      e['tournamentType'] = 'Tournament type does not match the selected category';
    }

    const regStart = this.parseDate(this.registrationStartDate);
    const regEnd = this.parseDate(this.registrationEndDate);
    const tourStart = this.parseDate(this.tournamentStartDate);
    const tourEnd = this.parseDate(this.tournamentEndDate);

    if (!this.registrationStartDate) {
      e['registrationStartDate'] = 'Registration start date is required';
    } else if (regStart && regStart.getTime() < Date.now()) {
      e['registrationStartDate'] = 'Registration start date cannot be in the past';
    }

    if (!this.registrationEndDate) {
      e['registrationEndDate'] = 'Registration end date is required';
    } else if (regStart && regEnd && regEnd.getTime() <= regStart.getTime()) {
      e['registrationEndDate'] = 'Registration end date must be after the registration start date';
    }

    if (!this.tournamentStartDate) {
      e['tournamentStartDate'] = 'Tournament start date is required';
    } else if (regEnd && tourStart && tourStart.getTime() <= regEnd.getTime()) {
      e['tournamentStartDate'] = 'Tournament start date must be after registration ends';
    }

    if (!this.tournamentEndDate) {
      e['tournamentEndDate'] = 'Tournament end date is required';
    } else if (tourStart && tourEnd && tourEnd.getTime() <= tourStart.getTime()) {
      e['tournamentEndDate'] = 'Tournament end date must be after the tournament start date';
    }

    if (this.maximumTeams === null || this.maximumTeams === undefined || (this.maximumTeams as any) === '') {
      e['maximumTeams'] = 'Maximum teams is required';
    } else if (!Number.isInteger(this.maximumTeams) || this.maximumTeams < 2) {
      e['maximumTeams'] = 'Minimum 2 teams required';
    }

    if (
      this.maximumPlayersPerTeam === null ||
      this.maximumPlayersPerTeam === undefined ||
      (this.maximumPlayersPerTeam as any) === ''
    ) {
      e['maximumPlayersPerTeam'] = 'Maximum players per team is required';
    } else if (!Number.isInteger(this.maximumPlayersPerTeam) || this.maximumPlayersPerTeam < 1) {
      e['maximumPlayersPerTeam'] = 'Minimum 1 player required';
    }

    if (!this.seedingTypeId) {
      e['seedingTypeId'] = 'Seeding type is required';
    }

    if (this.entryFee === null || this.entryFee === undefined || (this.entryFee as any) === '') {
      e['entryFee'] = 'Entry fee is required';
    } else if (this.entryFee < 0) {
      e['entryFee'] = 'Entry fee cannot be negative';
    }

    if (!this.verificationRequired) {
      e['verificationRequired'] = 'Verification type is required';
    }

    this.errors = e;
    return Object.keys(e).length === 0;
  }

  private parseDate(value: string): Date | null {
    if (!value) return null;
    const d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
  }

  /** datetime-local gives "2026-08-10T14:30" - pad to full LocalDateTime-friendly seconds. */
  private toLocalDateTimeString(value: string): string {
    return value.length === 16 ? `${value}:00` : value;
  }

  private resolveApiErrorMessage(err: any): string {
    if (err?.status === 400 && err?.error?.message) {
      return err.error.message;
    }
    if (err?.status === 401 || err?.status === 403) {
      return 'You are not authorized to create a tournament. Please log in again.';
    }
    if (err?.status === 0) {
      return 'Unable to reach the server. Check your connection and try again.';
    }
    if (typeof err?.status === 'number' && err.status >= 500) {
      return 'Something went wrong on our end. Please try again shortly.';
    }
    return err?.error?.message ?? 'Failed to create tournament. Please try again.';
  }
}
