import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';
import { roleGuard } from './guards/role.guard';
import { UserRole } from './core/constants/roles';

export const routes: Routes = [
  // ===================== PUBLIC =====================
  {
    path: '',
    loadComponent: () =>
      import('./layouts/public-layout/public-layout.component').then((m) => m.PublicLayoutComponent),
    children: [
      {
        path: '',
        loadComponent: () => import('./public/home/home.component').then((m) => m.HomeComponent)
      },
      {
        path: 'policy',
        loadComponent: () => import('./authentication/policy/policy.component').then((m) => m.PolicyComponent)
      }
    ]
  },

  // ===================== AUTHENTICATION =====================
  {
    path: 'login',
    loadComponent: () => import('./authentication/login/login.component').then((m) => m.LoginComponent)
  },
  {
    path: 'register',
    loadComponent: () => import('./authentication/register/register.component').then((m) => m.RegisterComponent)
  },
  {
    path: 'register-brand',
    loadComponent: () =>
      import('./authentication/brand-register/brand-register.component').then((m) => m.BrandRegisterComponent)
  },
  {
    path: 'forgot-password',
    loadComponent: () =>
      import('./authentication/forgot-password/forgot-password.component').then((m) => m.ForgotPasswordComponent)
  },
  {
    path: 'otp-verification',
    loadComponent: () =>
      import('./authentication/otp-verification/otp-verification.component').then((m) => m.OtpVerificationComponent)
  },
  {
    path: 'reset-password',
    loadComponent: () =>
      import('./authentication/reset-password/reset-password.component').then((m) => m.ResetPasswordComponent)
  },
  {
    path: 'password-reset-success',
    loadComponent: () =>
      import('./authentication/password-reset-success/password-reset-success.component').then(
        (m) => m.PasswordResetSuccessComponent
      )
  },

  // ===================== USER (PLAYER) =====================
  {
    path: 'user',
    loadComponent: () =>
      import('./layouts/dashboard-layout/dashboard-layout.component').then((m) => m.DashboardLayoutComponent),
    canActivate: [authGuard],
    data: { role: UserRole.USER },
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () => import('./user/dashboard/dashboard.component').then((m) => m.UserDashboardComponent),
        data: { role: UserRole.USER }
      },
      {
        path: 'profile',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.USER, title: 'My Profile' }
      },
      {
        path: 'become-influencer',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.USER, title: 'Become Influencer' }
      }
    ]
  },

  // ===================== INFLUENCER =====================
  {
    path: 'influencer',
    loadComponent: () =>
      import('./layouts/dashboard-layout/dashboard-layout.component').then((m) => m.DashboardLayoutComponent),
    canActivate: [authGuard],
    data: { role: UserRole.INFLUENCER },
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.INFLUENCER, title: 'Influencer Dashboard' }
      },
      {
        path: 'profile',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.INFLUENCER, title: 'My Profile' }
      },
      {
        path: 'campaigns',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.INFLUENCER, title: 'Campaigns' }
      }
    ]
  },

  // ===================== BRAND =====================
  {
    path: 'brand',
    loadComponent: () =>
      import('./layouts/dashboard-layout/dashboard-layout.component').then((m) => m.DashboardLayoutComponent),
    canActivate: [authGuard],
    data: { role: UserRole.BRAND },
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () => import('./brand/dashboard/dashboard.component').then((m) => m.BrandDashboardComponent),
        data: { role: UserRole.BRAND }
      },
      {
        path: 'find-influencer',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.BRAND, title: 'Find Influencer Page' }
      },
      {
        path: 'create-campaign',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.BRAND, title: 'Create Campaign Page' }
      },
      {
        path: 'campaign-management',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.BRAND, title: 'Campaign Management' }
      },
      {
        path: 'payments',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.BRAND, title: 'Payments' }
      }
    ]
  },

  // ===================== TOURNAMENT ORGANIZER =====================
  {
    path: 'tournament-organizer',
    loadComponent: () =>
      import('./layouts/dashboard-layout/dashboard-layout.component').then((m) => m.DashboardLayoutComponent),
    canActivate: [authGuard],
    data: { role: UserRole.TOURNAMENT_ORGANIZER },
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./tournament-organizer/dashboard/dashboard.component').then((m) => m.TournamentDashboardComponent),
        data: { role: UserRole.TOURNAMENT_ORGANIZER }
      },
      {
        path: 'create-tournament',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.TOURNAMENT_ORGANIZER, title: 'Create Tournament Page' }
      },
      {
        path: 'tournaments',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.TOURNAMENT_ORGANIZER, title: 'Tournament Management Page' }
      },
      {
        path: 'matches',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.TOURNAMENT_ORGANIZER, title: 'Matches' }
      },
      {
        path: 'teams',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.TOURNAMENT_ORGANIZER, title: 'Teams' }
      }
    ]
  },

  // ===================== ADMIN =====================
  {
    path: 'admin',
    loadComponent: () =>
      import('./layouts/dashboard-layout/dashboard-layout.component').then((m) => m.DashboardLayoutComponent),
    canActivate: [authGuard, roleGuard],
    data: { role: UserRole.ADMIN, roles: [UserRole.ADMIN] },
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () => import('./admin/dashboard/dashboard.component').then((m) => m.AdminDashboardComponent),
        data: { role: UserRole.ADMIN }
      },
      {
        path: 'users',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.ADMIN, title: 'Users' }
      },
      {
        path: 'brands',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.ADMIN, title: 'Brands' }
      },
      {
        path: 'influencers',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.ADMIN, title: 'Influencers' }
      },
      {
        path: 'tournaments',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.ADMIN, title: 'Tournament Management Page' }
      },
      {
        path: 'reports',
        loadComponent: () =>
          import('./shared/components/placeholder-page/placeholder-page.component').then(
            (m) => m.PlaceholderPageComponent
          ),
        data: { role: UserRole.ADMIN, title: 'Reports Page' }
      }
    ]
  },

  // ===================== FALLBACK =====================
  {
    path: '404',
    loadComponent: () => import('./authentication/not-found/not-found.component').then((m) => m.NotFoundComponent)
  },
  { path: '**', redirectTo: '404' }
];
