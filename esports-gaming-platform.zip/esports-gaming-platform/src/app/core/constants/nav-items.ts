import { UserRole } from './roles';

export interface NavItem {
  label: string;
  icon: string;
  route: string;
}

/**
 * Sidebar navigation configuration for each role.
 * Centralised here so the sidebar component and dashboard layouts
 * stay in sync without duplicating menu markup per page.
 */
export const NAV_ITEMS: Record<UserRole, NavItem[]> = {
  [UserRole.USER]: [
    { label: 'Dashboard', icon: 'fa-solid fa-house', route: '/user/dashboard' },
    { label: 'My Profile', icon: 'fa-solid fa-user', route: '/user/profile' },
    { label: 'Become Influencer', icon: 'fa-solid fa-star', route: '/user/become-influencer' }
  ],
  [UserRole.INFLUENCER]: [
    { label: 'Dashboard', icon: 'fa-solid fa-house', route: '/influencer/dashboard' },
    { label: 'My Profile', icon: 'fa-solid fa-user', route: '/influencer/profile' },
    { label: 'Campaigns', icon: 'fa-solid fa-bullhorn', route: '/influencer/campaigns' }
  ],
  [UserRole.BRAND]: [
    { label: 'Dashboard', icon: 'fa-solid fa-house', route: '/brand/dashboard' },
    { label: 'Find Influencers', icon: 'fa-solid fa-magnifying-glass', route: '/brand/find-influencer' },
    { label: 'Create Campaign', icon: 'fa-solid fa-plus', route: '/brand/create-campaign' },
    { label: 'Campaign Management', icon: 'fa-solid fa-layer-group', route: '/brand/campaign-management' },
    { label: 'Payments', icon: 'fa-solid fa-wallet', route: '/brand/payments' }
  ],
  [UserRole.TOURNAMENT_ORGANIZER]: [
    { label: 'Dashboard', icon: 'fa-solid fa-house', route: '/tournament-organizer/dashboard' },
    { label: 'Create Tournament', icon: 'fa-solid fa-plus', route: '/tournament-organizer/create-tournament' },
    { label: 'Tournaments', icon: 'fa-solid fa-trophy', route: '/tournament-organizer/tournaments' },
    { label: 'Matches', icon: 'fa-solid fa-gamepad', route: '/tournament-organizer/matches' },
    { label: 'Teams', icon: 'fa-solid fa-people-group', route: '/tournament-organizer/teams' }
  ],
  [UserRole.ADMIN]: [
    { label: 'Dashboard', icon: 'fa-solid fa-house', route: '/admin/dashboard' },
    { label: 'Users', icon: 'fa-solid fa-users', route: '/admin/users' },
    { label: 'Brands', icon: 'fa-solid fa-building', route: '/admin/brands' },
    { label: 'Influencers', icon: 'fa-solid fa-star', route: '/admin/influencers' },
    { label: 'Tournaments', icon: 'fa-solid fa-trophy', route: '/admin/tournaments' },
    { label: 'Reports', icon: 'fa-solid fa-chart-line', route: '/admin/reports' }
  ]
};
