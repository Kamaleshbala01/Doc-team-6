export interface DashboardStat {
  label: string;
  value: string;
  icon: string;
  trend?: string;
}
