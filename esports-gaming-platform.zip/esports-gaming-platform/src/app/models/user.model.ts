import { UserRole } from '../core/constants/roles';

export interface User {
  id: string;
  fullName: string;
  username: string;
  email: string;
  mobile: string;
  role: UserRole;
  avatarUrl?: string;
  createdAt: string;
}
