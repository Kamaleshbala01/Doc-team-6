/**
 * Mirrors com.esports.project.enums.TournamentCategory (tournament-service).
 */
export enum TournamentCategory {
  BRACKETS = 'BRACKETS',
  LEADERBOARD = 'LEADERBOARD'
}

/**
 * Mirrors com.esports.project.enums.TournamentType (tournament-service).
 * Each type belongs to exactly one category - the create-tournament form
 * filters this list by the selected category, mirroring
 * TournamentType.getCategory() on the backend.
 */
export enum TournamentType {
  SINGLE_ELIMINATION = 'SINGLE_ELIMINATION',
  DOUBLE_ELIMINATION = 'DOUBLE_ELIMINATION',
  ROUND_ROBIN = 'ROUND_ROBIN',
  POINT = 'POINT',
  RANK = 'RANK'
}

export const TOURNAMENT_TYPES_BY_CATEGORY: Record<TournamentCategory, TournamentType[]> = {
  [TournamentCategory.BRACKETS]: [
    TournamentType.SINGLE_ELIMINATION,
    TournamentType.DOUBLE_ELIMINATION,
    TournamentType.ROUND_ROBIN
  ],
  [TournamentCategory.LEADERBOARD]: [TournamentType.POINT, TournamentType.RANK]
};

/**
 * Mirrors com.esports.project.enums.SeedType (tournament-service).
 */
export enum SeedType {
  RANDOM = 'RANDOM',
  MANUAL = 'MANUAL'
}

/**
 * Mirrors com.esports.project.enums.TournamentVerification (tournament-service).
 */
export enum TournamentVerification {
  YES = 'YES',
  NO = 'NO'
}

/**
 * Mirrors com.esports.project.enums.StatusMaster (tournament-service's own copy -
 * distinct from the round-service/campaign-service copies of the same name).
 */
export enum TournamentStatus {
  ONGOING = 'ONGOING',
  UPCOMMING = 'UPCOMMING',
  CANCELLED = 'CANCELLED',
  POSTPONDED = 'POSTPONDED',
  REGISTERED = 'REGISTERED'
}

export const TOURNAMENT_CATEGORY_LABELS: Record<TournamentCategory, string> = {
  [TournamentCategory.BRACKETS]: 'Brackets',
  [TournamentCategory.LEADERBOARD]: 'Leaderboard'
};

export const TOURNAMENT_TYPE_LABELS: Record<TournamentType, string> = {
  [TournamentType.SINGLE_ELIMINATION]: 'Single Elimination',
  [TournamentType.DOUBLE_ELIMINATION]: 'Double Elimination',
  [TournamentType.ROUND_ROBIN]: 'Round Robin',
  [TournamentType.POINT]: 'Point System',
  [TournamentType.RANK]: 'Rank System'
};

export const SEED_TYPE_LABELS: Record<SeedType, string> = {
  [SeedType.RANDOM]: 'Random',
  [SeedType.MANUAL]: 'Manual'
};
