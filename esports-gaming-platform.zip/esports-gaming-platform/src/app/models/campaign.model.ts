export interface Campaign {
  id: string;
  title: string;
  brandName: string;
  budget: number;
  status: 'draft' | 'active' | 'completed';
  influencersCount: number;
}
