import {
  SeedType,
  TournamentCategory,
  TournamentStatus,
  TournamentType,
  TournamentVerification
} from './tournament-enums.model';

/**
 * Maps 1:1 to com.esports.project.DTO.TournamentRequestDTO (tournament-service).
 * Dates are sent as ISO-8601 strings (`LocalDateTime` on the backend).
 */
export interface TournamentRequest {
  name: string;
  description: string;
  registrationStartDate: string;
  registrationEndDate: string;
  tournamentStartDate: string;
  tournamentEndDate: string;
  tournamentCategory: TournamentCategory;
  tournamentType: TournamentType;
  maximumTeams: number;
  maximumPlayersPerTeam: number;
  seedingTypeId: SeedType;
  entryFee: number;
  verificationRequired: TournamentVerification;
  fileId?: string | null;
}

/**
 * Maps 1:1 to com.esports.project.DTO.TournamentResponseDTO (tournament-service).
 */
export interface TournamentResponse {
  id: string;
  name: string;
  description: string;
  registrationStartDate: string;
  registrationEndDate: string;
  tournamentStartDate: string;
  tournamentEndDate: string;
  tournamentCategory: TournamentCategory;
  tournamentType: TournamentType;
  maximumTeams: number;
  maximumPlayersPerTeam: number;
  seedingTypeId: SeedType;
  entryFee: number;
  verificationRequired: TournamentVerification;
  status: TournamentStatus;
  userId: string;
  fileId?: string | null;
  createdAt: string;
  updatedAt?: string | null;
}
