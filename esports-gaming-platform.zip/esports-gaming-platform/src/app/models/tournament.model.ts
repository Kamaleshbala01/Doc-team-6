export interface Tournament {
  id: string;
  title: string;
  game: string;
  startDate: string;
  endDate: string;
  prizePool: number;
  teamsCount: number;
  status: 'upcoming' | 'ongoing' | 'completed';
}
