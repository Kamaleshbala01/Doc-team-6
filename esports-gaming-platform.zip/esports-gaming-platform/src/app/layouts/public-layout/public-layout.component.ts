import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { FooterComponent } from '../../shared/components/footer/footer.component';

/** Shell for public marketing pages (landing, policy, 404): navbar + footer. */
@Component({
  selector: 'app-public-layout',
  standalone: true,
  imports: [RouterOutlet, RouterLink, FooterComponent],
  templateUrl: './public-layout.component.html'
})
export class PublicLayoutComponent {}
