import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

/** Thin shell for the authentication pages, each of which owns its full layout/markup. */
@Component({
  selector: 'app-auth-layout',
  standalone: true,
  imports: [RouterOutlet],
  template: `<router-outlet></router-outlet>`
})
export class AuthLayoutComponent {}
