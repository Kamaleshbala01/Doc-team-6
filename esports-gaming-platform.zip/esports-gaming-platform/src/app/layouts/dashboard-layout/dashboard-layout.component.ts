import { Component } from '@angular/core';
import { RouterOutlet, ActivatedRoute } from '@angular/router';
import { SidebarComponent } from '../../shared/components/sidebar/sidebar.component';
import { UserRole } from '../../core/constants/roles';

/**
 * Shared shell for every role dashboard: fixed sidebar + `.main-content`
 * area with a router-outlet for the active page. The active role is read
 * from the matched route's `data.role`, set in app.routes.ts.
 */
@Component({
  selector: 'app-dashboard-layout',
  standalone: true,
  imports: [RouterOutlet, SidebarComponent],
  templateUrl: './dashboard-layout.component.html'
})
export class DashboardLayoutComponent {
  role: UserRole;

  constructor(private route: ActivatedRoute) {
    this.role = (this.route.snapshot.firstChild?.data?.['role'] as UserRole) ?? UserRole.USER;
  }
}
