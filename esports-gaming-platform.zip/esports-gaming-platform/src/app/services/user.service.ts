import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { DashboardStat } from '../models/dashboard-stat.model';
import { User } from '../models/user.model';
import { UserRole } from '../core/constants/roles';

/** Placeholder service for the Player/User feature area. Replace with real HTTP calls when the API is ready. */
@Injectable({ providedIn: 'root' })
export class UserService {
  getProfile(): Observable<User> {
    return of({
      id: 'usr_001',
      fullName: 'Arjun Mehta',
      username: 'arjun_gg',
      email: 'arjun@example.com',
      mobile: '9876543210',
      role: UserRole.USER,
      createdAt: '2025-01-12'
    }).pipe(delay(200));
  }

  getDashboardStats(): Observable<DashboardStat[]> {
    return of([
      { label: 'Tournaments Played', value: '32', icon: 'fa-solid fa-trophy' },
      { label: 'Wins', value: '18', icon: 'fa-solid fa-medal' },
      { label: 'Current Rank', value: '#124', icon: 'fa-solid fa-ranking-star' },
      { label: 'Total Rewards', value: '₹24,500', icon: 'fa-solid fa-wallet' }
    ]).pipe(delay(200));
  }
}
