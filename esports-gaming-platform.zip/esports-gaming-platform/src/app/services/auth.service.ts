import { Injectable, signal } from '@angular/core';
import { Observable, delay, of, tap, throwError } from 'rxjs';
import { UserRole } from '../core/constants/roles';
import { AuthResponse, LoginRequest, RegisterRequest } from '../models/auth.model';

const TOKEN_KEY = 'esports_auth_token';
const ROLE_KEY = 'esports_auth_role';

/** Known usernames/emails used to simulate a "duplicate account" API failure. */
const TAKEN_EMAILS = new Set(['admin@gmail.com', 'organizer@gmail.com', 'brand@gmail.com', 'user@gmail.com', 'influencer@gmail.com']);

/**
 * Placeholder authentication service.
 * Simulates network latency and returns mock data so the UI can be
 * exercised end to end before a real backend is wired up. login()/register()
 * still return an Observable<AuthResponse> that can error, so components
 * already handle failures the same way they will once this is swapped
 * for real HttpClient calls.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  readonly currentRole = signal<UserRole | null>(this.readRole());

  login(payload: LoginRequest): Observable<AuthResponse> {
    const role = this.resolveRoleFromEmail(payload.email);
    const response: AuthResponse = {
      token: 'mock-jwt-token',
      user: {
        id: 'usr_001',
        fullName: 'Demo User',
        email: payload.email,
        role
      }
    };
    return of(response).pipe(
      delay(400),
      tap((res) => this.persistSession(res))
    );
  }

  register(payload: RegisterRequest): Observable<AuthResponse> {
    if (TAKEN_EMAILS.has(payload.email.trim().toLowerCase())) {
      return throwError(() => ({ status: 409, message: 'An account with this email already exists.' })).pipe(delay(400));
    }

    const response: AuthResponse = {
      token: 'mock-jwt-token',
      user: {
        id: 'usr_new',
        fullName: payload.fullName,
        email: payload.email,
        role: UserRole.USER
      }
    };
    return of(response).pipe(
      delay(400),
      tap((res) => this.persistSession(res))
    );
  }

  logout(): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(ROLE_KEY);
    this.currentRole.set(null);
  }

  isAuthenticated(): boolean {
    return !!localStorage.getItem(TOKEN_KEY);
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  getRole(): UserRole | null {
    return this.readRole();
  }

  private persistSession(res: AuthResponse): void {
    localStorage.setItem(TOKEN_KEY, res.token);
    localStorage.setItem(ROLE_KEY, res.user.role);
    this.currentRole.set(res.user.role);
  }

  private readRole(): UserRole | null {
    const stored = localStorage.getItem(ROLE_KEY);
    return stored ? (stored as UserRole) : null;
  }

  /** Mimics the demo-account routing used in the original vanilla JS app. */
  private resolveRoleFromEmail(email: string): UserRole {
    if (email.includes('organizer')) return UserRole.TOURNAMENT_ORGANIZER;
    if (email.includes('brand')) return UserRole.BRAND;
    if (email.includes('influencer')) return UserRole.INFLUENCER;
    if (email.includes('admin')) return UserRole.ADMIN;
    return UserRole.USER;
  }
}
