import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { DashboardStat } from '../models/dashboard-stat.model';

/** Placeholder service for the Admin feature area. Replace with real HTTP calls when the API is ready. */
@Injectable({ providedIn: 'root' })
export class AdminService {
  getDashboardStats(): Observable<DashboardStat[]> {
    return of([
      { label: 'Total Users', value: '25,412', icon: 'fa-solid fa-users' },
      { label: 'Total Brands', value: '512', icon: 'fa-solid fa-building' },
      { label: 'Total Influencers', value: '1,834', icon: 'fa-solid fa-star' },
      { label: 'Active Tournaments', value: '47', icon: 'fa-solid fa-trophy' }
    ]).pipe(delay(200));
  }
}
