import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { DashboardStat } from '../models/dashboard-stat.model';
import { Campaign } from '../models/campaign.model';

/** Placeholder service for the Brand feature area. Replace with real HTTP calls when the API is ready. */
@Injectable({ providedIn: 'root' })
export class BrandService {
  getDashboardStats(): Observable<DashboardStat[]> {
    return of([
      { label: 'Active Campaigns', value: '9', icon: 'fa-solid fa-bullhorn' },
      { label: 'Influencers Reached', value: '214', icon: 'fa-solid fa-users' },
      { label: 'Total Spend', value: '₹8,40,000', icon: 'fa-solid fa-wallet' },
      { label: 'Avg. ROI', value: '3.2x', icon: 'fa-solid fa-chart-line' }
    ]).pipe(delay(200));
  }

  getCampaigns(): Observable<Campaign[]> {
    return of([
      { id: 'cmp_1', title: 'Summer Gaming Blast', brandName: 'NovaTech', budget: 150000, status: 'active', influencersCount: 12 },
      { id: 'cmp_2', title: 'Launch Day Hype', brandName: 'NovaTech', budget: 90000, status: 'draft', influencersCount: 5 }
    ]).pipe(delay(200));
  }
}
