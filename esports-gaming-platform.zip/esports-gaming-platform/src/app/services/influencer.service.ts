import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { DashboardStat } from '../models/dashboard-stat.model';

/** Placeholder service for the Influencer feature area. Replace with real HTTP calls when the API is ready. */
@Injectable({ providedIn: 'root' })
export class InfluencerService {
  getDashboardStats(): Observable<DashboardStat[]> {
    return of([
      { label: 'Active Campaigns', value: '6', icon: 'fa-solid fa-bullhorn' },
      { label: 'Followers', value: '48.2K', icon: 'fa-solid fa-users' },
      { label: 'Engagement Rate', value: '7.4%', icon: 'fa-solid fa-chart-line' },
      { label: 'Earnings', value: '₹1,12,000', icon: 'fa-solid fa-wallet' }
    ]).pipe(delay(200));
  }
}
