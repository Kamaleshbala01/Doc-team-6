import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { DashboardStat } from '../models/dashboard-stat.model';
import { Tournament } from '../models/tournament.model';

/** Placeholder service for the Tournament Organizer feature area. Replace with real HTTP calls when the API is ready. */
@Injectable({ providedIn: 'root' })
export class TournamentService {
  getDashboardStats(): Observable<DashboardStat[]> {
    return of([
      { label: 'Active Tournaments', value: '5', icon: 'fa-solid fa-trophy' },
      { label: 'Registered Teams', value: '128', icon: 'fa-solid fa-people-group' },
      { label: 'Matches Today', value: '14', icon: 'fa-solid fa-gamepad' },
      { label: 'Total Prize Pool', value: '₹22,00,000', icon: 'fa-solid fa-sack-dollar' }
    ]).pipe(delay(200));
  }

  getTournaments(): Observable<Tournament[]> {
    return of([
      { id: 'trn_1', title: 'Invictus Winter Championship', game: 'Valorant', startDate: '2026-08-10', endDate: '2026-08-14', prizePool: 500000, teamsCount: 32, status: 'upcoming' },
      { id: 'trn_2', title: 'BGMI Masters Series', game: 'BGMI', startDate: '2026-07-20', endDate: '2026-07-25', prizePool: 300000, teamsCount: 24, status: 'ongoing' }
    ]).pipe(delay(200));
  }
}
