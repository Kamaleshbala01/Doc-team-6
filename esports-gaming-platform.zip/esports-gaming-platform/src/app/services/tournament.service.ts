import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../environments/environment';
import { DashboardStat } from '../models/dashboard-stat.model';
import { TournamentRequest, TournamentResponse } from '../models/tournament.model';
import { TournamentStatus } from '../models/tournament-enums.model';

/**
 * Talks to tournament-service through the API Gateway.
 * Base path matches TournamentController's @RequestMapping("/tournament") -
 * no extra "/api" segment, and no userId in the payload (the backend reads
 * it from the JWT via SecurityContextHolder).
 */
@Injectable({ providedIn: 'root' })
export class TournamentService {
  private readonly baseUrl = `${environment.apiBaseUrl}/tournament`;

  constructor(private http: HttpClient) {}

  createTournament(payload: TournamentRequest): Observable<TournamentResponse> {
    return this.http.post<TournamentResponse>(this.baseUrl, payload);
  }

  getMyTournaments(): Observable<TournamentResponse[]> {
    return this.http.get<TournamentResponse[]>(`${this.baseUrl}/my`);
  }

  getMyTournamentById(id: string): Observable<TournamentResponse> {
    return this.http.get<TournamentResponse>(`${this.baseUrl}/${id}/my`);
  }

  /**
   * No dedicated "dashboard stats" endpoint exists on the backend, so the
   * dashboard's summary cards are derived client-side from the organizer's
   * real tournament list rather than calling a made-up API.
   */
  getDashboardStats(): Observable<DashboardStat[]> {
    return this.getMyTournaments().pipe(
      map((tournaments) => {
        const active = tournaments.filter((t) => t.status === TournamentStatus.ONGOING).length;
        const upcoming = tournaments.filter((t) => t.status === TournamentStatus.UPCOMMING).length;
        const totalPrizePool = tournaments.reduce((sum, t) => sum + Number(t.entryFee ?? 0), 0);

        return [
          { label: 'Active Tournaments', value: String(active), icon: 'fa-solid fa-trophy' },
          { label: 'Upcoming Tournaments', value: String(upcoming), icon: 'fa-solid fa-calendar-days' },
          { label: 'Total Tournaments', value: String(tournaments.length), icon: 'fa-solid fa-gamepad' },
          { label: 'Combined Entry Fees', value: `\u20B9${totalPrizePool.toLocaleString('en-IN')}`, icon: 'fa-solid fa-sack-dollar' }
        ] as DashboardStat[];
      })
    );
  }
}
