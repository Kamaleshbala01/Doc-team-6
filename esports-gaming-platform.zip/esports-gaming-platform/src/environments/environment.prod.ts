export const environment = {
  production: true,
  // Replace with the deployed API Gateway's public URL.
  apiBaseUrl: '/gateway'
};
