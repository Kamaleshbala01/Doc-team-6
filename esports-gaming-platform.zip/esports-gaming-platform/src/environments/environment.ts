export const environment = {
  production: false,
  // Points at the local API Gateway (Eureka + Spring Cloud Gateway), which
  // routes to each microservice - see api-gateway's application.properties.
  // Controllers are NOT prefixed with /api (e.g. POST /tournament, not
  // POST /api/tournament), so no extra path segment is added here.
  apiBaseUrl: 'http://localhost:8080'
};
