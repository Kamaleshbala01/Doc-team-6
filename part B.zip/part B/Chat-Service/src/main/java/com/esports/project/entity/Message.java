package com.esports.project.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "messages")
public class Message {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String content;
    private Boolean isEdited;
    private LocalDateTime editedAt;
    private Boolean isDeleted;
    private LocalDateTime deletedAt;
    private LocalDateTime createdAt;

    /*
     * Relationship mapping
     */

    // converation mapping

    @ManyToOne
    @JoinColumn(name = "conversation_id")
    @JsonBackReference(value = "converation-message")
    private Conversation conversation;

    // sender mapping 

    private String sender;

    // message read status 

    @OneToMany(mappedBy = "message",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JsonManagedReference(value = "message-message-read-status")
    private List<MessageReadStatus> messageReadStatus;

}
