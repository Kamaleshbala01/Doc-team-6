package com.esports.project.entity;

import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Index;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "match_participants", indexes = { @Index(name = "idx_match_participants_match_details_id", columnList = "match_details_id"), @Index(name = "idx_match_participants_team_id", columnList = "team_id") })
public class MatchParticipants {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;

    private String teamId;


    /*
     * Relationship mapping
     */

    // match Details mapping

    @ManyToOne
    @JoinColumn(name = "match_details_id")
    @JsonBackReference(value = "match-details-participants")
    private MatchDetails matchDetails;

}
