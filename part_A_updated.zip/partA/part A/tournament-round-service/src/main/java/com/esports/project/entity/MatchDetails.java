package com.esports.project.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Index;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "match_details", indexes = { @Index(name = "idx_match_details_round_id", columnList = "round_id"), @Index(name = "idx_match_details_status", columnList = "status") })
public class MatchDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private LocalDateTime startTime;
    private LocalDateTime endTime;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;

    /*
     * Relationship mapping
     */

     // round details
     @ManyToOne
     @JoinColumn(name = "round_id")
     @JsonBackReference(value = "round-match-details")
     private RoundDetails roundDetails;

     // match participants

     @OneToMany(mappedBy = "matchDetails",cascade = CascadeType.REMOVE)
     @JsonManagedReference(value = "match-details-participants")
     private List<MatchParticipants> matchParticipants;
}
