package com.esports.user_service.entity;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;


import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Index;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "users", indexes = { @Index(name = "idx_users_username", columnList = "username"), @Index(name = "idx_users_email", columnList = "email") })
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String username;
    private String password;
    private String email;
    private Boolean emailVerified;
    private String mobileNumber;
    private Boolean mobileVerifed;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "user_roles",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();
    
     // user Profile
    @OneToOne(mappedBy = "user",fetch = FetchType.LAZY)
    private UserProfile userProfile;

    // brand profile
    @OneToOne(mappedBy = "user",fetch = FetchType.LAZY)
    private BrandDetails brandDetails;

    // organizer profile
    @OneToOne(mappedBy = "user",fetch = FetchType.LAZY)
    private OrganizerDetails organizerDetails;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Boolean getEmailVerified() {
		return emailVerified;
	}

	public void setEmailVerified(Boolean emailVerified) {
		this.emailVerified = emailVerified;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Boolean getMobileVerifed() {
		return mobileVerifed;
	}

	public void setMobileVerifed(Boolean mobileVerifed) {
		this.mobileVerifed = mobileVerifed;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public BrandDetails getBrandDetails() {
		return brandDetails;
	}

	public void setBrandDetails(BrandDetails brandDetails) {
		this.brandDetails = brandDetails;
	}

	public OrganizerDetails getOrganizerDetails() {
		return organizerDetails;
	}

	public void setOrganizerDetails(OrganizerDetails organizerDetails) {
		this.organizerDetails = organizerDetails;
	}

    

}
