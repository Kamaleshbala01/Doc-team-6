package com.esports.project.entity;

import java.time.LocalDateTime;

import com.esports.project.enums.StatusMaster;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Index;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tournament_faqs", indexes = { @Index(name = "idx_tournament_faqs_tournament_id", columnList = "tournament_id"), @Index(name = "idx_tournament_faqs_status", columnList = "status") })
public class TournamentFAQ {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    private String question;
    private String answer;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @Column(name = "user_id")
    private String userId;

    /*
     * Relationship mapping
     */

    @ManyToOne
    @JoinColumn(name = "tournament_id")
    @JsonBackReference(value = "tournament-faq")
    private Tournament tournament;

}
