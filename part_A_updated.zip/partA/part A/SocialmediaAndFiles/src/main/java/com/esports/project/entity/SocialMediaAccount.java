package com.esports.project.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Index;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "social_media_account", indexes = { @Index(name = "idx_social_media_account_user_id", columnList = "user_id"), @Index(name = "idx_social_media_account_status", columnList = "status") })
public class SocialMediaAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String platform;
    private String accountName;
    private String profileUrl;

    private Long followersCount;

    private Long subscriberCount;

    private BigDecimal viewSubscriptionRatio;

    private BigDecimal viewCommentRatio;

    private String status;

    private String userId;
    private Long totalViews;

    private Long totalLikes;

    private Long totalComments;

    private BigDecimal engagementRate;

    private BigDecimal genuineInfluencerScore;

    private String influencerRating;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;
}