package com.esports.project.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Index;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "files", indexes = { @Index(name = "idx_files_user_id", columnList = "user_id") })
public class Files {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String fileName;

    private String fileType;

    private String bucketName;

    private String storagePath;

    private Long fileSize;

    private String userId;

    private LocalDateTime createdAt;
    




}