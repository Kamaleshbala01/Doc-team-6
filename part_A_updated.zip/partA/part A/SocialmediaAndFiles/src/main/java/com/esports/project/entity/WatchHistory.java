package com.esports.project.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Index;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "watch_histories", indexes = { @Index(name = "idx_watch_histories_user_id", columnList = "user_id"), @Index(name = "idx_watch_histories_match_id", columnList = "match_id") })
public class WatchHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String userId;

    private String matchId;

    private LocalDateTime createdAt;

}