package com.esports.entity;

import java.time.LocalDateTime;

public class CampaignDeliverable {
    private Integer id;
    private Integer campaignId;
    private Integer fileId;
    private LocalDateTime createdAt;

    public CampaignDeliverable() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }

    public Integer getFileId() {
        return fileId;
    }

    public void setFileId(Integer fileId) {
        this.fileId = fileId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CampaignDeliverable)) return false;
        CampaignDeliverable that = (CampaignDeliverable) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "CampaignDeliverable{" +
                "id=" + id +
                '}';
    }
}