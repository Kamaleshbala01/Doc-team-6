package com.esports.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.esports.DAO.impl.TournamentDAOImpl;
import com.esports.DAO.interfaces.TournamentDAO;
import com.esports.config.DBConnection;
import com.esports.entity.MatchDetails;
import com.esports.entity.MatchParticipants;
import com.esports.entity.PrizeCategory;
import com.esports.entity.RoundDetails;
import com.esports.entity.RulesCategory;
import com.esports.entity.Tournament;
import com.esports.entity.TournamentAnnouncement;
import com.esports.entity.TournamentCategory;
import com.esports.entity.TournamentFAQ;
import com.esports.entity.TournamentPrize;
import com.esports.entity.TournamentRegistration;
import com.esports.entity.TournamentRegistrationPayment;
import com.esports.entity.TournamentRule;
import com.esports.entity.TournamentType;
import com.esports.service.interfaces.TournamentService;

/**
 * In-memory implementation of TournamentService.
 * The primary key is taken from the entity passed in on create() —
 * it is set on the dummy object by the controller before calling create(),
 * there is no separate id-generation step.
 */
public class TournamentServiceImpl implements TournamentService {

    private final TournamentDAO tournamentDAO = new TournamentDAOImpl();
    // ---- TournamentCategory ----
    @Override
   public TournamentCategory createTournamentCategory(TournamentCategory category) {

        if  (category == null) {
            throw new IllegalArgumentException("Category cannot be null");
        }

        if (category.getCategoryName() == null ||
            category.getCategoryName().trim().isEmpty()) {
            throw new IllegalArgumentException("Category name is required");
        }

        TournamentCategory existing =
                tournamentDAO.getTournamentCategoryById(category.getId());

        if (existing != null) {
            throw new RuntimeException(
                    "Tournament Category already exists with id: " + category.getId());
        }

        return tournamentDAO.createTournamentCategory(category);
    }
    @Override
    public TournamentCategory getTournamentCategoryById(Integer id) {

        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Invalid category id");
        }

        TournamentCategory category =
                tournamentDAO.getTournamentCategoryById(id);

        if (category == null) {
            throw new RuntimeException(
                    "Tournament Category not found with id: " + id);
        }

        return category;
    }
    @Override
    public List<TournamentCategory> getAllTournamentCategorys() {
        return tournamentDAO.getAllTournamentCategorys();
    }


    @Override
    public TournamentCategory updateTournamentCategory(Integer id,
                                                    TournamentCategory category) {

        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Invalid category id");
        }

        TournamentCategory existing =
                tournamentDAO.getTournamentCategoryById(id);

        if (existing == null) {
            throw new RuntimeException(
                    "Tournament Category not found with id: " + id);
        }

        if (category.getCategoryName() == null ||
            category.getCategoryName().trim().isEmpty()) {
            throw new IllegalArgumentException("Category name is required");
        }

        return tournamentDAO.updateTournamentCategory(id, category);
    }
    @Override
    public boolean deleteTournamentCategory(Integer id) {

        String sql = "DELETE FROM tournament_category WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    // ---- TournamentType ----
    @Override
    public TournamentType createTournamentType(TournamentType entity) {

        String sql = "INSERT INTO tournament_type " +
                    "(id, category_id, type_name, created_at) " +
                    "VALUES (?, ?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setInt(2, entity.getCategoryId());
            ps.setString(3, entity.getTypeName());
            ps.setTimestamp(4, Timestamp.valueOf(entity.getCreatedAt()));

            ps.executeUpdate();
            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public TournamentType getTournamentTypeById(Integer id) {

        String sql = "SELECT * FROM tournament_type WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    TournamentType type = new TournamentType();

                    type.setId(rs.getInt("id"));
                    type.setCategoryId(rs.getInt("category_id"));
                    type.setTypeName(rs.getString("type_name"));

                    Timestamp timestamp = rs.getTimestamp("created_at");
                    if (timestamp != null) {
                        type.setCreatedAt(timestamp.toLocalDateTime());
                    }

                    return type;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<TournamentType> getAllTournamentTypes() {

        List<TournamentType> types = new ArrayList<>();

        String sql = "SELECT * FROM tournament_type";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                TournamentType type = new TournamentType();

                type.setId(rs.getInt("id"));
                type.setCategoryId(rs.getInt("category_id"));
                type.setTypeName(rs.getString("type_name"));

                Timestamp timestamp = rs.getTimestamp("created_at");
                if (timestamp != null) {
                    type.setCreatedAt(timestamp.toLocalDateTime());
                }

                types.add(type);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return types;
    }

    @Override
    public TournamentType updateTournamentType(Integer id, TournamentType entity) {

        String sql = "UPDATE tournament_type " +
                    "SET category_id = ?, type_name = ?, created_at = ? " +
                    "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getCategoryId());
            ps.setString(2, entity.getTypeName());
            ps.setTimestamp(3, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setInt(4, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteTournamentType(Integer id) {

        String sql = "DELETE FROM tournament_type WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }


    // ---- Tournament ----
    @Override
    public Tournament createTournament(Tournament entity) {

        String sql = "INSERT INTO tournament (" +
                "id, organizer_id, name, description, registration_start_date, " +
                "registration_end_date, tournament_start_date, tournament_end_date, " +
                "banner_file_id, category_id, tournament_type_id, maximum_teams, " +
                "maximum_players_per_team, seeding_type_id, entry_fee, " +
                "verification_required, package_id, status, created_at, updated_at" +
                ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setInt(2, entity.getOrganizerId());
            ps.setString(3, entity.getName());
            ps.setString(4, entity.getDescription());
            ps.setTimestamp(5, Timestamp.valueOf(entity.getRegistrationStartDate()));
            ps.setTimestamp(6, Timestamp.valueOf(entity.getRegistrationEndDate()));
            ps.setTimestamp(7, Timestamp.valueOf(entity.getTournamentStartDate()));
            ps.setTimestamp(8, Timestamp.valueOf(entity.getTournamentEndDate()));
            ps.setInt(9, entity.getBannerFileId());
            ps.setInt(10, entity.getCategoryId());
            ps.setInt(11, entity.getTournamentTypeId());
            ps.setInt(12, entity.getMaximumTeams());
            ps.setInt(13, entity.getMaximumPlayersPerTeam());
            ps.setInt(14, entity.getSeedingTypeId());
            ps.setBigDecimal(15, entity.getEntryFee());
            ps.setBoolean(16, entity.getVerificationRequired());
            ps.setInt(17, entity.getPackageId());
            ps.setString(18, entity.getStatus());
            ps.setTimestamp(19, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(20, Timestamp.valueOf(entity.getUpdatedAt()));

            ps.executeUpdate();
            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public Tournament getTournamentById(Integer id) {

        String sql = "SELECT * FROM tournament WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    Tournament tournament = new Tournament();

                    tournament.setId(rs.getInt("id"));
                    tournament.setOrganizerId(rs.getInt("organizer_id"));
                    tournament.setName(rs.getString("name"));
                    tournament.setDescription(rs.getString("description"));
                    tournament.setRegistrationStartDate(rs.getTimestamp("registration_start_date").toLocalDateTime());
                    tournament.setRegistrationEndDate(rs.getTimestamp("registration_end_date").toLocalDateTime());
                    tournament.setTournamentStartDate(rs.getTimestamp("tournament_start_date").toLocalDateTime());
                    tournament.setTournamentEndDate(rs.getTimestamp("tournament_end_date").toLocalDateTime());
                    tournament.setBannerFileId(rs.getInt("banner_file_id"));
                    tournament.setCategoryId(rs.getInt("category_id"));
                    tournament.setTournamentTypeId(rs.getInt("tournament_type_id"));
                    tournament.setMaximumTeams(rs.getInt("maximum_teams"));
                    tournament.setMaximumPlayersPerTeam(rs.getInt("maximum_players_per_team"));
                    tournament.setSeedingTypeId(rs.getInt("seeding_type_id"));
                    tournament.setEntryFee(rs.getBigDecimal("entry_fee"));
                    tournament.setVerificationRequired(rs.getBoolean("verification_required"));
                    tournament.setPackageId(rs.getInt("package_id"));
                    tournament.setStatus(rs.getString("status"));
                    tournament.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
                    tournament.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());

                    return tournament;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

   @Override
    public List<Tournament> getAllTournaments() {

        List<Tournament> tournaments = new ArrayList<>();

        String sql = "SELECT * FROM tournament";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Tournament tournament = new Tournament();

                tournament.setId(rs.getInt("id"));
                tournament.setOrganizerId(rs.getInt("organizer_id"));
                tournament.setName(rs.getString("name"));
                tournament.setDescription(rs.getString("description"));
                tournament.setRegistrationStartDate(rs.getTimestamp("registration_start_date").toLocalDateTime());
                tournament.setRegistrationEndDate(rs.getTimestamp("registration_end_date").toLocalDateTime());
                tournament.setTournamentStartDate(rs.getTimestamp("tournament_start_date").toLocalDateTime());
                tournament.setTournamentEndDate(rs.getTimestamp("tournament_end_date").toLocalDateTime());
                tournament.setBannerFileId(rs.getInt("banner_file_id"));
                tournament.setCategoryId(rs.getInt("category_id"));
                tournament.setTournamentTypeId(rs.getInt("tournament_type_id"));
                tournament.setMaximumTeams(rs.getInt("maximum_teams"));
                tournament.setMaximumPlayersPerTeam(rs.getInt("maximum_players_per_team"));
                tournament.setSeedingTypeId(rs.getInt("seeding_type_id"));
                tournament.setEntryFee(rs.getBigDecimal("entry_fee"));
                tournament.setVerificationRequired(rs.getBoolean("verification_required"));
                tournament.setPackageId(rs.getInt("package_id"));
                tournament.setStatus(rs.getString("status"));
                tournament.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
                tournament.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());

                tournaments.add(tournament);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return tournaments;
    }

    @Override
    public Tournament updateTournament(Integer id, Tournament entity) {

        String sql = "UPDATE tournament SET " +
                "organizer_id = ?, " +
                "name = ?, " +
                "description = ?, " +
                "registration_start_date = ?, " +
                "registration_end_date = ?, " +
                "tournament_start_date = ?, " +
                "tournament_end_date = ?, " +
                "banner_file_id = ?, " +
                "category_id = ?, " +
                "tournament_type_id = ?, " +
                "maximum_teams = ?, " +
                "maximum_players_per_team = ?, " +
                "seeding_type_id = ?, " +
                "entry_fee = ?, " +
                "verification_required = ?, " +
                "package_id = ?, " +
                "status = ?, " +
                "created_at = ?, " +
                "updated_at = ? " +
                "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getOrganizerId());
            ps.setString(2, entity.getName());
            ps.setString(3, entity.getDescription());
            ps.setTimestamp(4, Timestamp.valueOf(entity.getRegistrationStartDate()));
            ps.setTimestamp(5, Timestamp.valueOf(entity.getRegistrationEndDate()));
            ps.setTimestamp(6, Timestamp.valueOf(entity.getTournamentStartDate()));
            ps.setTimestamp(7, Timestamp.valueOf(entity.getTournamentEndDate()));
            ps.setInt(8, entity.getBannerFileId());
            ps.setInt(9, entity.getCategoryId());
            ps.setInt(10, entity.getTournamentTypeId());
            ps.setInt(11, entity.getMaximumTeams());
            ps.setInt(12, entity.getMaximumPlayersPerTeam());
            ps.setInt(13, entity.getSeedingTypeId());
            ps.setBigDecimal(14, entity.getEntryFee());
            ps.setBoolean(15, entity.getVerificationRequired());
            ps.setInt(16, entity.getPackageId());
            ps.setString(17, entity.getStatus());
            ps.setTimestamp(18, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(19, Timestamp.valueOf(entity.getUpdatedAt()));
            ps.setInt(20, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteTournament(Integer id) {

        String sql = "DELETE FROM tournament WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    // ---- RulesCategory ----
    @Override
    public RulesCategory createRulesCategory(RulesCategory entity) {

        String sql = "INSERT INTO rules_category (id, category_name, created_at) VALUES (?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setString(2, entity.getCategoryName());
            ps.setTimestamp(3, Timestamp.valueOf(entity.getCreatedAt()));

            ps.executeUpdate();
            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public RulesCategory getRulesCategoryById(Integer id) {

        String sql = "SELECT * FROM rules_category WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    RulesCategory category = new RulesCategory();

                    category.setId(rs.getInt("id"));
                    category.setCategoryName(rs.getString("category_name"));

                    Timestamp timestamp = rs.getTimestamp("created_at");
                    if (timestamp != null) {
                        category.setCreatedAt(timestamp.toLocalDateTime());
                    }

                    return category;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<RulesCategory> getAllRulesCategorys() {

        List<RulesCategory> categories = new ArrayList<>();

        String sql = "SELECT * FROM rules_category";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                RulesCategory category = new RulesCategory();

                category.setId(rs.getInt("id"));
                category.setCategoryName(rs.getString("category_name"));

                Timestamp timestamp = rs.getTimestamp("created_at");
                if (timestamp != null) {
                    category.setCreatedAt(timestamp.toLocalDateTime());
                }

                categories.add(category);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return categories;
    }

    @Override
    public RulesCategory updateRulesCategory(Integer id, RulesCategory entity) {

        String sql = "UPDATE rules_category " +
                    "SET category_name = ?, created_at = ? " +
                    "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, entity.getCategoryName());
            ps.setTimestamp(2, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setInt(3, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteRulesCategory(Integer id) {

        String sql = "DELETE FROM rules_category WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    // ---- TournamentRule ----
    @Override
    public TournamentRule createTournamentRule(TournamentRule entity) {

        String sql = "INSERT INTO tournament_rule " +
                    "(id, tournament_id, category_id, rule_text, created_by, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setInt(2, entity.getTournamentId());
            ps.setInt(3, entity.getCategoryId());
            ps.setString(4, entity.getRuleText());
            ps.setInt(5, entity.getCreatedBy());
            ps.setTimestamp(6, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(7, Timestamp.valueOf(entity.getUpdatedAt()));

            ps.executeUpdate();
            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public TournamentRule getTournamentRuleById(Integer id) {

        String sql = "SELECT * FROM tournament_rule WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    TournamentRule rule = new TournamentRule();

                    rule.setId(rs.getInt("id"));
                    rule.setTournamentId(rs.getInt("tournament_id"));
                    rule.setCategoryId(rs.getInt("category_id"));
                    rule.setRuleText(rs.getString("rule_text"));
                    rule.setCreatedBy(rs.getInt("created_by"));

                    Timestamp createdAt = rs.getTimestamp("created_at");
                    if (createdAt != null) {
                        rule.setCreatedAt(createdAt.toLocalDateTime());
                    }

                    Timestamp updatedAt = rs.getTimestamp("updated_at");
                    if (updatedAt != null) {
                        rule.setUpdatedAt(updatedAt.toLocalDateTime());
                    }

                    return rule;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<TournamentRule> getAllTournamentRules() {

        List<TournamentRule> rules = new ArrayList<>();

        String sql = "SELECT * FROM tournament_rule";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                TournamentRule rule = new TournamentRule();

                rule.setId(rs.getInt("id"));
                rule.setTournamentId(rs.getInt("tournament_id"));
                rule.setCategoryId(rs.getInt("category_id"));
                rule.setRuleText(rs.getString("rule_text"));
                rule.setCreatedBy(rs.getInt("created_by"));

                Timestamp createdAt = rs.getTimestamp("created_at");
                if (createdAt != null) {
                    rule.setCreatedAt(createdAt.toLocalDateTime());
                }

                Timestamp updatedAt = rs.getTimestamp("updated_at");
                if (updatedAt != null) {
                    rule.setUpdatedAt(updatedAt.toLocalDateTime());
                }

                rules.add(rule);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return rules;
    }

    @Override
    public TournamentRule updateTournamentRule(Integer id, TournamentRule entity) {

        String sql = "UPDATE tournament_rule SET " +
                    "tournament_id = ?, " +
                    "category_id = ?, " +
                    "rule_text = ?, " +
                    "created_by = ?, " +
                    "created_at = ?, " +
                    "updated_at = ? " +
                    "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getTournamentId());
            ps.setInt(2, entity.getCategoryId());
            ps.setString(3, entity.getRuleText());
            ps.setInt(4, entity.getCreatedBy());
            ps.setTimestamp(5, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(6, Timestamp.valueOf(entity.getUpdatedAt()));
            ps.setInt(7, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteTournamentRule(Integer id) {

        String sql = "DELETE FROM tournament_rule WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    // ---- PrizeCategory ----
    @Override
    public PrizeCategory createPrizeCategory(PrizeCategory entity) {

        String sql = "INSERT INTO prize_category (id, name, created_at) VALUES (?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setString(2, entity.getName());
            ps.setTimestamp(3, Timestamp.valueOf(entity.getCreatedAt()));

            ps.executeUpdate();
            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public PrizeCategory getPrizeCategoryById(Integer id) {

        String sql = "SELECT * FROM prize_category WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    PrizeCategory category = new PrizeCategory();

                    category.setId(rs.getInt("id"));
                    category.setName(rs.getString("name"));

                    Timestamp timestamp = rs.getTimestamp("created_at");
                    if (timestamp != null) {
                        category.setCreatedAt(timestamp.toLocalDateTime());
                    }

                    return category;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<PrizeCategory> getAllPrizeCategorys() {

        List<PrizeCategory> categories = new ArrayList<>();

        String sql = "SELECT * FROM prize_category";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                PrizeCategory category = new PrizeCategory();

                category.setId(rs.getInt("id"));
                category.setName(rs.getString("name"));

                Timestamp timestamp = rs.getTimestamp("created_at");
                if (timestamp != null) {
                    category.setCreatedAt(timestamp.toLocalDateTime());
                }

                categories.add(category);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return categories;
    }

    @Override
    public PrizeCategory updatePrizeCategory(Integer id, PrizeCategory entity) {

        String sql = "UPDATE prize_category " +
                    "SET name = ?, created_at = ? " +
                    "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, entity.getName());
            ps.setTimestamp(2, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setInt(3, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deletePrizeCategory(Integer id) {

        String sql = "DELETE FROM prize_category WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    // ---- TournamentPrize ----
    @Override
    public TournamentPrize createTournamentPrize(TournamentPrize entity) {

        String sql = "INSERT INTO tournament_prize " +
                    "(id, tournament_id, prize_category_id, position_name, rank_order, " +
                    "prize_amount, prize_description, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setInt(2, entity.getTournamentId());
            ps.setInt(3, entity.getPrizeCategoryId());
            ps.setString(4, entity.getPositionName());
            ps.setInt(5, entity.getRankOrder());
            ps.setBigDecimal(6, entity.getPrizeAmount());
            ps.setString(7, entity.getPrizeDescription());
            ps.setTimestamp(8, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(9, Timestamp.valueOf(entity.getUpdatedAt()));

            ps.executeUpdate();
            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public TournamentPrize getTournamentPrizeById(Integer id) {

        String sql = "SELECT * FROM tournament_prize WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    TournamentPrize prize = new TournamentPrize();

                    prize.setId(rs.getInt("id"));
                    prize.setTournamentId(rs.getInt("tournament_id"));
                    prize.setPrizeCategoryId(rs.getInt("prize_category_id"));
                    prize.setPositionName(rs.getString("position_name"));
                    prize.setRankOrder(rs.getInt("rank_order"));
                    prize.setPrizeAmount(rs.getBigDecimal("prize_amount"));
                    prize.setPrizeDescription(rs.getString("prize_description"));

                    Timestamp createdAt = rs.getTimestamp("created_at");
                    if (createdAt != null) {
                        prize.setCreatedAt(createdAt.toLocalDateTime());
                    }

                    Timestamp updatedAt = rs.getTimestamp("updated_at");
                    if (updatedAt != null) {
                        prize.setUpdatedAt(updatedAt.toLocalDateTime());
                    }

                    return prize;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<TournamentPrize> getAllTournamentPrizes() {

        List<TournamentPrize> prizes = new ArrayList<>();

        String sql = "SELECT * FROM tournament_prize";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                TournamentPrize prize = new TournamentPrize();

                prize.setId(rs.getInt("id"));
                prize.setTournamentId(rs.getInt("tournament_id"));
                prize.setPrizeCategoryId(rs.getInt("prize_category_id"));
                prize.setPositionName(rs.getString("position_name"));
                prize.setRankOrder(rs.getInt("rank_order"));
                prize.setPrizeAmount(rs.getBigDecimal("prize_amount"));
                prize.setPrizeDescription(rs.getString("prize_description"));

                Timestamp createdAt = rs.getTimestamp("created_at");
                if (createdAt != null) {
                    prize.setCreatedAt(createdAt.toLocalDateTime());
                }

                Timestamp updatedAt = rs.getTimestamp("updated_at");
                if (updatedAt != null) {
                    prize.setUpdatedAt(updatedAt.toLocalDateTime());
                }

                prizes.add(prize);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return prizes;
    }

    @Override
    public TournamentPrize updateTournamentPrize(Integer id, TournamentPrize entity) {

        String sql = "UPDATE tournament_prize SET " +
                    "tournament_id = ?, " +
                    "prize_category_id = ?, " +
                    "position_name = ?, " +
                    "rank_order = ?, " +
                    "prize_amount = ?, " +
                    "prize_description = ?, " +
                    "created_at = ?, " +
                    "updated_at = ? " +
                    "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getTournamentId());
            ps.setInt(2, entity.getPrizeCategoryId());
            ps.setString(3, entity.getPositionName());
            ps.setInt(4, entity.getRankOrder());
            ps.setBigDecimal(5, entity.getPrizeAmount());
            ps.setString(6, entity.getPrizeDescription());
            ps.setTimestamp(7, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(8, Timestamp.valueOf(entity.getUpdatedAt()));
            ps.setInt(9, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteTournamentPrize(Integer id) {

        String sql = "DELETE FROM tournament_prize WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    // ---- TournamentRegistration ----
    @Override
    public TournamentRegistration createTournamentRegistration(TournamentRegistration entity) {

        String sql = "INSERT INTO tournament_registration " +
                    "(id, tournament_id, team_id, registration_status_id, " +
                    "registration_date, approved_by, approved_date, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setInt(2, entity.getTournamentId());
            ps.setInt(3, entity.getTeamId());
            ps.setInt(4, entity.getRegistrationStatusId());
            ps.setTimestamp(5, Timestamp.valueOf(entity.getRegistrationDate()));
            ps.setInt(6, entity.getApprovedBy());
            ps.setTimestamp(7, Timestamp.valueOf(entity.getApprovedDate()));
            ps.setTimestamp(8, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(9, Timestamp.valueOf(entity.getUpdatedAt()));

            ps.executeUpdate();
            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public TournamentRegistration getTournamentRegistrationById(Integer id) {

        String sql = "SELECT * FROM tournament_registration WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    TournamentRegistration registration = new TournamentRegistration();

                    registration.setId(rs.getInt("id"));
                    registration.setTournamentId(rs.getInt("tournament_id"));
                    registration.setTeamId(rs.getInt("team_id"));
                    registration.setRegistrationStatusId(rs.getInt("registration_status_id"));

                    Timestamp registrationDate = rs.getTimestamp("registration_date");
                    if (registrationDate != null) {
                        registration.setRegistrationDate(registrationDate.toLocalDateTime());
                    }

                    registration.setApprovedBy(rs.getInt("approved_by"));

                    Timestamp approvedDate = rs.getTimestamp("approved_date");
                    if (approvedDate != null) {
                        registration.setApprovedDate(approvedDate.toLocalDateTime());
                    }

                    Timestamp createdAt = rs.getTimestamp("created_at");
                    if (createdAt != null) {
                        registration.setCreatedAt(createdAt.toLocalDateTime());
                    }

                    Timestamp updatedAt = rs.getTimestamp("updated_at");
                    if (updatedAt != null) {
                        registration.setUpdatedAt(updatedAt.toLocalDateTime());
                    }

                    return registration;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<TournamentRegistration> getAllTournamentRegistrations() {

        List<TournamentRegistration> registrations = new ArrayList<>();

        String sql = "SELECT * FROM tournament_registration";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                TournamentRegistration registration = new TournamentRegistration();

                registration.setId(rs.getInt("id"));
                registration.setTournamentId(rs.getInt("tournament_id"));
                registration.setTeamId(rs.getInt("team_id"));
                registration.setRegistrationStatusId(rs.getInt("registration_status_id"));

                Timestamp registrationDate = rs.getTimestamp("registration_date");
                if (registrationDate != null) {
                    registration.setRegistrationDate(registrationDate.toLocalDateTime());
                }

                registration.setApprovedBy(rs.getInt("approved_by"));

                Timestamp approvedDate = rs.getTimestamp("approved_date");
                if (approvedDate != null) {
                    registration.setApprovedDate(approvedDate.toLocalDateTime());
                }

                Timestamp createdAt = rs.getTimestamp("created_at");
                if (createdAt != null) {
                    registration.setCreatedAt(createdAt.toLocalDateTime());
                }

                Timestamp updatedAt = rs.getTimestamp("updated_at");
                if (updatedAt != null) {
                    registration.setUpdatedAt(updatedAt.toLocalDateTime());
                }

                registrations.add(registration);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return registrations;
    }

    @Override
    public TournamentRegistration updateTournamentRegistration(Integer id, TournamentRegistration entity) {

        String sql = "UPDATE tournament_registration SET " +
                    "tournament_id = ?, " +
                    "team_id = ?, " +
                    "registration_status_id = ?, " +
                    "registration_date = ?, " +
                    "approved_by = ?, " +
                    "approved_date = ?, " +
                    "created_at = ?, " +
                    "updated_at = ? " +
                    "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getTournamentId());
            ps.setInt(2, entity.getTeamId());
            ps.setInt(3, entity.getRegistrationStatusId());
            ps.setTimestamp(4, Timestamp.valueOf(entity.getRegistrationDate()));
            ps.setInt(5, entity.getApprovedBy());
            ps.setTimestamp(6, Timestamp.valueOf(entity.getApprovedDate()));
            ps.setTimestamp(7, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(8, Timestamp.valueOf(entity.getUpdatedAt()));
            ps.setInt(9, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteTournamentRegistration(Integer id) {

        String sql = "DELETE FROM tournament_registration WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    // ---- TournamentRegistrationPayment ----
    @Override
    public TournamentRegistrationPayment createTournamentRegistrationPayment(
            TournamentRegistrationPayment entity) {

        String sql = "INSERT INTO tournament_registration_payment " +
                "(id, registration_id, tournament_id, participant_id, amount, " +
                "payment_reference, payment_status, paid_date, created_at) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setInt(2, entity.getRegistrationId());
            ps.setInt(3, entity.getTournamentId());
            ps.setInt(4, entity.getParticipantId());
            ps.setBigDecimal(5, entity.getAmount());
            ps.setString(6, entity.getPaymentReference());
            ps.setString(7, entity.getPaymentStatus());
            ps.setTimestamp(8, Timestamp.valueOf(entity.getPaidDate()));
            ps.setTimestamp(9, Timestamp.valueOf(entity.getCreatedAt()));

            ps.executeUpdate();
            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<TournamentRegistrationPayment> getAllTournamentRegistrationPayments() {

        List<TournamentRegistrationPayment> payments = new ArrayList<>();

        String sql = "SELECT * FROM tournament_registration_payment";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                TournamentRegistrationPayment payment =
                        new TournamentRegistrationPayment();

                payment.setId(rs.getInt("id"));
                payment.setRegistrationId(rs.getInt("registration_id"));
                payment.setTournamentId(rs.getInt("tournament_id"));
                payment.setParticipantId(rs.getInt("participant_id"));
                payment.setAmount(rs.getBigDecimal("amount"));
                payment.setPaymentReference(rs.getString("payment_reference"));
                payment.setPaymentStatus(rs.getString("payment_status"));

                Timestamp paidDate = rs.getTimestamp("paid_date");
                if (paidDate != null) {
                    payment.setPaidDate(paidDate.toLocalDateTime());
                }

                Timestamp createdAt = rs.getTimestamp("created_at");
                if (createdAt != null) {
                    payment.setCreatedAt(createdAt.toLocalDateTime());
                }

                payments.add(payment);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return payments;
    }


    @Override
    public TournamentRegistrationPayment getTournamentRegistrationPaymentById(Integer id) {

        String sql = "SELECT * FROM tournament_registration_payment WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    TournamentRegistrationPayment payment =
                            new TournamentRegistrationPayment();

                    payment.setId(rs.getInt("id"));
                    payment.setRegistrationId(rs.getInt("registration_id"));
                    payment.setTournamentId(rs.getInt("tournament_id"));
                    payment.setParticipantId(rs.getInt("participant_id"));
                    payment.setAmount(rs.getBigDecimal("amount"));
                    payment.setPaymentReference(rs.getString("payment_reference"));
                    payment.setPaymentStatus(rs.getString("payment_status"));

                    Timestamp paidDate = rs.getTimestamp("paid_date");
                    if (paidDate != null) {
                        payment.setPaidDate(paidDate.toLocalDateTime());
                    }

                    Timestamp createdAt = rs.getTimestamp("created_at");
                    if (createdAt != null) {
                        payment.setCreatedAt(createdAt.toLocalDateTime());
                    }

                    return payment;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public TournamentRegistrationPayment updateTournamentRegistrationPayment(
            Integer id,
            TournamentRegistrationPayment entity) {

        String sql = "UPDATE tournament_registration_payment SET " +
                "registration_id = ?, " +
                "tournament_id = ?, " +
                "participant_id = ?, " +
                "amount = ?, " +
                "payment_reference = ?, " +
                "payment_status = ?, " +
                "paid_date = ?, " +
                "created_at = ? " +
                "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getRegistrationId());
            ps.setInt(2, entity.getTournamentId());
            ps.setInt(3, entity.getParticipantId());
            ps.setBigDecimal(4, entity.getAmount());
            ps.setString(5, entity.getPaymentReference());
            ps.setString(6, entity.getPaymentStatus());
            ps.setTimestamp(7, Timestamp.valueOf(entity.getPaidDate()));
            ps.setTimestamp(8, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setInt(9, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteTournamentRegistrationPayment(Integer id) {

        String sql = "DELETE FROM tournament_registration_payment WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    // ---- TournamentAnnouncement ----
    @Override
    public TournamentAnnouncement createTournamentAnnouncement(TournamentAnnouncement entity) {

        String sql = "INSERT INTO tournament_announcement " +
                    "(id, tournament_id, title, content, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setInt(2, entity.getTournamentId());
            ps.setString(3, entity.getTitle());
            ps.setString(4, entity.getContent());
            ps.setTimestamp(5, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(6, Timestamp.valueOf(entity.getUpdatedAt()));

            ps.executeUpdate();
            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public TournamentAnnouncement getTournamentAnnouncementById(Integer id) {

        String sql = "SELECT * FROM tournament_announcement WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    TournamentAnnouncement announcement = new TournamentAnnouncement();

                    announcement.setId(rs.getInt("id"));
                    announcement.setTournamentId(rs.getInt("tournament_id"));
                    announcement.setTitle(rs.getString("title"));
                    announcement.setContent(rs.getString("content"));

                    Timestamp createdAt = rs.getTimestamp("created_at");
                    if (createdAt != null) {
                        announcement.setCreatedAt(createdAt.toLocalDateTime());
                    }

                    Timestamp updatedAt = rs.getTimestamp("updated_at");
                    if (updatedAt != null) {
                        announcement.setUpdatedAt(updatedAt.toLocalDateTime());
                    }

                    return announcement;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<TournamentAnnouncement> getAllTournamentAnnouncements() {

        List<TournamentAnnouncement> announcements = new ArrayList<>();

        String sql = "SELECT * FROM tournament_announcement";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                TournamentAnnouncement announcement = new TournamentAnnouncement();

                announcement.setId(rs.getInt("id"));
                announcement.setTournamentId(rs.getInt("tournament_id"));
                announcement.setTitle(rs.getString("title"));
                announcement.setContent(rs.getString("content"));

                Timestamp createdAt = rs.getTimestamp("created_at");
                if (createdAt != null) {
                    announcement.setCreatedAt(createdAt.toLocalDateTime());
                }

                Timestamp updatedAt = rs.getTimestamp("updated_at");
                if (updatedAt != null) {
                    announcement.setUpdatedAt(updatedAt.toLocalDateTime());
                }

                announcements.add(announcement);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return announcements;
    }

    @Override
    public TournamentAnnouncement updateTournamentAnnouncement(Integer id,
            TournamentAnnouncement entity) {

        String sql = "UPDATE tournament_announcement SET " +
                    "tournament_id = ?, " +
                    "title = ?, " +
                    "content = ?, " +
                    "created_at = ?, " +
                    "updated_at = ? " +
                    "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getTournamentId());
            ps.setString(2, entity.getTitle());
            ps.setString(3, entity.getContent());
            ps.setTimestamp(4, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(5, Timestamp.valueOf(entity.getUpdatedAt()));
            ps.setInt(6, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteTournamentAnnouncement(Integer id) {

        String sql = "DELETE FROM tournament_announcement WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    // ---- TournamentFAQ ----
    @Override
    public TournamentFAQ createTournamentFAQ(TournamentFAQ entity) {

        String sql = "INSERT INTO tournament_faq " +
                    "(id, tournament_id, user_id, question, answer, status, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setInt(2, entity.getTournamentId());
            ps.setInt(3, entity.getUserId());
            ps.setString(4, entity.getQuestion());
            ps.setString(5, entity.getAnswer());
            ps.setString(6, entity.getStatus());
            ps.setTimestamp(7, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(8, Timestamp.valueOf(entity.getUpdatedAt()));

            ps.executeUpdate();
            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public TournamentFAQ getTournamentFAQById(Integer id) {

        String sql = "SELECT * FROM tournament_faq WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    TournamentFAQ faq = new TournamentFAQ();

                    faq.setId(rs.getInt("id"));
                    faq.setTournamentId(rs.getInt("tournament_id"));
                    faq.setUserId(rs.getInt("user_id"));
                    faq.setQuestion(rs.getString("question"));
                    faq.setAnswer(rs.getString("answer"));
                    faq.setStatus(rs.getString("status"));

                    Timestamp createdAt = rs.getTimestamp("created_at");
                    if (createdAt != null) {
                        faq.setCreatedAt(createdAt.toLocalDateTime());
                    }

                    Timestamp updatedAt = rs.getTimestamp("updated_at");
                    if (updatedAt != null) {
                        faq.setUpdatedAt(updatedAt.toLocalDateTime());
                    }

                    return faq;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<TournamentFAQ> getAllTournamentFAQs() {

        List<TournamentFAQ> faqs = new ArrayList<>();

        String sql = "SELECT * FROM tournament_faq";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                TournamentFAQ faq = new TournamentFAQ();

                faq.setId(rs.getInt("id"));
                faq.setTournamentId(rs.getInt("tournament_id"));
                faq.setUserId(rs.getInt("user_id"));
                faq.setQuestion(rs.getString("question"));
                faq.setAnswer(rs.getString("answer"));
                faq.setStatus(rs.getString("status"));

                Timestamp createdAt = rs.getTimestamp("created_at");
                if (createdAt != null) {
                    faq.setCreatedAt(createdAt.toLocalDateTime());
                }

                Timestamp updatedAt = rs.getTimestamp("updated_at");
                if (updatedAt != null) {
                    faq.setUpdatedAt(updatedAt.toLocalDateTime());
                }

                faqs.add(faq);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return faqs;
    }

    @Override
    public TournamentFAQ updateTournamentFAQ(Integer id, TournamentFAQ entity) {

        String sql = "UPDATE tournament_faq SET " +
                    "tournament_id = ?, " +
                    "user_id = ?, " +
                    "question = ?, " +
                    "answer = ?, " +
                    "status = ?, " +
                    "created_at = ?, " +
                    "updated_at = ? " +
                    "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getTournamentId());
            ps.setInt(2, entity.getUserId());
            ps.setString(3, entity.getQuestion());
            ps.setString(4, entity.getAnswer());
            ps.setString(5, entity.getStatus());
            ps.setTimestamp(6, Timestamp.valueOf(entity.getCreatedAt()));
            ps.setTimestamp(7, Timestamp.valueOf(entity.getUpdatedAt()));
            ps.setInt(8, id);

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteTournamentFAQ(Integer id) {

        String sql = "DELETE FROM tournament_faq WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    // ==========================
    // RoundDetails
    // ==========================

    @Override
    public RoundDetails createRoundDetails(RoundDetails entity) {

        String sql = "INSERT INTO round_details " +
                "(id, tournament_id, round_name, maximum_participants, qualifying_count) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setInt(2, entity.getTournamentId());
            ps.setString(3, entity.getRoundName());
            ps.setInt(4, entity.getMaximumParticipants());
            ps.setInt(5, entity.getQualifyingCount());

            ps.executeUpdate();

            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public RoundDetails getRoundDetailsById(Integer id) {

        String sql = "SELECT * FROM round_details WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    RoundDetails entity = new RoundDetails();

                    entity.setId(rs.getInt("id"));
                    entity.setTournamentId(rs.getInt("tournament_id"));
                    entity.setRoundName(rs.getString("round_name"));
                    entity.setMaximumParticipants(rs.getInt("maximum_participants"));
                    entity.setQualifyingCount(rs.getInt("qualifying_count"));

                    return entity;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<RoundDetails> getAllRoundDetails() {

        List<RoundDetails> list = new ArrayList<>();

        String sql = "SELECT * FROM round_details";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                RoundDetails entity = new RoundDetails();

                entity.setId(rs.getInt("id"));
                entity.setTournamentId(rs.getInt("tournament_id"));
                entity.setRoundName(rs.getString("round_name"));
                entity.setMaximumParticipants(rs.getInt("maximum_participants"));
                entity.setQualifyingCount(rs.getInt("qualifying_count"));

                list.add(entity);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return list;
    }

    @Override
    public RoundDetails updateRoundDetails(Integer id, RoundDetails entity) {

        String sql = "UPDATE round_details SET " +
                "tournament_id = ?, " +
                "round_name = ?, " +
                "maximum_participants = ?, " +
                "qualifying_count = ? " +
                "WHERE id = ?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getTournamentId());
            ps.setString(2, entity.getRoundName());
            ps.setInt(3, entity.getMaximumParticipants());
            ps.setInt(4, entity.getQualifyingCount());
            ps.setInt(5, id);

            if (ps.executeUpdate() > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteRoundDetails(Integer id) {

        String sql = "DELETE FROM round_details WHERE id=?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }
    
    // ==========================
    // MatchDetails
    // ==========================

    @Override
    public MatchDetails createMatchDetails(MatchDetails entity) {

        String sql = "INSERT INTO match_details " +
                "(id, round_id, start_time, end_time, status) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setInt(2, entity.getRoundId());
            ps.setTimestamp(3, Timestamp.valueOf(entity.getStartTime()));
            ps.setTimestamp(4, Timestamp.valueOf(entity.getEndTime()));
            ps.setString(5, entity.getStatus());

            ps.executeUpdate();

            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public MatchDetails getMatchDetailsById(Integer id) {

        String sql = "SELECT * FROM match_details WHERE id=?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    MatchDetails entity = new MatchDetails();

                    entity.setId(rs.getInt("id"));
                    entity.setRoundId(rs.getInt("round_id"));
                    entity.setStartTime(rs.getTimestamp("start_time").toLocalDateTime());
                    entity.setEndTime(rs.getTimestamp("end_time").toLocalDateTime());
                    entity.setStatus(rs.getString("status"));

                    return entity;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<MatchDetails> getAllMatchDetails() {

        List<MatchDetails> list = new ArrayList<>();

        String sql = "SELECT * FROM match_details";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                MatchDetails entity = new MatchDetails();

                entity.setId(rs.getInt("id"));
                entity.setRoundId(rs.getInt("round_id"));
                entity.setStartTime(rs.getTimestamp("start_time").toLocalDateTime());
                entity.setEndTime(rs.getTimestamp("end_time").toLocalDateTime());
                entity.setStatus(rs.getString("status"));

                list.add(entity);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return list;
    }

    @Override
    public MatchDetails updateMatchDetails(Integer id, MatchDetails entity) {

        String sql = "UPDATE match_details SET " +
                "round_id=?, start_time=?, end_time=?, status=? WHERE id=?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getRoundId());
            ps.setTimestamp(2, Timestamp.valueOf(entity.getStartTime()));
            ps.setTimestamp(3, Timestamp.valueOf(entity.getEndTime()));
            ps.setString(4, entity.getStatus());
            ps.setInt(5, id);

            if (ps.executeUpdate() > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteMatchDetails(Integer id) {

        String sql = "DELETE FROM match_details WHERE id=?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

    // ==========================
    // MatchParticipants
    // ==========================
    
    @Override
    public MatchParticipants createMatchParticipants(MatchParticipants entity) {

        String sql = "INSERT INTO match_participants " +
                "(id, match_id, team_id, status) VALUES (?, ?, ?, ?)";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getId());
            ps.setInt(2, entity.getMatchId());
            ps.setInt(3, entity.getTeamId());
            ps.setString(4, entity.getStatus());

            ps.executeUpdate();

            return entity;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public MatchParticipants getMatchParticipantsById(Integer id) {

        String sql = "SELECT * FROM match_participants WHERE id=?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    MatchParticipants entity = new MatchParticipants();

                    entity.setId(rs.getInt("id"));
                    entity.setMatchId(rs.getInt("match_id"));
                    entity.setTeamId(rs.getInt("team_id"));
                    entity.setStatus(rs.getString("status"));

                    return entity;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public List<MatchParticipants> getAllMatchParticipants() {

        List<MatchParticipants> list = new ArrayList<>();

        String sql = "SELECT * FROM match_participants";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                MatchParticipants entity = new MatchParticipants();

                entity.setId(rs.getInt("id"));
                entity.setMatchId(rs.getInt("match_id"));
                entity.setTeamId(rs.getInt("team_id"));
                entity.setStatus(rs.getString("status"));

                list.add(entity);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return list;
    }

    @Override
    public MatchParticipants updateMatchParticipants(Integer id, MatchParticipants entity) {

        String sql = "UPDATE match_participants SET " +
                "match_id=?, team_id=?, status=? WHERE id=?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, entity.getMatchId());
            ps.setInt(2, entity.getTeamId());
            ps.setString(3, entity.getStatus());
            ps.setInt(4, id);

            if (ps.executeUpdate() > 0) {
                entity.setId(id);
                return entity;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean deleteMatchParticipants(Integer id) {

        String sql = "DELETE FROM match_participants WHERE id=?";

        try (Connection connection = DBConnection.getInstance().getConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;
    }

}