package com.esports.service.interfaces;

import com.esports.entity.*;
import java.util.List;

/**
 * CRUD contract for the Tournament Management module.
 * Covers entities: TournamentCategory, TournamentType, SeedingType, Tournament, RulesCategory, TournamentRule, PrizeCategory, TournamentPrize, TournamentPackage, TournamentPayment, TournamentRegistration, TournamentRegistrationPayment, TournamentAnnouncement, TournamentFAQ
 */
public interface TournamentService {

    // ---- TournamentCategory ----
    TournamentCategory createTournamentCategory(TournamentCategory entity);
    TournamentCategory getTournamentCategoryById(Integer id);
    List<TournamentCategory> getAllTournamentCategorys();
    TournamentCategory updateTournamentCategory(Integer id, TournamentCategory entity);
    boolean deleteTournamentCategory(Integer id);

    // ---- TournamentType ----
    TournamentType createTournamentType(TournamentType entity);
    TournamentType getTournamentTypeById(Integer id);
    List<TournamentType> getAllTournamentTypes();
    TournamentType updateTournamentType(Integer id, TournamentType entity);
    boolean deleteTournamentType(Integer id);


    // ---- Tournament ----
    Tournament createTournament(Tournament entity);
    Tournament getTournamentById(Integer id);
    List<Tournament> getAllTournaments();
    Tournament updateTournament(Integer id, Tournament entity);
    boolean deleteTournament(Integer id);

    // ---- RulesCategory ----
    RulesCategory createRulesCategory(RulesCategory entity);
    RulesCategory getRulesCategoryById(Integer id);
    List<RulesCategory> getAllRulesCategorys();
    RulesCategory updateRulesCategory(Integer id, RulesCategory entity);
    boolean deleteRulesCategory(Integer id);

    // ---- TournamentRule ----
    TournamentRule createTournamentRule(TournamentRule entity);
    TournamentRule getTournamentRuleById(Integer id);
    List<TournamentRule> getAllTournamentRules();
    TournamentRule updateTournamentRule(Integer id, TournamentRule entity);
    boolean deleteTournamentRule(Integer id);

    // ---- PrizeCategory ----
    PrizeCategory createPrizeCategory(PrizeCategory entity);
    PrizeCategory getPrizeCategoryById(Integer id);
    List<PrizeCategory> getAllPrizeCategorys();
    PrizeCategory updatePrizeCategory(Integer id, PrizeCategory entity);
    boolean deletePrizeCategory(Integer id);

    // ---- TournamentPrize ----
    TournamentPrize createTournamentPrize(TournamentPrize entity);
    TournamentPrize getTournamentPrizeById(Integer id);
    List<TournamentPrize> getAllTournamentPrizes();
    TournamentPrize updateTournamentPrize(Integer id, TournamentPrize entity);
    boolean deleteTournamentPrize(Integer id);

    // ---- TournamentRegistration ----
    TournamentRegistration createTournamentRegistration(TournamentRegistration entity);
    TournamentRegistration getTournamentRegistrationById(Integer id);
    List<TournamentRegistration> getAllTournamentRegistrations();
    TournamentRegistration updateTournamentRegistration(Integer id, TournamentRegistration entity);
    boolean deleteTournamentRegistration(Integer id);

    // ---- TournamentRegistrationPayment ----
    TournamentRegistrationPayment createTournamentRegistrationPayment(TournamentRegistrationPayment entity);
    TournamentRegistrationPayment getTournamentRegistrationPaymentById(Integer id);
    List<TournamentRegistrationPayment> getAllTournamentRegistrationPayments();
    TournamentRegistrationPayment updateTournamentRegistrationPayment(Integer id, TournamentRegistrationPayment entity);
    boolean deleteTournamentRegistrationPayment(Integer id);

    // ---- TournamentAnnouncement ----
    TournamentAnnouncement createTournamentAnnouncement(TournamentAnnouncement entity);
    TournamentAnnouncement getTournamentAnnouncementById(Integer id);
    List<TournamentAnnouncement> getAllTournamentAnnouncements();
    TournamentAnnouncement updateTournamentAnnouncement(Integer id, TournamentAnnouncement entity);
    boolean deleteTournamentAnnouncement(Integer id);

    // ---- TournamentFAQ ----
    TournamentFAQ createTournamentFAQ(TournamentFAQ entity);
    TournamentFAQ getTournamentFAQById(Integer id);
    List<TournamentFAQ> getAllTournamentFAQs();
    TournamentFAQ updateTournamentFAQ(Integer id, TournamentFAQ entity);
    boolean deleteTournamentFAQ(Integer id);

    // ==========================
    // RoundDetails
    // ==========================

    RoundDetails createRoundDetails(RoundDetails entity);

    RoundDetails getRoundDetailsById(Integer id);

    List<RoundDetails> getAllRoundDetails();

    RoundDetails updateRoundDetails(Integer id, RoundDetails entity);

    boolean deleteRoundDetails(Integer id);


    // ==========================
    // MatchDetails
    // ==========================

    MatchDetails createMatchDetails(MatchDetails entity);

    MatchDetails getMatchDetailsById(Integer id);

    List<MatchDetails> getAllMatchDetails();

    MatchDetails updateMatchDetails(Integer id, MatchDetails entity);

    boolean deleteMatchDetails(Integer id);


    // ==========================
    // MatchParticipants
    // ==========================

    MatchParticipants createMatchParticipants(MatchParticipants entity);

    MatchParticipants getMatchParticipantsById(Integer id);

    List<MatchParticipants> getAllMatchParticipants();

    MatchParticipants updateMatchParticipants(Integer id, MatchParticipants entity);

    boolean deleteMatchParticipants(Integer id);

}