import re, os

ENTITY_DIR = "src/main/java/com/esports/platform/entity"

# Each tuple:
# (child_table, fk_column, parent_table, cardinality, child_field, parent_field)
# cardinality: "OneToOne" or "ManyToOne"
# child_field  -> new field added on the CHILD (owning / FK-holding) entity, type = parent_table
# parent_field -> new field added on the PARENT entity.
#                 For ManyToOne  -> List<child_table>  (OneToMany, mappedBy=child_field)
#                 For OneToOne   -> child_table         (OneToOne,  mappedBy=child_field)
RELATIONS = [
    ("AffiliateLink", "affiliateCampaignId", "AffiliateCampaign", "ManyToOne", "affiliateCampaign", "affiliateLinks"),
    ("AffiliateLink", "assignedUserId", "Users", "ManyToOne", "assignedUser", "assignedAffiliateLinks"),
    ("AffiliateClick", "affiliateLinkId", "AffiliateLink", "ManyToOne", "affiliateLink", "clicks"),

    ("Conversation", "createdBy", "Users", "ManyToOne", "creator", "createdConversations"),
    ("ConversationParticipant", "conversationId", "Conversation", "ManyToOne", "conversation", "participants"),
    ("ConversationParticipant", "userId", "Users", "ManyToOne", "user", "conversationParticipations"),

    ("Message", "conversationId", "Conversation", "ManyToOne", "conversation", "messages"),
    ("Message", "senderId", "Users", "ManyToOne", "sender", "sentMessages"),
    ("Message", "replyMessageId", "Message", "ManyToOne", "replyMessage", "replies"),

    ("MessageAttachment", "messageId", "Message", "ManyToOne", "message", "attachments"),
    ("MessageAttachment", "fileId", "Files", "ManyToOne", "file", "messageAttachments"),

    ("MessageReadStatus", "messageId", "Message", "ManyToOne", "message", "readStatuses"),
    ("MessageReadStatus", "userId", "Users", "ManyToOne", "user", "messageReadStatuses"),

    ("MessageReaction", "messageId", "Message", "ManyToOne", "message", "reactions"),
    ("MessageReaction", "userId", "Users", "ManyToOne", "user", "messageReactions"),

    ("UserPresence", "userId", "Users", "OneToOne", "user", "presence"),

    ("ConversationPinnedMessage", "conversationId", "Conversation", "ManyToOne", "conversation", "pinnedMessages"),
    ("ConversationPinnedMessage", "messageId", "Message", "ManyToOne", "message", "pins"),
    ("ConversationPinnedMessage", "pinnedBy", "Users", "ManyToOne", "pinnedByUser", "pinnedMessagesByUser"),

    ("ConversationSettings", "conversationId", "Conversation", "OneToOne", "conversation", "settings"),

    ("UserRoles", "userId", "Users", "ManyToOne", "user", "userRoles"),
    ("UserRoles", "roleId", "Roles", "ManyToOne", "role", "userRoles"),

    ("UserProfile", "userId", "Users", "OneToOne", "user", "profile"),
    ("TournamentOrganizerDetails", "userId", "Users", "OneToOne", "user", "organizerDetails"),
    ("BrandDetails", "userId", "Users", "OneToOne", "user", "brandDetails"),
    ("InfluencerDetails", "userId", "Users", "OneToOne", "user", "influencerDetails"),

    ("SocialMediaAccount", "userId", "Users", "ManyToOne", "user", "socialMediaAccounts"),
    ("SocialMediaAccount", "platformId", "SocialMediaPlatform", "ManyToOne", "platform", "accounts"),
    ("SocialMediaAccount", "acceptanceStatusId", "StatusMaster", "ManyToOne", "acceptanceStatus", "socialMediaAccounts"),

    ("InfluencerGame", "influencerId", "InfluencerDetails", "ManyToOne", "influencer", "games"),
    ("InfluencerGame", "gameId", "Game", "ManyToOne", "game", "influencerGames"),

    ("TournamentType", "categoryId", "TournamentCategory", "ManyToOne", "category", "tournamentTypes"),

    ("Tournament", "organizerId", "Users", "ManyToOne", "organizer", "organizedTournaments"),
    ("Tournament", "categoryId", "TournamentCategory", "ManyToOne", "category", "tournaments"),
    ("Tournament", "tournamentTypeId", "TournamentType", "ManyToOne", "tournamentType", "tournaments"),
    ("Tournament", "seedingTypeId", "SeedingType", "ManyToOne", "seedingType", "tournaments"),
    ("Tournament", "packageId", "TournamentPackage", "ManyToOne", "tournamentPackage", "tournaments"),

    ("TournamentRule", "tournamentId", "Tournament", "ManyToOne", "tournament", "rules"),
    ("TournamentRule", "categoryId", "RulesCategory", "ManyToOne", "category", "rules"),

    ("TournamentPrize", "tournamentId", "Tournament", "ManyToOne", "tournament", "prizes"),
    ("TournamentPrize", "prizeCategoryId", "PrizeCategory", "ManyToOne", "prizeCategory", "prizes"),

    ("Team", "ownerId", "Users", "ManyToOne", "owner", "ownedTeams"),

    ("TeamMember", "teamId", "Team", "ManyToOne", "team", "members"),
    ("TeamMember", "userId", "Users", "ManyToOne", "user", "teamMemberships"),
    ("TeamMember", "positionId", "TeamPosition", "ManyToOne", "position", "teamMembers"),

    ("TournamentRegistration", "tournamentId", "Tournament", "ManyToOne", "tournament", "registrations"),
    ("TournamentRegistration", "teamId", "Team", "ManyToOne", "team", "registrations"),
    ("TournamentRegistration", "registrationStatusId", "StatusMaster", "ManyToOne", "registrationStatus", "tournamentRegistrations"),

    ("TournamentRegistrationPayment", "registrationId", "TournamentRegistration", "ManyToOne", "registration", "payments"),

    ("TournamentAnnouncement", "tournamentId", "Tournament", "ManyToOne", "tournament", "announcements"),

    ("TournamentFAQ", "tournamentId", "Tournament", "ManyToOne", "tournament", "faqs"),
    ("TournamentFAQ", "userId", "Users", "ManyToOne", "user", "tournamentFaqs"),

    ("Campaign", "brandId", "BrandDetails", "ManyToOne", "brand", "campaigns"),
    ("Campaign", "campaignTypeId", "CampaignType", "ManyToOne", "campaignType", "campaigns"),
    ("Campaign", "gameId", "Game", "ManyToOne", "game", "campaigns"),

    ("CampaignPlatform", "campaignId", "Campaign", "ManyToOne", "campaign", "platforms"),
    ("CampaignPlatform", "platformId", "SocialMediaPlatform", "ManyToOne", "platform", "campaignPlatforms"),

    ("CampaignAsset", "campaignId", "Campaign", "ManyToOne", "campaign", "assets"),
    ("CampaignDeliverable", "campaignId", "Campaign", "ManyToOne", "campaign", "deliverables"),

    ("CollaborationRequest", "senderId", "Users", "ManyToOne", "sender", "sentCollaborationRequests"),
    ("CollaborationRequest", "receiverId", "Users", "ManyToOne", "receiver", "receivedCollaborationRequests"),
    ("CollaborationRequest", "campaignId", "Campaign", "ManyToOne", "campaign", "collaborationRequests"),

    ("RevenueTransaction", "transactionTypeId", "TransactionType", "ManyToOne", "transactionType", "transactions"),
    ("RevenueTransaction", "userId", "Users", "ManyToOne", "user", "revenueTransactions"),
    ("RevenueTransaction", "paymentMethodId", "PaymentMethod", "ManyToOne", "paymentMethod", "transactions"),

    ("TournamentPayment", "organizerId", "Users", "ManyToOne", "organizer", "tournamentPayments"),
    ("TournamentPayment", "tournamentId", "Tournament", "ManyToOne", "tournament", "payments"),
    ("TournamentPayment", "packageId", "TournamentPackage", "ManyToOne", "tournamentPackage", "payments"),

    ("UserSubscription", "userId", "Users", "ManyToOne", "user", "subscriptions"),
    ("UserSubscription", "subscriptionPlanId", "SubscriptionPlan", "ManyToOne", "subscriptionPlan", "userSubscriptions"),

    ("Notification", "userId", "Users", "ManyToOne", "user", "notifications"),
    ("AuditLog", "userId", "Users", "ManyToOne", "user", "auditLogs"),
]

print(f"Total relationships: {len(RELATIONS)}")
assert len(RELATIONS) == 72, len(RELATIONS)

# ---------------------------------------------------------------------
# Build per-entity injection plans
# ---------------------------------------------------------------------
# child_additions[entity]  -> list of (fk_col, cardinality, parent_type, field_name, ref_name)
# parent_additions[entity] -> list of (cardinality, child_type, field_name, mapped_by, ref_name)
child_additions = {}
parent_additions = {}

for child, fk_col, parent, card, child_field, parent_field in RELATIONS:
    child_additions.setdefault(child, []).append((fk_col, card, parent, child_field, child_field))
    parent_additions.setdefault(parent, []).append((card, child, parent_field, child_field, child_field))

all_entities = sorted(set(list(child_additions.keys()) + list(parent_additions.keys())))
print(f"Entities touched: {len(all_entities)}")

def field_block_child(fk_col, card, parent_type, field_name, ref_name):
    if card == "OneToOne":
        return (
            f'    @OneToOne(fetch = FetchType.LAZY)\n'
            f'    @JoinColumn(name = "{fk_col}", insertable = false, updatable = false)\n'
            f'    @JsonBackReference("{ref_name}")\n'
            f'    private {parent_type} {field_name};\n'
        )
    return (
        f'    @ManyToOne(fetch = FetchType.LAZY)\n'
        f'    @JoinColumn(name = "{fk_col}", insertable = false, updatable = false)\n'
        f'    @JsonBackReference("{ref_name}")\n'
        f'    private {parent_type} {field_name};\n'
    )

def field_block_parent(card, child_type, field_name, mapped_by, ref_name):
    if card == "OneToOne":
        return (
            f'    @OneToOne(mappedBy = "{mapped_by}", fetch = FetchType.LAZY)\n'
            f'    @JsonManagedReference("{ref_name}")\n'
            f'    private {child_type} {field_name};\n'
        )
    return (
        f'    @OneToMany(mappedBy = "{mapped_by}", fetch = FetchType.LAZY)\n'
        f'    @JsonManagedReference("{ref_name}")\n'
        f'    private List<{child_type}> {field_name} = new ArrayList<>();\n'
    )

def accessor_block(java_type, field_name):
    cap = field_name[0].upper() + field_name[1:]
    return (
        f'    public {java_type} get{cap}() {{\n'
        f'        return {field_name};\n'
        f'    }}\n\n'
        f'    public void set{cap}({java_type} {field_name}) {{\n'
        f'        this.{field_name} = {field_name};\n'
        f'    }}\n\n'
    )

modified = 0
for entity in all_entities:
    path = f"{ENTITY_DIR}/{entity}.java"
    with open(path) as f:
        src = f.read()

    needs_list_imports = False
    needs_managed_ref = False
    needs_back_ref = False

    field_decls = []
    accessor_decls = []

    for fk_col, card, parent_type, field_name, ref_name in child_additions.get(entity, []):
        field_decls.append(field_block_child(fk_col, card, parent_type, field_name, ref_name))
        accessor_decls.append(accessor_block(parent_type, field_name))
        needs_back_ref = True

    for card, child_type, field_name, mapped_by, ref_name in parent_additions.get(entity, []):
        field_decls.append(field_block_parent(card, child_type, field_name, mapped_by, ref_name))
        java_type = child_type if card == "OneToOne" else f"List<{child_type}>"
        accessor_decls.append(accessor_block(java_type, field_name))
        needs_managed_ref = True
        if card != "OneToOne":
            needs_list_imports = True

    if not field_decls:
        continue

    # ---- imports ----
    import_lines = []
    if needs_managed_ref:
        import_lines.append("import com.fasterxml.jackson.annotation.JsonManagedReference;")
    if needs_back_ref:
        import_lines.append("import com.fasterxml.jackson.annotation.JsonBackReference;")
    if needs_list_imports:
        import_lines.append("import java.util.ArrayList;")
        import_lines.append("import java.util.List;")

    if import_lines:
        # insert after the last existing import line
        import_block = "\n".join(import_lines)
        last_import_match = list(re.finditer(r'^import .*;$', src, re.MULTILINE))
        if last_import_match:
            insert_at = last_import_match[-1].end()
            src = src[:insert_at] + "\n" + import_block + src[insert_at:]
        else:
            src = src.replace("package com.esports.platform.entity;\n",
                               f"package com.esports.platform.entity;\n\n{import_block}\n", 1)

    # ---- fields: insert right before the no-arg constructor ----
    ctor_marker = f"public {entity}() {{"
    assert ctor_marker in src, f"Constructor marker not found in {entity}"
    relation_comment = "    // ---- Relationships (added for association mapping) ----\n"
    fields_block = relation_comment + "\n".join(field_decls) + "\n"
    src = src.replace(ctor_marker, fields_block + "\n    " + ctor_marker, 1)

    # ---- accessors: insert right before "@Override\n    public boolean equals" ----
    equals_marker = "    @Override\n    public boolean equals(Object o) {"
    assert equals_marker in src, f"equals() marker not found in {entity}"
    accessors_block = "".join(accessor_decls)
    src = src.replace(equals_marker, accessors_block + equals_marker, 1)

    with open(path, "w") as f:
        f.write(src)
    modified += 1

print(f"Modified {modified} entity files.")
