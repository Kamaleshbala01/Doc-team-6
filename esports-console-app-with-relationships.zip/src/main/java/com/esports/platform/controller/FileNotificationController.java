package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.FileNotificationServiceImpl;
import com.esports.platform.service.interfaces.FileNotificationService;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Runs a full create / list / update / delete / list cycle for every
 * entity in the Files, Notifications & Audit module using static dummy data.
 * No user input is required.
 */
public class FileNotificationController {

    private static final LocalDateTime STATIC_DATE = LocalDateTime.of(2026, 1, 1, 10, 0);

    private final FileNotificationService fileNotificationService = new FileNotificationServiceImpl();

    public void start() {
        System.out.println();
        System.out.println("=== Files, Notifications & Audit ===");
        runFilesCrud();
        runNotificationCrud();
        runAuditLogCrud();
    }

    private void runFilesCrud() {
        System.out.println("\n--- Files CRUD ---");

        Files record1 = new Files();
        record1.setId(1);
        record1.setFileName("fileName1");
        record1.setFileType("fileType1");
        record1.setBucketName("bucketName1");
        record1.setStoragePath("storagePath1");
        record1.setFileSize(1L);
        record1.setUploadedBy(1);
        record1.setCreatedAt(STATIC_DATE);
        fileNotificationService.createFiles(record1);
        System.out.println("Created: " + record1);

        Files record2 = new Files();
        record2.setId(2);
        record2.setFileName("fileName2");
        record2.setFileType("fileType2");
        record2.setBucketName("bucketName2");
        record2.setStoragePath("storagePath2");
        record2.setFileSize(2L);
        record2.setUploadedBy(2);
        record2.setCreatedAt(STATIC_DATE);
        fileNotificationService.createFiles(record2);
        System.out.println("Created: " + record2);

        System.out.println("All Files after create:");
        fileNotificationService.getAllFiles().forEach(System.out::println);

        Files updated = new Files();
        updated.setFileName("fileName9");
        updated.setFileType("fileType9");
        updated.setBucketName("bucketName9");
        updated.setStoragePath("storagePath9");
        updated.setFileSize(9L);
        updated.setUploadedBy(9);
        updated.setCreatedAt(STATIC_DATE);
        fileNotificationService.updateFiles(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        fileNotificationService.deleteFiles(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All Files after update & delete:");
        fileNotificationService.getAllFiles().forEach(System.out::println);
    }

    private void runNotificationCrud() {
        System.out.println("\n--- Notification CRUD ---");

        Notification record1 = new Notification();
        record1.setId(1);
        record1.setUserId(1);
        record1.setTitle("title1");
        record1.setMessage("message1");
        record1.setIsRead(true);
        record1.setCreatedAt(STATIC_DATE);
        fileNotificationService.createNotification(record1);
        System.out.println("Created: " + record1);

        Notification record2 = new Notification();
        record2.setId(2);
        record2.setUserId(2);
        record2.setTitle("title2");
        record2.setMessage("message2");
        record2.setIsRead(false);
        record2.setCreatedAt(STATIC_DATE);
        fileNotificationService.createNotification(record2);
        System.out.println("Created: " + record2);

        System.out.println("All Notification after create:");
        fileNotificationService.getAllNotifications().forEach(System.out::println);

        Notification updated = new Notification();
        updated.setUserId(9);
        updated.setTitle("title9");
        updated.setMessage("message9");
        updated.setIsRead(false);
        updated.setCreatedAt(STATIC_DATE);
        fileNotificationService.updateNotification(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        fileNotificationService.deleteNotification(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All Notification after update & delete:");
        fileNotificationService.getAllNotifications().forEach(System.out::println);
    }

    private void runAuditLogCrud() {
        System.out.println("\n--- AuditLog CRUD ---");

        AuditLog record1 = new AuditLog();
        record1.setId(1);
        record1.setUserId(1);
        record1.setEntityName("entityName1");
        record1.setEntityId(1);
        record1.setActionType("actionType1");
        record1.setOldValue("oldValue1");
        record1.setNewValue("newValue1");
        record1.setIpAddress("ipAddress1");
        record1.setUserAgent("userAgent1");
        record1.setCreatedAt(STATIC_DATE);
        fileNotificationService.createAuditLog(record1);
        System.out.println("Created: " + record1);

        AuditLog record2 = new AuditLog();
        record2.setId(2);
        record2.setUserId(2);
        record2.setEntityName("entityName2");
        record2.setEntityId(2);
        record2.setActionType("actionType2");
        record2.setOldValue("oldValue2");
        record2.setNewValue("newValue2");
        record2.setIpAddress("ipAddress2");
        record2.setUserAgent("userAgent2");
        record2.setCreatedAt(STATIC_DATE);
        fileNotificationService.createAuditLog(record2);
        System.out.println("Created: " + record2);

        System.out.println("All AuditLog after create:");
        fileNotificationService.getAllAuditLogs().forEach(System.out::println);

        AuditLog updated = new AuditLog();
        updated.setUserId(9);
        updated.setEntityName("entityName9");
        updated.setEntityId(9);
        updated.setActionType("actionType9");
        updated.setOldValue("oldValue9");
        updated.setNewValue("newValue9");
        updated.setIpAddress("ipAddress9");
        updated.setUserAgent("userAgent9");
        updated.setCreatedAt(STATIC_DATE);
        fileNotificationService.updateAuditLog(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        fileNotificationService.deleteAuditLog(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All AuditLog after update & delete:");
        fileNotificationService.getAllAuditLogs().forEach(System.out::println);
    }

}