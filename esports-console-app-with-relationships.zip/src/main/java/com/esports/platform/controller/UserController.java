package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.UserServiceImpl;
import com.esports.platform.service.interfaces.UserService;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Runs a full create / list / update / delete / list cycle for every
 * entity in the User Management (Users, Roles, Profiles, Organiser/Brand/Influencer Details) module using static dummy data.
 * No user input is required.
 */
public class UserController {

    private static final LocalDateTime STATIC_DATE = LocalDateTime.of(2026, 1, 1, 10, 0);

    private final UserService userService = new UserServiceImpl();

    public void start() {
        System.out.println();
        System.out.println("=== User Management (Users, Roles, Profiles, Organiser/Brand/Influencer Details) ===");
        runUsersCrud();
        runRolesCrud();
        runUserRolesCrud();
        runUserProfileCrud();
        runTournamentOrganizerDetailsCrud();
        runBrandDetailsCrud();
        runInfluencerDetailsCrud();
    }

    private void runUsersCrud() {
        System.out.println("\n--- Users CRUD ---");

        Users record1 = new Users();
        record1.setId(1);
        record1.setEmail("email1");
        record1.setUsername("username1");
        record1.setPasswordHash("passwordHash1");
        record1.setEmailVerified(true);
        record1.setStatus("status1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        record1.setLastLoginAt(STATIC_DATE);
        userService.createUsers(record1);
        System.out.println("Created: " + record1);

        Users record2 = new Users();
        record2.setId(2);
        record2.setEmail("email2");
        record2.setUsername("username2");
        record2.setPasswordHash("passwordHash2");
        record2.setEmailVerified(false);
        record2.setStatus("status2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        record2.setLastLoginAt(STATIC_DATE);
        userService.createUsers(record2);
        System.out.println("Created: " + record2);

        System.out.println("All Users after create:");
        userService.getAllUsers().forEach(System.out::println);

        Users updated = new Users();
        updated.setEmail("email9");
        updated.setUsername("username9");
        updated.setPasswordHash("passwordHash9");
        updated.setEmailVerified(false);
        updated.setStatus("status9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        updated.setLastLoginAt(STATIC_DATE);
        userService.updateUsers(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        userService.deleteUsers(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All Users after update & delete:");
        userService.getAllUsers().forEach(System.out::println);
    }

    private void runRolesCrud() {
        System.out.println("\n--- Roles CRUD ---");

        Roles record1 = new Roles();
        record1.setId(1);
        record1.setRoleName("roleName1");
        record1.setCreatedAt(STATIC_DATE);
        userService.createRoles(record1);
        System.out.println("Created: " + record1);

        Roles record2 = new Roles();
        record2.setId(2);
        record2.setRoleName("roleName2");
        record2.setCreatedAt(STATIC_DATE);
        userService.createRoles(record2);
        System.out.println("Created: " + record2);

        System.out.println("All Roles after create:");
        userService.getAllRoles().forEach(System.out::println);

        Roles updated = new Roles();
        updated.setRoleName("roleName9");
        updated.setCreatedAt(STATIC_DATE);
        userService.updateRoles(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        userService.deleteRoles(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All Roles after update & delete:");
        userService.getAllRoles().forEach(System.out::println);
    }

    private void runUserRolesCrud() {
        System.out.println("\n--- UserRoles CRUD ---");

        UserRoles record1 = new UserRoles();
        record1.setId(1);
        record1.setUserId(1);
        record1.setRoleId(1);
        record1.setCreatedAt(STATIC_DATE);
        userService.createUserRoles(record1);
        System.out.println("Created: " + record1);

        UserRoles record2 = new UserRoles();
        record2.setId(2);
        record2.setUserId(2);
        record2.setRoleId(2);
        record2.setCreatedAt(STATIC_DATE);
        userService.createUserRoles(record2);
        System.out.println("Created: " + record2);

        System.out.println("All UserRoles after create:");
        userService.getAllUserRoles().forEach(System.out::println);

        UserRoles updated = new UserRoles();
        updated.setUserId(9);
        updated.setRoleId(9);
        updated.setCreatedAt(STATIC_DATE);
        userService.updateUserRoles(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        userService.deleteUserRoles(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All UserRoles after update & delete:");
        userService.getAllUserRoles().forEach(System.out::println);
    }

    private void runUserProfileCrud() {
        System.out.println("\n--- UserProfile CRUD ---");

        UserProfile record1 = new UserProfile();
        record1.setId(1);
        record1.setUserId(1);
        record1.setFirstName("firstName1");
        record1.setLastName("lastName1");
        record1.setProfileImage("profileImage1");
        record1.setBio("bio1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        userService.createUserProfile(record1);
        System.out.println("Created: " + record1);

        UserProfile record2 = new UserProfile();
        record2.setId(2);
        record2.setUserId(2);
        record2.setFirstName("firstName2");
        record2.setLastName("lastName2");
        record2.setProfileImage("profileImage2");
        record2.setBio("bio2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        userService.createUserProfile(record2);
        System.out.println("Created: " + record2);

        System.out.println("All UserProfile after create:");
        userService.getAllUserProfiles().forEach(System.out::println);

        UserProfile updated = new UserProfile();
        updated.setUserId(9);
        updated.setFirstName("firstName9");
        updated.setLastName("lastName9");
        updated.setProfileImage("profileImage9");
        updated.setBio("bio9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        userService.updateUserProfile(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        userService.deleteUserProfile(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All UserProfile after update & delete:");
        userService.getAllUserProfiles().forEach(System.out::println);
    }

    private void runTournamentOrganizerDetailsCrud() {
        System.out.println("\n--- TournamentOrganizerDetails CRUD ---");

        TournamentOrganizerDetails record1 = new TournamentOrganizerDetails();
        record1.setId(1);
        record1.setUserId(1);
        record1.setMobileNumber("mobileNumber1");
        record1.setGovernmentIdUri("governmentIdUri1");
        record1.setSelfieVerificationUri("selfieVerificationUri1");
        record1.setVerificationStatus("verificationStatus1");
        record1.setVerifiedAt(STATIC_DATE);
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        userService.createTournamentOrganizerDetails(record1);
        System.out.println("Created: " + record1);

        TournamentOrganizerDetails record2 = new TournamentOrganizerDetails();
        record2.setId(2);
        record2.setUserId(2);
        record2.setMobileNumber("mobileNumber2");
        record2.setGovernmentIdUri("governmentIdUri2");
        record2.setSelfieVerificationUri("selfieVerificationUri2");
        record2.setVerificationStatus("verificationStatus2");
        record2.setVerifiedAt(STATIC_DATE);
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        userService.createTournamentOrganizerDetails(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TournamentOrganizerDetails after create:");
        userService.getAllTournamentOrganizerDetails().forEach(System.out::println);

        TournamentOrganizerDetails updated = new TournamentOrganizerDetails();
        updated.setUserId(9);
        updated.setMobileNumber("mobileNumber9");
        updated.setGovernmentIdUri("governmentIdUri9");
        updated.setSelfieVerificationUri("selfieVerificationUri9");
        updated.setVerificationStatus("verificationStatus9");
        updated.setVerifiedAt(STATIC_DATE);
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        userService.updateTournamentOrganizerDetails(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        userService.deleteTournamentOrganizerDetails(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TournamentOrganizerDetails after update & delete:");
        userService.getAllTournamentOrganizerDetails().forEach(System.out::println);
    }

    private void runBrandDetailsCrud() {
        System.out.println("\n--- BrandDetails CRUD ---");

        BrandDetails record1 = new BrandDetails();
        record1.setId(1);
        record1.setUserId(1);
        record1.setBrandName("brandName1");
        record1.setMobileNumber("mobileNumber1");
        record1.setWebsiteUrl("websiteUrl1");
        record1.setLegalEntityIdentifier("legalEntityIdentifier1");
        record1.setBusinessAddress("businessAddress1");
        record1.setVerificationStatus("verificationStatus1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        userService.createBrandDetails(record1);
        System.out.println("Created: " + record1);

        BrandDetails record2 = new BrandDetails();
        record2.setId(2);
        record2.setUserId(2);
        record2.setBrandName("brandName2");
        record2.setMobileNumber("mobileNumber2");
        record2.setWebsiteUrl("websiteUrl2");
        record2.setLegalEntityIdentifier("legalEntityIdentifier2");
        record2.setBusinessAddress("businessAddress2");
        record2.setVerificationStatus("verificationStatus2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        userService.createBrandDetails(record2);
        System.out.println("Created: " + record2);

        System.out.println("All BrandDetails after create:");
        userService.getAllBrandDetails().forEach(System.out::println);

        BrandDetails updated = new BrandDetails();
        updated.setUserId(9);
        updated.setBrandName("brandName9");
        updated.setMobileNumber("mobileNumber9");
        updated.setWebsiteUrl("websiteUrl9");
        updated.setLegalEntityIdentifier("legalEntityIdentifier9");
        updated.setBusinessAddress("businessAddress9");
        updated.setVerificationStatus("verificationStatus9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        userService.updateBrandDetails(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        userService.deleteBrandDetails(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All BrandDetails after update & delete:");
        userService.getAllBrandDetails().forEach(System.out::println);
    }

    private void runInfluencerDetailsCrud() {
        System.out.println("\n--- InfluencerDetails CRUD ---");

        InfluencerDetails record1 = new InfluencerDetails();
        record1.setId(1);
        record1.setUserId(1);
        record1.setMobileNumber("mobileNumber1");
        record1.setAboutYourself("aboutYourself1");
        record1.setAccountStatus("accountStatus1");
        record1.setVerificationStatus("verificationStatus1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        userService.createInfluencerDetails(record1);
        System.out.println("Created: " + record1);

        InfluencerDetails record2 = new InfluencerDetails();
        record2.setId(2);
        record2.setUserId(2);
        record2.setMobileNumber("mobileNumber2");
        record2.setAboutYourself("aboutYourself2");
        record2.setAccountStatus("accountStatus2");
        record2.setVerificationStatus("verificationStatus2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        userService.createInfluencerDetails(record2);
        System.out.println("Created: " + record2);

        System.out.println("All InfluencerDetails after create:");
        userService.getAllInfluencerDetails().forEach(System.out::println);

        InfluencerDetails updated = new InfluencerDetails();
        updated.setUserId(9);
        updated.setMobileNumber("mobileNumber9");
        updated.setAboutYourself("aboutYourself9");
        updated.setAccountStatus("accountStatus9");
        updated.setVerificationStatus("verificationStatus9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        userService.updateInfluencerDetails(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        userService.deleteInfluencerDetails(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All InfluencerDetails after update & delete:");
        userService.getAllInfluencerDetails().forEach(System.out::println);
    }

}