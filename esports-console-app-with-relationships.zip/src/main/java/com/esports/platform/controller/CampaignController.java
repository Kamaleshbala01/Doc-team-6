package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.CampaignServiceImpl;
import com.esports.platform.service.interfaces.CampaignService;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Runs a full create / list / update / delete / list cycle for every
 * entity in the Campaign & Influencer Marketing module using static dummy data.
 * No user input is required.
 */
public class CampaignController {

    private static final LocalDateTime STATIC_DATE = LocalDateTime.of(2026, 1, 1, 10, 0);

    private final CampaignService campaignService = new CampaignServiceImpl();

    public void start() {
        System.out.println();
        System.out.println("=== Campaign & Influencer Marketing ===");
        runCampaignTypeCrud();
        runCampaignCrud();
        runCampaignPlatformCrud();
        runCampaignAssetCrud();
        runCampaignDeliverableCrud();
        runCollaborationRequestCrud();
    }

    private void runCampaignTypeCrud() {
        System.out.println("\n--- CampaignType CRUD ---");

        CampaignType record1 = new CampaignType();
        record1.setId(1);
        record1.setName("name1");
        record1.setCreatedAt(STATIC_DATE);
        campaignService.createCampaignType(record1);
        System.out.println("Created: " + record1);

        CampaignType record2 = new CampaignType();
        record2.setId(2);
        record2.setName("name2");
        record2.setCreatedAt(STATIC_DATE);
        campaignService.createCampaignType(record2);
        System.out.println("Created: " + record2);

        System.out.println("All CampaignType after create:");
        campaignService.getAllCampaignTypes().forEach(System.out::println);

        CampaignType updated = new CampaignType();
        updated.setName("name9");
        updated.setCreatedAt(STATIC_DATE);
        campaignService.updateCampaignType(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        campaignService.deleteCampaignType(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All CampaignType after update & delete:");
        campaignService.getAllCampaignTypes().forEach(System.out::println);
    }

    private void runCampaignCrud() {
        System.out.println("\n--- Campaign CRUD ---");

        Campaign record1 = new Campaign();
        record1.setId(1);
        record1.setBrandId(1);
        record1.setCampaignTypeId(1);
        record1.setCampaignName("campaignName1");
        record1.setGameId(1);
        record1.setStartDate(STATIC_DATE);
        record1.setEndDate(STATIC_DATE);
        record1.setDescription("description1");
        record1.setCampaignThumbnailFileId(1);
        record1.setTotalBudget(new BigDecimal("100.00"));
        record1.setInfluencerCost(new BigDecimal("100.00"));
        record1.setAdditionalExpenses(new BigDecimal("100.00"));
        record1.setStatus("status1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        campaignService.createCampaign(record1);
        System.out.println("Created: " + record1);

        Campaign record2 = new Campaign();
        record2.setId(2);
        record2.setBrandId(2);
        record2.setCampaignTypeId(2);
        record2.setCampaignName("campaignName2");
        record2.setGameId(2);
        record2.setStartDate(STATIC_DATE);
        record2.setEndDate(STATIC_DATE);
        record2.setDescription("description2");
        record2.setCampaignThumbnailFileId(2);
        record2.setTotalBudget(new BigDecimal("200.00"));
        record2.setInfluencerCost(new BigDecimal("200.00"));
        record2.setAdditionalExpenses(new BigDecimal("200.00"));
        record2.setStatus("status2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        campaignService.createCampaign(record2);
        System.out.println("Created: " + record2);

        System.out.println("All Campaign after create:");
        campaignService.getAllCampaigns().forEach(System.out::println);

        Campaign updated = new Campaign();
        updated.setBrandId(9);
        updated.setCampaignTypeId(9);
        updated.setCampaignName("campaignName9");
        updated.setGameId(9);
        updated.setStartDate(STATIC_DATE);
        updated.setEndDate(STATIC_DATE);
        updated.setDescription("description9");
        updated.setCampaignThumbnailFileId(9);
        updated.setTotalBudget(new BigDecimal("900.00"));
        updated.setInfluencerCost(new BigDecimal("900.00"));
        updated.setAdditionalExpenses(new BigDecimal("900.00"));
        updated.setStatus("status9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        campaignService.updateCampaign(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        campaignService.deleteCampaign(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All Campaign after update & delete:");
        campaignService.getAllCampaigns().forEach(System.out::println);
    }

    private void runCampaignPlatformCrud() {
        System.out.println("\n--- CampaignPlatform CRUD ---");

        CampaignPlatform record1 = new CampaignPlatform();
        record1.setId(1);
        record1.setCampaignId(1);
        record1.setPlatformId(1);
        campaignService.createCampaignPlatform(record1);
        System.out.println("Created: " + record1);

        CampaignPlatform record2 = new CampaignPlatform();
        record2.setId(2);
        record2.setCampaignId(2);
        record2.setPlatformId(2);
        campaignService.createCampaignPlatform(record2);
        System.out.println("Created: " + record2);

        System.out.println("All CampaignPlatform after create:");
        campaignService.getAllCampaignPlatforms().forEach(System.out::println);

        CampaignPlatform updated = new CampaignPlatform();
        updated.setCampaignId(9);
        updated.setPlatformId(9);
        campaignService.updateCampaignPlatform(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        campaignService.deleteCampaignPlatform(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All CampaignPlatform after update & delete:");
        campaignService.getAllCampaignPlatforms().forEach(System.out::println);
    }

    private void runCampaignAssetCrud() {
        System.out.println("\n--- CampaignAsset CRUD ---");

        CampaignAsset record1 = new CampaignAsset();
        record1.setId(1);
        record1.setCampaignId(1);
        record1.setAssetType("assetType1");
        record1.setFileId(1);
        record1.setCreatedAt(STATIC_DATE);
        campaignService.createCampaignAsset(record1);
        System.out.println("Created: " + record1);

        CampaignAsset record2 = new CampaignAsset();
        record2.setId(2);
        record2.setCampaignId(2);
        record2.setAssetType("assetType2");
        record2.setFileId(2);
        record2.setCreatedAt(STATIC_DATE);
        campaignService.createCampaignAsset(record2);
        System.out.println("Created: " + record2);

        System.out.println("All CampaignAsset after create:");
        campaignService.getAllCampaignAssets().forEach(System.out::println);

        CampaignAsset updated = new CampaignAsset();
        updated.setCampaignId(9);
        updated.setAssetType("assetType9");
        updated.setFileId(9);
        updated.setCreatedAt(STATIC_DATE);
        campaignService.updateCampaignAsset(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        campaignService.deleteCampaignAsset(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All CampaignAsset after update & delete:");
        campaignService.getAllCampaignAssets().forEach(System.out::println);
    }

    private void runCampaignDeliverableCrud() {
        System.out.println("\n--- CampaignDeliverable CRUD ---");

        CampaignDeliverable record1 = new CampaignDeliverable();
        record1.setId(1);
        record1.setCampaignId(1);
        record1.setFileId(1);
        record1.setCreatedAt(STATIC_DATE);
        campaignService.createCampaignDeliverable(record1);
        System.out.println("Created: " + record1);

        CampaignDeliverable record2 = new CampaignDeliverable();
        record2.setId(2);
        record2.setCampaignId(2);
        record2.setFileId(2);
        record2.setCreatedAt(STATIC_DATE);
        campaignService.createCampaignDeliverable(record2);
        System.out.println("Created: " + record2);

        System.out.println("All CampaignDeliverable after create:");
        campaignService.getAllCampaignDeliverables().forEach(System.out::println);

        CampaignDeliverable updated = new CampaignDeliverable();
        updated.setCampaignId(9);
        updated.setFileId(9);
        updated.setCreatedAt(STATIC_DATE);
        campaignService.updateCampaignDeliverable(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        campaignService.deleteCampaignDeliverable(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All CampaignDeliverable after update & delete:");
        campaignService.getAllCampaignDeliverables().forEach(System.out::println);
    }

    private void runCollaborationRequestCrud() {
        System.out.println("\n--- CollaborationRequest CRUD ---");

        CollaborationRequest record1 = new CollaborationRequest();
        record1.setId(1);
        record1.setSenderId(1);
        record1.setReceiverId(1);
        record1.setCampaignId(1);
        record1.setTitle("title1");
        record1.setDescription("description1");
        record1.setProposedAmount(new BigDecimal("100.00"));
        record1.setStatus("status1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        campaignService.createCollaborationRequest(record1);
        System.out.println("Created: " + record1);

        CollaborationRequest record2 = new CollaborationRequest();
        record2.setId(2);
        record2.setSenderId(2);
        record2.setReceiverId(2);
        record2.setCampaignId(2);
        record2.setTitle("title2");
        record2.setDescription("description2");
        record2.setProposedAmount(new BigDecimal("200.00"));
        record2.setStatus("status2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        campaignService.createCollaborationRequest(record2);
        System.out.println("Created: " + record2);

        System.out.println("All CollaborationRequest after create:");
        campaignService.getAllCollaborationRequests().forEach(System.out::println);

        CollaborationRequest updated = new CollaborationRequest();
        updated.setSenderId(9);
        updated.setReceiverId(9);
        updated.setCampaignId(9);
        updated.setTitle("title9");
        updated.setDescription("description9");
        updated.setProposedAmount(new BigDecimal("900.00"));
        updated.setStatus("status9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        campaignService.updateCollaborationRequest(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        campaignService.deleteCollaborationRequest(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All CollaborationRequest after update & delete:");
        campaignService.getAllCollaborationRequests().forEach(System.out::println);
    }

}