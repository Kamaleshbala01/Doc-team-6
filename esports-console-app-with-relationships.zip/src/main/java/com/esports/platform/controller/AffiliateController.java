package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.AffiliateServiceImpl;
import com.esports.platform.service.interfaces.AffiliateService;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Runs a full create / list / update / delete / list cycle for every
 * entity in the Affiliate Marketing module using static dummy data.
 * No user input is required.
 */
public class AffiliateController {

    private static final LocalDateTime STATIC_DATE = LocalDateTime.of(2026, 1, 1, 10, 0);

    private final AffiliateService affiliateService = new AffiliateServiceImpl();

    public void start() {
        System.out.println();
        System.out.println("=== Affiliate Marketing ===");
        runAffiliateCampaignCrud();
        runAffiliateLinkCrud();
        runAffiliateClickCrud();
    }

    private void runAffiliateCampaignCrud() {
        System.out.println("\n--- AffiliateCampaign CRUD ---");

        AffiliateCampaign record1 = new AffiliateCampaign();
        record1.setId(1);
        record1.setBrandId(1);
        record1.setCampaignName("campaignName1");
        record1.setDescription("description1");
        record1.setStartDate(STATIC_DATE);
        record1.setEndDate(STATIC_DATE);
        record1.setStatus("status1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        affiliateService.createAffiliateCampaign(record1);
        System.out.println("Created: " + record1);

        AffiliateCampaign record2 = new AffiliateCampaign();
        record2.setId(2);
        record2.setBrandId(2);
        record2.setCampaignName("campaignName2");
        record2.setDescription("description2");
        record2.setStartDate(STATIC_DATE);
        record2.setEndDate(STATIC_DATE);
        record2.setStatus("status2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        affiliateService.createAffiliateCampaign(record2);
        System.out.println("Created: " + record2);

        System.out.println("All AffiliateCampaign after create:");
        affiliateService.getAllAffiliateCampaigns().forEach(System.out::println);

        AffiliateCampaign updated = new AffiliateCampaign();
        updated.setBrandId(9);
        updated.setCampaignName("campaignName9");
        updated.setDescription("description9");
        updated.setStartDate(STATIC_DATE);
        updated.setEndDate(STATIC_DATE);
        updated.setStatus("status9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        affiliateService.updateAffiliateCampaign(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        affiliateService.deleteAffiliateCampaign(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All AffiliateCampaign after update & delete:");
        affiliateService.getAllAffiliateCampaigns().forEach(System.out::println);
    }

    private void runAffiliateLinkCrud() {
        System.out.println("\n--- AffiliateLink CRUD ---");

        AffiliateLink record1 = new AffiliateLink();
        record1.setId(1);
        record1.setAffiliateCampaignId(1);
        record1.setAssignedUserId(1);
        record1.setAssignedUserType("assignedUserType1");
        record1.setLinkName("linkName1");
        record1.setDestinationUrl("destinationUrl1");
        record1.setShortCode("shortCode1");
        record1.setStatus("status1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        affiliateService.createAffiliateLink(record1);
        System.out.println("Created: " + record1);

        AffiliateLink record2 = new AffiliateLink();
        record2.setId(2);
        record2.setAffiliateCampaignId(2);
        record2.setAssignedUserId(2);
        record2.setAssignedUserType("assignedUserType2");
        record2.setLinkName("linkName2");
        record2.setDestinationUrl("destinationUrl2");
        record2.setShortCode("shortCode2");
        record2.setStatus("status2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        affiliateService.createAffiliateLink(record2);
        System.out.println("Created: " + record2);

        System.out.println("All AffiliateLink after create:");
        affiliateService.getAllAffiliateLinks().forEach(System.out::println);

        AffiliateLink updated = new AffiliateLink();
        updated.setAffiliateCampaignId(9);
        updated.setAssignedUserId(9);
        updated.setAssignedUserType("assignedUserType9");
        updated.setLinkName("linkName9");
        updated.setDestinationUrl("destinationUrl9");
        updated.setShortCode("shortCode9");
        updated.setStatus("status9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        affiliateService.updateAffiliateLink(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        affiliateService.deleteAffiliateLink(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All AffiliateLink after update & delete:");
        affiliateService.getAllAffiliateLinks().forEach(System.out::println);
    }

    private void runAffiliateClickCrud() {
        System.out.println("\n--- AffiliateClick CRUD ---");

        AffiliateClick record1 = new AffiliateClick();
        record1.setId(1L);
        record1.setAffiliateLinkId(1);
        record1.setSessionId("sessionId1");
        record1.setVisitorIp("visitorIp1");
        record1.setCountry("country1");
        record1.setCity("city1");
        record1.setDeviceType("deviceType1");
        record1.setBrowser("browser1");
        record1.setRefererUrl("refererUrl1");
        record1.setClickedAt(STATIC_DATE);
        affiliateService.createAffiliateClick(record1);
        System.out.println("Created: " + record1);

        AffiliateClick record2 = new AffiliateClick();
        record2.setId(2L);
        record2.setAffiliateLinkId(2);
        record2.setSessionId("sessionId2");
        record2.setVisitorIp("visitorIp2");
        record2.setCountry("country2");
        record2.setCity("city2");
        record2.setDeviceType("deviceType2");
        record2.setBrowser("browser2");
        record2.setRefererUrl("refererUrl2");
        record2.setClickedAt(STATIC_DATE);
        affiliateService.createAffiliateClick(record2);
        System.out.println("Created: " + record2);

        System.out.println("All AffiliateClick after create:");
        affiliateService.getAllAffiliateClicks().forEach(System.out::println);

        AffiliateClick updated = new AffiliateClick();
        updated.setAffiliateLinkId(9);
        updated.setSessionId("sessionId9");
        updated.setVisitorIp("visitorIp9");
        updated.setCountry("country9");
        updated.setCity("city9");
        updated.setDeviceType("deviceType9");
        updated.setBrowser("browser9");
        updated.setRefererUrl("refererUrl9");
        updated.setClickedAt(STATIC_DATE);
        affiliateService.updateAffiliateClick(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        affiliateService.deleteAffiliateClick(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All AffiliateClick after update & delete:");
        affiliateService.getAllAffiliateClicks().forEach(System.out::println);
    }

}