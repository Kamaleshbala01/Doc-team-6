package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.TeamServiceImpl;
import com.esports.platform.service.interfaces.TeamService;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Runs a full create / list / update / delete / list cycle for every
 * entity in the Team Management module using static dummy data.
 * No user input is required.
 */
public class TeamController {

    private static final LocalDateTime STATIC_DATE = LocalDateTime.of(2026, 1, 1, 10, 0);

    private final TeamService teamService = new TeamServiceImpl();

    public void start() {
        System.out.println();
        System.out.println("=== Team Management ===");
        runTeamCrud();
        runTeamPositionCrud();
        runTeamMemberCrud();
    }

    private void runTeamCrud() {
        System.out.println("\n--- Team CRUD ---");

        Team record1 = new Team();
        record1.setId(1);
        record1.setOwnerId(1);
        record1.setTeamName("teamName1");
        record1.setTeamLogoFileId(1);
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        teamService.createTeam(record1);
        System.out.println("Created: " + record1);

        Team record2 = new Team();
        record2.setId(2);
        record2.setOwnerId(2);
        record2.setTeamName("teamName2");
        record2.setTeamLogoFileId(2);
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        teamService.createTeam(record2);
        System.out.println("Created: " + record2);

        System.out.println("All Team after create:");
        teamService.getAllTeams().forEach(System.out::println);

        Team updated = new Team();
        updated.setOwnerId(9);
        updated.setTeamName("teamName9");
        updated.setTeamLogoFileId(9);
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        teamService.updateTeam(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        teamService.deleteTeam(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All Team after update & delete:");
        teamService.getAllTeams().forEach(System.out::println);
    }

    private void runTeamPositionCrud() {
        System.out.println("\n--- TeamPosition CRUD ---");

        TeamPosition record1 = new TeamPosition();
        record1.setId(1);
        record1.setName("name1");
        record1.setCreatedAt(STATIC_DATE);
        teamService.createTeamPosition(record1);
        System.out.println("Created: " + record1);

        TeamPosition record2 = new TeamPosition();
        record2.setId(2);
        record2.setName("name2");
        record2.setCreatedAt(STATIC_DATE);
        teamService.createTeamPosition(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TeamPosition after create:");
        teamService.getAllTeamPositions().forEach(System.out::println);

        TeamPosition updated = new TeamPosition();
        updated.setName("name9");
        updated.setCreatedAt(STATIC_DATE);
        teamService.updateTeamPosition(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        teamService.deleteTeamPosition(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TeamPosition after update & delete:");
        teamService.getAllTeamPositions().forEach(System.out::println);
    }

    private void runTeamMemberCrud() {
        System.out.println("\n--- TeamMember CRUD ---");

        TeamMember record1 = new TeamMember();
        record1.setId(1);
        record1.setTeamId(1);
        record1.setUserId(1);
        record1.setPositionId(1);
        record1.setJoinedAt(STATIC_DATE);
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        teamService.createTeamMember(record1);
        System.out.println("Created: " + record1);

        TeamMember record2 = new TeamMember();
        record2.setId(2);
        record2.setTeamId(2);
        record2.setUserId(2);
        record2.setPositionId(2);
        record2.setJoinedAt(STATIC_DATE);
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        teamService.createTeamMember(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TeamMember after create:");
        teamService.getAllTeamMembers().forEach(System.out::println);

        TeamMember updated = new TeamMember();
        updated.setTeamId(9);
        updated.setUserId(9);
        updated.setPositionId(9);
        updated.setJoinedAt(STATIC_DATE);
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        teamService.updateTeamMember(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        teamService.deleteTeamMember(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TeamMember after update & delete:");
        teamService.getAllTeamMembers().forEach(System.out::println);
    }

}