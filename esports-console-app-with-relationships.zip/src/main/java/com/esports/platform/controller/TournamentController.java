package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.TournamentServiceImpl;
import com.esports.platform.service.interfaces.TournamentService;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Runs a full create / list / update / delete / list cycle for every
 * entity in the Tournament Management module using static dummy data.
 * No user input is required.
 */
public class TournamentController {

    private static final LocalDateTime STATIC_DATE = LocalDateTime.of(2026, 1, 1, 10, 0);

    private final TournamentService tournamentService = new TournamentServiceImpl();

    public void start() {
        System.out.println();
        System.out.println("=== Tournament Management ===");
        runTournamentCategoryCrud();
        runTournamentTypeCrud();
        runSeedingTypeCrud();
        runTournamentCrud();
        runRulesCategoryCrud();
        runTournamentRuleCrud();
        runPrizeCategoryCrud();
        runTournamentPrizeCrud();
        runTournamentPackageCrud();
        runTournamentPaymentCrud();
        runTournamentRegistrationCrud();
        runTournamentRegistrationPaymentCrud();
        runTournamentAnnouncementCrud();
        runTournamentFAQCrud();
    }

    private void runTournamentCategoryCrud() {
        System.out.println("\n--- TournamentCategory CRUD ---");

        TournamentCategory record1 = new TournamentCategory();
        record1.setId(1);
        record1.setCategoryName("categoryName1");
        record1.setCreatedAt(STATIC_DATE);
        tournamentService.createTournamentCategory(record1);
        System.out.println("Created: " + record1);

        TournamentCategory record2 = new TournamentCategory();
        record2.setId(2);
        record2.setCategoryName("categoryName2");
        record2.setCreatedAt(STATIC_DATE);
        tournamentService.createTournamentCategory(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TournamentCategory after create:");
        tournamentService.getAllTournamentCategorys().forEach(System.out::println);

        TournamentCategory updated = new TournamentCategory();
        updated.setCategoryName("categoryName9");
        updated.setCreatedAt(STATIC_DATE);
        tournamentService.updateTournamentCategory(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteTournamentCategory(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TournamentCategory after update & delete:");
        tournamentService.getAllTournamentCategorys().forEach(System.out::println);
    }

    private void runTournamentTypeCrud() {
        System.out.println("\n--- TournamentType CRUD ---");

        TournamentType record1 = new TournamentType();
        record1.setId(1);
        record1.setCategoryId(1);
        record1.setTypeName("typeName1");
        record1.setCreatedAt(STATIC_DATE);
        tournamentService.createTournamentType(record1);
        System.out.println("Created: " + record1);

        TournamentType record2 = new TournamentType();
        record2.setId(2);
        record2.setCategoryId(2);
        record2.setTypeName("typeName2");
        record2.setCreatedAt(STATIC_DATE);
        tournamentService.createTournamentType(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TournamentType after create:");
        tournamentService.getAllTournamentTypes().forEach(System.out::println);

        TournamentType updated = new TournamentType();
        updated.setCategoryId(9);
        updated.setTypeName("typeName9");
        updated.setCreatedAt(STATIC_DATE);
        tournamentService.updateTournamentType(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteTournamentType(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TournamentType after update & delete:");
        tournamentService.getAllTournamentTypes().forEach(System.out::println);
    }

    private void runSeedingTypeCrud() {
        System.out.println("\n--- SeedingType CRUD ---");

        SeedingType record1 = new SeedingType();
        record1.setId(1);
        record1.setName("name1");
        record1.setCreatedAt(STATIC_DATE);
        tournamentService.createSeedingType(record1);
        System.out.println("Created: " + record1);

        SeedingType record2 = new SeedingType();
        record2.setId(2);
        record2.setName("name2");
        record2.setCreatedAt(STATIC_DATE);
        tournamentService.createSeedingType(record2);
        System.out.println("Created: " + record2);

        System.out.println("All SeedingType after create:");
        tournamentService.getAllSeedingTypes().forEach(System.out::println);

        SeedingType updated = new SeedingType();
        updated.setName("name9");
        updated.setCreatedAt(STATIC_DATE);
        tournamentService.updateSeedingType(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteSeedingType(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All SeedingType after update & delete:");
        tournamentService.getAllSeedingTypes().forEach(System.out::println);
    }

    private void runTournamentCrud() {
        System.out.println("\n--- Tournament CRUD ---");

        Tournament record1 = new Tournament();
        record1.setId(1);
        record1.setOrganizerId(1);
        record1.setName("name1");
        record1.setDescription("description1");
        record1.setRegistrationStartDate(STATIC_DATE);
        record1.setRegistrationEndDate(STATIC_DATE);
        record1.setTournamentStartDate(STATIC_DATE);
        record1.setTournamentEndDate(STATIC_DATE);
        record1.setBannerFileId(1);
        record1.setCategoryId(1);
        record1.setTournamentTypeId(1);
        record1.setMaximumTeams(1);
        record1.setMaximumPlayersPerTeam(1);
        record1.setSeedingTypeId(1);
        record1.setEntryFee(new BigDecimal("100.00"));
        record1.setVerificationRequired(true);
        record1.setPackageId(1);
        record1.setStatus("status1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournament(record1);
        System.out.println("Created: " + record1);

        Tournament record2 = new Tournament();
        record2.setId(2);
        record2.setOrganizerId(2);
        record2.setName("name2");
        record2.setDescription("description2");
        record2.setRegistrationStartDate(STATIC_DATE);
        record2.setRegistrationEndDate(STATIC_DATE);
        record2.setTournamentStartDate(STATIC_DATE);
        record2.setTournamentEndDate(STATIC_DATE);
        record2.setBannerFileId(2);
        record2.setCategoryId(2);
        record2.setTournamentTypeId(2);
        record2.setMaximumTeams(2);
        record2.setMaximumPlayersPerTeam(2);
        record2.setSeedingTypeId(2);
        record2.setEntryFee(new BigDecimal("200.00"));
        record2.setVerificationRequired(false);
        record2.setPackageId(2);
        record2.setStatus("status2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournament(record2);
        System.out.println("Created: " + record2);

        System.out.println("All Tournament after create:");
        tournamentService.getAllTournaments().forEach(System.out::println);

        Tournament updated = new Tournament();
        updated.setOrganizerId(9);
        updated.setName("name9");
        updated.setDescription("description9");
        updated.setRegistrationStartDate(STATIC_DATE);
        updated.setRegistrationEndDate(STATIC_DATE);
        updated.setTournamentStartDate(STATIC_DATE);
        updated.setTournamentEndDate(STATIC_DATE);
        updated.setBannerFileId(9);
        updated.setCategoryId(9);
        updated.setTournamentTypeId(9);
        updated.setMaximumTeams(9);
        updated.setMaximumPlayersPerTeam(9);
        updated.setSeedingTypeId(9);
        updated.setEntryFee(new BigDecimal("900.00"));
        updated.setVerificationRequired(false);
        updated.setPackageId(9);
        updated.setStatus("status9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        tournamentService.updateTournament(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteTournament(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All Tournament after update & delete:");
        tournamentService.getAllTournaments().forEach(System.out::println);
    }

    private void runRulesCategoryCrud() {
        System.out.println("\n--- RulesCategory CRUD ---");

        RulesCategory record1 = new RulesCategory();
        record1.setId(1);
        record1.setCategoryName("categoryName1");
        record1.setCreatedAt(STATIC_DATE);
        tournamentService.createRulesCategory(record1);
        System.out.println("Created: " + record1);

        RulesCategory record2 = new RulesCategory();
        record2.setId(2);
        record2.setCategoryName("categoryName2");
        record2.setCreatedAt(STATIC_DATE);
        tournamentService.createRulesCategory(record2);
        System.out.println("Created: " + record2);

        System.out.println("All RulesCategory after create:");
        tournamentService.getAllRulesCategorys().forEach(System.out::println);

        RulesCategory updated = new RulesCategory();
        updated.setCategoryName("categoryName9");
        updated.setCreatedAt(STATIC_DATE);
        tournamentService.updateRulesCategory(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteRulesCategory(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All RulesCategory after update & delete:");
        tournamentService.getAllRulesCategorys().forEach(System.out::println);
    }

    private void runTournamentRuleCrud() {
        System.out.println("\n--- TournamentRule CRUD ---");

        TournamentRule record1 = new TournamentRule();
        record1.setId(1);
        record1.setTournamentId(1);
        record1.setCategoryId(1);
        record1.setRuleText("ruleText1");
        record1.setCreatedBy(1);
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentRule(record1);
        System.out.println("Created: " + record1);

        TournamentRule record2 = new TournamentRule();
        record2.setId(2);
        record2.setTournamentId(2);
        record2.setCategoryId(2);
        record2.setRuleText("ruleText2");
        record2.setCreatedBy(2);
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentRule(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TournamentRule after create:");
        tournamentService.getAllTournamentRules().forEach(System.out::println);

        TournamentRule updated = new TournamentRule();
        updated.setTournamentId(9);
        updated.setCategoryId(9);
        updated.setRuleText("ruleText9");
        updated.setCreatedBy(9);
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        tournamentService.updateTournamentRule(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteTournamentRule(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TournamentRule after update & delete:");
        tournamentService.getAllTournamentRules().forEach(System.out::println);
    }

    private void runPrizeCategoryCrud() {
        System.out.println("\n--- PrizeCategory CRUD ---");

        PrizeCategory record1 = new PrizeCategory();
        record1.setId(1);
        record1.setName("name1");
        record1.setCreatedAt(STATIC_DATE);
        tournamentService.createPrizeCategory(record1);
        System.out.println("Created: " + record1);

        PrizeCategory record2 = new PrizeCategory();
        record2.setId(2);
        record2.setName("name2");
        record2.setCreatedAt(STATIC_DATE);
        tournamentService.createPrizeCategory(record2);
        System.out.println("Created: " + record2);

        System.out.println("All PrizeCategory after create:");
        tournamentService.getAllPrizeCategorys().forEach(System.out::println);

        PrizeCategory updated = new PrizeCategory();
        updated.setName("name9");
        updated.setCreatedAt(STATIC_DATE);
        tournamentService.updatePrizeCategory(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deletePrizeCategory(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All PrizeCategory after update & delete:");
        tournamentService.getAllPrizeCategorys().forEach(System.out::println);
    }

    private void runTournamentPrizeCrud() {
        System.out.println("\n--- TournamentPrize CRUD ---");

        TournamentPrize record1 = new TournamentPrize();
        record1.setId(1);
        record1.setTournamentId(1);
        record1.setPrizeCategoryId(1);
        record1.setPositionName("positionName1");
        record1.setRankOrder(1);
        record1.setPrizeAmount(new BigDecimal("100.00"));
        record1.setPrizeDescription("prizeDescription1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentPrize(record1);
        System.out.println("Created: " + record1);

        TournamentPrize record2 = new TournamentPrize();
        record2.setId(2);
        record2.setTournamentId(2);
        record2.setPrizeCategoryId(2);
        record2.setPositionName("positionName2");
        record2.setRankOrder(2);
        record2.setPrizeAmount(new BigDecimal("200.00"));
        record2.setPrizeDescription("prizeDescription2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentPrize(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TournamentPrize after create:");
        tournamentService.getAllTournamentPrizes().forEach(System.out::println);

        TournamentPrize updated = new TournamentPrize();
        updated.setTournamentId(9);
        updated.setPrizeCategoryId(9);
        updated.setPositionName("positionName9");
        updated.setRankOrder(9);
        updated.setPrizeAmount(new BigDecimal("900.00"));
        updated.setPrizeDescription("prizeDescription9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        tournamentService.updateTournamentPrize(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteTournamentPrize(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TournamentPrize after update & delete:");
        tournamentService.getAllTournamentPrizes().forEach(System.out::println);
    }

    private void runTournamentPackageCrud() {
        System.out.println("\n--- TournamentPackage CRUD ---");

        TournamentPackage record1 = new TournamentPackage();
        record1.setId(1);
        record1.setName("name1");
        record1.setPrice(new BigDecimal("100.00"));
        record1.setMaxTeams(1);
        record1.setIsActive(true);
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentPackage(record1);
        System.out.println("Created: " + record1);

        TournamentPackage record2 = new TournamentPackage();
        record2.setId(2);
        record2.setName("name2");
        record2.setPrice(new BigDecimal("200.00"));
        record2.setMaxTeams(2);
        record2.setIsActive(false);
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentPackage(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TournamentPackage after create:");
        tournamentService.getAllTournamentPackages().forEach(System.out::println);

        TournamentPackage updated = new TournamentPackage();
        updated.setName("name9");
        updated.setPrice(new BigDecimal("900.00"));
        updated.setMaxTeams(9);
        updated.setIsActive(false);
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        tournamentService.updateTournamentPackage(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteTournamentPackage(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TournamentPackage after update & delete:");
        tournamentService.getAllTournamentPackages().forEach(System.out::println);
    }

    private void runTournamentPaymentCrud() {
        System.out.println("\n--- TournamentPayment CRUD ---");

        TournamentPayment record1 = new TournamentPayment();
        record1.setId(1);
        record1.setOrganizerId(1);
        record1.setTournamentId(1);
        record1.setPackageId(1);
        record1.setAmount(new BigDecimal("100.00"));
        record1.setPaymentReference("paymentReference1");
        record1.setPaymentStatus("paymentStatus1");
        record1.setPaidDate(STATIC_DATE);
        record1.setCreatedAt(STATIC_DATE);
        tournamentService.createTournamentPayment(record1);
        System.out.println("Created: " + record1);

        TournamentPayment record2 = new TournamentPayment();
        record2.setId(2);
        record2.setOrganizerId(2);
        record2.setTournamentId(2);
        record2.setPackageId(2);
        record2.setAmount(new BigDecimal("200.00"));
        record2.setPaymentReference("paymentReference2");
        record2.setPaymentStatus("paymentStatus2");
        record2.setPaidDate(STATIC_DATE);
        record2.setCreatedAt(STATIC_DATE);
        tournamentService.createTournamentPayment(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TournamentPayment after create:");
        tournamentService.getAllTournamentPayments().forEach(System.out::println);

        TournamentPayment updated = new TournamentPayment();
        updated.setOrganizerId(9);
        updated.setTournamentId(9);
        updated.setPackageId(9);
        updated.setAmount(new BigDecimal("900.00"));
        updated.setPaymentReference("paymentReference9");
        updated.setPaymentStatus("paymentStatus9");
        updated.setPaidDate(STATIC_DATE);
        updated.setCreatedAt(STATIC_DATE);
        tournamentService.updateTournamentPayment(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteTournamentPayment(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TournamentPayment after update & delete:");
        tournamentService.getAllTournamentPayments().forEach(System.out::println);
    }

    private void runTournamentRegistrationCrud() {
        System.out.println("\n--- TournamentRegistration CRUD ---");

        TournamentRegistration record1 = new TournamentRegistration();
        record1.setId(1);
        record1.setTournamentId(1);
        record1.setTeamId(1);
        record1.setRegistrationStatusId(1);
        record1.setRegistrationDate(STATIC_DATE);
        record1.setApprovedBy(1);
        record1.setApprovedDate(STATIC_DATE);
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentRegistration(record1);
        System.out.println("Created: " + record1);

        TournamentRegistration record2 = new TournamentRegistration();
        record2.setId(2);
        record2.setTournamentId(2);
        record2.setTeamId(2);
        record2.setRegistrationStatusId(2);
        record2.setRegistrationDate(STATIC_DATE);
        record2.setApprovedBy(2);
        record2.setApprovedDate(STATIC_DATE);
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentRegistration(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TournamentRegistration after create:");
        tournamentService.getAllTournamentRegistrations().forEach(System.out::println);

        TournamentRegistration updated = new TournamentRegistration();
        updated.setTournamentId(9);
        updated.setTeamId(9);
        updated.setRegistrationStatusId(9);
        updated.setRegistrationDate(STATIC_DATE);
        updated.setApprovedBy(9);
        updated.setApprovedDate(STATIC_DATE);
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        tournamentService.updateTournamentRegistration(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteTournamentRegistration(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TournamentRegistration after update & delete:");
        tournamentService.getAllTournamentRegistrations().forEach(System.out::println);
    }

    private void runTournamentRegistrationPaymentCrud() {
        System.out.println("\n--- TournamentRegistrationPayment CRUD ---");

        TournamentRegistrationPayment record1 = new TournamentRegistrationPayment();
        record1.setId(1);
        record1.setRegistrationId(1);
        record1.setTournamentId(1);
        record1.setParticipantId(1);
        record1.setAmount(new BigDecimal("100.00"));
        record1.setPaymentReference("paymentReference1");
        record1.setPaymentStatus("paymentStatus1");
        record1.setPaidDate(STATIC_DATE);
        record1.setCreatedAt(STATIC_DATE);
        tournamentService.createTournamentRegistrationPayment(record1);
        System.out.println("Created: " + record1);

        TournamentRegistrationPayment record2 = new TournamentRegistrationPayment();
        record2.setId(2);
        record2.setRegistrationId(2);
        record2.setTournamentId(2);
        record2.setParticipantId(2);
        record2.setAmount(new BigDecimal("200.00"));
        record2.setPaymentReference("paymentReference2");
        record2.setPaymentStatus("paymentStatus2");
        record2.setPaidDate(STATIC_DATE);
        record2.setCreatedAt(STATIC_DATE);
        tournamentService.createTournamentRegistrationPayment(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TournamentRegistrationPayment after create:");
        tournamentService.getAllTournamentRegistrationPayments().forEach(System.out::println);

        TournamentRegistrationPayment updated = new TournamentRegistrationPayment();
        updated.setRegistrationId(9);
        updated.setTournamentId(9);
        updated.setParticipantId(9);
        updated.setAmount(new BigDecimal("900.00"));
        updated.setPaymentReference("paymentReference9");
        updated.setPaymentStatus("paymentStatus9");
        updated.setPaidDate(STATIC_DATE);
        updated.setCreatedAt(STATIC_DATE);
        tournamentService.updateTournamentRegistrationPayment(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteTournamentRegistrationPayment(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TournamentRegistrationPayment after update & delete:");
        tournamentService.getAllTournamentRegistrationPayments().forEach(System.out::println);
    }

    private void runTournamentAnnouncementCrud() {
        System.out.println("\n--- TournamentAnnouncement CRUD ---");

        TournamentAnnouncement record1 = new TournamentAnnouncement();
        record1.setId(1);
        record1.setTournamentId(1);
        record1.setTitle("title1");
        record1.setContent("content1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentAnnouncement(record1);
        System.out.println("Created: " + record1);

        TournamentAnnouncement record2 = new TournamentAnnouncement();
        record2.setId(2);
        record2.setTournamentId(2);
        record2.setTitle("title2");
        record2.setContent("content2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentAnnouncement(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TournamentAnnouncement after create:");
        tournamentService.getAllTournamentAnnouncements().forEach(System.out::println);

        TournamentAnnouncement updated = new TournamentAnnouncement();
        updated.setTournamentId(9);
        updated.setTitle("title9");
        updated.setContent("content9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        tournamentService.updateTournamentAnnouncement(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteTournamentAnnouncement(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TournamentAnnouncement after update & delete:");
        tournamentService.getAllTournamentAnnouncements().forEach(System.out::println);
    }

    private void runTournamentFAQCrud() {
        System.out.println("\n--- TournamentFAQ CRUD ---");

        TournamentFAQ record1 = new TournamentFAQ();
        record1.setId(1);
        record1.setTournamentId(1);
        record1.setUserId(1);
        record1.setQuestion("question1");
        record1.setAnswer("answer1");
        record1.setStatus("status1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentFAQ(record1);
        System.out.println("Created: " + record1);

        TournamentFAQ record2 = new TournamentFAQ();
        record2.setId(2);
        record2.setTournamentId(2);
        record2.setUserId(2);
        record2.setQuestion("question2");
        record2.setAnswer("answer2");
        record2.setStatus("status2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        tournamentService.createTournamentFAQ(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TournamentFAQ after create:");
        tournamentService.getAllTournamentFAQs().forEach(System.out::println);

        TournamentFAQ updated = new TournamentFAQ();
        updated.setTournamentId(9);
        updated.setUserId(9);
        updated.setQuestion("question9");
        updated.setAnswer("answer9");
        updated.setStatus("status9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        tournamentService.updateTournamentFAQ(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        tournamentService.deleteTournamentFAQ(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TournamentFAQ after update & delete:");
        tournamentService.getAllTournamentFAQs().forEach(System.out::println);
    }

}