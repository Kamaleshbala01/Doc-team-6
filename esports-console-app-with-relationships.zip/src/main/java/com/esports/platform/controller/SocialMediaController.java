package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.SocialMediaServiceImpl;
import com.esports.platform.service.interfaces.SocialMediaService;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Runs a full create / list / update / delete / list cycle for every
 * entity in the Social Media & Games module using static dummy data.
 * No user input is required.
 */
public class SocialMediaController {

    private static final LocalDateTime STATIC_DATE = LocalDateTime.of(2026, 1, 1, 10, 0);

    private final SocialMediaService socialMediaService = new SocialMediaServiceImpl();

    public void start() {
        System.out.println();
        System.out.println("=== Social Media & Games ===");
        runSocialMediaPlatformCrud();
        runSocialMediaAccountCrud();
        runGameCrud();
        runInfluencerGameCrud();
        runStatusMasterCrud();
    }

    private void runSocialMediaPlatformCrud() {
        System.out.println("\n--- SocialMediaPlatform CRUD ---");

        SocialMediaPlatform record1 = new SocialMediaPlatform();
        record1.setId(1);
        record1.setPlatformName("platformName1");
        record1.setUrlPrefix("urlPrefix1");
        record1.setCreatedAt(STATIC_DATE);
        socialMediaService.createSocialMediaPlatform(record1);
        System.out.println("Created: " + record1);

        SocialMediaPlatform record2 = new SocialMediaPlatform();
        record2.setId(2);
        record2.setPlatformName("platformName2");
        record2.setUrlPrefix("urlPrefix2");
        record2.setCreatedAt(STATIC_DATE);
        socialMediaService.createSocialMediaPlatform(record2);
        System.out.println("Created: " + record2);

        System.out.println("All SocialMediaPlatform after create:");
        socialMediaService.getAllSocialMediaPlatforms().forEach(System.out::println);

        SocialMediaPlatform updated = new SocialMediaPlatform();
        updated.setPlatformName("platformName9");
        updated.setUrlPrefix("urlPrefix9");
        updated.setCreatedAt(STATIC_DATE);
        socialMediaService.updateSocialMediaPlatform(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        socialMediaService.deleteSocialMediaPlatform(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All SocialMediaPlatform after update & delete:");
        socialMediaService.getAllSocialMediaPlatforms().forEach(System.out::println);
    }

    private void runSocialMediaAccountCrud() {
        System.out.println("\n--- SocialMediaAccount CRUD ---");

        SocialMediaAccount record1 = new SocialMediaAccount();
        record1.setId(1);
        record1.setUserId(1);
        record1.setPlatformId(1);
        record1.setAccountName("accountName1");
        record1.setProfileUrl("profileUrl1");
        record1.setFollowersCount(1L);
        record1.setSubscriberCount(1L);
        record1.setViewSubscriptionRatio(new BigDecimal("100.00"));
        record1.setViewCommentRatio(new BigDecimal("100.00"));
        record1.setAcceptanceStatusId(1);
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        socialMediaService.createSocialMediaAccount(record1);
        System.out.println("Created: " + record1);

        SocialMediaAccount record2 = new SocialMediaAccount();
        record2.setId(2);
        record2.setUserId(2);
        record2.setPlatformId(2);
        record2.setAccountName("accountName2");
        record2.setProfileUrl("profileUrl2");
        record2.setFollowersCount(2L);
        record2.setSubscriberCount(2L);
        record2.setViewSubscriptionRatio(new BigDecimal("200.00"));
        record2.setViewCommentRatio(new BigDecimal("200.00"));
        record2.setAcceptanceStatusId(2);
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        socialMediaService.createSocialMediaAccount(record2);
        System.out.println("Created: " + record2);

        System.out.println("All SocialMediaAccount after create:");
        socialMediaService.getAllSocialMediaAccounts().forEach(System.out::println);

        SocialMediaAccount updated = new SocialMediaAccount();
        updated.setUserId(9);
        updated.setPlatformId(9);
        updated.setAccountName("accountName9");
        updated.setProfileUrl("profileUrl9");
        updated.setFollowersCount(9L);
        updated.setSubscriberCount(9L);
        updated.setViewSubscriptionRatio(new BigDecimal("900.00"));
        updated.setViewCommentRatio(new BigDecimal("900.00"));
        updated.setAcceptanceStatusId(9);
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        socialMediaService.updateSocialMediaAccount(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        socialMediaService.deleteSocialMediaAccount(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All SocialMediaAccount after update & delete:");
        socialMediaService.getAllSocialMediaAccounts().forEach(System.out::println);
    }

    private void runGameCrud() {
        System.out.println("\n--- Game CRUD ---");

        Game record1 = new Game();
        record1.setId(1);
        record1.setGameName("gameName1");
        record1.setGameType("gameType1");
        record1.setGameMode("gameMode1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        socialMediaService.createGame(record1);
        System.out.println("Created: " + record1);

        Game record2 = new Game();
        record2.setId(2);
        record2.setGameName("gameName2");
        record2.setGameType("gameType2");
        record2.setGameMode("gameMode2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        socialMediaService.createGame(record2);
        System.out.println("Created: " + record2);

        System.out.println("All Game after create:");
        socialMediaService.getAllGames().forEach(System.out::println);

        Game updated = new Game();
        updated.setGameName("gameName9");
        updated.setGameType("gameType9");
        updated.setGameMode("gameMode9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        socialMediaService.updateGame(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        socialMediaService.deleteGame(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All Game after update & delete:");
        socialMediaService.getAllGames().forEach(System.out::println);
    }

    private void runInfluencerGameCrud() {
        System.out.println("\n--- InfluencerGame CRUD ---");

        InfluencerGame record1 = new InfluencerGame();
        record1.setId(1);
        record1.setInfluencerId(1);
        record1.setGameId(1);
        record1.setIsPrimary(true);
        record1.setCreatedAt(STATIC_DATE);
        socialMediaService.createInfluencerGame(record1);
        System.out.println("Created: " + record1);

        InfluencerGame record2 = new InfluencerGame();
        record2.setId(2);
        record2.setInfluencerId(2);
        record2.setGameId(2);
        record2.setIsPrimary(false);
        record2.setCreatedAt(STATIC_DATE);
        socialMediaService.createInfluencerGame(record2);
        System.out.println("Created: " + record2);

        System.out.println("All InfluencerGame after create:");
        socialMediaService.getAllInfluencerGames().forEach(System.out::println);

        InfluencerGame updated = new InfluencerGame();
        updated.setInfluencerId(9);
        updated.setGameId(9);
        updated.setIsPrimary(false);
        updated.setCreatedAt(STATIC_DATE);
        socialMediaService.updateInfluencerGame(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        socialMediaService.deleteInfluencerGame(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All InfluencerGame after update & delete:");
        socialMediaService.getAllInfluencerGames().forEach(System.out::println);
    }

    private void runStatusMasterCrud() {
        System.out.println("\n--- StatusMaster CRUD ---");

        StatusMaster record1 = new StatusMaster();
        record1.setId(1);
        record1.setStatusType("statusType1");
        record1.setStatusName("statusName1");
        record1.setCreatedAt(STATIC_DATE);
        socialMediaService.createStatusMaster(record1);
        System.out.println("Created: " + record1);

        StatusMaster record2 = new StatusMaster();
        record2.setId(2);
        record2.setStatusType("statusType2");
        record2.setStatusName("statusName2");
        record2.setCreatedAt(STATIC_DATE);
        socialMediaService.createStatusMaster(record2);
        System.out.println("Created: " + record2);

        System.out.println("All StatusMaster after create:");
        socialMediaService.getAllStatusMasters().forEach(System.out::println);

        StatusMaster updated = new StatusMaster();
        updated.setStatusType("statusType9");
        updated.setStatusName("statusName9");
        updated.setCreatedAt(STATIC_DATE);
        socialMediaService.updateStatusMaster(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        socialMediaService.deleteStatusMaster(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All StatusMaster after update & delete:");
        socialMediaService.getAllStatusMasters().forEach(System.out::println);
    }

}