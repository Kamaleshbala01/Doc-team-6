package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.FinanceServiceImpl;
import com.esports.platform.service.interfaces.FinanceService;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Runs a full create / list / update / delete / list cycle for every
 * entity in the Finance (Payments, Subscriptions, Revenue) module using static dummy data.
 * No user input is required.
 */
public class FinanceController {

    private static final LocalDateTime STATIC_DATE = LocalDateTime.of(2026, 1, 1, 10, 0);

    private final FinanceService financeService = new FinanceServiceImpl();

    public void start() {
        System.out.println();
        System.out.println("=== Finance (Payments, Subscriptions, Revenue) ===");
        runPaymentMethodCrud();
        runTransactionTypeCrud();
        runRevenueTransactionCrud();
        runSubscriptionPlanCrud();
        runUserSubscriptionCrud();
    }

    private void runPaymentMethodCrud() {
        System.out.println("\n--- PaymentMethod CRUD ---");

        PaymentMethod record1 = new PaymentMethod();
        record1.setId(1);
        record1.setMethodName("methodName1");
        record1.setCreatedAt(STATIC_DATE);
        financeService.createPaymentMethod(record1);
        System.out.println("Created: " + record1);

        PaymentMethod record2 = new PaymentMethod();
        record2.setId(2);
        record2.setMethodName("methodName2");
        record2.setCreatedAt(STATIC_DATE);
        financeService.createPaymentMethod(record2);
        System.out.println("Created: " + record2);

        System.out.println("All PaymentMethod after create:");
        financeService.getAllPaymentMethods().forEach(System.out::println);

        PaymentMethod updated = new PaymentMethod();
        updated.setMethodName("methodName9");
        updated.setCreatedAt(STATIC_DATE);
        financeService.updatePaymentMethod(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        financeService.deletePaymentMethod(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All PaymentMethod after update & delete:");
        financeService.getAllPaymentMethods().forEach(System.out::println);
    }

    private void runTransactionTypeCrud() {
        System.out.println("\n--- TransactionType CRUD ---");

        TransactionType record1 = new TransactionType();
        record1.setId(1);
        record1.setTypeName("typeName1");
        record1.setCreatedAt(STATIC_DATE);
        financeService.createTransactionType(record1);
        System.out.println("Created: " + record1);

        TransactionType record2 = new TransactionType();
        record2.setId(2);
        record2.setTypeName("typeName2");
        record2.setCreatedAt(STATIC_DATE);
        financeService.createTransactionType(record2);
        System.out.println("Created: " + record2);

        System.out.println("All TransactionType after create:");
        financeService.getAllTransactionTypes().forEach(System.out::println);

        TransactionType updated = new TransactionType();
        updated.setTypeName("typeName9");
        updated.setCreatedAt(STATIC_DATE);
        financeService.updateTransactionType(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        financeService.deleteTransactionType(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All TransactionType after update & delete:");
        financeService.getAllTransactionTypes().forEach(System.out::println);
    }

    private void runRevenueTransactionCrud() {
        System.out.println("\n--- RevenueTransaction CRUD ---");

        RevenueTransaction record1 = new RevenueTransaction();
        record1.setId(1);
        record1.setTransactionTypeId(1);
        record1.setEntityType("entityType1");
        record1.setEntityId(1);
        record1.setReferenceId("referenceId1");
        record1.setUserId(1);
        record1.setAmount(new BigDecimal("100.00"));
        record1.setPaymentMethodId(1);
        record1.setPaymentReference("paymentReference1");
        record1.setPaymentStatus("paymentStatus1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        financeService.createRevenueTransaction(record1);
        System.out.println("Created: " + record1);

        RevenueTransaction record2 = new RevenueTransaction();
        record2.setId(2);
        record2.setTransactionTypeId(2);
        record2.setEntityType("entityType2");
        record2.setEntityId(2);
        record2.setReferenceId("referenceId2");
        record2.setUserId(2);
        record2.setAmount(new BigDecimal("200.00"));
        record2.setPaymentMethodId(2);
        record2.setPaymentReference("paymentReference2");
        record2.setPaymentStatus("paymentStatus2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        financeService.createRevenueTransaction(record2);
        System.out.println("Created: " + record2);

        System.out.println("All RevenueTransaction after create:");
        financeService.getAllRevenueTransactions().forEach(System.out::println);

        RevenueTransaction updated = new RevenueTransaction();
        updated.setTransactionTypeId(9);
        updated.setEntityType("entityType9");
        updated.setEntityId(9);
        updated.setReferenceId("referenceId9");
        updated.setUserId(9);
        updated.setAmount(new BigDecimal("900.00"));
        updated.setPaymentMethodId(9);
        updated.setPaymentReference("paymentReference9");
        updated.setPaymentStatus("paymentStatus9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        financeService.updateRevenueTransaction(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        financeService.deleteRevenueTransaction(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All RevenueTransaction after update & delete:");
        financeService.getAllRevenueTransactions().forEach(System.out::println);
    }

    private void runSubscriptionPlanCrud() {
        System.out.println("\n--- SubscriptionPlan CRUD ---");

        SubscriptionPlan record1 = new SubscriptionPlan();
        record1.setId(1);
        record1.setName("name1");
        record1.setUserType("userType1");
        record1.setPrice(new BigDecimal("100.00"));
        record1.setDurationDays(1);
        record1.setIsActive(true);
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        financeService.createSubscriptionPlan(record1);
        System.out.println("Created: " + record1);

        SubscriptionPlan record2 = new SubscriptionPlan();
        record2.setId(2);
        record2.setName("name2");
        record2.setUserType("userType2");
        record2.setPrice(new BigDecimal("200.00"));
        record2.setDurationDays(2);
        record2.setIsActive(false);
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        financeService.createSubscriptionPlan(record2);
        System.out.println("Created: " + record2);

        System.out.println("All SubscriptionPlan after create:");
        financeService.getAllSubscriptionPlans().forEach(System.out::println);

        SubscriptionPlan updated = new SubscriptionPlan();
        updated.setName("name9");
        updated.setUserType("userType9");
        updated.setPrice(new BigDecimal("900.00"));
        updated.setDurationDays(9);
        updated.setIsActive(false);
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        financeService.updateSubscriptionPlan(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        financeService.deleteSubscriptionPlan(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All SubscriptionPlan after update & delete:");
        financeService.getAllSubscriptionPlans().forEach(System.out::println);
    }

    private void runUserSubscriptionCrud() {
        System.out.println("\n--- UserSubscription CRUD ---");

        UserSubscription record1 = new UserSubscription();
        record1.setId(1);
        record1.setUserId(1);
        record1.setSubscriptionPlanId(1);
        record1.setStartDate(STATIC_DATE);
        record1.setEndDate(STATIC_DATE);
        record1.setAmountPaid(new BigDecimal("100.00"));
        record1.setStatus("status1");
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        financeService.createUserSubscription(record1);
        System.out.println("Created: " + record1);

        UserSubscription record2 = new UserSubscription();
        record2.setId(2);
        record2.setUserId(2);
        record2.setSubscriptionPlanId(2);
        record2.setStartDate(STATIC_DATE);
        record2.setEndDate(STATIC_DATE);
        record2.setAmountPaid(new BigDecimal("200.00"));
        record2.setStatus("status2");
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        financeService.createUserSubscription(record2);
        System.out.println("Created: " + record2);

        System.out.println("All UserSubscription after create:");
        financeService.getAllUserSubscriptions().forEach(System.out::println);

        UserSubscription updated = new UserSubscription();
        updated.setUserId(9);
        updated.setSubscriptionPlanId(9);
        updated.setStartDate(STATIC_DATE);
        updated.setEndDate(STATIC_DATE);
        updated.setAmountPaid(new BigDecimal("900.00"));
        updated.setStatus("status9");
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        financeService.updateUserSubscription(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        financeService.deleteUserSubscription(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All UserSubscription after update & delete:");
        financeService.getAllUserSubscriptions().forEach(System.out::println);
    }

}