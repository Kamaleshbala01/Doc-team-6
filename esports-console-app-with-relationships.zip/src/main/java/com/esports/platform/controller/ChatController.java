package com.esports.platform.controller;

import com.esports.platform.entity.*;
import com.esports.platform.service.impl.ChatServiceImpl;
import com.esports.platform.service.interfaces.ChatService;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Runs a full create / list / update / delete / list cycle for every
 * entity in the Chat / Messaging module using static dummy data.
 * No user input is required.
 */
public class ChatController {

    private static final LocalDateTime STATIC_DATE = LocalDateTime.of(2026, 1, 1, 10, 0);

    private final ChatService chatService = new ChatServiceImpl();

    public void start() {
        System.out.println();
        System.out.println("=== Chat / Messaging ===");
        runConversationCrud();
        runConversationParticipantCrud();
        runMessageCrud();
        runMessageAttachmentCrud();
        runMessageReadStatusCrud();
        runMessageReactionCrud();
        runUserPresenceCrud();
        runConversationPinnedMessageCrud();
        runConversationSettingsCrud();
    }

    private void runConversationCrud() {
        System.out.println("\n--- Conversation CRUD ---");

        Conversation record1 = new Conversation();
        record1.setId(1);
        record1.setConversationType("conversationType1");
        record1.setName("name1");
        record1.setDescription("description1");
        record1.setGroupImageFileId(1);
        record1.setCreatedBy(1);
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        chatService.createConversation(record1);
        System.out.println("Created: " + record1);

        Conversation record2 = new Conversation();
        record2.setId(2);
        record2.setConversationType("conversationType2");
        record2.setName("name2");
        record2.setDescription("description2");
        record2.setGroupImageFileId(2);
        record2.setCreatedBy(2);
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        chatService.createConversation(record2);
        System.out.println("Created: " + record2);

        System.out.println("All Conversation after create:");
        chatService.getAllConversations().forEach(System.out::println);

        Conversation updated = new Conversation();
        updated.setConversationType("conversationType9");
        updated.setName("name9");
        updated.setDescription("description9");
        updated.setGroupImageFileId(9);
        updated.setCreatedBy(9);
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        chatService.updateConversation(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        chatService.deleteConversation(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All Conversation after update & delete:");
        chatService.getAllConversations().forEach(System.out::println);
    }

    private void runConversationParticipantCrud() {
        System.out.println("\n--- ConversationParticipant CRUD ---");

        ConversationParticipant record1 = new ConversationParticipant();
        record1.setId(1L);
        record1.setConversationId(1);
        record1.setUserId(1);
        record1.setIsAdmin(true);
        record1.setIsMuted(true);
        record1.setJoinedAt(STATIC_DATE);
        record1.setLeftAt(STATIC_DATE);
        record1.setCreatedAt(STATIC_DATE);
        chatService.createConversationParticipant(record1);
        System.out.println("Created: " + record1);

        ConversationParticipant record2 = new ConversationParticipant();
        record2.setId(2L);
        record2.setConversationId(2);
        record2.setUserId(2);
        record2.setIsAdmin(false);
        record2.setIsMuted(false);
        record2.setJoinedAt(STATIC_DATE);
        record2.setLeftAt(STATIC_DATE);
        record2.setCreatedAt(STATIC_DATE);
        chatService.createConversationParticipant(record2);
        System.out.println("Created: " + record2);

        System.out.println("All ConversationParticipant after create:");
        chatService.getAllConversationParticipants().forEach(System.out::println);

        ConversationParticipant updated = new ConversationParticipant();
        updated.setConversationId(9);
        updated.setUserId(9);
        updated.setIsAdmin(false);
        updated.setIsMuted(false);
        updated.setJoinedAt(STATIC_DATE);
        updated.setLeftAt(STATIC_DATE);
        updated.setCreatedAt(STATIC_DATE);
        chatService.updateConversationParticipant(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        chatService.deleteConversationParticipant(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All ConversationParticipant after update & delete:");
        chatService.getAllConversationParticipants().forEach(System.out::println);
    }

    private void runMessageCrud() {
        System.out.println("\n--- Message CRUD ---");

        Message record1 = new Message();
        record1.setId(1L);
        record1.setConversationId(1);
        record1.setSenderId(1);
        record1.setMessageType("messageType1");
        record1.setContent("content1");
        record1.setReplyMessageId(1L);
        record1.setIsEdited(true);
        record1.setEditedAt(STATIC_DATE);
        record1.setIsDeleted(true);
        record1.setDeletedAt(STATIC_DATE);
        record1.setCreatedAt(STATIC_DATE);
        chatService.createMessage(record1);
        System.out.println("Created: " + record1);

        Message record2 = new Message();
        record2.setId(2L);
        record2.setConversationId(2);
        record2.setSenderId(2);
        record2.setMessageType("messageType2");
        record2.setContent("content2");
        record2.setReplyMessageId(2L);
        record2.setIsEdited(false);
        record2.setEditedAt(STATIC_DATE);
        record2.setIsDeleted(false);
        record2.setDeletedAt(STATIC_DATE);
        record2.setCreatedAt(STATIC_DATE);
        chatService.createMessage(record2);
        System.out.println("Created: " + record2);

        System.out.println("All Message after create:");
        chatService.getAllMessages().forEach(System.out::println);

        Message updated = new Message();
        updated.setConversationId(9);
        updated.setSenderId(9);
        updated.setMessageType("messageType9");
        updated.setContent("content9");
        updated.setReplyMessageId(9L);
        updated.setIsEdited(false);
        updated.setEditedAt(STATIC_DATE);
        updated.setIsDeleted(false);
        updated.setDeletedAt(STATIC_DATE);
        updated.setCreatedAt(STATIC_DATE);
        chatService.updateMessage(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        chatService.deleteMessage(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All Message after update & delete:");
        chatService.getAllMessages().forEach(System.out::println);
    }

    private void runMessageAttachmentCrud() {
        System.out.println("\n--- MessageAttachment CRUD ---");

        MessageAttachment record1 = new MessageAttachment();
        record1.setId(1L);
        record1.setMessageId(1L);
        record1.setFileId(1);
        record1.setCreatedAt(STATIC_DATE);
        chatService.createMessageAttachment(record1);
        System.out.println("Created: " + record1);

        MessageAttachment record2 = new MessageAttachment();
        record2.setId(2L);
        record2.setMessageId(2L);
        record2.setFileId(2);
        record2.setCreatedAt(STATIC_DATE);
        chatService.createMessageAttachment(record2);
        System.out.println("Created: " + record2);

        System.out.println("All MessageAttachment after create:");
        chatService.getAllMessageAttachments().forEach(System.out::println);

        MessageAttachment updated = new MessageAttachment();
        updated.setMessageId(9L);
        updated.setFileId(9);
        updated.setCreatedAt(STATIC_DATE);
        chatService.updateMessageAttachment(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        chatService.deleteMessageAttachment(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All MessageAttachment after update & delete:");
        chatService.getAllMessageAttachments().forEach(System.out::println);
    }

    private void runMessageReadStatusCrud() {
        System.out.println("\n--- MessageReadStatus CRUD ---");

        MessageReadStatus record1 = new MessageReadStatus();
        record1.setId(1L);
        record1.setMessageId(1L);
        record1.setUserId(1);
        record1.setReadAt(STATIC_DATE);
        chatService.createMessageReadStatus(record1);
        System.out.println("Created: " + record1);

        MessageReadStatus record2 = new MessageReadStatus();
        record2.setId(2L);
        record2.setMessageId(2L);
        record2.setUserId(2);
        record2.setReadAt(STATIC_DATE);
        chatService.createMessageReadStatus(record2);
        System.out.println("Created: " + record2);

        System.out.println("All MessageReadStatus after create:");
        chatService.getAllMessageReadStatus().forEach(System.out::println);

        MessageReadStatus updated = new MessageReadStatus();
        updated.setMessageId(9L);
        updated.setUserId(9);
        updated.setReadAt(STATIC_DATE);
        chatService.updateMessageReadStatus(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        chatService.deleteMessageReadStatus(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All MessageReadStatus after update & delete:");
        chatService.getAllMessageReadStatus().forEach(System.out::println);
    }

    private void runMessageReactionCrud() {
        System.out.println("\n--- MessageReaction CRUD ---");

        MessageReaction record1 = new MessageReaction();
        record1.setId(1L);
        record1.setMessageId(1L);
        record1.setUserId(1);
        record1.setReaction("reaction1");
        record1.setCreatedAt(STATIC_DATE);
        chatService.createMessageReaction(record1);
        System.out.println("Created: " + record1);

        MessageReaction record2 = new MessageReaction();
        record2.setId(2L);
        record2.setMessageId(2L);
        record2.setUserId(2);
        record2.setReaction("reaction2");
        record2.setCreatedAt(STATIC_DATE);
        chatService.createMessageReaction(record2);
        System.out.println("Created: " + record2);

        System.out.println("All MessageReaction after create:");
        chatService.getAllMessageReactions().forEach(System.out::println);

        MessageReaction updated = new MessageReaction();
        updated.setMessageId(9L);
        updated.setUserId(9);
        updated.setReaction("reaction9");
        updated.setCreatedAt(STATIC_DATE);
        chatService.updateMessageReaction(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        chatService.deleteMessageReaction(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All MessageReaction after update & delete:");
        chatService.getAllMessageReactions().forEach(System.out::println);
    }

    private void runUserPresenceCrud() {
        System.out.println("\n--- UserPresence CRUD ---");

        UserPresence record1 = new UserPresence();
        record1.setUserId(1);
        record1.setIsOnline(true);
        record1.setCurrentSocketId("currentSocketId1");
        record1.setLastSeenAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        chatService.createUserPresence(record1);
        System.out.println("Created: " + record1);

        UserPresence record2 = new UserPresence();
        record2.setUserId(2);
        record2.setIsOnline(false);
        record2.setCurrentSocketId("currentSocketId2");
        record2.setLastSeenAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        chatService.createUserPresence(record2);
        System.out.println("Created: " + record2);

        System.out.println("All UserPresence after create:");
        chatService.getAllUserPresences().forEach(System.out::println);

        UserPresence updated = new UserPresence();
        updated.setIsOnline(false);
        updated.setCurrentSocketId("currentSocketId9");
        updated.setLastSeenAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        chatService.updateUserPresence(record1.getUserId(), updated);
        System.out.println("Updated record 1: " + updated);

        chatService.deleteUserPresence(record2.getUserId());
        System.out.println("Deleted record 2 (id=" + record2.getUserId() + ")");

        System.out.println("All UserPresence after update & delete:");
        chatService.getAllUserPresences().forEach(System.out::println);
    }

    private void runConversationPinnedMessageCrud() {
        System.out.println("\n--- ConversationPinnedMessage CRUD ---");

        ConversationPinnedMessage record1 = new ConversationPinnedMessage();
        record1.setId(1L);
        record1.setConversationId(1);
        record1.setMessageId(1L);
        record1.setPinnedBy(1);
        record1.setPinnedAt(STATIC_DATE);
        chatService.createConversationPinnedMessage(record1);
        System.out.println("Created: " + record1);

        ConversationPinnedMessage record2 = new ConversationPinnedMessage();
        record2.setId(2L);
        record2.setConversationId(2);
        record2.setMessageId(2L);
        record2.setPinnedBy(2);
        record2.setPinnedAt(STATIC_DATE);
        chatService.createConversationPinnedMessage(record2);
        System.out.println("Created: " + record2);

        System.out.println("All ConversationPinnedMessage after create:");
        chatService.getAllConversationPinnedMessages().forEach(System.out::println);

        ConversationPinnedMessage updated = new ConversationPinnedMessage();
        updated.setConversationId(9);
        updated.setMessageId(9L);
        updated.setPinnedBy(9);
        updated.setPinnedAt(STATIC_DATE);
        chatService.updateConversationPinnedMessage(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        chatService.deleteConversationPinnedMessage(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All ConversationPinnedMessage after update & delete:");
        chatService.getAllConversationPinnedMessages().forEach(System.out::println);
    }

    private void runConversationSettingsCrud() {
        System.out.println("\n--- ConversationSettings CRUD ---");

        ConversationSettings record1 = new ConversationSettings();
        record1.setId(1);
        record1.setConversationId(1);
        record1.setAllowMemberMessaging(true);
        record1.setAllowMemberInvite(true);
        record1.setOnlyAdminCanPost(true);
        record1.setCreatedAt(STATIC_DATE);
        record1.setUpdatedAt(STATIC_DATE);
        chatService.createConversationSettings(record1);
        System.out.println("Created: " + record1);

        ConversationSettings record2 = new ConversationSettings();
        record2.setId(2);
        record2.setConversationId(2);
        record2.setAllowMemberMessaging(false);
        record2.setAllowMemberInvite(false);
        record2.setOnlyAdminCanPost(false);
        record2.setCreatedAt(STATIC_DATE);
        record2.setUpdatedAt(STATIC_DATE);
        chatService.createConversationSettings(record2);
        System.out.println("Created: " + record2);

        System.out.println("All ConversationSettings after create:");
        chatService.getAllConversationSettings().forEach(System.out::println);

        ConversationSettings updated = new ConversationSettings();
        updated.setConversationId(9);
        updated.setAllowMemberMessaging(false);
        updated.setAllowMemberInvite(false);
        updated.setOnlyAdminCanPost(false);
        updated.setCreatedAt(STATIC_DATE);
        updated.setUpdatedAt(STATIC_DATE);
        chatService.updateConversationSettings(record1.getId(), updated);
        System.out.println("Updated record 1: " + updated);

        chatService.deleteConversationSettings(record2.getId());
        System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

        System.out.println("All ConversationSettings after update & delete:");
        chatService.getAllConversationSettings().forEach(System.out::println);
    }

}