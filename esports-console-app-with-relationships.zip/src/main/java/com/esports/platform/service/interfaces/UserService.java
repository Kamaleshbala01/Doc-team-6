package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;

/**
 * CRUD contract for the User Management (Users, Roles, Profiles, Organiser/Brand/Influencer Details) module.
 * Covers entities: Users, Roles, UserRoles, UserProfile, TournamentOrganizerDetails, BrandDetails, InfluencerDetails
 */
public interface UserService {

    // ---- Users ----
    Users createUsers(Users entity);
    Users getUsersById(Integer id);
    List<Users> getAllUsers();
    Users updateUsers(Integer id, Users entity);
    boolean deleteUsers(Integer id);

    // ---- Roles ----
    Roles createRoles(Roles entity);
    Roles getRolesById(Integer id);
    List<Roles> getAllRoles();
    Roles updateRoles(Integer id, Roles entity);
    boolean deleteRoles(Integer id);

    // ---- UserRoles ----
    UserRoles createUserRoles(UserRoles entity);
    UserRoles getUserRolesById(Integer id);
    List<UserRoles> getAllUserRoles();
    UserRoles updateUserRoles(Integer id, UserRoles entity);
    boolean deleteUserRoles(Integer id);

    // ---- UserProfile ----
    UserProfile createUserProfile(UserProfile entity);
    UserProfile getUserProfileById(Integer id);
    List<UserProfile> getAllUserProfiles();
    UserProfile updateUserProfile(Integer id, UserProfile entity);
    boolean deleteUserProfile(Integer id);

    // ---- TournamentOrganizerDetails ----
    TournamentOrganizerDetails createTournamentOrganizerDetails(TournamentOrganizerDetails entity);
    TournamentOrganizerDetails getTournamentOrganizerDetailsById(Integer id);
    List<TournamentOrganizerDetails> getAllTournamentOrganizerDetails();
    TournamentOrganizerDetails updateTournamentOrganizerDetails(Integer id, TournamentOrganizerDetails entity);
    boolean deleteTournamentOrganizerDetails(Integer id);

    // ---- BrandDetails ----
    BrandDetails createBrandDetails(BrandDetails entity);
    BrandDetails getBrandDetailsById(Integer id);
    List<BrandDetails> getAllBrandDetails();
    BrandDetails updateBrandDetails(Integer id, BrandDetails entity);
    boolean deleteBrandDetails(Integer id);

    // ---- InfluencerDetails ----
    InfluencerDetails createInfluencerDetails(InfluencerDetails entity);
    InfluencerDetails getInfluencerDetailsById(Integer id);
    List<InfluencerDetails> getAllInfluencerDetails();
    InfluencerDetails updateInfluencerDetails(Integer id, InfluencerDetails entity);
    boolean deleteInfluencerDetails(Integer id);

}