package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;

/**
 * CRUD contract for the Social Media & Games module.
 * Covers entities: SocialMediaPlatform, SocialMediaAccount, Game, InfluencerGame, StatusMaster
 */
public interface SocialMediaService {

    // ---- SocialMediaPlatform ----
    SocialMediaPlatform createSocialMediaPlatform(SocialMediaPlatform entity);
    SocialMediaPlatform getSocialMediaPlatformById(Integer id);
    List<SocialMediaPlatform> getAllSocialMediaPlatforms();
    SocialMediaPlatform updateSocialMediaPlatform(Integer id, SocialMediaPlatform entity);
    boolean deleteSocialMediaPlatform(Integer id);

    // ---- SocialMediaAccount ----
    SocialMediaAccount createSocialMediaAccount(SocialMediaAccount entity);
    SocialMediaAccount getSocialMediaAccountById(Integer id);
    List<SocialMediaAccount> getAllSocialMediaAccounts();
    SocialMediaAccount updateSocialMediaAccount(Integer id, SocialMediaAccount entity);
    boolean deleteSocialMediaAccount(Integer id);

    // ---- Game ----
    Game createGame(Game entity);
    Game getGameById(Integer id);
    List<Game> getAllGames();
    Game updateGame(Integer id, Game entity);
    boolean deleteGame(Integer id);

    // ---- InfluencerGame ----
    InfluencerGame createInfluencerGame(InfluencerGame entity);
    InfluencerGame getInfluencerGameById(Integer id);
    List<InfluencerGame> getAllInfluencerGames();
    InfluencerGame updateInfluencerGame(Integer id, InfluencerGame entity);
    boolean deleteInfluencerGame(Integer id);

    // ---- StatusMaster ----
    StatusMaster createStatusMaster(StatusMaster entity);
    StatusMaster getStatusMasterById(Integer id);
    List<StatusMaster> getAllStatusMasters();
    StatusMaster updateStatusMaster(Integer id, StatusMaster entity);
    boolean deleteStatusMaster(Integer id);

}