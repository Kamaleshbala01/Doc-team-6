package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.CampaignService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * In-memory implementation of CampaignService.
 * The primary key is taken from the entity passed in on create() —
 * it is set on the dummy object by the controller before calling create(),
 * there is no separate id-generation step.
 */
public class CampaignServiceImpl implements CampaignService {

    private final Map<Integer, CampaignType> campaignTypeStore = new LinkedHashMap<>();
    private final Map<Integer, Campaign> campaignStore = new LinkedHashMap<>();
    private final Map<Integer, CampaignPlatform> campaignPlatformStore = new LinkedHashMap<>();
    private final Map<Integer, CampaignAsset> campaignAssetStore = new LinkedHashMap<>();
    private final Map<Integer, CampaignDeliverable> campaignDeliverableStore = new LinkedHashMap<>();
    private final Map<Integer, CollaborationRequest> collaborationRequestStore = new LinkedHashMap<>();

    // ---- CampaignType ----
    @Override
    public CampaignType createCampaignType(CampaignType entity) {
        campaignTypeStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public CampaignType getCampaignTypeById(Integer id) {
        return campaignTypeStore.get(id);
    }

    @Override
    public List<CampaignType> getAllCampaignTypes() {
        return campaignTypeStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public CampaignType updateCampaignType(Integer id, CampaignType entity) {
        if (!campaignTypeStore.containsKey(id)) return null;
        entity.setId(id);
        campaignTypeStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteCampaignType(Integer id) {
        return campaignTypeStore.remove(id) != null;
    }

    // ---- Campaign ----
    @Override
    public Campaign createCampaign(Campaign entity) {
        campaignStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Campaign getCampaignById(Integer id) {
        return campaignStore.get(id);
    }

    @Override
    public List<Campaign> getAllCampaigns() {
        return campaignStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Campaign updateCampaign(Integer id, Campaign entity) {
        if (!campaignStore.containsKey(id)) return null;
        entity.setId(id);
        campaignStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteCampaign(Integer id) {
        return campaignStore.remove(id) != null;
    }

    // ---- CampaignPlatform ----
    @Override
    public CampaignPlatform createCampaignPlatform(CampaignPlatform entity) {
        campaignPlatformStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public CampaignPlatform getCampaignPlatformById(Integer id) {
        return campaignPlatformStore.get(id);
    }

    @Override
    public List<CampaignPlatform> getAllCampaignPlatforms() {
        return campaignPlatformStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public CampaignPlatform updateCampaignPlatform(Integer id, CampaignPlatform entity) {
        if (!campaignPlatformStore.containsKey(id)) return null;
        entity.setId(id);
        campaignPlatformStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteCampaignPlatform(Integer id) {
        return campaignPlatformStore.remove(id) != null;
    }

    // ---- CampaignAsset ----
    @Override
    public CampaignAsset createCampaignAsset(CampaignAsset entity) {
        campaignAssetStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public CampaignAsset getCampaignAssetById(Integer id) {
        return campaignAssetStore.get(id);
    }

    @Override
    public List<CampaignAsset> getAllCampaignAssets() {
        return campaignAssetStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public CampaignAsset updateCampaignAsset(Integer id, CampaignAsset entity) {
        if (!campaignAssetStore.containsKey(id)) return null;
        entity.setId(id);
        campaignAssetStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteCampaignAsset(Integer id) {
        return campaignAssetStore.remove(id) != null;
    }

    // ---- CampaignDeliverable ----
    @Override
    public CampaignDeliverable createCampaignDeliverable(CampaignDeliverable entity) {
        campaignDeliverableStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public CampaignDeliverable getCampaignDeliverableById(Integer id) {
        return campaignDeliverableStore.get(id);
    }

    @Override
    public List<CampaignDeliverable> getAllCampaignDeliverables() {
        return campaignDeliverableStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public CampaignDeliverable updateCampaignDeliverable(Integer id, CampaignDeliverable entity) {
        if (!campaignDeliverableStore.containsKey(id)) return null;
        entity.setId(id);
        campaignDeliverableStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteCampaignDeliverable(Integer id) {
        return campaignDeliverableStore.remove(id) != null;
    }

    // ---- CollaborationRequest ----
    @Override
    public CollaborationRequest createCollaborationRequest(CollaborationRequest entity) {
        collaborationRequestStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public CollaborationRequest getCollaborationRequestById(Integer id) {
        return collaborationRequestStore.get(id);
    }

    @Override
    public List<CollaborationRequest> getAllCollaborationRequests() {
        return collaborationRequestStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public CollaborationRequest updateCollaborationRequest(Integer id, CollaborationRequest entity) {
        if (!collaborationRequestStore.containsKey(id)) return null;
        entity.setId(id);
        collaborationRequestStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteCollaborationRequest(Integer id) {
        return collaborationRequestStore.remove(id) != null;
    }

}