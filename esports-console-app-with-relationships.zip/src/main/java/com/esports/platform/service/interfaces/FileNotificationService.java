package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;

/**
 * CRUD contract for the Files, Notifications & Audit module.
 * Covers entities: Files, Notification, AuditLog
 */
public interface FileNotificationService {

    // ---- Files ----
    Files createFiles(Files entity);
    Files getFilesById(Integer id);
    List<Files> getAllFiles();
    Files updateFiles(Integer id, Files entity);
    boolean deleteFiles(Integer id);

    // ---- Notification ----
    Notification createNotification(Notification entity);
    Notification getNotificationById(Integer id);
    List<Notification> getAllNotifications();
    Notification updateNotification(Integer id, Notification entity);
    boolean deleteNotification(Integer id);

    // ---- AuditLog ----
    AuditLog createAuditLog(AuditLog entity);
    AuditLog getAuditLogById(Integer id);
    List<AuditLog> getAllAuditLogs();
    AuditLog updateAuditLog(Integer id, AuditLog entity);
    boolean deleteAuditLog(Integer id);

}