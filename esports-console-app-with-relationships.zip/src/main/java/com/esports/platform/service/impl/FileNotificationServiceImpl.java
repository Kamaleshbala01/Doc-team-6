package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.FileNotificationService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * In-memory implementation of FileNotificationService.
 * The primary key is taken from the entity passed in on create() —
 * it is set on the dummy object by the controller before calling create(),
 * there is no separate id-generation step.
 */
public class FileNotificationServiceImpl implements FileNotificationService {

    private final Map<Integer, Files> filesStore = new LinkedHashMap<>();
    private final Map<Integer, Notification> notificationStore = new LinkedHashMap<>();
    private final Map<Integer, AuditLog> auditLogStore = new LinkedHashMap<>();

    // ---- Files ----
    @Override
    public Files createFiles(Files entity) {
        filesStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Files getFilesById(Integer id) {
        return filesStore.get(id);
    }

    @Override
    public List<Files> getAllFiles() {
        return filesStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Files updateFiles(Integer id, Files entity) {
        if (!filesStore.containsKey(id)) return null;
        entity.setId(id);
        filesStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteFiles(Integer id) {
        return filesStore.remove(id) != null;
    }

    // ---- Notification ----
    @Override
    public Notification createNotification(Notification entity) {
        notificationStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Notification getNotificationById(Integer id) {
        return notificationStore.get(id);
    }

    @Override
    public List<Notification> getAllNotifications() {
        return notificationStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Notification updateNotification(Integer id, Notification entity) {
        if (!notificationStore.containsKey(id)) return null;
        entity.setId(id);
        notificationStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteNotification(Integer id) {
        return notificationStore.remove(id) != null;
    }

    // ---- AuditLog ----
    @Override
    public AuditLog createAuditLog(AuditLog entity) {
        auditLogStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public AuditLog getAuditLogById(Integer id) {
        return auditLogStore.get(id);
    }

    @Override
    public List<AuditLog> getAllAuditLogs() {
        return auditLogStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public AuditLog updateAuditLog(Integer id, AuditLog entity) {
        if (!auditLogStore.containsKey(id)) return null;
        entity.setId(id);
        auditLogStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteAuditLog(Integer id) {
        return auditLogStore.remove(id) != null;
    }

}