package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;

/**
 * CRUD contract for the Chat / Messaging module.
 * Covers entities: Conversation, ConversationParticipant, Message, MessageAttachment, MessageReadStatus, MessageReaction, UserPresence, ConversationPinnedMessage, ConversationSettings
 */
public interface ChatService {

    // ---- Conversation ----
    Conversation createConversation(Conversation entity);
    Conversation getConversationById(Integer id);
    List<Conversation> getAllConversations();
    Conversation updateConversation(Integer id, Conversation entity);
    boolean deleteConversation(Integer id);

    // ---- ConversationParticipant ----
    ConversationParticipant createConversationParticipant(ConversationParticipant entity);
    ConversationParticipant getConversationParticipantById(Long id);
    List<ConversationParticipant> getAllConversationParticipants();
    ConversationParticipant updateConversationParticipant(Long id, ConversationParticipant entity);
    boolean deleteConversationParticipant(Long id);

    // ---- Message ----
    Message createMessage(Message entity);
    Message getMessageById(Long id);
    List<Message> getAllMessages();
    Message updateMessage(Long id, Message entity);
    boolean deleteMessage(Long id);

    // ---- MessageAttachment ----
    MessageAttachment createMessageAttachment(MessageAttachment entity);
    MessageAttachment getMessageAttachmentById(Long id);
    List<MessageAttachment> getAllMessageAttachments();
    MessageAttachment updateMessageAttachment(Long id, MessageAttachment entity);
    boolean deleteMessageAttachment(Long id);

    // ---- MessageReadStatus ----
    MessageReadStatus createMessageReadStatus(MessageReadStatus entity);
    MessageReadStatus getMessageReadStatusById(Long id);
    List<MessageReadStatus> getAllMessageReadStatus();
    MessageReadStatus updateMessageReadStatus(Long id, MessageReadStatus entity);
    boolean deleteMessageReadStatus(Long id);

    // ---- MessageReaction ----
    MessageReaction createMessageReaction(MessageReaction entity);
    MessageReaction getMessageReactionById(Long id);
    List<MessageReaction> getAllMessageReactions();
    MessageReaction updateMessageReaction(Long id, MessageReaction entity);
    boolean deleteMessageReaction(Long id);

    // ---- UserPresence ----
    UserPresence createUserPresence(UserPresence entity);
    UserPresence getUserPresenceById(Integer id);
    List<UserPresence> getAllUserPresences();
    UserPresence updateUserPresence(Integer id, UserPresence entity);
    boolean deleteUserPresence(Integer id);

    // ---- ConversationPinnedMessage ----
    ConversationPinnedMessage createConversationPinnedMessage(ConversationPinnedMessage entity);
    ConversationPinnedMessage getConversationPinnedMessageById(Long id);
    List<ConversationPinnedMessage> getAllConversationPinnedMessages();
    ConversationPinnedMessage updateConversationPinnedMessage(Long id, ConversationPinnedMessage entity);
    boolean deleteConversationPinnedMessage(Long id);

    // ---- ConversationSettings ----
    ConversationSettings createConversationSettings(ConversationSettings entity);
    ConversationSettings getConversationSettingsById(Integer id);
    List<ConversationSettings> getAllConversationSettings();
    ConversationSettings updateConversationSettings(Integer id, ConversationSettings entity);
    boolean deleteConversationSettings(Integer id);

}