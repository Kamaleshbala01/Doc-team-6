package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.SocialMediaService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * In-memory implementation of SocialMediaService.
 * The primary key is taken from the entity passed in on create() —
 * it is set on the dummy object by the controller before calling create(),
 * there is no separate id-generation step.
 */
public class SocialMediaServiceImpl implements SocialMediaService {

    private final Map<Integer, SocialMediaPlatform> socialMediaPlatformStore = new LinkedHashMap<>();
    private final Map<Integer, SocialMediaAccount> socialMediaAccountStore = new LinkedHashMap<>();
    private final Map<Integer, Game> gameStore = new LinkedHashMap<>();
    private final Map<Integer, InfluencerGame> influencerGameStore = new LinkedHashMap<>();
    private final Map<Integer, StatusMaster> statusMasterStore = new LinkedHashMap<>();

    // ---- SocialMediaPlatform ----
    @Override
    public SocialMediaPlatform createSocialMediaPlatform(SocialMediaPlatform entity) {
        socialMediaPlatformStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public SocialMediaPlatform getSocialMediaPlatformById(Integer id) {
        return socialMediaPlatformStore.get(id);
    }

    @Override
    public List<SocialMediaPlatform> getAllSocialMediaPlatforms() {
        return socialMediaPlatformStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public SocialMediaPlatform updateSocialMediaPlatform(Integer id, SocialMediaPlatform entity) {
        if (!socialMediaPlatformStore.containsKey(id)) return null;
        entity.setId(id);
        socialMediaPlatformStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteSocialMediaPlatform(Integer id) {
        return socialMediaPlatformStore.remove(id) != null;
    }

    // ---- SocialMediaAccount ----
    @Override
    public SocialMediaAccount createSocialMediaAccount(SocialMediaAccount entity) {
        socialMediaAccountStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public SocialMediaAccount getSocialMediaAccountById(Integer id) {
        return socialMediaAccountStore.get(id);
    }

    @Override
    public List<SocialMediaAccount> getAllSocialMediaAccounts() {
        return socialMediaAccountStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public SocialMediaAccount updateSocialMediaAccount(Integer id, SocialMediaAccount entity) {
        if (!socialMediaAccountStore.containsKey(id)) return null;
        entity.setId(id);
        socialMediaAccountStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteSocialMediaAccount(Integer id) {
        return socialMediaAccountStore.remove(id) != null;
    }

    // ---- Game ----
    @Override
    public Game createGame(Game entity) {
        gameStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Game getGameById(Integer id) {
        return gameStore.get(id);
    }

    @Override
    public List<Game> getAllGames() {
        return gameStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Game updateGame(Integer id, Game entity) {
        if (!gameStore.containsKey(id)) return null;
        entity.setId(id);
        gameStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteGame(Integer id) {
        return gameStore.remove(id) != null;
    }

    // ---- InfluencerGame ----
    @Override
    public InfluencerGame createInfluencerGame(InfluencerGame entity) {
        influencerGameStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public InfluencerGame getInfluencerGameById(Integer id) {
        return influencerGameStore.get(id);
    }

    @Override
    public List<InfluencerGame> getAllInfluencerGames() {
        return influencerGameStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public InfluencerGame updateInfluencerGame(Integer id, InfluencerGame entity) {
        if (!influencerGameStore.containsKey(id)) return null;
        entity.setId(id);
        influencerGameStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteInfluencerGame(Integer id) {
        return influencerGameStore.remove(id) != null;
    }

    // ---- StatusMaster ----
    @Override
    public StatusMaster createStatusMaster(StatusMaster entity) {
        statusMasterStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public StatusMaster getStatusMasterById(Integer id) {
        return statusMasterStore.get(id);
    }

    @Override
    public List<StatusMaster> getAllStatusMasters() {
        return statusMasterStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public StatusMaster updateStatusMaster(Integer id, StatusMaster entity) {
        if (!statusMasterStore.containsKey(id)) return null;
        entity.setId(id);
        statusMasterStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteStatusMaster(Integer id) {
        return statusMasterStore.remove(id) != null;
    }

}