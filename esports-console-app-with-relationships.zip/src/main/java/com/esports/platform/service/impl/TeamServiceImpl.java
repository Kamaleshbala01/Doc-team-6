package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.TeamService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * In-memory implementation of TeamService.
 * The primary key is taken from the entity passed in on create() —
 * it is set on the dummy object by the controller before calling create(),
 * there is no separate id-generation step.
 */
public class TeamServiceImpl implements TeamService {

    private final Map<Integer, Team> teamStore = new LinkedHashMap<>();
    private final Map<Integer, TeamPosition> teamPositionStore = new LinkedHashMap<>();
    private final Map<Integer, TeamMember> teamMemberStore = new LinkedHashMap<>();

    // ---- Team ----
    @Override
    public Team createTeam(Team entity) {
        teamStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Team getTeamById(Integer id) {
        return teamStore.get(id);
    }

    @Override
    public List<Team> getAllTeams() {
        return teamStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Team updateTeam(Integer id, Team entity) {
        if (!teamStore.containsKey(id)) return null;
        entity.setId(id);
        teamStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTeam(Integer id) {
        return teamStore.remove(id) != null;
    }

    // ---- TeamPosition ----
    @Override
    public TeamPosition createTeamPosition(TeamPosition entity) {
        teamPositionStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TeamPosition getTeamPositionById(Integer id) {
        return teamPositionStore.get(id);
    }

    @Override
    public List<TeamPosition> getAllTeamPositions() {
        return teamPositionStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TeamPosition updateTeamPosition(Integer id, TeamPosition entity) {
        if (!teamPositionStore.containsKey(id)) return null;
        entity.setId(id);
        teamPositionStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTeamPosition(Integer id) {
        return teamPositionStore.remove(id) != null;
    }

    // ---- TeamMember ----
    @Override
    public TeamMember createTeamMember(TeamMember entity) {
        teamMemberStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TeamMember getTeamMemberById(Integer id) {
        return teamMemberStore.get(id);
    }

    @Override
    public List<TeamMember> getAllTeamMembers() {
        return teamMemberStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TeamMember updateTeamMember(Integer id, TeamMember entity) {
        if (!teamMemberStore.containsKey(id)) return null;
        entity.setId(id);
        teamMemberStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTeamMember(Integer id) {
        return teamMemberStore.remove(id) != null;
    }

}