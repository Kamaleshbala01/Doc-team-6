package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.FinanceService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * In-memory implementation of FinanceService.
 * The primary key is taken from the entity passed in on create() —
 * it is set on the dummy object by the controller before calling create(),
 * there is no separate id-generation step.
 */
public class FinanceServiceImpl implements FinanceService {

    private final Map<Integer, PaymentMethod> paymentMethodStore = new LinkedHashMap<>();
    private final Map<Integer, TransactionType> transactionTypeStore = new LinkedHashMap<>();
    private final Map<Integer, RevenueTransaction> revenueTransactionStore = new LinkedHashMap<>();
    private final Map<Integer, SubscriptionPlan> subscriptionPlanStore = new LinkedHashMap<>();
    private final Map<Integer, UserSubscription> userSubscriptionStore = new LinkedHashMap<>();

    // ---- PaymentMethod ----
    @Override
    public PaymentMethod createPaymentMethod(PaymentMethod entity) {
        paymentMethodStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public PaymentMethod getPaymentMethodById(Integer id) {
        return paymentMethodStore.get(id);
    }

    @Override
    public List<PaymentMethod> getAllPaymentMethods() {
        return paymentMethodStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public PaymentMethod updatePaymentMethod(Integer id, PaymentMethod entity) {
        if (!paymentMethodStore.containsKey(id)) return null;
        entity.setId(id);
        paymentMethodStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deletePaymentMethod(Integer id) {
        return paymentMethodStore.remove(id) != null;
    }

    // ---- TransactionType ----
    @Override
    public TransactionType createTransactionType(TransactionType entity) {
        transactionTypeStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TransactionType getTransactionTypeById(Integer id) {
        return transactionTypeStore.get(id);
    }

    @Override
    public List<TransactionType> getAllTransactionTypes() {
        return transactionTypeStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TransactionType updateTransactionType(Integer id, TransactionType entity) {
        if (!transactionTypeStore.containsKey(id)) return null;
        entity.setId(id);
        transactionTypeStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTransactionType(Integer id) {
        return transactionTypeStore.remove(id) != null;
    }

    // ---- RevenueTransaction ----
    @Override
    public RevenueTransaction createRevenueTransaction(RevenueTransaction entity) {
        revenueTransactionStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public RevenueTransaction getRevenueTransactionById(Integer id) {
        return revenueTransactionStore.get(id);
    }

    @Override
    public List<RevenueTransaction> getAllRevenueTransactions() {
        return revenueTransactionStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public RevenueTransaction updateRevenueTransaction(Integer id, RevenueTransaction entity) {
        if (!revenueTransactionStore.containsKey(id)) return null;
        entity.setId(id);
        revenueTransactionStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteRevenueTransaction(Integer id) {
        return revenueTransactionStore.remove(id) != null;
    }

    // ---- SubscriptionPlan ----
    @Override
    public SubscriptionPlan createSubscriptionPlan(SubscriptionPlan entity) {
        subscriptionPlanStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public SubscriptionPlan getSubscriptionPlanById(Integer id) {
        return subscriptionPlanStore.get(id);
    }

    @Override
    public List<SubscriptionPlan> getAllSubscriptionPlans() {
        return subscriptionPlanStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public SubscriptionPlan updateSubscriptionPlan(Integer id, SubscriptionPlan entity) {
        if (!subscriptionPlanStore.containsKey(id)) return null;
        entity.setId(id);
        subscriptionPlanStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteSubscriptionPlan(Integer id) {
        return subscriptionPlanStore.remove(id) != null;
    }

    // ---- UserSubscription ----
    @Override
    public UserSubscription createUserSubscription(UserSubscription entity) {
        userSubscriptionStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public UserSubscription getUserSubscriptionById(Integer id) {
        return userSubscriptionStore.get(id);
    }

    @Override
    public List<UserSubscription> getAllUserSubscriptions() {
        return userSubscriptionStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public UserSubscription updateUserSubscription(Integer id, UserSubscription entity) {
        if (!userSubscriptionStore.containsKey(id)) return null;
        entity.setId(id);
        userSubscriptionStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteUserSubscription(Integer id) {
        return userSubscriptionStore.remove(id) != null;
    }

}