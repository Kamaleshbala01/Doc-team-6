package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;

/**
 * CRUD contract for the Campaign & Influencer Marketing module.
 * Covers entities: CampaignType, Campaign, CampaignPlatform, CampaignAsset, CampaignDeliverable, CollaborationRequest
 */
public interface CampaignService {

    // ---- CampaignType ----
    CampaignType createCampaignType(CampaignType entity);
    CampaignType getCampaignTypeById(Integer id);
    List<CampaignType> getAllCampaignTypes();
    CampaignType updateCampaignType(Integer id, CampaignType entity);
    boolean deleteCampaignType(Integer id);

    // ---- Campaign ----
    Campaign createCampaign(Campaign entity);
    Campaign getCampaignById(Integer id);
    List<Campaign> getAllCampaigns();
    Campaign updateCampaign(Integer id, Campaign entity);
    boolean deleteCampaign(Integer id);

    // ---- CampaignPlatform ----
    CampaignPlatform createCampaignPlatform(CampaignPlatform entity);
    CampaignPlatform getCampaignPlatformById(Integer id);
    List<CampaignPlatform> getAllCampaignPlatforms();
    CampaignPlatform updateCampaignPlatform(Integer id, CampaignPlatform entity);
    boolean deleteCampaignPlatform(Integer id);

    // ---- CampaignAsset ----
    CampaignAsset createCampaignAsset(CampaignAsset entity);
    CampaignAsset getCampaignAssetById(Integer id);
    List<CampaignAsset> getAllCampaignAssets();
    CampaignAsset updateCampaignAsset(Integer id, CampaignAsset entity);
    boolean deleteCampaignAsset(Integer id);

    // ---- CampaignDeliverable ----
    CampaignDeliverable createCampaignDeliverable(CampaignDeliverable entity);
    CampaignDeliverable getCampaignDeliverableById(Integer id);
    List<CampaignDeliverable> getAllCampaignDeliverables();
    CampaignDeliverable updateCampaignDeliverable(Integer id, CampaignDeliverable entity);
    boolean deleteCampaignDeliverable(Integer id);

    // ---- CollaborationRequest ----
    CollaborationRequest createCollaborationRequest(CollaborationRequest entity);
    CollaborationRequest getCollaborationRequestById(Integer id);
    List<CollaborationRequest> getAllCollaborationRequests();
    CollaborationRequest updateCollaborationRequest(Integer id, CollaborationRequest entity);
    boolean deleteCollaborationRequest(Integer id);

}