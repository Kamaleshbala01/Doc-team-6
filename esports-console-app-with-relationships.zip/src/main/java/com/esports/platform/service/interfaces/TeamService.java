package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;

/**
 * CRUD contract for the Team Management module.
 * Covers entities: Team, TeamPosition, TeamMember
 */
public interface TeamService {

    // ---- Team ----
    Team createTeam(Team entity);
    Team getTeamById(Integer id);
    List<Team> getAllTeams();
    Team updateTeam(Integer id, Team entity);
    boolean deleteTeam(Integer id);

    // ---- TeamPosition ----
    TeamPosition createTeamPosition(TeamPosition entity);
    TeamPosition getTeamPositionById(Integer id);
    List<TeamPosition> getAllTeamPositions();
    TeamPosition updateTeamPosition(Integer id, TeamPosition entity);
    boolean deleteTeamPosition(Integer id);

    // ---- TeamMember ----
    TeamMember createTeamMember(TeamMember entity);
    TeamMember getTeamMemberById(Integer id);
    List<TeamMember> getAllTeamMembers();
    TeamMember updateTeamMember(Integer id, TeamMember entity);
    boolean deleteTeamMember(Integer id);

}