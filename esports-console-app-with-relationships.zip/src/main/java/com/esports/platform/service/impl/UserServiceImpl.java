package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.UserService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * In-memory implementation of UserService.
 * The primary key is taken from the entity passed in on create() —
 * it is set on the dummy object by the controller before calling create(),
 * there is no separate id-generation step.
 */
public class UserServiceImpl implements UserService {

    private final Map<Integer, Users> usersStore = new LinkedHashMap<>();
    private final Map<Integer, Roles> rolesStore = new LinkedHashMap<>();
    private final Map<Integer, UserRoles> userRolesStore = new LinkedHashMap<>();
    private final Map<Integer, UserProfile> userProfileStore = new LinkedHashMap<>();
    private final Map<Integer, TournamentOrganizerDetails> tournamentOrganizerDetailsStore = new LinkedHashMap<>();
    private final Map<Integer, BrandDetails> brandDetailsStore = new LinkedHashMap<>();
    private final Map<Integer, InfluencerDetails> influencerDetailsStore = new LinkedHashMap<>();

    // ---- Users ----
    @Override
    public Users createUsers(Users entity) {
        usersStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Users getUsersById(Integer id) {
        return usersStore.get(id);
    }

    @Override
    public List<Users> getAllUsers() {
        return usersStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Users updateUsers(Integer id, Users entity) {
        if (!usersStore.containsKey(id)) return null;
        entity.setId(id);
        usersStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteUsers(Integer id) {
        return usersStore.remove(id) != null;
    }

    // ---- Roles ----
    @Override
    public Roles createRoles(Roles entity) {
        rolesStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Roles getRolesById(Integer id) {
        return rolesStore.get(id);
    }

    @Override
    public List<Roles> getAllRoles() {
        return rolesStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Roles updateRoles(Integer id, Roles entity) {
        if (!rolesStore.containsKey(id)) return null;
        entity.setId(id);
        rolesStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteRoles(Integer id) {
        return rolesStore.remove(id) != null;
    }

    // ---- UserRoles ----
    @Override
    public UserRoles createUserRoles(UserRoles entity) {
        userRolesStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public UserRoles getUserRolesById(Integer id) {
        return userRolesStore.get(id);
    }

    @Override
    public List<UserRoles> getAllUserRoles() {
        return userRolesStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public UserRoles updateUserRoles(Integer id, UserRoles entity) {
        if (!userRolesStore.containsKey(id)) return null;
        entity.setId(id);
        userRolesStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteUserRoles(Integer id) {
        return userRolesStore.remove(id) != null;
    }

    // ---- UserProfile ----
    @Override
    public UserProfile createUserProfile(UserProfile entity) {
        userProfileStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public UserProfile getUserProfileById(Integer id) {
        return userProfileStore.get(id);
    }

    @Override
    public List<UserProfile> getAllUserProfiles() {
        return userProfileStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public UserProfile updateUserProfile(Integer id, UserProfile entity) {
        if (!userProfileStore.containsKey(id)) return null;
        entity.setId(id);
        userProfileStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteUserProfile(Integer id) {
        return userProfileStore.remove(id) != null;
    }

    // ---- TournamentOrganizerDetails ----
    @Override
    public TournamentOrganizerDetails createTournamentOrganizerDetails(TournamentOrganizerDetails entity) {
        tournamentOrganizerDetailsStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TournamentOrganizerDetails getTournamentOrganizerDetailsById(Integer id) {
        return tournamentOrganizerDetailsStore.get(id);
    }

    @Override
    public List<TournamentOrganizerDetails> getAllTournamentOrganizerDetails() {
        return tournamentOrganizerDetailsStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentOrganizerDetails updateTournamentOrganizerDetails(Integer id, TournamentOrganizerDetails entity) {
        if (!tournamentOrganizerDetailsStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentOrganizerDetailsStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentOrganizerDetails(Integer id) {
        return tournamentOrganizerDetailsStore.remove(id) != null;
    }

    // ---- BrandDetails ----
    @Override
    public BrandDetails createBrandDetails(BrandDetails entity) {
        brandDetailsStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public BrandDetails getBrandDetailsById(Integer id) {
        return brandDetailsStore.get(id);
    }

    @Override
    public List<BrandDetails> getAllBrandDetails() {
        return brandDetailsStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public BrandDetails updateBrandDetails(Integer id, BrandDetails entity) {
        if (!brandDetailsStore.containsKey(id)) return null;
        entity.setId(id);
        brandDetailsStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteBrandDetails(Integer id) {
        return brandDetailsStore.remove(id) != null;
    }

    // ---- InfluencerDetails ----
    @Override
    public InfluencerDetails createInfluencerDetails(InfluencerDetails entity) {
        influencerDetailsStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public InfluencerDetails getInfluencerDetailsById(Integer id) {
        return influencerDetailsStore.get(id);
    }

    @Override
    public List<InfluencerDetails> getAllInfluencerDetails() {
        return influencerDetailsStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public InfluencerDetails updateInfluencerDetails(Integer id, InfluencerDetails entity) {
        if (!influencerDetailsStore.containsKey(id)) return null;
        entity.setId(id);
        influencerDetailsStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteInfluencerDetails(Integer id) {
        return influencerDetailsStore.remove(id) != null;
    }

}