package com.esports.platform.service.interfaces;

import com.esports.platform.entity.*;
import java.util.List;

/**
 * CRUD contract for the Finance (Payments, Subscriptions, Revenue) module.
 * Covers entities: PaymentMethod, TransactionType, RevenueTransaction, SubscriptionPlan, UserSubscription
 */
public interface FinanceService {

    // ---- PaymentMethod ----
    PaymentMethod createPaymentMethod(PaymentMethod entity);
    PaymentMethod getPaymentMethodById(Integer id);
    List<PaymentMethod> getAllPaymentMethods();
    PaymentMethod updatePaymentMethod(Integer id, PaymentMethod entity);
    boolean deletePaymentMethod(Integer id);

    // ---- TransactionType ----
    TransactionType createTransactionType(TransactionType entity);
    TransactionType getTransactionTypeById(Integer id);
    List<TransactionType> getAllTransactionTypes();
    TransactionType updateTransactionType(Integer id, TransactionType entity);
    boolean deleteTransactionType(Integer id);

    // ---- RevenueTransaction ----
    RevenueTransaction createRevenueTransaction(RevenueTransaction entity);
    RevenueTransaction getRevenueTransactionById(Integer id);
    List<RevenueTransaction> getAllRevenueTransactions();
    RevenueTransaction updateRevenueTransaction(Integer id, RevenueTransaction entity);
    boolean deleteRevenueTransaction(Integer id);

    // ---- SubscriptionPlan ----
    SubscriptionPlan createSubscriptionPlan(SubscriptionPlan entity);
    SubscriptionPlan getSubscriptionPlanById(Integer id);
    List<SubscriptionPlan> getAllSubscriptionPlans();
    SubscriptionPlan updateSubscriptionPlan(Integer id, SubscriptionPlan entity);
    boolean deleteSubscriptionPlan(Integer id);

    // ---- UserSubscription ----
    UserSubscription createUserSubscription(UserSubscription entity);
    UserSubscription getUserSubscriptionById(Integer id);
    List<UserSubscription> getAllUserSubscriptions();
    UserSubscription updateUserSubscription(Integer id, UserSubscription entity);
    boolean deleteUserSubscription(Integer id);

}