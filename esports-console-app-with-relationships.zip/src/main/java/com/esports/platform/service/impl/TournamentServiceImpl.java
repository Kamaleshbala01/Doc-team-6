package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.TournamentService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * In-memory implementation of TournamentService.
 * The primary key is taken from the entity passed in on create() —
 * it is set on the dummy object by the controller before calling create(),
 * there is no separate id-generation step.
 */
public class TournamentServiceImpl implements TournamentService {

    private final Map<Integer, TournamentCategory> tournamentCategoryStore = new LinkedHashMap<>();
    private final Map<Integer, TournamentType> tournamentTypeStore = new LinkedHashMap<>();
    private final Map<Integer, SeedingType> seedingTypeStore = new LinkedHashMap<>();
    private final Map<Integer, Tournament> tournamentStore = new LinkedHashMap<>();
    private final Map<Integer, RulesCategory> rulesCategoryStore = new LinkedHashMap<>();
    private final Map<Integer, TournamentRule> tournamentRuleStore = new LinkedHashMap<>();
    private final Map<Integer, PrizeCategory> prizeCategoryStore = new LinkedHashMap<>();
    private final Map<Integer, TournamentPrize> tournamentPrizeStore = new LinkedHashMap<>();
    private final Map<Integer, TournamentPackage> tournamentPackageStore = new LinkedHashMap<>();
    private final Map<Integer, TournamentPayment> tournamentPaymentStore = new LinkedHashMap<>();
    private final Map<Integer, TournamentRegistration> tournamentRegistrationStore = new LinkedHashMap<>();
    private final Map<Integer, TournamentRegistrationPayment> tournamentRegistrationPaymentStore = new LinkedHashMap<>();
    private final Map<Integer, TournamentAnnouncement> tournamentAnnouncementStore = new LinkedHashMap<>();
    private final Map<Integer, TournamentFAQ> tournamentFAQStore = new LinkedHashMap<>();

    // ---- TournamentCategory ----
    @Override
    public TournamentCategory createTournamentCategory(TournamentCategory entity) {
        tournamentCategoryStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TournamentCategory getTournamentCategoryById(Integer id) {
        return tournamentCategoryStore.get(id);
    }

    @Override
    public List<TournamentCategory> getAllTournamentCategorys() {
        return tournamentCategoryStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentCategory updateTournamentCategory(Integer id, TournamentCategory entity) {
        if (!tournamentCategoryStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentCategoryStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentCategory(Integer id) {
        return tournamentCategoryStore.remove(id) != null;
    }

    // ---- TournamentType ----
    @Override
    public TournamentType createTournamentType(TournamentType entity) {
        tournamentTypeStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TournamentType getTournamentTypeById(Integer id) {
        return tournamentTypeStore.get(id);
    }

    @Override
    public List<TournamentType> getAllTournamentTypes() {
        return tournamentTypeStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentType updateTournamentType(Integer id, TournamentType entity) {
        if (!tournamentTypeStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentTypeStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentType(Integer id) {
        return tournamentTypeStore.remove(id) != null;
    }

    // ---- SeedingType ----
    @Override
    public SeedingType createSeedingType(SeedingType entity) {
        seedingTypeStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public SeedingType getSeedingTypeById(Integer id) {
        return seedingTypeStore.get(id);
    }

    @Override
    public List<SeedingType> getAllSeedingTypes() {
        return seedingTypeStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public SeedingType updateSeedingType(Integer id, SeedingType entity) {
        if (!seedingTypeStore.containsKey(id)) return null;
        entity.setId(id);
        seedingTypeStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteSeedingType(Integer id) {
        return seedingTypeStore.remove(id) != null;
    }

    // ---- Tournament ----
    @Override
    public Tournament createTournament(Tournament entity) {
        tournamentStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Tournament getTournamentById(Integer id) {
        return tournamentStore.get(id);
    }

    @Override
    public List<Tournament> getAllTournaments() {
        return tournamentStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Tournament updateTournament(Integer id, Tournament entity) {
        if (!tournamentStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournament(Integer id) {
        return tournamentStore.remove(id) != null;
    }

    // ---- RulesCategory ----
    @Override
    public RulesCategory createRulesCategory(RulesCategory entity) {
        rulesCategoryStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public RulesCategory getRulesCategoryById(Integer id) {
        return rulesCategoryStore.get(id);
    }

    @Override
    public List<RulesCategory> getAllRulesCategorys() {
        return rulesCategoryStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public RulesCategory updateRulesCategory(Integer id, RulesCategory entity) {
        if (!rulesCategoryStore.containsKey(id)) return null;
        entity.setId(id);
        rulesCategoryStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteRulesCategory(Integer id) {
        return rulesCategoryStore.remove(id) != null;
    }

    // ---- TournamentRule ----
    @Override
    public TournamentRule createTournamentRule(TournamentRule entity) {
        tournamentRuleStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TournamentRule getTournamentRuleById(Integer id) {
        return tournamentRuleStore.get(id);
    }

    @Override
    public List<TournamentRule> getAllTournamentRules() {
        return tournamentRuleStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentRule updateTournamentRule(Integer id, TournamentRule entity) {
        if (!tournamentRuleStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentRuleStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentRule(Integer id) {
        return tournamentRuleStore.remove(id) != null;
    }

    // ---- PrizeCategory ----
    @Override
    public PrizeCategory createPrizeCategory(PrizeCategory entity) {
        prizeCategoryStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public PrizeCategory getPrizeCategoryById(Integer id) {
        return prizeCategoryStore.get(id);
    }

    @Override
    public List<PrizeCategory> getAllPrizeCategorys() {
        return prizeCategoryStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public PrizeCategory updatePrizeCategory(Integer id, PrizeCategory entity) {
        if (!prizeCategoryStore.containsKey(id)) return null;
        entity.setId(id);
        prizeCategoryStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deletePrizeCategory(Integer id) {
        return prizeCategoryStore.remove(id) != null;
    }

    // ---- TournamentPrize ----
    @Override
    public TournamentPrize createTournamentPrize(TournamentPrize entity) {
        tournamentPrizeStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TournamentPrize getTournamentPrizeById(Integer id) {
        return tournamentPrizeStore.get(id);
    }

    @Override
    public List<TournamentPrize> getAllTournamentPrizes() {
        return tournamentPrizeStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentPrize updateTournamentPrize(Integer id, TournamentPrize entity) {
        if (!tournamentPrizeStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentPrizeStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentPrize(Integer id) {
        return tournamentPrizeStore.remove(id) != null;
    }

    // ---- TournamentPackage ----
    @Override
    public TournamentPackage createTournamentPackage(TournamentPackage entity) {
        tournamentPackageStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TournamentPackage getTournamentPackageById(Integer id) {
        return tournamentPackageStore.get(id);
    }

    @Override
    public List<TournamentPackage> getAllTournamentPackages() {
        return tournamentPackageStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentPackage updateTournamentPackage(Integer id, TournamentPackage entity) {
        if (!tournamentPackageStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentPackageStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentPackage(Integer id) {
        return tournamentPackageStore.remove(id) != null;
    }

    // ---- TournamentPayment ----
    @Override
    public TournamentPayment createTournamentPayment(TournamentPayment entity) {
        tournamentPaymentStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TournamentPayment getTournamentPaymentById(Integer id) {
        return tournamentPaymentStore.get(id);
    }

    @Override
    public List<TournamentPayment> getAllTournamentPayments() {
        return tournamentPaymentStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentPayment updateTournamentPayment(Integer id, TournamentPayment entity) {
        if (!tournamentPaymentStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentPaymentStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentPayment(Integer id) {
        return tournamentPaymentStore.remove(id) != null;
    }

    // ---- TournamentRegistration ----
    @Override
    public TournamentRegistration createTournamentRegistration(TournamentRegistration entity) {
        tournamentRegistrationStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TournamentRegistration getTournamentRegistrationById(Integer id) {
        return tournamentRegistrationStore.get(id);
    }

    @Override
    public List<TournamentRegistration> getAllTournamentRegistrations() {
        return tournamentRegistrationStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentRegistration updateTournamentRegistration(Integer id, TournamentRegistration entity) {
        if (!tournamentRegistrationStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentRegistrationStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentRegistration(Integer id) {
        return tournamentRegistrationStore.remove(id) != null;
    }

    // ---- TournamentRegistrationPayment ----
    @Override
    public TournamentRegistrationPayment createTournamentRegistrationPayment(TournamentRegistrationPayment entity) {
        tournamentRegistrationPaymentStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TournamentRegistrationPayment getTournamentRegistrationPaymentById(Integer id) {
        return tournamentRegistrationPaymentStore.get(id);
    }

    @Override
    public List<TournamentRegistrationPayment> getAllTournamentRegistrationPayments() {
        return tournamentRegistrationPaymentStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentRegistrationPayment updateTournamentRegistrationPayment(Integer id, TournamentRegistrationPayment entity) {
        if (!tournamentRegistrationPaymentStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentRegistrationPaymentStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentRegistrationPayment(Integer id) {
        return tournamentRegistrationPaymentStore.remove(id) != null;
    }

    // ---- TournamentAnnouncement ----
    @Override
    public TournamentAnnouncement createTournamentAnnouncement(TournamentAnnouncement entity) {
        tournamentAnnouncementStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TournamentAnnouncement getTournamentAnnouncementById(Integer id) {
        return tournamentAnnouncementStore.get(id);
    }

    @Override
    public List<TournamentAnnouncement> getAllTournamentAnnouncements() {
        return tournamentAnnouncementStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentAnnouncement updateTournamentAnnouncement(Integer id, TournamentAnnouncement entity) {
        if (!tournamentAnnouncementStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentAnnouncementStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentAnnouncement(Integer id) {
        return tournamentAnnouncementStore.remove(id) != null;
    }

    // ---- TournamentFAQ ----
    @Override
    public TournamentFAQ createTournamentFAQ(TournamentFAQ entity) {
        tournamentFAQStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public TournamentFAQ getTournamentFAQById(Integer id) {
        return tournamentFAQStore.get(id);
    }

    @Override
    public List<TournamentFAQ> getAllTournamentFAQs() {
        return tournamentFAQStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public TournamentFAQ updateTournamentFAQ(Integer id, TournamentFAQ entity) {
        if (!tournamentFAQStore.containsKey(id)) return null;
        entity.setId(id);
        tournamentFAQStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteTournamentFAQ(Integer id) {
        return tournamentFAQStore.remove(id) != null;
    }

}