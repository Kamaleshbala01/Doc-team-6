package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.ChatService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * In-memory implementation of ChatService.
 * The primary key is taken from the entity passed in on create() —
 * it is set on the dummy object by the controller before calling create(),
 * there is no separate id-generation step.
 */
public class ChatServiceImpl implements ChatService {

    private final Map<Integer, Conversation> conversationStore = new LinkedHashMap<>();
    private final Map<Long, ConversationParticipant> conversationParticipantStore = new LinkedHashMap<>();
    private final Map<Long, Message> messageStore = new LinkedHashMap<>();
    private final Map<Long, MessageAttachment> messageAttachmentStore = new LinkedHashMap<>();
    private final Map<Long, MessageReadStatus> messageReadStatusStore = new LinkedHashMap<>();
    private final Map<Long, MessageReaction> messageReactionStore = new LinkedHashMap<>();
    private final Map<Integer, UserPresence> userPresenceStore = new LinkedHashMap<>();
    private final Map<Long, ConversationPinnedMessage> conversationPinnedMessageStore = new LinkedHashMap<>();
    private final Map<Integer, ConversationSettings> conversationSettingsStore = new LinkedHashMap<>();

    // ---- Conversation ----
    @Override
    public Conversation createConversation(Conversation entity) {
        conversationStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Conversation getConversationById(Integer id) {
        return conversationStore.get(id);
    }

    @Override
    public List<Conversation> getAllConversations() {
        return conversationStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Conversation updateConversation(Integer id, Conversation entity) {
        if (!conversationStore.containsKey(id)) return null;
        entity.setId(id);
        conversationStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteConversation(Integer id) {
        return conversationStore.remove(id) != null;
    }

    // ---- ConversationParticipant ----
    @Override
    public ConversationParticipant createConversationParticipant(ConversationParticipant entity) {
        conversationParticipantStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public ConversationParticipant getConversationParticipantById(Long id) {
        return conversationParticipantStore.get(id);
    }

    @Override
    public List<ConversationParticipant> getAllConversationParticipants() {
        return conversationParticipantStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public ConversationParticipant updateConversationParticipant(Long id, ConversationParticipant entity) {
        if (!conversationParticipantStore.containsKey(id)) return null;
        entity.setId(id);
        conversationParticipantStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteConversationParticipant(Long id) {
        return conversationParticipantStore.remove(id) != null;
    }

    // ---- Message ----
    @Override
    public Message createMessage(Message entity) {
        messageStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public Message getMessageById(Long id) {
        return messageStore.get(id);
    }

    @Override
    public List<Message> getAllMessages() {
        return messageStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public Message updateMessage(Long id, Message entity) {
        if (!messageStore.containsKey(id)) return null;
        entity.setId(id);
        messageStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteMessage(Long id) {
        return messageStore.remove(id) != null;
    }

    // ---- MessageAttachment ----
    @Override
    public MessageAttachment createMessageAttachment(MessageAttachment entity) {
        messageAttachmentStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public MessageAttachment getMessageAttachmentById(Long id) {
        return messageAttachmentStore.get(id);
    }

    @Override
    public List<MessageAttachment> getAllMessageAttachments() {
        return messageAttachmentStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public MessageAttachment updateMessageAttachment(Long id, MessageAttachment entity) {
        if (!messageAttachmentStore.containsKey(id)) return null;
        entity.setId(id);
        messageAttachmentStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteMessageAttachment(Long id) {
        return messageAttachmentStore.remove(id) != null;
    }

    // ---- MessageReadStatus ----
    @Override
    public MessageReadStatus createMessageReadStatus(MessageReadStatus entity) {
        messageReadStatusStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public MessageReadStatus getMessageReadStatusById(Long id) {
        return messageReadStatusStore.get(id);
    }

    @Override
    public List<MessageReadStatus> getAllMessageReadStatus() {
        return messageReadStatusStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public MessageReadStatus updateMessageReadStatus(Long id, MessageReadStatus entity) {
        if (!messageReadStatusStore.containsKey(id)) return null;
        entity.setId(id);
        messageReadStatusStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteMessageReadStatus(Long id) {
        return messageReadStatusStore.remove(id) != null;
    }

    // ---- MessageReaction ----
    @Override
    public MessageReaction createMessageReaction(MessageReaction entity) {
        messageReactionStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public MessageReaction getMessageReactionById(Long id) {
        return messageReactionStore.get(id);
    }

    @Override
    public List<MessageReaction> getAllMessageReactions() {
        return messageReactionStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public MessageReaction updateMessageReaction(Long id, MessageReaction entity) {
        if (!messageReactionStore.containsKey(id)) return null;
        entity.setId(id);
        messageReactionStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteMessageReaction(Long id) {
        return messageReactionStore.remove(id) != null;
    }

    // ---- UserPresence ----
    @Override
    public UserPresence createUserPresence(UserPresence entity) {
        userPresenceStore.put(entity.getUserId(), entity);
        return entity;
    }

    @Override
    public UserPresence getUserPresenceById(Integer id) {
        return userPresenceStore.get(id);
    }

    @Override
    public List<UserPresence> getAllUserPresences() {
        return userPresenceStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public UserPresence updateUserPresence(Integer id, UserPresence entity) {
        if (!userPresenceStore.containsKey(id)) return null;
        entity.setUserId(id);
        userPresenceStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteUserPresence(Integer id) {
        return userPresenceStore.remove(id) != null;
    }

    // ---- ConversationPinnedMessage ----
    @Override
    public ConversationPinnedMessage createConversationPinnedMessage(ConversationPinnedMessage entity) {
        conversationPinnedMessageStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public ConversationPinnedMessage getConversationPinnedMessageById(Long id) {
        return conversationPinnedMessageStore.get(id);
    }

    @Override
    public List<ConversationPinnedMessage> getAllConversationPinnedMessages() {
        return conversationPinnedMessageStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public ConversationPinnedMessage updateConversationPinnedMessage(Long id, ConversationPinnedMessage entity) {
        if (!conversationPinnedMessageStore.containsKey(id)) return null;
        entity.setId(id);
        conversationPinnedMessageStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteConversationPinnedMessage(Long id) {
        return conversationPinnedMessageStore.remove(id) != null;
    }

    // ---- ConversationSettings ----
    @Override
    public ConversationSettings createConversationSettings(ConversationSettings entity) {
        conversationSettingsStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public ConversationSettings getConversationSettingsById(Integer id) {
        return conversationSettingsStore.get(id);
    }

    @Override
    public List<ConversationSettings> getAllConversationSettings() {
        return conversationSettingsStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public ConversationSettings updateConversationSettings(Integer id, ConversationSettings entity) {
        if (!conversationSettingsStore.containsKey(id)) return null;
        entity.setId(id);
        conversationSettingsStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteConversationSettings(Integer id) {
        return conversationSettingsStore.remove(id) != null;
    }

}