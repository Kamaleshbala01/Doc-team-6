package com.esports.platform.service.impl;

import com.esports.platform.entity.*;
import com.esports.platform.service.interfaces.AffiliateService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * In-memory implementation of AffiliateService.
 * The primary key is taken from the entity passed in on create() —
 * it is set on the dummy object by the controller before calling create(),
 * there is no separate id-generation step.
 */
public class AffiliateServiceImpl implements AffiliateService {

    private final Map<Integer, AffiliateCampaign> affiliateCampaignStore = new LinkedHashMap<>();
    private final Map<Integer, AffiliateLink> affiliateLinkStore = new LinkedHashMap<>();
    private final Map<Long, AffiliateClick> affiliateClickStore = new LinkedHashMap<>();

    // ---- AffiliateCampaign ----
    @Override
    public AffiliateCampaign createAffiliateCampaign(AffiliateCampaign entity) {
        affiliateCampaignStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public AffiliateCampaign getAffiliateCampaignById(Integer id) {
        return affiliateCampaignStore.get(id);
    }

    @Override
    public List<AffiliateCampaign> getAllAffiliateCampaigns() {
        return affiliateCampaignStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public AffiliateCampaign updateAffiliateCampaign(Integer id, AffiliateCampaign entity) {
        if (!affiliateCampaignStore.containsKey(id)) return null;
        entity.setId(id);
        affiliateCampaignStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteAffiliateCampaign(Integer id) {
        return affiliateCampaignStore.remove(id) != null;
    }

    // ---- AffiliateLink ----
    @Override
    public AffiliateLink createAffiliateLink(AffiliateLink entity) {
        affiliateLinkStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public AffiliateLink getAffiliateLinkById(Integer id) {
        return affiliateLinkStore.get(id);
    }

    @Override
    public List<AffiliateLink> getAllAffiliateLinks() {
        return affiliateLinkStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public AffiliateLink updateAffiliateLink(Integer id, AffiliateLink entity) {
        if (!affiliateLinkStore.containsKey(id)) return null;
        entity.setId(id);
        affiliateLinkStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteAffiliateLink(Integer id) {
        return affiliateLinkStore.remove(id) != null;
    }

    // ---- AffiliateClick ----
    @Override
    public AffiliateClick createAffiliateClick(AffiliateClick entity) {
        affiliateClickStore.put(entity.getId(), entity);
        return entity;
    }

    @Override
    public AffiliateClick getAffiliateClickById(Long id) {
        return affiliateClickStore.get(id);
    }

    @Override
    public List<AffiliateClick> getAllAffiliateClicks() {
        return affiliateClickStore.values().stream().collect(Collectors.toList());
    }

    @Override
    public AffiliateClick updateAffiliateClick(Long id, AffiliateClick entity) {
        if (!affiliateClickStore.containsKey(id)) return null;
        entity.setId(id);
        affiliateClickStore.put(id, entity);
        return entity;
    }

    @Override
    public boolean deleteAffiliateClick(Long id) {
        return affiliateClickStore.remove(id) != null;
    }

}