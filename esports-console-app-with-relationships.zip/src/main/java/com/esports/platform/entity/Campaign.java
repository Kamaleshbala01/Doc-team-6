package com.esports.platform.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonBackReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity mapping for the "Campaign" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "Campaign")
public class Campaign {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "brandId")
    private Integer brandId;

    @Column(name = "campaignTypeId")
    private Integer campaignTypeId;

    @Column(name = "campaignName")
    private String campaignName;

    @Column(name = "gameId")
    private Integer gameId;

    @Column(name = "startDate")
    private LocalDateTime startDate;

    @Column(name = "endDate")
    private LocalDateTime endDate;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "campaignThumbnailFileId")
    private Integer campaignThumbnailFileId;

    @Column(name = "totalBudget")
    private BigDecimal totalBudget;

    @Column(name = "influencerCost")
    private BigDecimal influencerCost;

    @Column(name = "additionalExpenses")
    private BigDecimal additionalExpenses;

    @Column(name = "status")
    private String status;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

        // ---- Relationships (added for association mapping) ----
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "brandId", insertable = false, updatable = false)
    @JsonBackReference("brand")
    private BrandDetails brand;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "campaignTypeId", insertable = false, updatable = false)
    @JsonBackReference("campaignType")
    private CampaignType campaignType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "gameId", insertable = false, updatable = false)
    @JsonBackReference("game")
    private Game game;

    @OneToMany(mappedBy = "campaign", fetch = FetchType.LAZY)
    @JsonManagedReference("campaign")
    private List<CampaignPlatform> platforms = new ArrayList<>();

    @OneToMany(mappedBy = "campaign", fetch = FetchType.LAZY)
    @JsonManagedReference("campaign")
    private List<CampaignAsset> assets = new ArrayList<>();

    @OneToMany(mappedBy = "campaign", fetch = FetchType.LAZY)
    @JsonManagedReference("campaign")
    private List<CampaignDeliverable> deliverables = new ArrayList<>();

    @OneToMany(mappedBy = "campaign", fetch = FetchType.LAZY)
    @JsonManagedReference("campaign")
    private List<CollaborationRequest> collaborationRequests = new ArrayList<>();


    public Campaign() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBrandId() {
        return brandId;
    }

    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

    public Integer getCampaignTypeId() {
        return campaignTypeId;
    }

    public void setCampaignTypeId(Integer campaignTypeId) {
        this.campaignTypeId = campaignTypeId;
    }

    public String getCampaignName() {
        return campaignName;
    }

    public void setCampaignName(String campaignName) {
        this.campaignName = campaignName;
    }

    public Integer getGameId() {
        return gameId;
    }

    public void setGameId(Integer gameId) {
        this.gameId = gameId;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getCampaignThumbnailFileId() {
        return campaignThumbnailFileId;
    }

    public void setCampaignThumbnailFileId(Integer campaignThumbnailFileId) {
        this.campaignThumbnailFileId = campaignThumbnailFileId;
    }

    public BigDecimal getTotalBudget() {
        return totalBudget;
    }

    public void setTotalBudget(BigDecimal totalBudget) {
        this.totalBudget = totalBudget;
    }

    public BigDecimal getInfluencerCost() {
        return influencerCost;
    }

    public void setInfluencerCost(BigDecimal influencerCost) {
        this.influencerCost = influencerCost;
    }

    public BigDecimal getAdditionalExpenses() {
        return additionalExpenses;
    }

    public void setAdditionalExpenses(BigDecimal additionalExpenses) {
        this.additionalExpenses = additionalExpenses;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public BrandDetails getBrand() {
        return brand;
    }

    public void setBrand(BrandDetails brand) {
        this.brand = brand;
    }

    public CampaignType getCampaignType() {
        return campaignType;
    }

    public void setCampaignType(CampaignType campaignType) {
        this.campaignType = campaignType;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public List<CampaignPlatform> getPlatforms() {
        return platforms;
    }

    public void setPlatforms(List<CampaignPlatform> platforms) {
        this.platforms = platforms;
    }

    public List<CampaignAsset> getAssets() {
        return assets;
    }

    public void setAssets(List<CampaignAsset> assets) {
        this.assets = assets;
    }

    public List<CampaignDeliverable> getDeliverables() {
        return deliverables;
    }

    public void setDeliverables(List<CampaignDeliverable> deliverables) {
        this.deliverables = deliverables;
    }

    public List<CollaborationRequest> getCollaborationRequests() {
        return collaborationRequests;
    }

    public void setCollaborationRequests(List<CollaborationRequest> collaborationRequests) {
        this.collaborationRequests = collaborationRequests;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Campaign)) return false;
        Campaign that = (Campaign) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Campaign{" +
                "id=" + id +
                '}';
    }
}