package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity mapping for the "StatusMaster" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "StatusMaster")
public class StatusMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "statusType")
    private String statusType;

    @Column(name = "statusName")
    private String statusName;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

        // ---- Relationships (added for association mapping) ----
    @OneToMany(mappedBy = "acceptanceStatus", fetch = FetchType.LAZY)
    @JsonManagedReference("acceptanceStatus")
    private List<SocialMediaAccount> socialMediaAccounts = new ArrayList<>();

    @OneToMany(mappedBy = "registrationStatus", fetch = FetchType.LAZY)
    @JsonManagedReference("registrationStatus")
    private List<TournamentRegistration> tournamentRegistrations = new ArrayList<>();


    public StatusMaster() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStatusType() {
        return statusType;
    }

    public void setStatusType(String statusType) {
        this.statusType = statusType;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public List<SocialMediaAccount> getSocialMediaAccounts() {
        return socialMediaAccounts;
    }

    public void setSocialMediaAccounts(List<SocialMediaAccount> socialMediaAccounts) {
        this.socialMediaAccounts = socialMediaAccounts;
    }

    public List<TournamentRegistration> getTournamentRegistrations() {
        return tournamentRegistrations;
    }

    public void setTournamentRegistrations(List<TournamentRegistration> tournamentRegistrations) {
        this.tournamentRegistrations = tournamentRegistrations;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StatusMaster)) return false;
        StatusMaster that = (StatusMaster) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "StatusMaster{" +
                "id=" + id +
                '}';
    }
}