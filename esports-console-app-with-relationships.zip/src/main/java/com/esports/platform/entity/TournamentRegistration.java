package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonBackReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity mapping for the "TournamentRegistration" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "TournamentRegistration")
public class TournamentRegistration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "tournamentId")
    private Integer tournamentId;

    @Column(name = "teamId")
    private Integer teamId;

    @Column(name = "registrationStatusId")
    private Integer registrationStatusId;

    @Column(name = "registrationDate")
    private LocalDateTime registrationDate;

    @Column(name = "approvedBy")
    private Integer approvedBy;

    @Column(name = "approvedDate")
    private LocalDateTime approvedDate;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

        // ---- Relationships (added for association mapping) ----
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tournamentId", insertable = false, updatable = false)
    @JsonBackReference("tournament")
    private Tournament tournament;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "teamId", insertable = false, updatable = false)
    @JsonBackReference("team")
    private Team team;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "registrationStatusId", insertable = false, updatable = false)
    @JsonBackReference("registrationStatus")
    private StatusMaster registrationStatus;

    @OneToMany(mappedBy = "registration", fetch = FetchType.LAZY)
    @JsonManagedReference("registration")
    private List<TournamentRegistrationPayment> payments = new ArrayList<>();


    public TournamentRegistration() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTournamentId() {
        return tournamentId;
    }

    public void setTournamentId(Integer tournamentId) {
        this.tournamentId = tournamentId;
    }

    public Integer getTeamId() {
        return teamId;
    }

    public void setTeamId(Integer teamId) {
        this.teamId = teamId;
    }

    public Integer getRegistrationStatusId() {
        return registrationStatusId;
    }

    public void setRegistrationStatusId(Integer registrationStatusId) {
        this.registrationStatusId = registrationStatusId;
    }

    public LocalDateTime getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(LocalDateTime registrationDate) {
        this.registrationDate = registrationDate;
    }

    public Integer getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(Integer approvedBy) {
        this.approvedBy = approvedBy;
    }

    public LocalDateTime getApprovedDate() {
        return approvedDate;
    }

    public void setApprovedDate(LocalDateTime approvedDate) {
        this.approvedDate = approvedDate;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Tournament getTournament() {
        return tournament;
    }

    public void setTournament(Tournament tournament) {
        this.tournament = tournament;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public StatusMaster getRegistrationStatus() {
        return registrationStatus;
    }

    public void setRegistrationStatus(StatusMaster registrationStatus) {
        this.registrationStatus = registrationStatus;
    }

    public List<TournamentRegistrationPayment> getPayments() {
        return payments;
    }

    public void setPayments(List<TournamentRegistrationPayment> payments) {
        this.payments = payments;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TournamentRegistration)) return false;
        TournamentRegistration that = (TournamentRegistration) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "TournamentRegistration{" +
                "id=" + id +
                '}';
    }
}