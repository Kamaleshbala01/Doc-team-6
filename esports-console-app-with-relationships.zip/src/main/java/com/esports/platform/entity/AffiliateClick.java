package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonBackReference;

/**
 * Entity mapping for the "AffiliateClick" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "AffiliateClick")
public class AffiliateClick {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "affiliateLinkId", nullable = false)
    private Integer affiliateLinkId;

    @Column(name = "sessionId")
    private String sessionId;

    @Column(name = "visitorIp")
    private String visitorIp;

    @Column(name = "country")
    private String country;

    @Column(name = "city")
    private String city;

    @Column(name = "deviceType")
    private String deviceType;

    @Column(name = "browser")
    private String browser;

    @Column(name = "refererUrl")
    private String refererUrl;

    @Column(name = "clickedAt")
    private LocalDateTime clickedAt;

        // ---- Relationships (added for association mapping) ----
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "affiliateLinkId", insertable = false, updatable = false)
    @JsonBackReference("affiliateLink")
    private AffiliateLink affiliateLink;


    public AffiliateClick() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getAffiliateLinkId() {
        return affiliateLinkId;
    }

    public void setAffiliateLinkId(Integer affiliateLinkId) {
        this.affiliateLinkId = affiliateLinkId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getVisitorIp() {
        return visitorIp;
    }

    public void setVisitorIp(String visitorIp) {
        this.visitorIp = visitorIp;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getBrowser() {
        return browser;
    }

    public void setBrowser(String browser) {
        this.browser = browser;
    }

    public String getRefererUrl() {
        return refererUrl;
    }

    public void setRefererUrl(String refererUrl) {
        this.refererUrl = refererUrl;
    }

    public LocalDateTime getClickedAt() {
        return clickedAt;
    }

    public void setClickedAt(LocalDateTime clickedAt) {
        this.clickedAt = clickedAt;
    }

    public AffiliateLink getAffiliateLink() {
        return affiliateLink;
    }

    public void setAffiliateLink(AffiliateLink affiliateLink) {
        this.affiliateLink = affiliateLink;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AffiliateClick)) return false;
        AffiliateClick that = (AffiliateClick) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "AffiliateClick{" +
                "id=" + id +
                '}';
    }
}