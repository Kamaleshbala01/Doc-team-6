package com.esports.platform.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonBackReference;

/**
 * Entity mapping for the "TournamentPayment" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "TournamentPayment")
public class TournamentPayment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "organizerId")
    private Integer organizerId;

    @Column(name = "tournamentId")
    private Integer tournamentId;

    @Column(name = "packageId")
    private Integer packageId;

    @Column(name = "amount")
    private BigDecimal amount;

    @Column(name = "paymentReference")
    private String paymentReference;

    @Column(name = "paymentStatus")
    private String paymentStatus;

    @Column(name = "paidDate")
    private LocalDateTime paidDate;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

        // ---- Relationships (added for association mapping) ----
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organizerId", insertable = false, updatable = false)
    @JsonBackReference("organizer")
    private Users organizer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tournamentId", insertable = false, updatable = false)
    @JsonBackReference("tournament")
    private Tournament tournament;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "packageId", insertable = false, updatable = false)
    @JsonBackReference("tournamentPackage")
    private TournamentPackage tournamentPackage;


    public TournamentPayment() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrganizerId() {
        return organizerId;
    }

    public void setOrganizerId(Integer organizerId) {
        this.organizerId = organizerId;
    }

    public Integer getTournamentId() {
        return tournamentId;
    }

    public void setTournamentId(Integer tournamentId) {
        this.tournamentId = tournamentId;
    }

    public Integer getPackageId() {
        return packageId;
    }

    public void setPackageId(Integer packageId) {
        this.packageId = packageId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getPaymentReference() {
        return paymentReference;
    }

    public void setPaymentReference(String paymentReference) {
        this.paymentReference = paymentReference;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public LocalDateTime getPaidDate() {
        return paidDate;
    }

    public void setPaidDate(LocalDateTime paidDate) {
        this.paidDate = paidDate;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Users getOrganizer() {
        return organizer;
    }

    public void setOrganizer(Users organizer) {
        this.organizer = organizer;
    }

    public Tournament getTournament() {
        return tournament;
    }

    public void setTournament(Tournament tournament) {
        this.tournament = tournament;
    }

    public TournamentPackage getTournamentPackage() {
        return tournamentPackage;
    }

    public void setTournamentPackage(TournamentPackage tournamentPackage) {
        this.tournamentPackage = tournamentPackage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TournamentPayment)) return false;
        TournamentPayment that = (TournamentPayment) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "TournamentPayment{" +
                "id=" + id +
                '}';
    }
}