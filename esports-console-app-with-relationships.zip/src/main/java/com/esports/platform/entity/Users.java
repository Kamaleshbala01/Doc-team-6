package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity mapping for the "Users" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "Users")
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @Column(name = "username", nullable = false, unique = true)
    private String username;

    @Column(name = "passwordHash", nullable = false)
    private String passwordHash;

    @Column(name = "emailVerified")
    private Boolean emailVerified;

    @Column(name = "status")
    private String status;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

    @Column(name = "lastLoginAt")
    private LocalDateTime lastLoginAt;

        // ---- Relationships (added for association mapping) ----
    @OneToMany(mappedBy = "assignedUser", fetch = FetchType.LAZY)
    @JsonManagedReference("assignedUser")
    private List<AffiliateLink> assignedAffiliateLinks = new ArrayList<>();

    @OneToMany(mappedBy = "creator", fetch = FetchType.LAZY)
    @JsonManagedReference("creator")
    private List<Conversation> createdConversations = new ArrayList<>();

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private List<ConversationParticipant> conversationParticipations = new ArrayList<>();

    @OneToMany(mappedBy = "sender", fetch = FetchType.LAZY)
    @JsonManagedReference("sender")
    private List<Message> sentMessages = new ArrayList<>();

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private List<MessageReadStatus> messageReadStatuses = new ArrayList<>();

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private List<MessageReaction> messageReactions = new ArrayList<>();

    @OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private UserPresence presence;

    @OneToMany(mappedBy = "pinnedByUser", fetch = FetchType.LAZY)
    @JsonManagedReference("pinnedByUser")
    private List<ConversationPinnedMessage> pinnedMessagesByUser = new ArrayList<>();

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private List<UserRoles> userRoles = new ArrayList<>();

    @OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private UserProfile profile;

    @OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private TournamentOrganizerDetails organizerDetails;

    @OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private BrandDetails brandDetails;

    @OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private InfluencerDetails influencerDetails;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private List<SocialMediaAccount> socialMediaAccounts = new ArrayList<>();

    @OneToMany(mappedBy = "organizer", fetch = FetchType.LAZY)
    @JsonManagedReference("organizer")
    private List<Tournament> organizedTournaments = new ArrayList<>();

    @OneToMany(mappedBy = "owner", fetch = FetchType.LAZY)
    @JsonManagedReference("owner")
    private List<Team> ownedTeams = new ArrayList<>();

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private List<TeamMember> teamMemberships = new ArrayList<>();

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private List<TournamentFAQ> tournamentFaqs = new ArrayList<>();

    @OneToMany(mappedBy = "sender", fetch = FetchType.LAZY)
    @JsonManagedReference("sender")
    private List<CollaborationRequest> sentCollaborationRequests = new ArrayList<>();

    @OneToMany(mappedBy = "receiver", fetch = FetchType.LAZY)
    @JsonManagedReference("receiver")
    private List<CollaborationRequest> receivedCollaborationRequests = new ArrayList<>();

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private List<RevenueTransaction> revenueTransactions = new ArrayList<>();

    @OneToMany(mappedBy = "organizer", fetch = FetchType.LAZY)
    @JsonManagedReference("organizer")
    private List<TournamentPayment> tournamentPayments = new ArrayList<>();

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private List<UserSubscription> subscriptions = new ArrayList<>();

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private List<Notification> notifications = new ArrayList<>();

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    @JsonManagedReference("user")
    private List<AuditLog> auditLogs = new ArrayList<>();


    public Users() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public Boolean getEmailVerified() {
        return emailVerified;
    }

    public void setEmailVerified(Boolean emailVerified) {
        this.emailVerified = emailVerified;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public LocalDateTime getLastLoginAt() {
        return lastLoginAt;
    }

    public void setLastLoginAt(LocalDateTime lastLoginAt) {
        this.lastLoginAt = lastLoginAt;
    }

    public List<AffiliateLink> getAssignedAffiliateLinks() {
        return assignedAffiliateLinks;
    }

    public void setAssignedAffiliateLinks(List<AffiliateLink> assignedAffiliateLinks) {
        this.assignedAffiliateLinks = assignedAffiliateLinks;
    }

    public List<Conversation> getCreatedConversations() {
        return createdConversations;
    }

    public void setCreatedConversations(List<Conversation> createdConversations) {
        this.createdConversations = createdConversations;
    }

    public List<ConversationParticipant> getConversationParticipations() {
        return conversationParticipations;
    }

    public void setConversationParticipations(List<ConversationParticipant> conversationParticipations) {
        this.conversationParticipations = conversationParticipations;
    }

    public List<Message> getSentMessages() {
        return sentMessages;
    }

    public void setSentMessages(List<Message> sentMessages) {
        this.sentMessages = sentMessages;
    }

    public List<MessageReadStatus> getMessageReadStatuses() {
        return messageReadStatuses;
    }

    public void setMessageReadStatuses(List<MessageReadStatus> messageReadStatuses) {
        this.messageReadStatuses = messageReadStatuses;
    }

    public List<MessageReaction> getMessageReactions() {
        return messageReactions;
    }

    public void setMessageReactions(List<MessageReaction> messageReactions) {
        this.messageReactions = messageReactions;
    }

    public UserPresence getPresence() {
        return presence;
    }

    public void setPresence(UserPresence presence) {
        this.presence = presence;
    }

    public List<ConversationPinnedMessage> getPinnedMessagesByUser() {
        return pinnedMessagesByUser;
    }

    public void setPinnedMessagesByUser(List<ConversationPinnedMessage> pinnedMessagesByUser) {
        this.pinnedMessagesByUser = pinnedMessagesByUser;
    }

    public List<UserRoles> getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(List<UserRoles> userRoles) {
        this.userRoles = userRoles;
    }

    public UserProfile getProfile() {
        return profile;
    }

    public void setProfile(UserProfile profile) {
        this.profile = profile;
    }

    public TournamentOrganizerDetails getOrganizerDetails() {
        return organizerDetails;
    }

    public void setOrganizerDetails(TournamentOrganizerDetails organizerDetails) {
        this.organizerDetails = organizerDetails;
    }

    public BrandDetails getBrandDetails() {
        return brandDetails;
    }

    public void setBrandDetails(BrandDetails brandDetails) {
        this.brandDetails = brandDetails;
    }

    public InfluencerDetails getInfluencerDetails() {
        return influencerDetails;
    }

    public void setInfluencerDetails(InfluencerDetails influencerDetails) {
        this.influencerDetails = influencerDetails;
    }

    public List<SocialMediaAccount> getSocialMediaAccounts() {
        return socialMediaAccounts;
    }

    public void setSocialMediaAccounts(List<SocialMediaAccount> socialMediaAccounts) {
        this.socialMediaAccounts = socialMediaAccounts;
    }

    public List<Tournament> getOrganizedTournaments() {
        return organizedTournaments;
    }

    public void setOrganizedTournaments(List<Tournament> organizedTournaments) {
        this.organizedTournaments = organizedTournaments;
    }

    public List<Team> getOwnedTeams() {
        return ownedTeams;
    }

    public void setOwnedTeams(List<Team> ownedTeams) {
        this.ownedTeams = ownedTeams;
    }

    public List<TeamMember> getTeamMemberships() {
        return teamMemberships;
    }

    public void setTeamMemberships(List<TeamMember> teamMemberships) {
        this.teamMemberships = teamMemberships;
    }

    public List<TournamentFAQ> getTournamentFaqs() {
        return tournamentFaqs;
    }

    public void setTournamentFaqs(List<TournamentFAQ> tournamentFaqs) {
        this.tournamentFaqs = tournamentFaqs;
    }

    public List<CollaborationRequest> getSentCollaborationRequests() {
        return sentCollaborationRequests;
    }

    public void setSentCollaborationRequests(List<CollaborationRequest> sentCollaborationRequests) {
        this.sentCollaborationRequests = sentCollaborationRequests;
    }

    public List<CollaborationRequest> getReceivedCollaborationRequests() {
        return receivedCollaborationRequests;
    }

    public void setReceivedCollaborationRequests(List<CollaborationRequest> receivedCollaborationRequests) {
        this.receivedCollaborationRequests = receivedCollaborationRequests;
    }

    public List<RevenueTransaction> getRevenueTransactions() {
        return revenueTransactions;
    }

    public void setRevenueTransactions(List<RevenueTransaction> revenueTransactions) {
        this.revenueTransactions = revenueTransactions;
    }

    public List<TournamentPayment> getTournamentPayments() {
        return tournamentPayments;
    }

    public void setTournamentPayments(List<TournamentPayment> tournamentPayments) {
        this.tournamentPayments = tournamentPayments;
    }

    public List<UserSubscription> getSubscriptions() {
        return subscriptions;
    }

    public void setSubscriptions(List<UserSubscription> subscriptions) {
        this.subscriptions = subscriptions;
    }

    public List<Notification> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<Notification> notifications) {
        this.notifications = notifications;
    }

    public List<AuditLog> getAuditLogs() {
        return auditLogs;
    }

    public void setAuditLogs(List<AuditLog> auditLogs) {
        this.auditLogs = auditLogs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Users)) return false;
        Users that = (Users) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Users{" +
                "id=" + id +
                '}';
    }
}