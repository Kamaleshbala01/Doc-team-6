package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonBackReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity mapping for the "TournamentType" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "TournamentType")
public class TournamentType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "categoryId")
    private Integer categoryId;

    @Column(name = "typeName")
    private String typeName;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

        // ---- Relationships (added for association mapping) ----
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoryId", insertable = false, updatable = false)
    @JsonBackReference("category")
    private TournamentCategory category;

    @OneToMany(mappedBy = "tournamentType", fetch = FetchType.LAZY)
    @JsonManagedReference("tournamentType")
    private List<Tournament> tournaments = new ArrayList<>();


    public TournamentType() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public TournamentCategory getCategory() {
        return category;
    }

    public void setCategory(TournamentCategory category) {
        this.category = category;
    }

    public List<Tournament> getTournaments() {
        return tournaments;
    }

    public void setTournaments(List<Tournament> tournaments) {
        this.tournaments = tournaments;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TournamentType)) return false;
        TournamentType that = (TournamentType) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "TournamentType{" +
                "id=" + id +
                '}';
    }
}