package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonBackReference;

/**
 * Entity mapping for the "ConversationPinnedMessage" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "ConversationPinnedMessage")
public class ConversationPinnedMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "conversationId", nullable = false)
    private Integer conversationId;

    @Column(name = "messageId", nullable = false)
    private Long messageId;

    @Column(name = "pinnedBy")
    private Integer pinnedBy;

    @Column(name = "pinnedAt")
    private LocalDateTime pinnedAt;

        // ---- Relationships (added for association mapping) ----
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "conversationId", insertable = false, updatable = false)
    @JsonBackReference("conversation")
    private Conversation conversation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "messageId", insertable = false, updatable = false)
    @JsonBackReference("message")
    private Message message;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pinnedBy", insertable = false, updatable = false)
    @JsonBackReference("pinnedByUser")
    private Users pinnedByUser;


    public ConversationPinnedMessage() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getConversationId() {
        return conversationId;
    }

    public void setConversationId(Integer conversationId) {
        this.conversationId = conversationId;
    }

    public Long getMessageId() {
        return messageId;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public Integer getPinnedBy() {
        return pinnedBy;
    }

    public void setPinnedBy(Integer pinnedBy) {
        this.pinnedBy = pinnedBy;
    }

    public LocalDateTime getPinnedAt() {
        return pinnedAt;
    }

    public void setPinnedAt(LocalDateTime pinnedAt) {
        this.pinnedAt = pinnedAt;
    }

    public Conversation getConversation() {
        return conversation;
    }

    public void setConversation(Conversation conversation) {
        this.conversation = conversation;
    }

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    public Users getPinnedByUser() {
        return pinnedByUser;
    }

    public void setPinnedByUser(Users pinnedByUser) {
        this.pinnedByUser = pinnedByUser;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ConversationPinnedMessage)) return false;
        ConversationPinnedMessage that = (ConversationPinnedMessage) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "ConversationPinnedMessage{" +
                "id=" + id +
                '}';
    }
}