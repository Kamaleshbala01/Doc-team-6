package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonBackReference;

/**
 * Entity mapping for the "TournamentOrganizerDetails" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "TournamentOrganizerDetails")
public class TournamentOrganizerDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "userId", nullable = false)
    private Integer userId;

    @Column(name = "mobileNumber")
    private String mobileNumber;

    @Column(name = "governmentIdUri")
    private String governmentIdUri;

    @Column(name = "selfieVerificationUri")
    private String selfieVerificationUri;

    @Column(name = "verificationStatus")
    private String verificationStatus;

    @Column(name = "verifiedAt")
    private LocalDateTime verifiedAt;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

        // ---- Relationships (added for association mapping) ----
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId", insertable = false, updatable = false)
    @JsonBackReference("user")
    private Users user;


    public TournamentOrganizerDetails() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getGovernmentIdUri() {
        return governmentIdUri;
    }

    public void setGovernmentIdUri(String governmentIdUri) {
        this.governmentIdUri = governmentIdUri;
    }

    public String getSelfieVerificationUri() {
        return selfieVerificationUri;
    }

    public void setSelfieVerificationUri(String selfieVerificationUri) {
        this.selfieVerificationUri = selfieVerificationUri;
    }

    public String getVerificationStatus() {
        return verificationStatus;
    }

    public void setVerificationStatus(String verificationStatus) {
        this.verificationStatus = verificationStatus;
    }

    public LocalDateTime getVerifiedAt() {
        return verifiedAt;
    }

    public void setVerifiedAt(LocalDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TournamentOrganizerDetails)) return false;
        TournamentOrganizerDetails that = (TournamentOrganizerDetails) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "TournamentOrganizerDetails{" +
                "id=" + id +
                '}';
    }
}