package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonBackReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity mapping for the "Message" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "Message")
public class Message {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "conversationId", nullable = false)
    private Integer conversationId;

    @Column(name = "senderId", nullable = false)
    private Integer senderId;

    @Column(name = "messageType", nullable = false)
    private String messageType;

    @Column(name = "content", columnDefinition = "TEXT")
    private String content;

    @Column(name = "replyMessageId")
    private Long replyMessageId;

    @Column(name = "isEdited")
    private Boolean isEdited;

    @Column(name = "editedAt")
    private LocalDateTime editedAt;

    @Column(name = "isDeleted")
    private Boolean isDeleted;

    @Column(name = "deletedAt")
    private LocalDateTime deletedAt;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

        // ---- Relationships (added for association mapping) ----
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "conversationId", insertable = false, updatable = false)
    @JsonBackReference("conversation")
    private Conversation conversation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "senderId", insertable = false, updatable = false)
    @JsonBackReference("sender")
    private Users sender;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "replyMessageId", insertable = false, updatable = false)
    @JsonBackReference("replyMessage")
    private Message replyMessage;

    @OneToMany(mappedBy = "replyMessage", fetch = FetchType.LAZY)
    @JsonManagedReference("replyMessage")
    private List<Message> replies = new ArrayList<>();

    @OneToMany(mappedBy = "message", fetch = FetchType.LAZY)
    @JsonManagedReference("message")
    private List<MessageAttachment> attachments = new ArrayList<>();

    @OneToMany(mappedBy = "message", fetch = FetchType.LAZY)
    @JsonManagedReference("message")
    private List<MessageReadStatus> readStatuses = new ArrayList<>();

    @OneToMany(mappedBy = "message", fetch = FetchType.LAZY)
    @JsonManagedReference("message")
    private List<MessageReaction> reactions = new ArrayList<>();

    @OneToMany(mappedBy = "message", fetch = FetchType.LAZY)
    @JsonManagedReference("message")
    private List<ConversationPinnedMessage> pins = new ArrayList<>();


    public Message() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getConversationId() {
        return conversationId;
    }

    public void setConversationId(Integer conversationId) {
        this.conversationId = conversationId;
    }

    public Integer getSenderId() {
        return senderId;
    }

    public void setSenderId(Integer senderId) {
        this.senderId = senderId;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Long getReplyMessageId() {
        return replyMessageId;
    }

    public void setReplyMessageId(Long replyMessageId) {
        this.replyMessageId = replyMessageId;
    }

    public Boolean getIsEdited() {
        return isEdited;
    }

    public void setIsEdited(Boolean isEdited) {
        this.isEdited = isEdited;
    }

    public LocalDateTime getEditedAt() {
        return editedAt;
    }

    public void setEditedAt(LocalDateTime editedAt) {
        this.editedAt = editedAt;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public LocalDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(LocalDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Conversation getConversation() {
        return conversation;
    }

    public void setConversation(Conversation conversation) {
        this.conversation = conversation;
    }

    public Users getSender() {
        return sender;
    }

    public void setSender(Users sender) {
        this.sender = sender;
    }

    public Message getReplyMessage() {
        return replyMessage;
    }

    public void setReplyMessage(Message replyMessage) {
        this.replyMessage = replyMessage;
    }

    public List<Message> getReplies() {
        return replies;
    }

    public void setReplies(List<Message> replies) {
        this.replies = replies;
    }

    public List<MessageAttachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<MessageAttachment> attachments) {
        this.attachments = attachments;
    }

    public List<MessageReadStatus> getReadStatuses() {
        return readStatuses;
    }

    public void setReadStatuses(List<MessageReadStatus> readStatuses) {
        this.readStatuses = readStatuses;
    }

    public List<MessageReaction> getReactions() {
        return reactions;
    }

    public void setReactions(List<MessageReaction> reactions) {
        this.reactions = reactions;
    }

    public List<ConversationPinnedMessage> getPins() {
        return pins;
    }

    public void setPins(List<ConversationPinnedMessage> pins) {
        this.pins = pins;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Message)) return false;
        Message that = (Message) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Message{" +
                "id=" + id +
                '}';
    }
}