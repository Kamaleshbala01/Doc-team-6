package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonBackReference;

/**
 * Entity mapping for the "InfluencerGame" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "InfluencerGame")
public class InfluencerGame {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "influencerId")
    private Integer influencerId;

    @Column(name = "gameId")
    private Integer gameId;

    @Column(name = "isPrimary")
    private Boolean isPrimary;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

        // ---- Relationships (added for association mapping) ----
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "influencerId", insertable = false, updatable = false)
    @JsonBackReference("influencer")
    private InfluencerDetails influencer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "gameId", insertable = false, updatable = false)
    @JsonBackReference("game")
    private Game game;


    public InfluencerGame() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getInfluencerId() {
        return influencerId;
    }

    public void setInfluencerId(Integer influencerId) {
        this.influencerId = influencerId;
    }

    public Integer getGameId() {
        return gameId;
    }

    public void setGameId(Integer gameId) {
        this.gameId = gameId;
    }

    public Boolean getIsPrimary() {
        return isPrimary;
    }

    public void setIsPrimary(Boolean isPrimary) {
        this.isPrimary = isPrimary;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public InfluencerDetails getInfluencer() {
        return influencer;
    }

    public void setInfluencer(InfluencerDetails influencer) {
        this.influencer = influencer;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InfluencerGame)) return false;
        InfluencerGame that = (InfluencerGame) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "InfluencerGame{" +
                "id=" + id +
                '}';
    }
}