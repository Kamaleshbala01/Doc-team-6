package com.esports.platform.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity mapping for the "TransactionType" table.
 * Generated from eSportsSchema.sql
 */
@Entity
@Table(name = "TransactionType")
public class TransactionType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "typeName")
    private String typeName;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

        // ---- Relationships (added for association mapping) ----
    @OneToMany(mappedBy = "transactionType", fetch = FetchType.LAZY)
    @JsonManagedReference("transactionType")
    private List<RevenueTransaction> transactions = new ArrayList<>();


    public TransactionType() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public List<RevenueTransaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<RevenueTransaction> transactions) {
        this.transactions = transactions;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TransactionType)) return false;
        TransactionType that = (TransactionType) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "TransactionType{" +
                "id=" + id +
                '}';
    }
}