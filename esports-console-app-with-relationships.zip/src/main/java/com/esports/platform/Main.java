package com.esports.platform;

import com.esports.platform.controller.*;

import java.util.Scanner;

/**
 * Entry point. Pick a module number; the matching controller then runs
 * a full create/list/update/delete/list cycle for every entity it owns
 * using static dummy data — no further input is needed.
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("==================================================================");
        System.out.println(" Gaming & Esports Influencer Marketing Platform - Console CRUD App ");
        System.out.println("==================================================================");

        boolean running = true;
        while (running) {
            printMenu();
            System.out.print("Select module: ");
            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1": new UserController().start(); break;
                case "2": new TournamentController().start(); break;
                case "3": new TeamController().start(); break;
                case "4": new CampaignController().start(); break;
                case "5": new SocialMediaController().start(); break;
                case "6": new FinanceController().start(); break;
                case "7": new FileNotificationController().start(); break;
                case "8": new ChatController().start(); break;
                case "9": new AffiliateController().start(); break;
                case "0":
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
        sc.close();
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("--- Main Menu ---");
        System.out.println("1. User Management (Users, Roles, Profiles, Organiser/Brand/Influencer Details)");
        System.out.println("2. Tournament Management");
        System.out.println("3. Team Management");
        System.out.println("4. Campaign & Influencer Marketing");
        System.out.println("5. Social Media & Games");
        System.out.println("6. Finance (Payments, Subscriptions, Revenue)");
        System.out.println("7. Files, Notifications & Audit");
        System.out.println("8. Chat / Messaging");
        System.out.println("9. Affiliate Marketing");
        System.out.println("0. Exit");
    }
}