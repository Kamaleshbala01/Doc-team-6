# Entity relationship mapping reference

Every foreign key in `eSportsSchema.sql` (72 in total, from the `ALTER TABLE ... ADD FOREIGN KEY` statements) is now mapped as a JPA association on both sides, in addition to the plain scalar FK column that was already there.

## How each relationship is wired

**Child side (owning / holds the FK column)**
```java
@Column(name = "organizerId")
private Integer organizerId;              // <-- unchanged, existing scalar FK

@ManyToOne(fetch = FetchType.LAZY)
@JoinColumn(name = "organizerId", insertable = false, updatable = false)
@JsonBackReference("organizer")
private Users organizer;                  // <-- new: object navigation
```

**Parent side (inverse / collection)**
```java
@OneToMany(mappedBy = "organizer", fetch = FetchType.LAZY)
@JsonManagedReference("organizer")
private List<Tournament> organizedTournaments = new ArrayList<>();
```

The scalar FK field (`organizerId`) is left exactly as it was — every service/controller method from the CRUD console app still compiles and works unchanged, since they only ever call the scalar getters/setters. The object-reference field is purely additive, mapped **read-only** (`insertable = false, updatable = false`) onto the same column so JPA never tries to manage the same column twice.

`fetch = FetchType.LAZY` is set explicitly everywhere (JPA defaults `@ManyToOne`/`@OneToOne` to `EAGER`, which is rarely what you want on a graph this interconnected).

## Why named `@JsonManagedReference`/`@JsonBackReference`

Several entities have more than one relationship to the same target type — e.g. `CollaborationRequest` has both a `sender` and a `receiver`, both pointing at `Users`. Jackson pairs managed/back references by name, so every pair here uses an explicit, unique name (the child-side field name, e.g. `"sender"` / `"receiver"`) instead of the unnamed default. Without this, Jackson throws on entities like `CollaborationRequest` or `Tournament` (which has five separate relationships back to lookup tables) because it can't tell which back-reference belongs to which managed collection.

## One-to-one relationships

Five relationships are modeled as `@OneToOne` rather than `@ManyToOne`/`@OneToMany`:

| Child (owning side) | Column | Parent | Why |
|---|---|---|---|
| `UserProfile` | `userId` | `Users` | schema declares `userId integer UNIQUE NOT NULL` |
| `ConversationSettings` | `conversationId` | `Conversation` | schema declares `conversationId integer UNIQUE` |
| `TournamentOrganizerDetails` | `userId` | `Users` | one detail record per user, per the ER diagram's `0..1` cardinality |
| `BrandDetails` | `userId` | `Users` | same — `0..1` in the ER diagram |
| `InfluencerDetails` | `userId` | `Users` | same — `0..1` in the ER diagram |
| `UserPresence` | `userId` | `Users` | shared primary key — `userId` is both `@Id` and the FK |

**Note:** only `UserProfile.userId` and `ConversationSettings.conversationId` have an actual `UNIQUE` constraint in the SQL schema. The three user-details tables (`TournamentOrganizerDetails`, `BrandDetails`, `InfluencerDetails`) are mapped as one-to-one because that's the relationship the ER diagram draws (`0..1`), but the schema itself doesn't enforce it at the database level. If you want that guarantee enforced by the database, add `UNIQUE` to those three `userId` columns in `eSportsSchema.sql`.

## Many-to-many relationships

The schema expresses every many-to-many relationship through an explicit join/association table that already exists as its own first-class entity with its own CRUD service (`UserRoles`, `CampaignPlatform`, `InfluencerGame`, `TeamMember`, `TournamentType`→category isn't M:N but similar shape). Rather than collapsing these into a hidden `@ManyToMany` + `@JoinTable` (which would conflict with the fact that these tables are already managed independently, e.g. `UserRoles` has its own `createdAt` and its own CRUD controller), each one is mapped as **two `@ManyToOne` relationships** — the standard JPA pattern for a many-to-many association that carries its own attributes:

```java
// UserRoles.java
@ManyToOne @JoinColumn(name = "userId", insertable = false, updatable = false)
private Users user;

@ManyToOne @JoinColumn(name = "roleId", insertable = false, updatable = false)
private Roles role;
```
```java
// Users.java
@OneToMany(mappedBy = "user") private List<UserRoles> userRoles;
// Roles.java
@OneToMany(mappedBy = "role") private List<UserRoles> userRoles;
```

So `Users ↔ Roles` is many-to-many *through* `UserRoles`; walking `user.getUserRoles()` and then `.getRole()` on each gets you from a user to all of their roles, and it stays consistent with `UserRoles` also being independently creatable/listable/deletable via `UserService`.

The same pattern is used for:
- `Campaign ↔ SocialMediaPlatform` via `CampaignPlatform`
- `InfluencerDetails ↔ Game` via `InfluencerGame`
- `Team ↔ Users` via `TeamMember` (also carries `positionId`, so it's genuinely an association-with-attributes, not a plain M:N)

## Self-referencing relationship

`Message.replyMessageId` references `Message.id` — a message can be a reply to another message:

```java
@ManyToOne @JoinColumn(name = "replyMessageId", insertable = false, updatable = false)
@JsonBackReference("replyMessage")
private Message replyMessage;      // the message this one replies to

@OneToMany(mappedBy = "replyMessage")
@JsonManagedReference("replyMessage")
private List<Message> replies = new ArrayList<>();   // messages that reply to this one
```

## Full one-to-many / many-to-one list

Every other one of the 72 foreign keys follows the plain `@ManyToOne`/`@OneToMany` pattern shown above. See `add_relationships.py`'s `RELATIONS` list (included in this zip) for the exhaustive table of every `(child, column, parent, cardinality, child field, parent field)` tuple — it's the single source of truth this whole mapping was generated from, so it doubles as documentation.

## A note on `toString()` / `equals()` / `hashCode()`

These were left untouched — they still only reference the primary key, exactly as before. That's intentional: including relationship fields in `toString()` on a graph this interconnected (`Users` alone touches 24 other entities) would either recurse or print enormous output. Jackson's `@JsonManagedReference`/`@JsonBackReference` only protects JSON serialization, not `toString()`/`equals()`, so this is a second, independent safeguard against runaway output.

## What this doesn't do

- No cascade (`CascadeType`) or `orphanRemoval` is configured. Nothing here talks to a real database yet (the console app's services are plain in-memory `Map`s), so there's no persistence-context behavior for cascades to affect — add `CascadeType`/`orphanRemoval` deliberately per relationship once you wire these entities to a real `EntityManager`.
- No `@ManyToMany` + `@JoinTable` was added anywhere, for the reasons above.
