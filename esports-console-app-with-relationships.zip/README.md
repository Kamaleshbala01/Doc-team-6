# Esports Platform — Simple Console CRUD Application

Plain-Java (no Spring), no user input, no reflection tricks. Every entity
gets a straightforward Create → List → Update → Delete → List cycle driven
by hardcoded, static dummy data.

## What changed from the previous version

- **No Scanner-based field prompts.** Each entity's dummy records are built
  with explicit `setXxx(...)` calls using fixed literal values.
- **No auto-generated ids.** The primary key is set directly on the dummy
  object (e.g. `record1.setId(1)`) before `create()` is called; the service
  just stores whatever id the entity already has.
- **All dates are one static constant** — `STATIC_DATE = LocalDateTime.of(2026, 1, 1, 10, 0)` —
  reused everywhere a timestamp field exists, instead of `LocalDateTime.now()`.
- **No `CrudBinding`/reflection engine, no `Predicate` filtering.** Each
  interface only has the five basic operations: create, getById, getAll,
  update, delete.

## Layout

```
src/main/java/com/esports/platform/
├── Main.java                   switch/case menu — only input is the module number
├── entity/                     unchanged, your existing entity classes
├── service/
│   ├── interfaces/              one interface per module — 5 CRUD methods per entity
│   └── impl/                    one impl per interface — in-memory Map storage
└── controller/                  one controller per module
    └── run<Entity>Crud()        per entity: build 2 dummy records, create both,
                                  list, update record 1, delete record 2, list again
```

## Module → entity mapping

| Module | Entities |
|---|---|
| User | Users, Roles, UserRoles, UserProfile, TournamentOrganizerDetails, BrandDetails, InfluencerDetails |
| Tournament | TournamentCategory, TournamentType, SeedingType, Tournament, RulesCategory, TournamentRule, PrizeCategory, TournamentPrize, TournamentPackage, TournamentPayment, TournamentRegistration, TournamentRegistrationPayment, TournamentAnnouncement, TournamentFAQ |
| Team | Team, TeamPosition, TeamMember |
| Campaign | CampaignType, Campaign, CampaignPlatform, CampaignAsset, CampaignDeliverable, CollaborationRequest |
| SocialMedia | SocialMediaPlatform, SocialMediaAccount, Game, InfluencerGame, StatusMaster |
| Finance | PaymentMethod, TransactionType, RevenueTransaction, SubscriptionPlan, UserSubscription |
| FileNotification | Files, Notification, AuditLog |
| Chat | Conversation, ConversationParticipant, Message, MessageAttachment, MessageReadStatus, MessageReaction, UserPresence, ConversationPinnedMessage, ConversationSettings |
| Affiliate | AffiliateCampaign, AffiliateLink, AffiliateClick |

## Example: what one entity's CRUD method looks like

```java
private void runTournamentCategoryCrud() {
    System.out.println("\n--- TournamentCategory CRUD ---");

    TournamentCategory record1 = new TournamentCategory();
    record1.setId(1);
    record1.setCategoryName("categoryName1");
    record1.setCreatedAt(STATIC_DATE);
    tournamentService.createTournamentCategory(record1);
    System.out.println("Created: " + record1);

    TournamentCategory record2 = new TournamentCategory();
    record2.setId(2);
    record2.setCategoryName("categoryName2");
    record2.setCreatedAt(STATIC_DATE);
    tournamentService.createTournamentCategory(record2);
    System.out.println("Created: " + record2);

    System.out.println("All TournamentCategory after create:");
    tournamentService.getAllTournamentCategorys().forEach(System.out::println);

    TournamentCategory updated = new TournamentCategory();
    updated.setCategoryName("categoryName9");
    updated.setCreatedAt(STATIC_DATE);
    tournamentService.updateTournamentCategory(record1.getId(), updated);
    System.out.println("Updated record 1: " + updated);

    tournamentService.deleteTournamentCategory(record2.getId());
    System.out.println("Deleted record 2 (id=" + record2.getId() + ")");

    System.out.println("All TournamentCategory after update & delete:");
    tournamentService.getAllTournamentCategorys().forEach(System.out::println);
}
```

Every one of the 55 entities has a method built the same way — only the
field names/types and dummy values differ. Foreign-key-looking `Integer`/
`Long` fields get `1`/`2` as placeholder values, `String` fields get
`"<fieldName><variant>"`, `Boolean` gets `true`/`false`, `BigDecimal` gets
`"100.00"`/`"200.00"`, and every timestamp field gets `STATIC_DATE`.

## Running the app

Requires JDK 17+ and Maven (for the one dependency, `jakarta.persistence-api`,
which only supplies the `@Entity`/`@Id`/`@Column`/`@Table` annotations
already on your entity classes — no database is involved).

```bash
mvn compile exec:java
```

or

```bash
mvn package
java -jar target/esports-console-app.jar
```

Pick a module number (1–9) and its controller runs straight through every
entity's CRUD cycle automatically — the only input the app ever asks for
is that one menu number, or `0` to exit.

**No Maven?** Compile directly against a `jakarta.persistence-api-3.1.0.jar`
you've downloaded yourself:

```bash
javac -cp jakarta.persistence-api-3.1.0.jar -d out $(find src -name "*.java")
java -cp "out:jakarta.persistence-api-3.1.0.jar" com.esports.platform.Main
```

## Notes

- Storage is in-memory and resets each run — swap the `Map` fields in each
  `*ServiceImpl` for a real repository/DAO later without touching the
  interfaces or controllers.
- `update` replaces the stored object entirely (the id is carried over from
  the id you pass in); it isn't a partial patch.
- Since ids are static per entity (`1` and `2` in every `run<Entity>Crud()`
  method), re-running `start()` on the same controller instance a second
  time would try to recreate ids that already exist in that Map — each
  controller is only invoked once per `Main` run, so this doesn't come up
  in normal use, but it's worth knowing if you extend this yourself.
