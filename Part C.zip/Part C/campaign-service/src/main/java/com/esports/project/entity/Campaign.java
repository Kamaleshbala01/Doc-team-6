package com.esports.project.entity;


import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.esports.project.enums.CampaignType;
import com.esports.project.enums.StatusMaster;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.OneToMany;

import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "campaigns")
public class Campaign {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private CampaignType campaignType;

    private String campaignName;

    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private String description;

    private BigDecimal totalBudget;
    private BigDecimal influencerCost;
    private BigDecimal additionalExpenses;

    @Enumerated(EnumType.STRING)
    private StatusMaster status;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    private String brandId;


    private String file_id;



    private String affiliateLinkID;

    // colaburation request

    @OneToMany(mappedBy = "campaign",fetch = FetchType.LAZY)
    @JsonManagedReference(value = "Collaboration-request")
    private List<CollaborationRequest> CollaborationRequests;
    
    

    public Campaign() {
		super();
	}

	public Campaign(String id, CampaignType campaignType, String campaignName, LocalDateTime startDate,
			LocalDateTime endDate, String description, BigDecimal totalBudget, BigDecimal influencerCost,
			BigDecimal additionalExpenses, StatusMaster status, LocalDateTime createdAt, LocalDateTime updatedAt,
			String brandId, String file_id, String affiliateLinkID, List<CollaborationRequest> collaborationRequests) {
		super();
		this.id = id;
		this.campaignType = campaignType;
		this.campaignName = campaignName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.description = description;
		this.totalBudget = totalBudget;
		this.influencerCost = influencerCost;
		this.additionalExpenses = additionalExpenses;
		this.status = status;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.brandId = brandId;
		this.file_id = file_id;
		this.affiliateLinkID = affiliateLinkID;
		CollaborationRequests = collaborationRequests;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public CampaignType getCampaignType() {
		return campaignType;
	}

	public void setCampaignType(CampaignType campaignType) {
		this.campaignType = campaignType;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getTotalBudget() {
		return totalBudget;
	}

	public void setTotalBudget(BigDecimal totalBudget) {
		this.totalBudget = totalBudget;
	}

	public BigDecimal getInfluencerCost() {
		return influencerCost;
	}

	public void setInfluencerCost(BigDecimal influencerCost) {
		this.influencerCost = influencerCost;
	}

	public BigDecimal getAdditionalExpenses() {
		return additionalExpenses;
	}

	public void setAdditionalExpenses(BigDecimal additionalExpenses) {
		this.additionalExpenses = additionalExpenses;
	}

	public StatusMaster getStatus() {
		return status;
	}

	public void setStatus(StatusMaster status) {
		this.status = status;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getBrandId() {
		return brandId;
	}

	public void setBrandId(String brandId) {
		this.brandId = brandId;
	}

	public String getFile_id() {
		return file_id;
	}

	public void setFile_id(String file_id) {
		this.file_id = file_id;
	}

	public String getAffiliateLinkID() {
		return affiliateLinkID;
	}

	public void setAffiliateLinkID(String affiliateLinkID) {
		this.affiliateLinkID = affiliateLinkID;
	}

	public List<CollaborationRequest> getCollaborationRequests() {
		return CollaborationRequests;
	}

	public void setCollaborationRequests(List<CollaborationRequest> collaborationRequests) {
		CollaborationRequests = collaborationRequests;
	}

	
}
